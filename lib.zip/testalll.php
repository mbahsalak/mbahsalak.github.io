<?php
/**
 * public/test-all-api.php
 * RouterOS API Comprehensive Tester — Tests ALL methods
 * Works with RouterOS 6.x & 7.x
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Jakarta');

// Load RouterOS API class
$apiFile = dirname(__DIR__) . '/routeros_api.class7.php';
if (!file_exists($apiFile)) {
    die('<h2 style="color:red">❌ File core/routeros_api.class.php tidak ditemukan!</h2>');
}
require_once $apiFile;

// =====================================================================
// TEST RUNNER
// =====================================================================
class APITester
{
    private RouterosAPI $api;
    private array $results = [];
    private int $pass = 0;
    private int $fail = 0;
    private int $skip = 0;
    private int $warn = 0;
    private array $testItem = []; // track test items for cleanup
    private float $startTime;
    private bool $isROS7 = false;

    public function __construct(RouterosAPI $api)
    {
        $this->api = $api;
        $this->startTime = microtime(true);
    }

    /**
     * Run a single test
     */
    public function test(string $category, string $name, callable $fn): void
    {
        $start = microtime(true);
        $status = 'pass';
        $message = '';
        $data = null;

        try {
            $result = $fn();
            if ($result === 'SKIP') {
                $status = 'skip';
                $message = 'Skipped';
            } elseif ($result === false) {
                $status = 'fail';
                $message = 'Returned false';
                $err = $this->api->getLastError();
                if ($err) $message .= " — {$err}";
            } elseif (is_string($result) && str_starts_with($result, 'WARN:')) {
                $status = 'warn';
                $message = substr($result, 5);
            } elseif (is_string($result) && str_starts_with($result, 'SKIP:')) {
                $status = 'skip';
                $message = substr($result, 5);
            } else {
                $message = is_array($result) ? json_encode($result, JSON_UNESCAPED_UNICODE) : (string)$result;
                if (strlen($message) > 300) $message = substr($message, 0, 300) . '...';
                $data = $result;
            }
        } catch (\Throwable $e) {
            $status = 'fail';
            $message = 'Exception: ' . $e->getMessage();
        }

        $elapsed = round((microtime(true) - $start) * 1000, 1);

        match ($status) {
            'pass' => $this->pass++,
            'fail' => $this->fail++,
            'skip' => $this->skip++,
            'warn' => $this->warn++,
        };

        $this->results[$category][] = [
            'name' => $name,
            'status' => $status,
            'message' => $message,
            'time_ms' => $elapsed,
            'data' => $data,
        ];
    }

    /**
     * Run all tests
     */
    public function runAll(): void
    {
        $this->testConnection();
        $this->testVersionDetection();
        $this->testSystemInfo();
        $this->testNetwork();
        $this->testWireless();
        $this->testHotspotPPP();
        $this->testIPv6();
        $this->testFirewall();
        $this->testQueue();
        $this->testDNS();
        $this->testPPPoEExtended();
        $this->testVlanBridge();
        $this->testRouting();
        $this->testTools();
        $this->testCRUDOperations();
        $this->testBatchOperations();
        $this->testQueryBuilders();
        $this->testAdvancedFeatures();
        $this->testUtilityFunctions();
        $this->testStatistics();

        // RouterOS 7 specific
        if ($this->api->isRouterOS7()) {
            $this->isROS7 = true;
            $this->testWireGuard();
            $this->testContainer();
            $this->testBGPOSPF();
            $this->testKidControl();
            $this->testUserManager();
            $this->testBFD();
            $this->testMPLSVPLS();
            $this->testRestAPI();
        }
    }

    // =====================================================================
    // TEST: CONNECTION & AUTH
    // =====================================================================
    private function testConnection(): void
    {
        $cat = '🔌 Connection & Auth';

        $this->test($cat, 'isConnected()', fn() =>
            $this->api->isConnected() ? 'Connected' : 'Not connected'
        );

        $this->test($cat, 'isAuthenticated()', fn() =>
            $this->api->isAuthenticated() ? 'Authenticated' : 'Not authenticated'
        );

        $this->test($cat, 'getStats() — connection info', fn() =>
            $this->api->getStats()
        );
    }

    // =====================================================================
    // TEST: VERSION DETECTION
    // =====================================================================
    private function testVersionDetection(): void
    {
        $cat = '🏷️ Version Detection';

        $this->test($cat, 'getRouterVersion()', fn() =>
            $this->api->getRouterVersion() ?? 'SKIP: Not detected'
        );

        $this->test($cat, 'getMajorVersion()', fn() =>
            (string)($this->api->getMajorVersion() ?? 'null')
        );

        $this->test($cat, 'isRouterOS7()', fn() =>
            $this->api->isRouterOS7() ? 'Yes (ROS7)' : 'No (ROS6)'
        );

        $this->test($cat, 'isRouterOS6()', fn() =>
            $this->api->isRouterOS6() ? 'Yes (ROS6)' : 'No (ROS7+)'
        );
    }

    // =====================================================================
    // TEST: SYSTEM INFO
    // =====================================================================
    private function testSystemInfo(): void
    {
        $cat = '🖥️ System Info';

        $this->test($cat, 'getIdentity()', fn() =>
            $this->api->getIdentity()
        );

        $this->test($cat, 'getVersion()', fn() =>
            $this->api->getVersion()
        );

        $this->test($cat, 'getBoardName()', fn() =>
            $this->api->getBoardName()
        );

        $this->test($cat, 'getCpuLoad()', fn() =>
            $this->api->getCpuLoad() !== false ? $this->api->getCpuLoad() . '%' : false
        );

        $this->test($cat, 'getUptime()', fn() =>
            $this->api->getUptime()
        );

        $this->test($cat, 'getResource()', fn() =>
            $this->api->getResource()
        );

        $this->test($cat, 'getHealth()', fn() =>
            $this->api->getHealth() ?: 'WARN: No health data (may not be supported)'
        );

        $this->test($cat, 'getHealthValue("voltage")', fn() =>
            (string)($this->api->getHealthValue('voltage', 'N/A'))
        );

        $this->test($cat, 'getHealthValue("temperature")', fn() =>
            (string)($this->api->getHealthValue('temperature', 'N/A'))
        );

        $this->test($cat, 'getClock()', fn() =>
            $this->api->getClock()
        );

        $this->test($cat, 'getLog(10)', fn() =>
            $this->api->getLog(10)
        );

        $this->test($cat, 'getScheduler()', fn() =>
            $this->api->getScheduler() ?? []
        );

        $this->test($cat, 'getScripts()', fn() =>
            $this->api->getScripts() ?? []
        );
    }

    // =====================================================================
    // TEST: NETWORK
    // =====================================================================
    private function testNetwork(): void
    {
        $cat = '🌐 Network';

        $this->test($cat, 'getInterfaces()', fn() =>
            $this->api->getInterfaces()
        );

        $this->test($cat, 'getIpAddresses()', fn() =>
            $this->api->getIpAddresses()
        );

        $this->test($cat, 'getDhcpLeases()', fn() =>
            $this->api->getDhcpLeases() ?? []
        );

        $this->test($cat, 'getActiveDhcpLeases()', fn() =>
            $this->api->getActiveDhcpLeases() ?? []
        );
    }

    // =====================================================================
    // TEST: WIRELESS
    // =====================================================================
    private function testWireless(): void
    {
        $cat = '📡 Wireless';

        $this->test($cat, 'getWirelessInterfaces()', fn() =>
            $this->api->getWirelessInterfaces() ?? 'SKIP: No wireless'
        );

        $this->test($cat, 'getWirelessClients()', fn() =>
            $this->api->getWirelessClients() ?? 'SKIP: No wireless'
        );
    }

    // =====================================================================
    // TEST: HOTSPOT & PPP
    // =====================================================================
    private function testHotspotPPP(): void
    {
        $cat = '🔐 Hotspot & PPP';

        $this->test($cat, 'getHotspotUsers()', fn() =>
            $this->api->getHotspotUsers() ?? 'SKIP: No hotspot'
        );

        $this->test($cat, 'getPppActive()', fn() =>
            $this->api->getPppActive() ?? []
        );
    }

    // =====================================================================
    // TEST: IPv6
    // =====================================================================
    private function testIPv6(): void
    {
        $cat = '🌍 IPv6';

        $this->test($cat, 'getIpv6Addresses()', fn() =>
            $this->api->getIpv6Addresses() ?? []
        );

        $this->test($cat, 'getIpv6Routes()', fn() =>
            $this->api->getIpv6Routes() ?? []
        );

        $this->test($cat, 'getIpv6Neighbors()', fn() =>
            $this->api->getIpv6Neighbors() ?? []
        );

        $this->test($cat, 'getIpv6DhcpClient()', fn() =>
            $this->api->getIpv6DhcpClient() ?? []
        );

        $this->test($cat, 'getIpv6DhcpServer()', fn() =>
            $this->api->getIpv6DhcpServer() ?? []
        );

        $this->test($cat, 'getIpv6DhcpLeases()', fn() =>
            $this->api->getIpv6DhcpLeases() ?? []
        );

        $this->test($cat, 'getIpv6Nd()', fn() =>
            $this->api->getIpv6Nd() ?? []
        );

        $this->test($cat, 'getIpv6NdPrefix()', fn() =>
            $this->api->getIpv6NdPrefix() ?? []
        );

        $this->test($cat, 'getIpv6Pool()', fn() =>
            $this->api->getIpv6Pool() ?? []
        );

        $this->test($cat, 'getIpv6FirewallFilter()', fn() =>
            $this->api->getIpv6FirewallFilter() ?? []
        );

        $this->test($cat, 'getIpv6FirewallNat()', fn() =>
            $this->api->getIpv6FirewallNat() ?? []
        );

        $this->test($cat, 'getIpv6FirewallMangle()', fn() =>
            $this->api->getIpv6FirewallMangle() ?? []
        );
    }

    // =====================================================================
    // TEST: FIREWALL
    // =====================================================================
    private function testFirewall(): void
    {
        $cat = '🛡️ Firewall';

        $this->test($cat, 'getFirewallRules("filter")', fn() =>
            $this->api->getFirewallRules('filter') ?? []
        );

        $this->test($cat, 'getFirewallRules("nat")', fn() =>
            $this->api->getFirewallRules('nat') ?? []
        );

        $this->test($cat, 'getFirewallRules("mangle")', fn() =>
            $this->api->getFirewallRules('mangle') ?? []
        );

        $this->test($cat, 'getFirewallRules("raw")', fn() =>
            $this->api->getFirewallRules('raw') ?? []
        );

        $this->test($cat, 'getNatRules()', fn() =>
            $this->api->getNatRules() ?? []
        );

        $this->test($cat, 'count("/ip/firewall/filter")', fn() =>
            (string)($this->api->count('/ip/firewall/filter') ?? 'false')
        );
    }

    // =====================================================================
    // TEST: QUEUE
    // =====================================================================
    private function testQueue(): void
    {
        $cat = '📊 Queue';

        $this->test($cat, 'getSimpleQueues()', fn() =>
            $this->api->getSimpleQueues() ?? []
        );

        $this->test($cat, 'getQueueTree()', fn() =>
            $this->api->getQueueTree() ?? []
        );
    }

    // =====================================================================
    // TEST: DNS
    // =====================================================================
    private function testDNS(): void
    {
        $cat = '🔍 DNS';

        $this->test($cat, 'getDnsCache()', fn() =>
            $this->api->getDnsCache() ?? 'WARN: May require DNS cache enabled'
        );
    }

    // =====================================================================
    // TEST: PPPoE EXTENDED
    // =====================================================================
    private function testPPPoEExtended(): void
    {
        $cat = '🔗 PPPoE Extended';

        $this->test($cat, 'getPppSecrets()', fn() =>
            $this->api->getPppSecrets() ?? []
        );

        $this->test($cat, 'getPppProfiles()', fn() =>
            $this->api->getPppProfiles() ?? []
        );

        $this->test($cat, 'getPppoeServerInterfaces()', fn() =>
            $this->api->getPppoeServerInterfaces() ?? 'SKIP: No PPPoE server'
        );

        $this->test($cat, 'getPppoeClients()', fn() =>
            $this->api->getPppoeClients() ?? []
        );
    }

    // =====================================================================
    // TEST: VLAN & BRIDGE
    // =====================================================================
    private function testVlanBridge(): void
    {
        $cat = '🌉 VLAN & Bridge';

        $this->test($cat, 'getBridges()', fn() =>
            $this->api->getBridges() ?? []
        );

        $this->test($cat, 'getBridgePorts()', fn() =>
            $this->api->getBridgePorts() ?? []
        );

        $this->test($cat, 'getBridgeVlans()', fn() =>
            $this->api->getBridgeVlans() ?? []
        );
    }

    // =====================================================================
    // TEST: ROUTING
    // =====================================================================
    private function testRouting(): void
    {
        $cat = '🗺️ Routing';

        $this->test($cat, 'getRoutingTables()', fn() =>
            $this->api->getRoutingTables() ?? 'SKIP: ROS7 only'
        );

        $this->test($cat, 'getRoutes()', fn() =>
            $this->api->getRoutes() ?? []
        );

        $this->test($cat, 'getRoutes("main")', fn() =>
            $this->api->getRoutes('main') ?? []
        );
    }

    // =====================================================================
    // TEST: TOOLS
    // =====================================================================
    private function testTools(): void
    {
        $cat = '🔧 Tools';

        $this->test($cat, 'ping("8.8.8.8", count=2)', fn() =>
            $this->api->ping('8.8.8.8', 2) ?: 'WARN: Ping may timeout'
        );

        // Skip traceroute — too slow
        $this->test($cat, 'traceroute()', fn() => 'SKIP: Too slow for test');

        $this->test($cat, 'exportConfig("test_export.rsc")', fn() =>
            $this->api->exportConfig('test_export.rsc') ? 'Exported' : 'WARN: May need permissions'
        );
    }

    // =====================================================================
    // TEST: CRUD OPERATIONS (safe — create then delete)
    // =====================================================================
    private function testCRUDOperations(): void
    {
        $cat = '✏️ CRUD Operations';
        $testId = null;

        // ADD — Create test address list
        $this->test($cat, 'add("/ip/firewall/address-list") — CREATE', function () use (&$testId) {
            $result = $this->api->add('/ip/firewall/address-list', [
                'list' => 'test_api_list',
                'address' => '192.168.255.1',
                'comment' => 'API Test - Safe to delete',
            ]);
            if ($result && is_string($result)) {
                $testId = $result;
                return "Created .id = {$result}";
            }
            return $result;
        });

        // GET ONE — Read the created item
        $this->test($cat, 'getOne() — READ created item', function () use (&$testId) {
            if (!$testId) return 'SKIP: No test ID from add';
            return $this->api->getOne('/ip/firewall/address-list', $testId);
        });

        // GET BY NAME
        $this->test($cat, 'getByName("/interface", "ether1")', fn() =>
            $this->api->getByName('/interface', 'ether1') ?? 'SKIP: ether1 not found'
        );

        // SET — Update the item
        $this->test($cat, 'set() — UPDATE item', function () use (&$testId) {
            if (!$testId) return 'SKIP: No test ID';
            $ok = $this->api->set('/ip/firewall/address-list', $testId, [
                'comment' => 'API Test - UPDATED',
                'address' => '192.168.255.2',
            ]);
            return $ok ? 'Updated' : false;
        });

        // COMMENT
        $this->test($cat, 'comment() — Set comment', function () use (&$testId) {
            if (!$testId) return 'SKIP: No test ID';
            $ok = $this->api->comment('/ip/firewall/address-list', $testId, 'API Test - COMMENTED');
            return $ok ? 'Commented' : false;
        });

        // FIND
        $this->test($cat, 'find() — Find by query', fn() =>
            $this->api->find('/ip/firewall/address-list', ['?list' => 'test_api_list'])
        );

        // FIND ONE
        $this->test($cat, 'findOne() — Find first match', fn() =>
            $this->api->findOne('/ip/firewall/address-list', ['?list' => 'test_api_list'])
        );

        // COUNT
        $this->test($cat, 'count() — Count matching', fn() =>
            (string)($this->api->count('/ip/firewall/address-list', ['?list' => 'test_api_list']) ?? 'false')
        );

        // REMOVE — Clean up
        $this->test($cat, 'remove() — DELETE test item', function () use (&$testId) {
            if (!$testId) return 'SKIP: No test ID';
            $ok = $this->api->remove('/ip/firewall/address-list', $testId);
            $testId = null;
            return $ok ? 'Removed' : false;
        });

        // RESOLVE ID
        $this->test($cat, 'resolveId("/interface", "ether1")', fn() =>
            $this->api->resolveId('/interface', 'ether1') ?? 'SKIP: ether1 not found'
        );

        // PRINT ALL (legacy alias)
        $this->test($cat, 'printAll("/interface") — legacy alias', fn() =>
            $this->api->printAll('/interface') ?? []
        );
    }

    // =====================================================================
    // TEST: BATCH OPERATIONS
    // =====================================================================
    private function testBatchOperations(): void
    {
        $cat = '📦 Batch Operations';
        $createdIds = [];

        // ADD MANY
        $this->test($cat, 'addMany() — Add 3 items', function () use (&$createdIds) {
            $items = [
                ['list' => 'test_batch', 'address' => '10.0.0.1', 'comment' => 'batch1'],
                ['list' => 'test_batch', 'address' => '10.0.0.2', 'comment' => 'batch2'],
                ['list' => 'test_batch', 'address' => '10.0.0.3', 'comment' => 'batch3'],
            ];
            $results = $this->api->addMany('/ip/firewall/address-list', $items);
            foreach ($results as $r) {
                if ($r && is_string($r)) $createdIds[] = $r;
            }
            return 'Created: ' . count(array_filter($results)) . '/3 items';
        });

        // SET MANY
        $this->test($cat, 'setMany() — Update batch items', function () use (&$createdIds) {
            if (empty($createdIds)) return 'SKIP: No IDs from addMany';
            $updates = [];
            foreach ($createdIds as $id) {
                $updates[] = ['id' => $id, 'params' => ['comment' => 'batch-updated']];
            }
            $results = $this->api->setMany('/ip/firewall/address-list', $updates);
            return 'Updated: ' . count(array_filter($results)) . '/' . count($createdIds);
        });

        // REMOVE MANY — cleanup
        $this->test($cat, 'removeMany() — Delete batch items', function () use (&$createdIds) {
            if (empty($createdIds)) return 'SKIP: No IDs to remove';
            $results = $this->api->removeMany('/ip/firewall/address-list', $createdIds);
            $count = count(array_filter($results));
            $createdIds = [];
            return "Removed: {$count} items";
        });
    }

    // =====================================================================
    // TEST: QUERY BUILDERS
    // =====================================================================
    private function testQueryBuilders(): void
    {
        $cat = '🔎 Query Builders';

        $this->test($cat, 'query("name", "ether1", "=")', fn() =>
            RouterosAPI::query('name', 'ether1', '=')
        );

        $this->test($cat, 'query("bytes", "1000", ">")', fn() =>
            RouterosAPI::query('bytes', '1000', '>')
        );

        $this->test($cat, 'query("disabled", "", "")', fn() =>
            RouterosAPI::query('disabled', '', '')
        );

        $this->test($cat, 'query("type", "ether", "!=")', fn() =>
            RouterosAPI::query('type', 'ether', '!=')
        );

        $this->test($cat, 'buildQuery() — AND conditions', fn() =>
            RouterosAPI::buildQuery([
                ['chain', 'forward'],
                ['action', 'accept'],
            ], 'and')
        );

        $this->test($cat, 'buildQuery() — OR conditions', fn() =>
            RouterosAPI::buildQuery([
                ['src-address', '192.168.1.0/24'],
                ['src-address', '10.0.0.0/8'],
            ], 'or')
        );
    }

    // =====================================================================
    // TEST: ADVANCED FEATURES
    // =====================================================================
    private function testAdvancedFeatures(): void
    {
        $cat = '⚡ Advanced Features';

        // readGenerator
        $this->test($cat, 'readGenerator("/interface/print")', function () {
            $count = 0;
            foreach ($this->api->readGenerator('/interface/print') as $item) {
                $count++;
                if ($count >= 3) break; // Only read first 3
            }
            return "Read {$count} items via generator";
        });

        // execScript
        $this->test($cat, 'execScript() — Run raw ROS command', fn() =>
            $this->api->execScript(':put "API test script executed"')
                ? 'Script executed'
                : 'WARN: Script execution failed'
        );

        // listen + cancel (quick test)
        $this->test($cat, 'listen() + cancel() — Real-time subscribe', function () {
            $tag = 'test_listen_' . uniqid();
            $ok = $this->api->listen('/interface', [], $tag);
            if (!$ok) return false;

            // Read 1 response then cancel
            usleep(200000); // 200ms
            $this->api->cancel($tag);
            return "Listened and cancelled (tag: {$tag})";
        });

        // get with proplist
        $this->test($cat, 'get() with proplist — Selective fields', fn() =>
            $this->api->get('/interface', [], '.id,name,type')
        );

        // get with detail
        $this->test($cat, 'get() with detail=true', fn() =>
            $this->api->get('/interface', [], null, true)
        );
    }

    // =====================================================================
    // TEST: UTILITY FUNCTIONS (static)
    // =====================================================================
    private function testUtilityFunctions(): void
    {
        $cat = '🧮 Utility Functions';

        $this->test($cat, 'timeToSeconds("1d2h30m15s")', fn() =>
            (string)RouterosAPI::timeToSeconds('1d2h30m15s') . ' seconds (expect 95415)'
        );

        $this->test($cat, 'timeToSeconds("3w2d")', fn() =>
            (string)RouterosAPI::timeToSeconds('3w2d') . ' seconds (expect 1987200)'
        );

        $this->test($cat, 'timeToSeconds("45m")', fn() =>
            (string)RouterosAPI::timeToSeconds('45m') . ' seconds (expect 2700)'
        );

        $this->test($cat, 'formatBytes(1073741824)', fn() =>
            RouterosAPI::formatBytes(1073741824) . ' (expect 1 GB)'
        );

        $this->test($cat, 'formatBytes(1536)', fn() =>
            RouterosAPI::formatBytes(1536) . ' (expect 1.5 KB)'
        );

        $this->test($cat, 'formatBps(100000000)', fn() =>
            RouterosAPI::formatBps(100000000) . ' (expect 100 Mbps)'
        );

        $this->test($cat, 'formatBps(1500)', fn() =>
            RouterosAPI::formatBps(1500) . ' (expect 1.5 Kbps)'
        );

        $this->test($cat, 'parseSize("10M")', fn() =>
            (string)RouterosAPI::parseSize('10M') . ' bytes (expect 10485760)'
        );

        $this->test($cat, 'parseSize("512K")', fn() =>
            (string)RouterosAPI::parseSize('512K') . ' bytes (expect 524288)'
        );

        $this->test($cat, 'parseSize("1G")', fn() =>
            (string)RouterosAPI::parseSize('1G') . ' bytes (expect 1073741824)'
        );

        $this->test($cat, 'parseSize("1024")', fn() =>
            (string)RouterosAPI::parseSize('1024') . ' bytes (expect 1024)'
        );
    }

    // =====================================================================
    // TEST: STATISTICS & DEBUG
    // =====================================================================
    private function testStatistics(): void
    {
        $cat = '📈 Statistics & Debug';

        $this->test($cat, 'getStats()', fn() =>
            $this->api->getStats()
        );

        $this->test($cat, 'getLastError()', fn() =>
            $this->api->getLastError() ?? 'null (no error)'
        );

        $this->test($cat, 'hasError()', fn() =>
            $this->api->hasError() ? 'true' : 'false'
        );

        $this->test($cat, 'getLastResponseType()', fn() =>
            $this->api->getLastResponseType() ?? 'null'
        );

        $this->test($cat, 'getLastResponse() — item count', fn() =>
            (string)count($this->api->getLastResponse()) . ' sentences'
        );

        $this->test($cat, 'getDebugLog() — entry count', fn() =>
            (string)count($this->api->getDebugLog()) . ' entries'
        );

        $this->test($cat, 'clearDebugLog()', function () {
            $this->api->clearDebugLog();
            return 'Cleared. Remaining: ' . count($this->api->getDebugLog()) . ' entries';
        });
    }

    // =====================================================================
    // TEST: WIREGUARD (RouterOS 7+)
    // =====================================================================
    private function testWireGuard(): void
    {
        $cat = '🔒 WireGuard (ROS7)';

        $this->test($cat, 'getWireguardInterfaces()', fn() =>
            $this->api->getWireguardInterfaces() ?? []
        );

        $this->test($cat, 'getWireguardPeers()', fn() =>
            $this->api->getWireguardPeers() ?? []
        );
    }

    // =====================================================================
    // TEST: CONTAINER (RouterOS 7.4+)
    // =====================================================================
    private function testContainer(): void
    {
        $cat = '🐳 Container (ROS7)';

        $this->test($cat, 'getContainers()', fn() =>
            $this->api->getContainers() ?? 'SKIP: Container may not be enabled'
        );

        $this->test($cat, 'getContainerConfig()', fn() =>
            $this->api->getContainerConfig() ?? []
        );

        $this->test($cat, 'getContainerMounts()', fn() =>
            $this->api->getContainerMounts() ?? []
        );

        $this->test($cat, 'getContainerEnvs()', fn() =>
            $this->api->getContainerEnvs() ?? []
        );
    }

    // =====================================================================
    // TEST: BGP & OSPF (RouterOS 7)
    // =====================================================================
    private function testBGPOSPF(): void
    {
        $cat = '🔀 BGP & OSPF (ROS7)';

        // BGP
        $this->test($cat, 'getBgpConnections()', fn() =>
            $this->api->getBgpConnections() ?? []
        );

        $this->test($cat, 'getBgpTemplates()', fn() =>
            $this->api->getBgpTemplates() ?? []
        );

        $this->test($cat, 'getBgpInstances()', fn() =>
            $this->api->getBgpInstances() ?? []
        );

        $this->test($cat, 'getBgpSessions()', fn() =>
            $this->api->getBgpSessions() ?? []
        );

        // OSPF
        $this->test($cat, 'getOspfInstances()', fn() =>
            $this->api->getOspfInstances() ?? []
        );

        $this->test($cat, 'getOspfAreas()', fn() =>
            $this->api->getOspfAreas() ?? []
        );

        $this->test($cat, 'getOspfInterfaceTemplates()', fn() =>
            $this->api->getOspfInterfaceTemplates() ?? []
        );

        $this->test($cat, 'getOspfNeighbors()', fn() =>
            $this->api->getOspfNeighbors() ?? []
        );

        $this->test($cat, 'getOspfLsa()', fn() =>
            $this->api->getOspfLsa() ?? []
        );
    }

    // =====================================================================
    // TEST: KID CONTROL (RouterOS 7+)
    // =====================================================================
    private function testKidControl(): void
    {
        $cat = '👨‍👩‍👧 Kid Control (ROS7)';

        $this->test($cat, 'getKidControlProfiles()', fn() =>
            $this->api->getKidControlProfiles() ?? 'SKIP: Kid control may not be available'
        );

        $this->test($cat, 'getKidControlDevices()', fn() =>
            $this->api->getKidControlDevices() ?? []
        );
    }

    // =====================================================================
    // TEST: USER MANAGER (RouterOS 7)
    // =====================================================================
    private function testUserManager(): void
    {
        $cat = '👥 User Manager v7 (ROS7)';

        $this->test($cat, 'getUsermanUsers()', fn() =>
            $this->api->getUsermanUsers() ?? 'SKIP: Userman may not be installed'
        );

        $this->test($cat, 'getUsermanProfiles()', fn() =>
            $this->api->getUsermanProfiles() ?? []
        );

        $this->test($cat, 'getUsermanLimitations()', fn() =>
            $this->api->getUsermanLimitations() ?? []
        );

        $this->test($cat, 'getUsermanRouters()', fn() =>
            $this->api->getUsermanRouters() ?? []
        );

        $this->test($cat, 'getUsermanSessions()', fn() =>
            $this->api->getUsermanSessions() ?? []
        );
    }

    // =====================================================================
    // TEST: BFD (RouterOS 7)
    // =====================================================================
    private function testBFD(): void
    {
        $cat = '💓 BFD (ROS7)';

        $this->test($cat, 'getBfdSessions()', fn() =>
            $this->api->getBfdSessions() ?? []
        );

        $this->test($cat, 'getBfdConfiguration()', fn() =>
            $this->api->getBfdConfiguration() ?? 'SKIP: BFD may not be available'
        );
    }

    // =====================================================================
    // TEST: MPLS / VPLS
    // =====================================================================
    private function testMPLSVPLS(): void
    {
        $cat = '🏗️ MPLS & VPLS (ROS7)';

        $this->test($cat, 'getMplsInterfaces()', fn() =>
            $this->api->getMplsInterfaces() ?? 'SKIP: MPLS may not be available'
        );

        $this->test($cat, 'getVplsInterfaces()', fn() =>
            $this->api->getVplsInterfaces() ?? []
        );
    }

    // =====================================================================
    // TEST: REST API (RouterOS 7.1+)
    // =====================================================================
    private function testRestAPI(): void
    {
        $cat = '🌐 REST API (ROS7)';

        $this->test($cat, 'restGet("/rest/system/resource")', fn() =>
            $this->api->restGet('/rest/system/resource') ?? 'WARN: REST API may not be enabled'
        );

        $this->test($cat, 'restGet("/rest/interface")', fn() =>
            $this->api->restGet('/rest/interface') ?? 'WARN: REST API may not be enabled'
        );
    }

    // =====================================================================
    // GET RESULTS
    // =====================================================================
    public function getResults(): array { return $this->results; }
    public function getPass(): int { return $this->pass; }
    public function getFail(): int { return $this->fail; }
    public function getSkip(): int { return $this->skip; }
    public function getWarn(): int { return $this->warn; }
    public function getTotal(): int { return $this->pass + $this->fail + $this->skip + $this->warn; }
    public function getElapsedTime(): float { return round(microtime(true) - $this->startTime, 2); }
    public function isROS7(): bool { return $this->isROS7; }
}

// =====================================================================
// PROCESS REQUEST (DATABASE VERSION)
// =====================================================================
require_once dirname(__DIR__) . '/database.php'; // Load PDO

$tested = false;
$tester = null;
$connectError = null;
$selectedRouter = null;

// Ambil semua router aktif dari database
$stmt = $pdo->query("SELECT * FROM routers WHERE status = 'active' ORDER BY nama_router ASC");
$routers = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['router_id'])) {
    // Ambil detail router yang dipilih
    $stmt = $pdo->prepare("SELECT * FROM routers WHERE id = ?");
    $stmt->execute([$_POST['router_id']]);
    $selectedRouter = $stmt->fetch();

    if ($selectedRouter) {
        $api = new RouterosAPI();
        
        // Koneksi menggunakan data dari database
        if ($api->connect(
            $selectedRouter['ip_address'], 
            $selectedRouter['api_user'], 
            $selectedRouter['api_password'], 
            (int)$selectedRouter['api_port']
        )) {
            $tester = new APITester($api);
            $tester->runAll();
            $tested = true;
            $api->disconnect();
        } else {
            $connectError = "Gagal koneksi ke {$selectedRouter['nama_router']} ({$selectedRouter['ip_address']}): " . $api->getLastError();
        }
    } else {
        $connectError = "Router tidak ditemukan di database.";
    }
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RouterOS API — Full Test Suite</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: #0a0e1a;
            color: #e2e8f0;
            min-height: 100vh;
            padding: 16px;
        }
        .container { max-width: 1000px; margin: 0 auto; }

        h1 {
            text-align: center;
            font-size: 1.6em;
            margin-bottom: 4px;
            background: linear-gradient(135deg, #38bdf8, #a78bfa, #f472b6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .subtitle {
            text-align: center;
            color: #64748b;
            margin-bottom: 20px;
            font-size: 0.85em;
        }

        .card {
            background: #111827;
            border: 1px solid #1e293b;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 16px;
        }
        .card h2 {
            font-size: 1em;
            margin-bottom: 14px;
            color: #38bdf8;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr;
            gap: 10px;
        }
        .form-group { display: flex; flex-direction: column; gap: 4px; }
        label { font-size: 0.78em; color: #94a3b8; font-weight: 500; }
        input {
            padding: 9px 11px;
            border: 1px solid #334155;
            border-radius: 8px;
            background: #0a0e1a;
            color: #e2e8f0;
            font-size: 0.9em;
        }
        input:focus { outline: none; border-color: #38bdf8; }
        .btn-run {
            grid-column: 1 / -1;
            padding: 11px;
            border: none;
            border-radius: 8px;
            background: linear-gradient(135deg, #38bdf8, #a78bfa);
            color: #0a0e1a;
            font-size: 1em;
            font-weight: 700;
            cursor: pointer;
            margin-top: 4px;
            transition: all 0.2s;
        }
        .btn-run:hover { transform: translateY(-1px); box-shadow: 0 4px 20px rgba(56,189,248,0.3); }
        .btn-run:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }

        .error-box {
            background: rgba(239,68,68,0.1);
            border: 1px solid rgba(239,68,68,0.3);
            border-radius: 10px;
            padding: 16px;
            margin-bottom: 16px;
            color: #f87171;
        }

        .summary {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 10px;
            margin-bottom: 16px;
        }
        .summary-item {
            background: #111827;
            border: 1px solid #1e293b;
            border-radius: 10px;
            padding: 14px;
            text-align: center;
        }
        .summary-value {
            font-size: 1.8em;
            font-weight: 800;
            line-height: 1;
        }
        .summary-label {
            font-size: 0.72em;
            color: #64748b;
            margin-top: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .s-pass { color: #4ade80; }
        .s-fail { color: #f87171; }
        .s-skip { color: #fbbf24; }
        .s-warn { color: #fb923c; }
        .s-total { color: #38bdf8; }

        .progress-bar {
            height: 6px;
            border-radius: 3px;
            background: #1e293b;
            overflow: hidden;
            margin-bottom: 16px;
            display: flex;
        }
        .progress-bar .bar-pass { background: #4ade80; }
        .progress-bar .bar-fail { background: #f87171; }
        .progress-bar .bar-skip { background: #fbbf24; }
        .progress-bar .bar-warn { background: #fb923c; }

        .category { margin-bottom: 12px; }
        .category-header {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 14px;
            background: #1e293b;
            border-radius: 8px 8px 0 0;
            cursor: pointer;
            user-select: none;
            font-weight: 600;
            font-size: 0.9em;
        }
        .category-header:hover { background: #253347; }
        .category-header .badge {
            margin-left: auto;
            font-size: 0.75em;
            padding: 2px 8px;
            border-radius: 12px;
            font-weight: 600;
        }
        .badge-pass { background: rgba(74,222,128,0.15); color: #4ade80; }
        .badge-fail { background: rgba(248,113,113,0.15); color: #f87171; }
        .badge-skip { background: rgba(251,191,36,0.15); color: #fbbf24; }
        .badge-warn { background: rgba(251,146,60,0.15); color: #fb923c; }

        .category-body {
            border: 1px solid #1e293b;
            border-top: none;
            border-radius: 0 0 8px 8px;
            overflow: hidden;
        }
        .category-body.collapsed { display: none; }

        .test-row {
            display: grid;
            grid-template-columns: 24px 1fr auto auto;
            gap: 10px;
            align-items: center;
            padding: 8px 14px;
            border-bottom: 1px solid #1e293b;
            font-size: 0.82em;
        }
        .test-row:last-child { border-bottom: none; }
        .test-row:hover { background: rgba(56,189,248,0.03); }

        .icon {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: 700;
        }
        .icon.pass { background: rgba(74,222,128,0.15); color: #4ade80; }
        .icon.fail { background: rgba(248,113,113,0.15); color: #f87171; }
        .icon.skip { background: rgba(251,191,36,0.15); color: #fbbf24; }
        .icon.warn { background: rgba(251,146,60,0.15); color: #fb923c; }

        .test-name { font-weight: 500; color: #e2e8f0; }
        .test-msg {
            font-size: 0.8em;
            color: #64748b;
            max-width: 400px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .test-time {
            font-size: 0.75em;
            color: #475569;
            font-family: 'Courier New', monospace;
            min-width: 55px;
            text-align: right;
        }

        .toolbar {
            display: flex;
            gap: 8px;
            margin-bottom: 12px;
            flex-wrap: wrap;
        }
        .toolbar button {
            padding: 6px 14px;
            border: 1px solid #334155;
            border-radius: 6px;
            background: #111827;
            color: #94a3b8;
            font-size: 0.78em;
            cursor: pointer;
            transition: all 0.15s;
        }
        .toolbar button:hover { background: #1e293b; color: #e2e8f0; }

        .ros-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.75em;
            font-weight: 600;
        }
        .ros7 { background: rgba(167,139,250,0.15); color: #a78bfa; }
        .ros6 { background: rgba(56,189,248,0.15); color: #38bdf8; }

        .footer {
            text-align: center;
            color: #475569;
            font-size: 0.75em;
            margin-top: 20px;
            padding-bottom: 20px;
        }

        @media (max-width: 700px) {
            .form-grid { grid-template-columns: 1fr 1fr; }
            .summary { grid-template-columns: repeat(3, 1fr); }
            .test-row { grid-template-columns: 20px 1fr auto; }
            .test-msg { display: none; }
        }
    </style>
</head>
<body>
<div class="container">
    <h1>🧪 RouterOS API — Full Test Suite</h1>
    <p class="subtitle">Comprehensive test for ALL methods in routeros_api.class.php (RouterOS 6 & 7)</p>

        <div class="card">
        <h2>⚙️ Pilih Router dari Database</h2>
        <form method="POST" id="testForm">
            <div class="form-grid" style="grid-template-columns: 1fr;">
                <div class="form-group">
                    <label>Pilih Router Aktif</label>
                    <select name="router_id" required style="padding: 10px; border: 1px solid #334155; border-radius: 8px; background: #0a0e1a; color: #e2e8f0; font-size: 0.95em;">
                        <option value="">-- Pilih Router --</option>
                        <?php if (empty($routers)): ?>
                            <option value="" disabled>Tidak ada router aktif di database</option>
                        <?php else: ?>
                            <?php foreach ($routers as $r): ?>
                                <option value="<?= $r['id'] ?>" <?= ($selectedRouter && $selectedRouter['id'] == $r['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['nama_router']) ?> 
                                    (<?= htmlspecialchars($r['ip_address']) ?>:<?= $r['api_port'] ?>) 
                                    - <?= htmlspecialchars($r['lokasi']) ?>
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <button type="submit" class="btn-run" id="btnRun" <?= empty($routers) ? 'disabled' : '' ?>>
                    🚀 Jalankan Test pada Router Terpilih
                </button>
            </div>
        </form>
        <?php if ($selectedRouter && $tested): ?>
            <p style="margin-top:10px; font-size:0.8em; color:#4ade80;">
                ✅ Sedang menguji: <strong><?= htmlspecialchars($selectedRouter['nama_router']) ?></strong>
            </p>
        <?php endif; ?>
    </div>

    <?php if ($connectError): ?>
    <div class="error-box">
        ❌ <strong>Koneksi Gagal!</strong><br>
        <?= htmlspecialchars($connectError) ?>
    </div>
    <?php endif; ?>

    <?php if ($tested && $tester):
        $results = $tester->getResults();
        $pass = $tester->getPass();
        $fail = $tester->getFail();
        $skip = $tester->getSkip();
        $warn = $tester->getWarn();
        $total = $tester->getTotal();
        $elapsed = $tester->getElapsedTime();
        $isROS7 = $tester->isROS7();
    ?>

    <div class="summary">
        <div class="summary-item">
            <div class="summary-value s-total"><?= $total ?></div>
            <div class="summary-label">Total Test</div>
        </div>
        <div class="summary-item">
            <div class="summary-value s-pass"><?= $pass ?></div>
            <div class="summary-label">✅ Pass</div>
        </div>
        <div class="summary-item">
            <div class="summary-value s-fail"><?= $fail ?></div>
            <div class="summary-label">❌ Fail</div>
        </div>
        <div class="summary-item">
            <div class="summary-value s-warn"><?= $warn ?></div>
            <div class="summary-label">⚠️ Warn</div>
        </div>
        <div class="summary-item">
            <div class="summary-value s-skip"><?= $skip ?></div>
            <div class="summary-label">⏭️ Skip</div>
        </div>
    </div>

    <div class="progress-bar">
        <?php if ($total > 0): ?>
        <div class="bar-pass" style="width: <?= ($pass/$total)*100 ?>%"></div>
        <div class="bar-fail" style="width: <?= ($fail/$total)*100 ?>%"></div>
        <div class="bar-warn" style="width: <?= ($warn/$total)*100 ?>%"></div>
        <div class="bar-skip" style="width: <?= ($skip/$total)*100 ?>%"></div>
        <?php endif; ?>
    </div>

    <div style="text-align:center; margin-bottom:14px; font-size:0.82em; color:#64748b;">
        <span class="ros-badge <?= $isROS7 ? 'ros7' : 'ros6' ?>"><?= $isROS7 ? 'RouterOS 7' : 'RouterOS 6' ?></span>
        &nbsp; ⏱️ Selesai dalam <strong><?= $elapsed ?>s</strong>
        &nbsp; 📊 <?= count($results) ?> kategori diuji
    </div>

    <div class="toolbar">
        <button onclick="toggleAll(true)">📂 Expand All</button>
        <button onclick="toggleAll(false)">📁 Collapse All</button>
        <button onclick="toggleFilter('fail')">❌ Show Fail Only</button>
        <button onclick="toggleFilter('warn')">⚠️ Show Warn Only</button>
        <button onclick="toggleFilter('all')">🔄 Show All</button>
    </div>

    <?php foreach ($results as $category => $tests):
        $catPass = count(array_filter($tests, fn($t) => $t['status'] === 'pass'));
        $catFail = count(array_filter($tests, fn($t) => $t['status'] === 'fail'));
        $catSkip = count(array_filter($tests, fn($t) => $t['status'] === 'skip'));
        $catWarn = count(array_filter($tests, fn($t) => $t['status'] === 'warn'));
        $catTotal = count($tests);
        $catId = 'cat_' . md5($category);
    ?>
    <div class="category" data-category>
        <div class="category-header" onclick="toggleCategory('<?= $catId ?>')">
            <span><?= htmlspecialchars($category) ?></span>
            <?php if ($catFail > 0): ?>
                <span class="badge badge-fail"><?= $catFail ?> fail</span>
            <?php endif; ?>
            <?php if ($catWarn > 0): ?>
                <span class="badge badge-warn"><?= $catWarn ?> warn</span>
            <?php endif; ?>
            <?php if ($catSkip > 0): ?>
                <span class="badge badge-skip"><?= $catSkip ?> skip</span>
            <?php endif; ?>
            <span class="badge badge-pass"><?= $catPass ?>/<?= $catTotal ?></span>
        </div>
        <div class="category-body" id="<?= $catId ?>">
            <?php foreach ($tests as $test): ?>
            <div class="test-row" data-status="<?= $test['status'] ?>">
                <div class="icon <?= $test['status'] ?>">
                    <?= match($test['status']) { 'pass' => '✓', 'fail' => '✗', 'skip' => '⏭', 'warn' => '!' } ?>
                </div>
                <div class="test-name"><?= htmlspecialchars($test['name']) ?></div>
                <div class="test-msg" title="<?= htmlspecialchars($test['message']) ?>"><?= htmlspecialchars($test['message']) ?></div>
                <div class="test-time"><?= $test['time_ms'] ?>ms</div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endforeach; ?>

    <?php endif; ?>

    <div class="footer">
        RouterOS API Full Test Suite &mdash; Tests <?= $tested ? $total : '??' ?> methods
        <br>PHP <?= PHP_VERSION ?> &mdash; <?= date('Y-m-d H:i:s') ?>
    </div>
</div>

<script>
document.getElementById('testForm').addEventListener('submit', function() {
    const btn = document.getElementById('btnRun');
    btn.disabled = true;
    btn.textContent = '⏳ Testing... (tunggu sampai selesai)';
});

function toggleCategory(id) {
    const el = document.getElementById(id);
    el.classList.toggle('collapsed');
}

function toggleAll(expand) {
    document.querySelectorAll('.category-body').forEach(el => {
        if (expand) el.classList.remove('collapsed');
        else el.classList.add('collapsed');
    });
}

function toggleFilter(status) {
    document.querySelectorAll('[data-category]').forEach(cat => {
        if (status === 'all') {
            cat.style.display = '';
            cat.querySelectorAll('.test-row').forEach(r => r.style.display = '');
        } else {
            const rows = cat.querySelectorAll('.test-row');
            let hasMatch = false;
            rows.forEach(r => {
                if (r.dataset.status === status) {
                    r.style.display = '';
                    hasMatch = true;
                } else {
                    r.style.display = 'none';
                }
            });
            cat.style.display = hasMatch ? '' : 'none';
            if (hasMatch) {
                const body = cat.querySelector('.category-body');
                body.classList.remove('collapsed');
            }
        }
    });
}

document.querySelectorAll('[data-category]').forEach(cat => {
    const fails = cat.querySelectorAll('[data-status="fail"]');
    if (fails.length > 0) {
        const body = cat.querySelector('.category-body');
        body.classList.remove('collapsed');
    }
});
</script>
</body>
</html>

