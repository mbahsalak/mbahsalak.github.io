<?php
// config/database.php
declare(strict_types=1);

$host = '10.100.0.16';
$db   = 'isp_billing';
$user = 'ubs'; // Sesuaikan user MySQL KSWEB
$pass = 'sembarang';     // Sesuaikan password MySQL KSWEB
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("❌ Koneksi Database Gagal: " . $e->getMessage());
}
