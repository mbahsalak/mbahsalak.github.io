<?php
/**
 * routeros_api.class.php — RouterOS 7 Edition
 * 
 * PHP 8.4 RouterOS API Client — Full Support for RouterOS 6.x & 7.x
 * 
 * Changelog v7 Edition:
 * + WireGuard VPN management
 * + Container (Docker) management
 * + BGP & OSPF routing management
 * + IPv6 extended (DHCPv6, NDP, Router Advertisement)
 * + Kid Control management
 * + User Manager v7 support
 * + PPPoE extended management
 * + Fixed System Health parsing for ROS7
 * + Auto-detect RouterOS version
 * + REST API support (RouterOS 7.1+)
 * + Optimized login for RouterOS 7.x
 */

declare(strict_types=0);

class RouterosAPI
{
    // =====================================================================
    // PROPERTIES
    // =====================================================================

    public bool $debug = false;
    public $error = null;
    public array $response = [];
    public ?string $lastResponseType = null;

    private $socket = null;
    private string $host = '';
    private int $port = 8728;
    private bool $ssl = false;
    private int $timeout = 5;
    private bool $connected = false;
    private bool $authenticated = false;
    private string $username = '';
    private string $password = '';

    private int $tagCounter = 0;
    private float $connectTime = 0.0;
    private int $bytesSent = 0;
    private int $bytesReceived = 0;
    private int $commandsSent = 0;
    private ?string $lastSentenceSent = null;
    private array $debugLog = [];

    private bool $autoReconnect = false;
    private int $maxReconnectAttempts = 3;
    private int $reconnectDelay = 1000;
    private int $readTimeout = 10;
    private bool $connectionLost = false;

    /** @var string|null Detected RouterOS version (e.g., "7.15.3") */
    private ?string $routerVersion = null;

    /** @var int|null Major version number (6 or 7) */
    private ?int $majorVersion = null;

    // =====================================================================
    // CONSTRUCTOR & DESTRUCTOR
    // =====================================================================

    public function __construct(string $host = '', int $port = 8728, bool $ssl = false, int $timeout = 5)
    {
        $this->host    = $host;
        $this->port    = $port;
        $this->ssl     = $ssl || ($port === 8729);
        $this->timeout = $timeout;
    }

    public function __destruct()
    {
        $this->disconnect();
    }

    // =====================================================================
    // CONNECTION MANAGEMENT
    // =====================================================================

    public function connect(string $host = '', string $username = 'admin', string $password = '', int $port = 0): bool
    {
        if ($host !== '') $this->host = $host;
        if ($port > 0) $this->port = $port;

        $this->username = $username;
        $this->password = $password;
        $this->error    = null;

        if ($this->host === '') {
            $this->setError('Host is empty');
            return false;
        }

        $address = $this->buildAddress();
        $this->debugMessage("Connecting to {$address}...");

        $errno = 0;
        $errstr = '';

        if ($this->ssl) {
            $context = stream_context_create([
                'ssl' => [
                    'verify_peer'       => false,
                    'verify_peer_name'  => false,
                    'allow_self_signed' => true,
                    'crypto_method'     => STREAM_CRYPTO_METHOD_TLS_CLIENT,
                ],
            ]);
            $this->socket = @stream_socket_client($address, $errno, $errstr, $this->timeout, STREAM_CLIENT_CONNECT, $context);
        } else {
            $this->socket = @stream_socket_client($address, $errno, $errstr, $this->timeout, STREAM_CLIENT_CONNECT);
        }

        if (!$this->socket) {
            $this->setError("Connection failed: {$errstr} ({$errno})");
            return false;
        }

        stream_set_timeout($this->socket, $this->readTimeout);
        stream_set_blocking($this->socket, true);

        $this->connected      = true;
        $this->connectTime    = microtime(true);
        $this->connectionLost = false;

        if (!$this->login($username, $password)) {
            $this->disconnect();
            return false;
        }

        // Auto-detect RouterOS version
        $this->detectVersion();

        return true;
    }

    public function disconnect(): void
    {
        if ($this->socket) {
            if ($this->connected && $this->authenticated) {
                try { $this->write('/quit'); } catch (\Throwable $e) {}
            }
            @fclose($this->socket);
            $this->socket = null;
        }
        $this->connected      = false;
        $this->authenticated  = false;
        $this->connectionLost = false;
        $this->routerVersion  = null;
        $this->majorVersion   = null;
    }

    public function isConnected(): bool
    {
        if (!$this->socket || !$this->connected) return false;
        $meta = @stream_get_meta_data($this->socket);
        if ($meta && (!empty($meta['timed_out']) || !empty($meta['eof']))) {
            $this->connectionLost = true;
            $this->connected = false;
            return false;
        }
        return true;
    }

    public function isAuthenticated(): bool
    {
        return $this->authenticated && $this->isConnected();
    }

    public function reconnect(): bool
    {
        $this->disconnect();
        for ($i = 1; $i <= $this->maxReconnectAttempts; $i++) {
            if ($this->connect($this->host, $this->username, $this->password, $this->port)) return true;
            if ($i < $this->maxReconnectAttempts) usleep($this->reconnectDelay * 1000);
        }
        $this->setError("Reconnect failed after {$this->maxReconnectAttempts} attempts");
        return false;
    }

    public function setAutoReconnect(bool $enable = true, int $maxAttempts = 3, int $delayMs = 1000): void
    {
        $this->autoReconnect        = $enable;
        $this->maxReconnectAttempts = $maxAttempts;
        $this->reconnectDelay       = $delayMs;
    }

    public function setReadTimeout(int $seconds): void
    {
        $this->readTimeout = $seconds;
        if ($this->socket) stream_set_timeout($this->socket, $seconds);
    }

    // =====================================================================
    // VERSION DETECTION (NEW in v7 Edition)
    // =====================================================================

    /**
     * Detect RouterOS version after login
     */
    private function detectVersion(): void
    {
        $resource = $this->getResource();
        if ($resource && isset($resource['version'])) {
            $this->routerVersion = $resource['version'];
            // Extract major version: "7.15.3" → 7, "6.49.10" → 6
            if (preg_match('/^(\d+)/', $resource['version'], $m)) {
                $this->majorVersion = (int) $m[1];
            }
            $this->debugMessage("Detected RouterOS v{$this->routerVersion} (major: {$this->majorVersion})");
        }
    }

    /**
     * Get detected RouterOS version string
     */
    public function getRouterVersion(): ?string
    {
        return $this->routerVersion;
    }

    /**
     * Get major version number (6 or 7)
     */
    public function getMajorVersion(): ?int
    {
        return $this->majorVersion;
    }

    /**
     * Check if router is running RouterOS 7+
     */
    public function isRouterOS7(): bool
    {
        return $this->majorVersion !== null && $this->majorVersion >= 7;
    }

    /**
     * Check if router is running RouterOS 6
     */
    public function isRouterOS6(): bool
    {
        return $this->majorVersion !== null && $this->majorVersion === 6;
    }

    // =====================================================================
    // AUTHENTICATION
    // =====================================================================

    private function login(string $username, string $password): bool
    {
        // RouterOS v6.43+ and v7.x: Direct login with username & password
        $this->write('/login', false);
        $this->write('=name=' . $username, false);
        $this->write('=password=' . $password, true);

        $this->read();

        // Direct success (v6.43+ and v7.x)
        if ($this->lastResponseType === '!done' && empty($this->error)) {
            $challenge = $this->getResponseValue('ret');
            if ($challenge === null) {
                $this->authenticated = true;
                $this->debugMessage("Login successful (direct method)");
                return true;
            }
            // Legacy challenge (pre-v6.43, unlikely but kept for compatibility)
            return $this->loginLegacy($username, $password, $challenge);
        }

        if ($this->lastResponseType === '!trap') {
            $this->setError("Login failed: " . ($this->getResponseValue('message') ?? 'Unknown error'));
            return false;
        }

        $challenge = $this->getResponseValue('ret');
        if ($challenge !== null) {
            return $this->loginLegacy($username, $password, $challenge);
        }

        if ($this->lastResponseType === '!done') {
            $this->authenticated = true;
            return true;
        }

        $this->setError('Login failed: unexpected response');
        return false;
    }

    private function loginLegacy(string $username, string $password, string $challenge): bool
    {
        $this->debugMessage("Using legacy challenge-response login (pre-v6.43)");
        $md5 = md5(chr(0) . $password . pack('H*', $challenge));
        $this->write('/login', false);
        $this->write('=name=' . $username, false);
        $this->write('=response=00' . $md5, true);

        $this->read();

        if ($this->lastResponseType === '!done') {
            $this->authenticated = true;
            return true;
        }

        $this->setError("Login failed: " . ($this->getResponseValue('message') ?? 'Authentication failed'));
        return false;
    }

    // =====================================================================
    // COMMAND EXECUTION
    // =====================================================================

    public function write($command, bool $end = true): bool
    {
        if (!$this->socket) { $this->setError('Not connected'); return false; }

        if (is_array($command)) {
            foreach ($command as $word) {
                if (!$this->sendWord((string) $word)) return false;
            }
            if ($end) $this->sendWord('');
        } else {
            $this->sendWord((string) $command);
            if ($end) $this->sendWord('');
        }

        $this->commandsSent++;
        $this->lastSentenceSent = is_array($command) ? implode("\n", $command) : $command;
        return true;
    }

    public function comm(string $command, array $params = [], array $queries = [], ?string $tag = null, bool $readResponse = true)
    {
        if (!$this->ensureConnectedInternal()) return false;

        $sentence = [$command];

        foreach ($params as $key => $value) {
            $sentence[] = (str_starts_with($key, '=') ? $key : '=' . $key) . '=' . $value;
        }

        foreach ($queries as $key => $value) {
            if (str_starts_with($key, '?') || str_starts_with($key, '#')) {
                $sentence[] = ($value === '' || $value === true) ? $key : $key . '=' . $value;
            } else {
                $sentence[] = '?' . $key . '=' . $value;
            }
        }

        if ($tag !== null) $sentence[] = '.tag=' . $tag;

        foreach ($sentence as $word) {
            if (!$this->sendWord($word)) {
                $this->setError('Failed to send word: ' . $word);
                return false;
            }
        }
        $this->sendWord('');
        $this->commandsSent++;

        if ($this->debug) $this->debugMessage("SENT: " . implode(' | ', $sentence));
        if (!$readResponse) return true;

        return $this->read();
    }

    // =====================================================================
    // HIGH-LEVEL CRUD
    // =====================================================================

    public function get(string $path, array $query = [], ?string $proplist = null, bool $detail = false): array|false
    {
        $params = [];
        if ($proplist !== null) $params['.proplist'] = $proplist;
        if ($detail) $params['detail'] = '';
        $result = $this->comm($path . '/print', $params, $query);
        return $result === false ? false : $this->parseResponse($result);
    }

    public function getOne(string $path, string $id, ?string $proplist = null): array|false
    {
        $params = [];
        if ($proplist !== null) $params['.proplist'] = $proplist;
        $result = $this->comm($path . '/print', $params, ['?.id' => $id]);
        if ($result === false) return false;
        $items = $this->parseResponse($result);
        return $items[0] ?? false;
    }

    public function getByName(string $path, string $name): array|false
    {
        $result = $this->comm($path . '/print', [], ['?name' => $name]);
        if ($result === false) return false;
        $items = $this->parseResponse($result);
        return $items[0] ?? false;
    }

    public function add(string $path, array $params = []): string|false
    {
        $result = $this->comm($path . '/add', $params);
        if ($result === false || $this->lastResponseType === '!trap') return false;
        return $this->getResponseValue('ret') ?? true;
    }

    public function set(string $path, string $id, array $params = []): bool
    {
        $params['.id'] = $id;
        $result = $this->comm($path . '/set', $params);
        return $result !== false && $this->lastResponseType !== '!trap';
    }

    public function remove(string $path, string $id): bool
    {
        $result = $this->comm($path . '/remove', ['.id' => $id]);
        return $result !== false && $this->lastResponseType !== '!trap';
    }

    public function enable(string $path, string $id): bool
    {
        $result = $this->comm($path . '/enable', ['.id' => $id]);
        return $result !== false && $this->lastResponseType !== '!trap';
    }

    public function disable(string $path, string $id): bool
    {
        $result = $this->comm($path . '/disable', ['.id' => $id]);
        return $result !== false && $this->lastResponseType !== '!trap';
    }

    public function move(string $path, string $id, ?string $destination = null): bool
    {
        $params = ['.id' => $id];
        if ($destination !== null) $params['=destination'] = $destination;
        $result = $this->comm($path . '/move', $params);
        return $result !== false && $this->lastResponseType !== '!trap';
    }

    public function unset(string $path, string $id, string $key): bool
    {
        $result = $this->comm($path . '/unset', ['.id' => $id, '=value-name' => $key]);
        return $result !== false && $this->lastResponseType !== '!trap';
    }

    public function comment(string $path, string $id, string $comment): bool
    {
        $result = $this->comm($path . '/comment', ['.id' => $id, '=comment' => $comment]);
        return $result !== false && $this->lastResponseType !== '!trap';
    }

    public function count(string $path, array $query = []): int|false
    {
        $result = $this->comm($path . '/print', ['count-only' => ''], $query);
        if ($result === false) return false;
        $ret = $this->getResponseValue('ret');
        return $ret !== null ? (int) $ret : false;
    }

    public function find(string $path, array $query = []): array
    {
        $items = $this->get($path, $query, '.id');
        if (!is_array($items)) return [];
        $ids = [];
        foreach ($items as $item) if (isset($item['.id'])) $ids[] = $item['.id'];
        return $ids;
    }

    public function findOne(string $path, array $query = []): array|false
    {
        $items = $this->get($path, $query);
        return (is_array($items) && !empty($items)) ? $items[0] : false;
    }

    // =====================================================================
    // BATCH OPERATIONS
    // =====================================================================

    public function addMany(string $path, array $items): array
    {
        $results = [];
        foreach ($items as $params) $results[] = $this->add($path, $params);
        return $results;
    }

    public function setMany(string $path, array $updates): array
    {
        $results = [];
        foreach ($updates as $u) $results[] = $this->set($path, $u['id'] ?? $u['.id'] ?? '', $u['params'] ?? $u['data'] ?? []);
        return $results;
    }

    public function removeMany(string $path, array $ids): array
    {
        $results = [];
        foreach ($ids as $id) $results[] = $this->remove($path, $id);
        return $results;
    }

    // =====================================================================
    // ADVANCED: LISTEN, CANCEL, GENERATOR, SCRIPT
    // =====================================================================

    public function listen(string $path, array $queries = [], ?string $tag = null): bool
    {
        if (!$this->ensureConnectedInternal()) return false;
        $sentence = [$path . '/listen'];
        foreach ($queries as $key => $value) {
            $sentence[] = (str_starts_with($key, '?') ? $key : '?' . $key) . ($value === '' || $value === true ? '' : '=' . $value);
        }
        if ($tag !== null) $sentence[] = '.tag=' . $tag;
        foreach ($sentence as $word) if (!$this->sendWord($word)) return false;
        $this->sendWord('');
        $this->commandsSent++;
        return true;
    }

    public function cancel(?string $tag = null): bool
    {
        $sentence = ['/cancel'];
        if ($tag !== null) $sentence[] = '=tag=' . $tag;
        foreach ($sentence as $word) if (!$this->sendWord($word)) return false;
        $this->sendWord('');
        $this->read();
        return true;
    }

    public function readGenerator(string $command, array $params = [], array $queries = []): \Generator
    {
        $this->comm($command, $params, $queries, null, false);
        $currentItem = [];
        $sentenceType = null;

        while (true) {
            $word = $this->readWord();
            if ($word === false) { $this->connectionLost = true; break; }

            if ($word === '') {
                if ($sentenceType === '!re' && !empty($currentItem)) yield $currentItem;
                if ($sentenceType === '!done' || $sentenceType === '!fatal') break;
                $currentItem = [];
                $sentenceType = null;
                continue;
            }

            if (in_array($word, ['!re', '!done', '!trap', '!fatal'], true)) {
                $sentenceType = $word;
                $this->lastResponseType = $word;
                continue;
            }

            if (str_starts_with($word, '=')) {
                $eqPos = strpos($word, '=', 1);
                if ($eqPos !== false) $currentItem[substr($word, 1, $eqPos - 1)] = substr($word, $eqPos + 1);
            }
        }
    }

    public function execScript(string $scriptSource, string $namePrefix = 'api_tmp_'): bool
    {
        if (!$this->ensureConnectedInternal()) return false;
        $scriptName = $namePrefix . uniqid();
        $addResult = $this->add('/system/script', ['name' => $scriptName, 'source' => $scriptSource]);
        if ($addResult === false) return false;
        $runResult = $this->comm('/system/script/run', ['=number' => $scriptName]);
        $this->comm('/system/script/remove', ['=numbers' => $scriptName]);
        return $runResult !== false && $this->lastResponseType !== '!trap';
    }

    // =====================================================================
    // RESPONSE READING
    // =====================================================================

    public function read(bool $parse = false): array
    {
        if (!$this->socket) { $this->setError('Not connected'); return []; }

        $response = [];
        $sentence = [];
        $this->lastResponseType = null;
        $this->error = null;

        while (true) {
            $word = $this->readWord();

            if ($word === false) {
                $this->connectionLost = true;
                $this->connected = false;
                $this->setError('Connection lost during read');
                break;
            }

            if ($word === '') {
                if (!empty($sentence)) {
                    $response[] = $sentence;
                    $sentence = [];
                }
                if ($this->lastResponseType === '!done' || $this->lastResponseType === '!fatal') {
                    break;
                }
                continue;
            }

            if (in_array($word, ['!done', '!re', '!trap', '!fatal'], true)) {
                $this->lastResponseType = $word;
                if ($word === '!re' && !empty($sentence)) {
                    $response[] = $sentence;
                    $sentence = [];
                }
                $sentence[] = $word;
                continue;
            }

            $sentence[] = $word;
        }

        if (!empty($sentence)) $response[] = $sentence;
        $this->response = $response;

        foreach ($response as $sent) {
            if (is_array($sent)) {
                foreach ($sent as $w) {
                    if (is_string($w) && str_starts_with($w, '=message=')) {
                        if (in_array($this->lastResponseType, ['!trap', '!fatal'])) {
                            $this->setError(substr($w, 9));
                        }
                    }
                }
            }
        }

        if ($this->debug) $this->debugMessage("RECV: " . json_encode($response, JSON_UNESCAPED_UNICODE));
        return $parse ? $this->parseResponse($response) : $response;
    }

    public function readParsed(): array { return $this->read(true); }

    // =====================================================================
    // PROTOCOL: ENCODING/DECODING
    // =====================================================================

    private function sendWord(string $word): bool
    {
        if (!$this->socket) return false;
        $data = $this->encodeLength(strlen($word)) . $word;
        $written = @fwrite($this->socket, $data);
        if ($written === false) {
            $this->setError('Failed to write to socket');
            $this->connectionLost = true;
            $this->connected = false;
            return false;
        }
        $this->bytesSent += $written;
        return true;
    }

    private function readWord(): string|false
    {
        if (!$this->socket) return false;
        $len = $this->readLength();
        if ($len === false) return false;
        if ($len === 0) return '';

        $word = '';
        $remaining = $len;
        while ($remaining > 0) {
            $chunk = @fread($this->socket, $remaining);
            if ($chunk === false || $chunk === '') {
                $meta = @stream_get_meta_data($this->socket);
                if ($meta && !empty($meta['timed_out'])) {
                    $this->setError('Read timeout');
                } elseif ($meta && !empty($meta['eof'])) {
                    $this->setError('Connection closed by router');
                } else {
                    $this->setError('Failed to read from socket');
                }
                return false;
            }
            $word .= $chunk;
            $remaining -= strlen($chunk);
        }
        $this->bytesReceived += $len;
        return $word;
    }

    private function encodeLength(int $length): string
    {
        if ($length < 0x80) return chr($length);
        if ($length < 0x4000) { $length |= 0x8000; return chr(($length >> 8) & 0xFF) . chr($length & 0xFF); }
        if ($length < 0x200000) { $length |= 0xC00000; return chr(($length >> 16) & 0xFF) . chr(($length >> 8) & 0xFF) . chr($length & 0xFF); }
        if ($length < 0x10000000) { $length |= 0xE0000000; return chr(($length >> 24) & 0xFF) . chr(($length >> 16) & 0xFF) . chr(($length >> 8) & 0xFF) . chr($length & 0xFF); }
        return chr(0xF0) . pack('N', $length);
    }

    private function readLength(): int|false
    {
        $byte1 = $this->readByte();
        if ($byte1 === false) return false;
        if (($byte1 & 0x80) === 0) return $byte1;
        if (($byte1 & 0xC0) === 0x80) { $b2 = $this->readByte(); return $b2 === false ? false : (($byte1 & 0x3F) << 8) | $b2; }
        if (($byte1 & 0xE0) === 0xC0) { $b2 = $this->readByte(); $b3 = $this->readByte(); return ($b2 === false || $b3 === false) ? false : (($byte1 & 0x1F) << 16) | ($b2 << 8) | $b3; }
        if (($byte1 & 0xF0) === 0xE0) { $b2 = $this->readByte(); $b3 = $this->readByte(); $b4 = $this->readByte(); return ($b2 === false || $b3 === false || $b4 === false) ? false : (($byte1 & 0x0F) << 24) | ($b2 << 16) | ($b3 << 8) | $b4; }
        if ($byte1 === 0xF0) { $data = @fread($this->socket, 4); if (!$data || strlen($data) < 4) return false; $this->bytesReceived += 4; return unpack('N', $data)[1]; }
        $this->setError("Invalid length encoding: 0x" . dechex($byte1));
        return false;
    }

    private function readByte(): int|false
    {
        $byte = @fread($this->socket, 1);
        if ($byte === false || $byte === '') {
            $meta = @stream_get_meta_data($this->socket);
            if ($meta && !empty($meta['timed_out'])) $this->setError('Read timeout');
            return false;
        }
        $this->bytesReceived += 1;
        return ord($byte);
    }

    // =====================================================================
    // RESPONSE PARSING & QUERIES
    // =====================================================================

    public function parseResponse(?array $response = null): array
    {
        $response = $response ?? $this->response;
        $items = [];
        foreach ($response as $sentence) {
            if (!is_array($sentence)) continue;
            if (!in_array('!re', $sentence, true)) continue;
            $item = [];
            foreach ($sentence as $word) {
                if (is_string($word) && str_starts_with($word, '=') && !str_starts_with($word, '!')) {
                    $eqPos = strpos($word, '=', 1);
                    if ($eqPos !== false) $item[substr($word, 1, $eqPos - 1)] = substr($word, $eqPos + 1);
                }
            }
            if (!empty($item)) $items[] = $item;
        }
        return $items;
    }

    public function parseResponseFlat(?array $response = null): array
    {
        $response = $response ?? $this->response;
        $result = [];
        foreach ($response as $sentence) {
            if (!is_array($sentence)) continue;
            foreach ($sentence as $word) {
                if (is_string($word) && str_starts_with($word, '=') && !str_starts_with($word, '!')) {
                    $eqPos = strpos($word, '=', 1);
                    if ($eqPos !== false) $result[substr($word, 1, $eqPos - 1)] = substr($word, $eqPos + 1);
                }
            }
        }
        return $result;
    }

    public function getResponseValue(string $key): ?string
    {
        foreach ($this->response as $sentence) {
            if (!is_array($sentence)) continue;
            foreach ($sentence as $word) {
                if (is_string($word) && str_starts_with($word, '=' . $key . '=')) {
                    return substr($word, strlen('=' . $key . '='));
                }
            }
        }
        return null;
    }

    public function getResponseValues(string $key): array
    {
        $values = [];
        foreach ($this->response as $sentence) {
            if (!is_array($sentence)) continue;
            foreach ($sentence as $word) {
                if (is_string($word) && str_starts_with($word, '=' . $key . '=')) {
                    $values[] = substr($word, strlen('=' . $key . '='));
                }
            }
        }
        return $values;
    }

    public static function query(string $key, mixed $value = '', string $operator = '='): array
    {
        if ($operator === '') return ['?' . $key];
        $prefix = match ($operator) { '<' => '?<', '>' => '?>', '!=' => '?!', '<>' => '?!', default => '?=' };
        return [$prefix . $key . '=' . $value];
    }

    public static function buildQuery(array $conditions, string $logic = 'and'): array
    {
        $query = [];
        $count = count($conditions);
        foreach ($conditions as $condition) {
            $q = self::query($condition[0], $condition[1] ?? '', $condition[2] ?? '=');
            $query = array_merge($query, $q);
        }
        if ($count > 1) {
            $logicOp = ($logic === 'or') ? '?#|' : '?#&';
            for ($i = 0; $i < $count - 1; $i++) $query[] = $logicOp;
        }
        return $query;
    }

    // =====================================================================
    // SYSTEM INFO METHODS
    // =====================================================================

    public function getIdentity(): string|false { $r = $this->comm('/system/identity/print'); return $r === false ? false : ($this->parseResponseFlat($r)['name'] ?? false); }
    public function getVersion(): string|false { $r = $this->getResource(); return $r['version'] ?? false; }
    public function getBoardName(): string|false { $r = $this->getResource(); return $r['board-name'] ?? false; }
    public function getCpuLoad(): int|false { $r = $this->getResource(); return isset($r['cpu-load']) ? (int) $r['cpu-load'] : false; }
    public function getUptime(): string|false { $r = $this->getResource(); return $r['uptime'] ?? false; }

    public function getResource(): array|false
    {
        $r = $this->comm('/system/resource/print');
        return $r === false ? false : $this->parseResponseFlat($r);
    }

    /**
     * Get system health — FIXED for RouterOS 7
     * ROS6: flat key-value (voltage=24.1, temperature=45)
     * ROS7: array of {name, value, type} items
     */
    public function getHealth(): array|false
    {
        $r = $this->comm('/system/health/print');
        if ($r === false) return false;

        $items = $this->parseResponse($r);
        $health = [];

        // ROS7 format: array of items with 'name' and 'value' keys
        if (!empty($items) && isset($items[0]['name'])) {
            foreach ($items as $item) {
                if (isset($item['name'], $item['value'])) {
                    $health[$item['name']] = $item['value'];
                }
            }
        } else {
            // ROS6 format: flat key-value
            $flat = $this->parseResponseFlat($r);
            foreach ($flat as $key => $value) {
                if (!in_array($key, ['.id', 'name', 'type'])) {
                    $health[$key] = $value;
                }
            }
        }

        return $health;
    }

    /**
     * Get specific health value (works for both ROS6 and ROS7)
     */
    public function getHealthValue(string $name, mixed $default = null): mixed
    {
        $health = $this->getHealth();
        if ($health === false) return $default;
        return $health[$name] ?? $default;
    }

    public function getLog(int $limit = 100): array|false
    {
        $r = $this->comm('/log/print');
        if ($r === false) return false;
        $items = $this->parseResponse($r);
        return ($limit > 0 && count($items) > $limit) ? array_slice($items, -$limit) : $items;
    }

    public function getScheduler(): array|false { return $this->get('/system/scheduler'); }
    public function getScripts(): array|false { return $this->get('/system/script'); }

    public function runScript(string $name): bool
    {
        $r = $this->comm('/system/script/run', ['=number' => $name]);
        return $r !== false && $this->lastResponseType !== '!trap';
    }

    public function execute(string $command, array $params = []): array|false
    {
        return $this->comm($command, $params);
    }

    // =====================================================================
    // NETWORK METHODS
    // =====================================================================

    public function getInterfaces(): array|false { return $this->get('/interface'); }
    public function getIpAddresses(): array|false { return $this->get('/ip/address'); }
    public function getDhcpLeases(): array|false { return $this->get('/ip/dhcp-server/lease'); }
    public function getActiveDhcpLeases(): array|false { return $this->get('/ip/dhcp-server/lease', ['?status' => 'bound']); }
    public function getFirewallRules(string $table = 'filter'): array|false { return $this->get("/ip/firewall/{$table}"); }
    public function getNatRules(): array|false { return $this->get('/ip/firewall/nat'); }
    public function getSimpleQueues(): array|false { return $this->get('/queue/simple'); }
    public function getQueueTree(): array|false { return $this->get('/queue/tree'); }
    public function getWirelessInterfaces(): array|false { return $this->get('/interface/wireless'); }
    public function getWirelessClients(): array|false { return $this->get('/interface/wireless/registration-table'); }
    public function getHotspotUsers(): array|false { return $this->get('/ip/hotspot/active'); }
    public function getPppActive(): array|false { return $this->get('/ppp/active'); }
    public function getDnsCache(): array|false { return $this->get('/ip/dns/cache'); }

    // =====================================================================
    // 🆕 WIREGUARD (RouterOS 7+)
    // =====================================================================

    public function getWireguardInterfaces(): array|false { return $this->get('/interface/wireguard'); }
    public function getWireguardPeers(): array|false { return $this->get('/interface/wireguard/peers'); }

    public function addWireguardInterface(string $name, string $listenPort, ?string $privateKey = null): string|false
    {
        $params = ['name' => $name, 'listen-port' => $listenPort];
        if ($privateKey !== null) $params['private-key'] = $privateKey;
        return $this->add('/interface/wireguard', $params);
    }

    public function addWireguardPeer(
        string $interface,
        string $publicKey,
        string $allowedAddress = '',
        string $endpointAddress = '',
        string $endpointPort = '',
        ?string $presharedKey = null,
        string $persistentKeepalive = ''
    ): string|false {
        $params = ['interface' => $interface, 'public-key' => $publicKey];
        if ($allowedAddress) $params['allowed-address'] = $allowedAddress;
        if ($endpointAddress) $params['endpoint-address'] = $endpointAddress;
        if ($endpointPort) $params['endpoint-port'] = $endpointPort;
        if ($presharedKey !== null) $params['preshared-key'] = $presharedKey;
        if ($persistentKeepalive) $params['persistent-keepalive'] = $persistentKeepalive;
        return $this->add('/interface/wireguard/peers', $params);
    }

    // =====================================================================
    // 🆕 CONTAINER (RouterOS 7.4+)
    // =====================================================================

    public function getContainers(): array|false { return $this->get('/container'); }
    public function getContainerConfig(): array|false { return $this->get('/container/configs'); }
    public function getContainerMounts(): array|false { return $this->get('/container/mounts'); }
    public function getContainerEnvs(): array|false { return $this->get('/container/envs'); }

    public function addContainer(string $remoteImage, string $interface, string $rootDir = '', string $comment = ''): string|false
    {
        $params = ['remote-image' => $remoteImage, 'interface' => $interface];
        if ($rootDir) $params['root-dir'] = $rootDir;
        if ($comment) $params['comment'] = $comment;
        return $this->add('/container', $params);
    }

    public function startContainer(string $id): bool
    {
        $result = $this->comm('/container/start', ['=number' => $id]);
        return $result !== false && $this->lastResponseType !== '!trap';
    }

    public function stopContainer(string $id): bool
    {
        $result = $this->comm('/container/stop', ['=number' => $id]);
        return $result !== false && $this->lastResponseType !== '!trap';
    }

    public function restartContainer(string $id): bool
    {
        $this->stopContainer($id);
        usleep(500000); // 500ms delay
        return $this->startContainer($id);
    }

    // =====================================================================
    // 🆕 IPv6 EXTENDED
    // =====================================================================

    public function getIpv6Addresses(): array|false { return $this->get('/ipv6/address'); }
    public function getIpv6Routes(): array|false { return $this->get('/ipv6/route'); }
    public function getIpv6Neighbors(): array|false { return $this->get('/ipv6/neighbor'); }
    public function getIpv6DhcpClient(): array|false { return $this->get('/ipv6/dhcp-client'); }
    public function getIpv6DhcpServer(): array|false { return $this->get('/ipv6/dhcp-server'); }
    public function getIpv6DhcpLeases(): array|false { return $this->get('/ipv6/dhcp-server/lease'); }
    public function getIpv6Nd(): array|false { return $this->get('/ipv6/nd'); }
    public function getIpv6NdPrefix(): array|false { return $this->get('/ipv6/nd/prefix'); }
    public function getIpv6Pool(): array|false { return $this->get('/ipv6/pool'); }
    public function getIpv6FirewallFilter(): array|false { return $this->get('/ipv6/firewall/filter'); }
    public function getIpv6FirewallNat(): array|false { return $this->get('/ipv6/firewall/nat'); }
    public function getIpv6FirewallMangle(): array|false { return $this->get('/ipv6/firewall/mangle'); }

    // =====================================================================
    // 🆕 BGP (RouterOS 7 — redesigned)
    // =====================================================================

    public function getBgpConnections(): array|false { return $this->get('/routing/bgp/connection'); }
    public function getBgpTemplates(): array|false { return $this->get('/routing/bgp/template'); }
    public function getBgpInstances(): array|false { return $this->get('/routing/bgp/instance'); }
    public function getBgpSessions(): array|false { return $this->get('/routing/bgp/session'); }

    public function addBgpConnection(string $name, string $remoteAddress, int $remoteAs, string $templates = 'default', bool $disabled = false): string|false
    {
        return $this->add('/routing/bgp/connection', [
            'name' => $name,
            'remote.address' => $remoteAddress,
            'remote.as' => (string)$remoteAs,
            'templates' => $templates,
            'disabled' => $disabled ? 'yes' : 'no',
        ]);
    }

    // =====================================================================
    // 🆕 OSPF (RouterOS 7 — redesigned)
    // =====================================================================

    public function getOspfInstances(): array|false { return $this->get('/routing/ospf/instance'); }
    public function getOspfAreas(): array|false { return $this->get('/routing/ospf/area'); }
    public function getOspfInterfaceTemplates(): array|false { return $this->get('/routing/ospf/interface-template'); }
    public function getOspfNeighbors(): array|false { return $this->get('/routing/ospf/neighbor'); }
    public function getOspfLsa(): array|false { return $this->get('/routing/ospf/lsa'); }

    // =====================================================================
    // 🆕 KID CONTROL (RouterOS 7+)
    // =====================================================================

    public function getKidControlProfiles(): array|false { return $this->get('/ip/kid-control'); }
    public function getKidControlDevices(): array|false { return $this->get('/ip/kid-control/device'); }

    public function addKidControlProfile(string $name, string $paused = 'no'): string|false
    {
        return $this->add('/ip/kid-control', ['name' => $name, 'paused' => $paused]);
    }

    public function addKidControlDevice(string $mac, string $profile, string $comment = ''): string|false
    {
        $params = ['mac' => $mac, 'profile' => $profile];
        if ($comment) $params['comment'] = $comment;
        return $this->add('/ip/kid-control/device', $params);
    }

    public function pauseKidControl(string $id): bool
    {
        return $this->set('/ip/kid-control', $id, ['paused' => 'yes']);
    }

    public function resumeKidControl(string $id): bool
    {
        return $this->set('/ip/kid-control', $id, ['paused' => 'no']);
    }

    // =====================================================================
    // 🆕 USER MANAGER v7 (RouterOS 7 — completely redesigned)
    // =====================================================================

    public function getUsermanUsers(): array|false { return $this->get('/user-manager/user'); }
    public function getUsermanProfiles(): array|false { return $this->get('/user-manager/profile'); }
    public function getUsermanLimitations(): array|false { return $this->get('/user-manager/limitation'); }
    public function getUsermanRouters(): array|false { return $this->get('/user-manager/router'); }
    public function getUsermanSessions(): array|false { return $this->get('/user-manager/session'); }

    public function addUsermanUser(string $username, string $password, string $profile = '', string $comment = ''): string|false
    {
        $params = ['username' => $username, 'password' => $password];
        if ($profile) $params['profile'] = $profile;
        if ($comment) $params['comment'] = $comment;
        return $this->add('/user-manager/user', $params);
    }

    // =====================================================================
    // 🆕 PPPoE EXTENDED
    // =====================================================================

    public function getPppSecrets(): array|false { return $this->get('/ppp/secret'); }
    public function getPppProfiles(): array|false { return $this->get('/ppp/profile'); }
    public function getPppoeServerInterfaces(): array|false { return $this->get('/interface/pppoe-server/server'); }
    public function getPppoeClients(): array|false { return $this->get('/interface/pppoe-client'); }

    public function addPppSecret(string $name, string $password, string $service = 'pppoe', string $profile = 'default', string $remoteAddress = '', string $comment = ''): string|false
    {
        $params = ['name' => $name, 'password' => $password, 'service' => $service, 'profile' => $profile];
        if ($remoteAddress) $params['remote-address'] = $remoteAddress;
        if ($comment) $params['comment'] = $comment;
        return $this->add('/ppp/secret', $params);
    }

    public function disconnectPpp(string $id): bool
    {
        $result = $this->comm('/ppp/active/remove', ['.id' => $id]);
        return $result !== false && $this->lastResponseType !== '!trap';
    }

    // =====================================================================
    // 🆕 ROUTING TABLE (RouterOS 7)
    // =====================================================================

    public function getRoutingTables(): array|false { return $this->get('/routing/table'); }
    public function getRoutes(string $table = ''): array|false
    {
        $query = $table ? ['?routing-table' => $table] : [];
        return $this->get('/routing/route', $query);
    }

    public function addRoute(string $dstAddress, string $gateway, string $routingTable = 'main', int $distance = 1): string|false
    {
        return $this->add('/routing/route', [
            'dst-address' => $dstAddress,
            'gateway' => $gateway,
            'routing-table' => $routingTable,
            'distance' => (string)$distance,
        ]);
    }

    // =====================================================================
    // 🆕 VLAN (RouterOS 7 bridge VLAN)
    // =====================================================================

    public function getBridgeVlans(): array|false { return $this->get('/interface/bridge/vlan'); }
    public function getBridgePorts(): array|false { return $this->get('/interface/bridge/port'); }
    public function getBridges(): array|false { return $this->get('/interface/bridge'); }

    public function addBridgeVlan(string $bridge, string $vlanIds, string $tagged = '', string $untagged = ''): string|false
    {
        $params = ['bridge' => $bridge, 'vlan-ids' => $vlanIds];
        if ($tagged) $params['tagged'] = $tagged;
        if ($untagged) $params['untagged'] = $untagged;
        return $this->add('/interface/bridge/vlan', $params);
    }

    // =====================================================================
    // 🆕 MPLS & VPLS (RouterOS 7)
    // =====================================================================

    public function getMplsInterfaces(): array|false { return $this->get('/mpls/interface'); }
    public function getVplsInterfaces(): array|false { return $this->get('/interface/vpls'); }

    // =====================================================================
    // 🆕 BFD (RouterOS 7)
    // =====================================================================

    public function getBfdSessions(): array|false { return $this->get('/routing/bfd/session'); }
    public function getBfdConfiguration(): array|false
    {
        $r = $this->comm('/routing/bfd/configuration/print');
        return $r === false ? false : $this->parseResponseFlat($r);
    }

    // =====================================================================
    // TOOLS
    // =====================================================================

    public function ping(string $address, int $count = 4, int $size = 56): array|false
    {
        $r = $this->comm('/ping', ['=address' => $address, '=count' => (string)$count, '=size' => (string)$size]);
        return $r === false ? false : $this->parseResponse($r);
    }

    public function traceroute(string $address): array|false
    {
        $r = $this->comm('/tool/traceroute', ['=address' => $address]);
        return $r === false ? false : $this->parseResponse($r);
    }

    /**
     * Fetch URL from router (download file)
     */
    public function fetch(string $url, string $dstPath = '', string $mode = 'http'): array|false
    {
        $params = ['=url' => $url, '=mode' => $mode];
        if ($dstPath) $params['=dst-path'] = $dstPath;
        $r = $this->comm('/tool/fetch', $params);
        return $r === false ? false : $this->parseResponseFlat($r);
    }

    /**
     * Send email from router
     */
    public function sendEmail(string $to, string $subject, string $body, string $from = ''): bool
    {
        $params = ['=to' => $to, '=subject' => $subject, '=body' => $body];
        if ($from) $params['=from'] = $from;
        $r = $this->comm('/tool/e-mail/send', $params);
        return $r !== false && $this->lastResponseType !== '!trap';
    }

    /**
     * Get system clock
     */
    public function getClock(): array|false
    {
        $r = $this->comm('/system/clock/print');
        return $r === false ? false : $this->parseResponseFlat($r);
    }

    /**
     * Reboot router
     */
    public function reboot(): bool
    {
        $r = $this->comm('/system/reboot');
        return $r !== false;
    }

    /**
     * Backup configuration
     */
    public function backup(string $name = '', string $password = ''): bool
    {
        $params = [];
        if ($name) $params['=name'] = $name;
        if ($password) $params['=password'] = $password;
        $r = $this->comm('/system/backup/save', $params);
        return $r !== false && $this->lastResponseType !== '!trap';
    }

    /**
     * Export configuration to file
     */
    public function exportConfig(string $fileName = 'config.rsc'): bool
    {
        $r = $this->comm('/export', ['=file' => $fileName]);
        return $r !== false && $this->lastResponseType !== '!trap';
    }

    // =====================================================================
    // REST API SUPPORT (RouterOS 7.1+)
    // =====================================================================

    /**
     * Make REST API request (RouterOS 7.1+ only)
     * Uses HTTP/HTTPS instead of binary API protocol
     *
     * @param string $method HTTP method (GET, POST, PUT, DELETE, PATCH)
     * @param string $path   REST path (e.g., '/rest/interface')
     * @param array  $data   Request body (for POST/PUT/PATCH)
     * @param int    $httpPort HTTP port (80 for www, 443 for www-ssl)
     * @return array|false
     */
    public function restApi(string $method, string $path, array $data = [], int $httpPort = 0): array|false
    {
        if (!$this->isRouterOS7()) {
            $this->setError('REST API only available in RouterOS 7.1+');
            return false;
        }

        if ($httpPort === 0) {
            $httpPort = $this->ssl ? 443 : 80;
        }

        $scheme = $this->ssl ? 'https' : 'http';
        $url = "{$scheme}://{$this->host}:{$httpPort}{$path}";

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->readTimeout,
            CURLOPT_USERPWD => "{$this->username}:{$this->password}",
            CURLOPT_HTTPAUTH => CURLAUTH_BASIC,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        ]);

        if (!empty($data) && in_array(strtoupper($method), ['POST', 'PUT', 'PATCH'])) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            $this->setError("REST API error: {$error}");
            return false;
        }

        $decoded = json_decode($response, true);

        if ($httpCode >= 400) {
            $this->setError("REST API HTTP {$httpCode}: " . ($decoded['error'] ?? $response));
            return false;
        }

        return $decoded;
    }

    /**
     * REST GET
     */
    public function restGet(string $path): array|false
    {
        return $this->restApi('GET', $path);
    }

    /**
     * REST POST (create)
     */
    public function restPost(string $path, array $data): array|false
    {
        return $this->restApi('POST', $path, $data);
    }

    /**
     * REST PUT (update)
     */
    public function restPut(string $path, array $data): array|false
    {
        return $this->restApi('PUT', $path, $data);
    }

    /**
     * REST DELETE
     */
    public function restDelete(string $path): array|false
    {
        return $this->restApi('DELETE', $path);
    }

    // =====================================================================
    // STATISTICS, UTILS & INTERNAL
    // =====================================================================

    public function getStats(): array
    {
        return [
            'connected' => $this->connected,
            'authenticated' => $this->authenticated,
            'host' => $this->host,
            'port' => $this->port,
            'ssl' => $this->ssl,
            'router_version' => $this->routerVersion,
            'major_version' => $this->majorVersion,
            'uptime_seconds' => $this->connected ? round(microtime(true) - $this->connectTime, 2) : 0,
            'bytes_sent' => $this->bytesSent,
            'bytes_received' => $this->bytesReceived,
            'commands_sent' => $this->commandsSent,
            'connection_lost' => $this->connectionLost,
        ];
    }

    public function getDebugLog(): array { return $this->debugLog; }
    public function clearDebugLog(): void { $this->debugLog = []; }
    public function getLastError(): ?string { return is_array($this->error) ? implode('; ', $this->error) : $this->error; }
    public function hasError(): bool { return $this->error !== null; }
    public function getLastResponse(): array { return $this->response; }
    public function getLastResponseType(): ?string { return $this->lastResponseType; }

    private function buildAddress(): string { return ($this->ssl ? "ssl://" : "tcp://") . "{$this->host}:{$this->port}"; }

    private function setError(string|array $error): void
    {
        $this->error = $error;
        if ($this->debug) $this->debugMessage("ERROR: " . (is_array($error) ? implode('; ', $error) : $error));
    }

    private function debugMessage(string $message): void
    {
        if (!$this->debug) return;
        $entry = "[" . date('Y-m-d H:i:s') . "] {$message}";
        $this->debugLog[] = $entry;
        if (php_sapi_name() === 'cli') fwrite(STDERR, $entry . PHP_EOL);
    }

    private function ensureConnectedInternal(): bool
    {
        if ($this->isConnected() && $this->authenticated) return true;
        if ($this->autoReconnect) return $this->reconnect();
        $this->setError('Not connected');
        return false;
    }

    public static function timeToSeconds(string $timeStr): int
    {
        $s = 0;
        if (preg_match('/(\d+)w/', $timeStr, $m)) $s += (int)$m[1] * 604800;
        if (preg_match('/(\d+)d/', $timeStr, $m)) $s += (int)$m[1] * 86400;
        if (preg_match('/(\d+)h/', $timeStr, $m)) $s += (int)$m[1] * 3600;
        if (preg_match('/(\d+)m(?!s)/', $timeStr, $m)) $s += (int)$m[1] * 60;
        if (preg_match('/(\d+)s/', $timeStr, $m)) $s += (int)$m[1];
        return $s;
    }

    public static function formatBytes(int|float $bytes, int $precision = 2): string
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        for ($i = 0; $bytes >= 1024 && $i < count($units) - 1; $i++) $bytes /= 1024;
        return round($bytes, $precision) . ' ' . $units[$i];
    }

    public static function formatBps(int|float $bps, int $precision = 2): string
    {
        $units = ['bps', 'Kbps', 'Mbps', 'Gbps'];
        for ($i = 0; $bps >= 1000 && $i < count($units) - 1; $i++) $bps /= 1000;
        return round($bps, $precision) . ' ' . $units[$i];
    }

    public static function parseSize(string $sizeStr): int
    {
        $sizeStr = trim($sizeStr);
        if (is_numeric($sizeStr)) return (int)$sizeStr;
        $num = (float)$sizeStr;
        $unit = strtoupper(preg_replace('/[^a-zA-Z]/', '', $sizeStr));
        return match ($unit) { 'K', 'KB', 'KI' => (int)($num * 1024), 'M', 'MB', 'MI' => (int)($num * 1048576), 'G', 'GB', 'GI' => (int)($num * 1073741824), 'T', 'TB', 'TI' => (int)($num * 1099511627776), default => (int)$num };
    }

    public function resolveId(string $path, string $ref): string|false
    {
        if (str_starts_with($ref, '*')) return $ref;
        $item = $this->getByName($path, $ref);
        return ($item && isset($item['.id'])) ? $item['.id'] : false;
    }

    public function printAll(string $path): array|false { return $this->get($path); }
}
