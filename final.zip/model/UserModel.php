<?php
/**
 * model/UserModel.php
 */

declare(strict_types=1);

namespace Model;

use PDO;

class UserModel extends BaseModel
{
    protected string $table      = 'users';
    protected string $primaryKey = 'id';

    public function findByUsername(string $username): ?array
    {
        $stmt = $this->db->prepare(
            "SELECT * FROM {$this->table} WHERE username=:username LIMIT 1"
        );
        $stmt->execute(['username' => $username]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function create(array $data): int  { return $this->insert($data); }
    public function edit(int $id, array $data): bool { return $this->update($id, $data); }
    public function hapus(int $id): bool      { return $this->delete($id); }

    public function getAllWithRole(?string $role = null): array
    {
        if ($role) {
            $stmt = $this->db->prepare(
                "SELECT u.*, p.nama_lengkap
                 FROM users u LEFT JOIN pelanggan p ON p.user_id = u.id
                 WHERE u.role = :role ORDER BY u.id DESC"
            );
            $stmt->execute(['role' => $role]);
        } else {
            $stmt = $this->db->query(
                "SELECT u.*, p.nama_lengkap
                 FROM users u LEFT JOIN pelanggan p ON p.user_id = u.id
                 ORDER BY u.id DESC"
            );
        }
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAllForExport(?string $role = null): array
    {
        return $this->getAllWithRole($role);
    }

    public function isUsernameTaken(string $username, int $excludeId = 0): bool
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM users WHERE username=:u AND id != :id"
        );
        $stmt->execute(['u' => $username, 'id' => $excludeId]);
        return (int)$stmt->fetchColumn() > 0;
    }

    public function resetPassword(int $id, string $hash): bool
    {
        return $this->update($id, ['password' => $hash]);
    }

    public function setStatus(int $id, string $status): bool
    {
        return $this->update($id, ['status' => $status]);
    }

    public function allActive(): array { return $this->where('status', 'active'); }
}
