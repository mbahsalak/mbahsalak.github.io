<?php
/**
 * model/PaketModel.php
 * Sesuai schema: ada kolom deskripsi
 */

declare(strict_types=1);

namespace Model;

use PDO;

class PaketModel extends BaseModel
{
    protected string $table      = 'paket';
    protected string $primaryKey = 'id';

    // ===== SUDAH ADA (jangan dihapus) =====
    public function getAll(): array              { return $this->all(); }
    public function create(array $data): int      { return $this->insert($data); }
    public function edit(int $id, array $data): bool { return $this->update($id, $data); }
    public function hapus(int $id): bool         { return $this->delete($id); }

    /** Distribusi pelanggan per paket untuk donut chart */
    public function getDistribusiPelanggan(): array
    {
        return $this->db->query(
            "SELECT pk.nama_paket AS label, COUNT(p.id) AS value
             FROM paket pk
             LEFT JOIN pelanggan p ON p.paket_id = pk.id
             GROUP BY pk.id, pk.nama_paket
             ORDER BY value DESC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getOptions(): array
    {
        return array_map(fn($r) => [
            'id'    => $r['id'],
            'label' => "{$r['nama_paket']} - {$r['kecepatan']} - Rp" .
                       number_format((float)$r['harga'], 0, ',', '.'),
        ], $this->all());
    }

    // ===== TAMBAHAN BARU (tanpa duplikasi getAll) =====

    /**
     * Ambil semua paket yang statusnya 'aktif'
     * Digunakan di halaman pendaftaran pelanggan
     */
    public function getAktif(): array
    {
        $stmt = $this->db->prepare("
            SELECT * FROM paket 
            WHERE status = 'aktif' 
            ORDER BY harga ASC
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Hitung jumlah paket aktif
     */
    public function countAktif(): int
    {
        $stmt = $this->db->query("SELECT COUNT(*) FROM paket WHERE status = 'aktif'");
        return (int)$stmt->fetchColumn();
    }

    /**
     * Cek apakah paket tertentu aktif
     */
    public function isAktif(int $id): bool
    {
        $stmt = $this->db->prepare("SELECT status FROM paket WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $status = $stmt->fetchColumn();
        return $status === 'aktif';
    }
}
