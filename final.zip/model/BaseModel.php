<?php
/**
 * model/BaseModel.php
 * Abstract Base Model + Query Builder
 * PHP 8.4 Native Semi-Framework
 */

declare(strict_types=1);

namespace Model;

use Config\Database;
use PDO;

abstract class BaseModel
{
    protected PDO    $db;
    protected string $table;
    protected string $primaryKey = 'id';

    public function __construct(?PDO $db = null)
{
    $this->db = $db ?? Database::getConnection();
}


    // -------------------------------------------------------------------------
    // Query Builder Dasar
    // -------------------------------------------------------------------------

    /** Ambil semua baris dari tabel */
    public function all(): array
    {
        return $this->db
            ->query("SELECT * FROM {$this->table}")
            ->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Cari satu baris berdasarkan primary key */
    public function find(int|string $id): ?array
    {
        $stmt = $this->db->prepare(
            "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = :id LIMIT 1"
        );
        $stmt->execute(['id' => $id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ?: null;
    }

    /** Cari baris dengan kondisi WHERE tunggal */
    public function where(string $column, mixed $value, string $operator = '='): array
    {
        $stmt = $this->db->prepare(
            "SELECT * FROM {$this->table} WHERE `{$column}` {$operator} :value"
        );
        $stmt->execute(['value' => $value]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Cari satu baris pertama dengan kondisi WHERE */
    public function whereFirst(string $column, mixed $value, string $operator = '='): ?array
    {
        $stmt = $this->db->prepare(
            "SELECT * FROM {$this->table} WHERE `{$column}` {$operator} :value LIMIT 1"
        );
        $stmt->execute(['value' => $value]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ?: null;
    }

    /** Insert baris baru, return lastInsertId */
    public function insert(array $data): int
    {
        $cols   = implode(', ', array_map(fn($k) => "`{$k}`", array_keys($data)));
        $places = ':' . implode(', :', array_keys($data));

        $stmt = $this->db->prepare(
            "INSERT INTO {$this->table} ({$cols}) VALUES ({$places})"
        );
        $stmt->execute($data);

        return (int) $this->db->lastInsertId();
    }

    /** Update baris berdasarkan primary key */
    public function update(int|string $id, array $data): bool
    {
        $sets = implode(', ', array_map(fn($k) => "`{$k}` = :{$k}", array_keys($data)));

        $stmt = $this->db->prepare(
            "UPDATE {$this->table} SET {$sets} WHERE {$this->primaryKey} = :__id__"
        );

        $data['__id__'] = $id;
        return $stmt->execute($data);
    }

    /** Hapus baris berdasarkan primary key */
    public function delete(int|string $id): bool
    {
        $stmt = $this->db->prepare(
            "DELETE FROM {$this->table} WHERE {$this->primaryKey} = :id"
        );
        return $stmt->execute(['id' => $id]);
    }

    /** Hitung total baris */
    public function count(): int
    {
        $stmt = $this->db->query("SELECT COUNT(*) FROM {$this->table}");
        return (int) $stmt->fetchColumn();
    }

    /** Cek apakah baris dengan ID tertentu ada */
    public function exists(int|string $id): bool
    {
        return $this->find($id) !== null;
    }

    /** Akses PDO langsung untuk query kompleks */
    public function getDb(): PDO
    {
        return $this->db;
    }
}
