<?php
/**
 * model/UsageLogModel.php
 * Model untuk tabel usage_log dan cron_log
 * FIXED: Sesuai dengan struktur database aktual
 * - cron_log menggunakan kolom 'ran_at' (bukan 'created_at')
 * - cron_log menggunakan kolom 'rows_affected' (bukan 'processed')
 */

declare(strict_types=1);

namespace Model;

use PDO;

class UsageLogModel extends BaseModel
{
    protected string $table      = 'usage_log';
    protected string $primaryKey = 'id';

    // =========================================================================
    // PELANGGAN
    // =========================================================================

    public function getPelangganWithMac(): array
    {
        return $this->db->query(
            "SELECT p.id, p.nama_lengkap, p.mac_address,
                    pk.nama_paket, pk.kecepatan
             FROM pelanggan p
             LEFT JOIN paket pk ON p.paket_id = pk.id
             WHERE p.mac_address IS NOT NULL
             AND   p.mac_address != ''
             ORDER BY p.id ASC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    // =========================================================================
    // USAGE LOG — CRUD & QUERY
    // =========================================================================

    /**
     * Ambil log berdasarkan snapshot_at
     */
    public function getBySnapshot(string $snapshotAt): array
    {
        $stmt = $this->db->prepare(
            "SELECT id, pelanggan_id, mac_address, rx_bytes, tx_bytes,
                    rx_mbps, tx_mbps, is_online, period, snapshot_at, logged_at
             FROM {$this->table}
             WHERE snapshot_at >= :snapshot
             ORDER BY snapshot_at DESC"
        );
        $stmt->execute([':snapshot' => $snapshotAt]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Ambil log per pelanggan
     */
    public function getByPelanggan(int $pelangganId, int $limit = 50): array
    {
        $stmt = $this->db->prepare(
            "SELECT id, pelanggan_id, mac_address, rx_bytes, tx_bytes,
                    rx_mbps, tx_mbps, is_online, period, snapshot_at, logged_at
             FROM {$this->table}
             WHERE pelanggan_id = :pid
             ORDER BY snapshot_at DESC
             LIMIT :lim"
        );
        $stmt->bindValue(':pid', $pelangganId, PDO::PARAM_INT);
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Insert satu baris snapshot bandwidth
     */
    public function insertSnapshot(array $data): bool
{
    $stmt = $this->db->prepare("
        INSERT INTO usage_log
            (pelanggan_id, mac_address, rx_bytes, tx_bytes,
             rx_mbps, tx_mbps, is_online, period, snapshot_at)
        VALUES
            (:pelanggan_id, :mac_address, :rx_bytes, :tx_bytes,
             :rx_mbps, :tx_mbps, :is_online, :period, :snapshot_at)
    ");

    return $stmt->execute([
        ':pelanggan_id' => $data['pelanggan_id'],
        ':mac_address'  => $data['mac_address'],
        ':rx_bytes'     => $data['rx_bytes']    ?? 0,
        ':tx_bytes'     => $data['tx_bytes']    ?? 0,
        ':rx_mbps'      => $data['rx_mbps']     ?? 0.0,
        ':tx_mbps'      => $data['tx_mbps']     ?? 0.0,
        ':is_online'    => $data['is_online']   ?? 0,
        ':period'       => $data['period']      ?? 'hourly',
        ':snapshot_at'  => $data['snapshot_at'] ?? date('Y-m-d H:i:s'),
    ]);
}

    /**
     * Cek apakah sudah ada snapshot dalam window tertentu
     */
    public function hasRecentSnapshot(int $pelangganId, int $windowMinutes = 50): bool
    {
        $windowMinutes = (int) $windowMinutes;
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM {$this->table}
             WHERE pelanggan_id = :id
             AND snapshot_at >= NOW() - INTERVAL {$windowMinutes} MINUTE"
        );
        $stmt->bindValue(':id', $pelangganId, PDO::PARAM_INT);
        $stmt->execute();
        return (int) $stmt->fetchColumn() > 0;
    }

    public function getUsageToday(int $pelangganId): ?array
    {
        $stmt = $this->db->prepare(
            "SELECT
                SUM(rx_bytes)  AS rx_bytes,
                SUM(tx_bytes)  AS tx_bytes,
                MAX(rx_mbps)   AS peak_rx_mbps,
                MAX(tx_mbps)   AS peak_tx_mbps,
                SUM(is_online) AS online_snapshots,
                COUNT(*)       AS total_snapshots
             FROM {$this->table}
             WHERE pelanggan_id = :id
             AND DATE(snapshot_at) = CURDATE()"
        );
        $stmt->execute([':id' => $pelangganId]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function getUsageMonth(int $pelangganId, string $ym): ?array
    {
        [$y, $m] = explode('-', $ym);
        $stmt = $this->db->prepare(
            "SELECT
                SUM(rx_bytes)    AS rx_bytes,
                SUM(tx_bytes)    AS tx_bytes,
                MAX(rx_mbps)     AS peak_rx_mbps,
                MAX(tx_mbps)     AS peak_tx_mbps,
                SUM(is_online)   AS online_snapshots,
                COUNT(*)         AS total_snapshots,
                MIN(snapshot_at) AS first_seen,
                MAX(snapshot_at) AS last_active
             FROM {$this->table}
             WHERE pelanggan_id = :id
             AND YEAR(snapshot_at)  = :y
             AND MONTH(snapshot_at) = :m"
        );
        $stmt->execute([':id' => $pelangganId, ':y' => (int)$y, ':m' => (int)$m]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function getMonthlySummaryAll(string $ym): array
    {
        [$y, $m] = explode('-', $ym);
        $stmt = $this->db->prepare(
            "SELECT
                ul.pelanggan_id,
                p.nama_lengkap,
                p.mac_address,
                pk.nama_paket,
                pk.kecepatan,
                SUM(ul.rx_bytes)   AS rx_bytes,
                SUM(ul.tx_bytes)   AS tx_bytes,
                MAX(ul.rx_mbps)    AS peak_rx_mbps,
                MAX(ul.tx_mbps)    AS peak_tx_mbps,
                SUM(ul.is_online)  AS online_snapshots,
                MAX(ul.snapshot_at) AS last_active
             FROM {$this->table} ul
             LEFT JOIN pelanggan p  ON ul.pelanggan_id = p.id
             LEFT JOIN paket     pk ON p.paket_id      = pk.id
             WHERE YEAR(ul.snapshot_at)  = :y
             AND   MONTH(ul.snapshot_at) = :m
             GROUP BY ul.pelanggan_id, p.nama_lengkap, p.mac_address,
                      pk.nama_paket, pk.kecepatan
             ORDER BY rx_bytes DESC"
        );
        $stmt->execute([':y' => (int)$y, ':m' => (int)$m]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Hapus log lebih lama dari tanggal tertentu
     */
    public function pruneOlderThan(string $beforeDate): int
    {
        $stmt = $this->db->prepare(
            "DELETE FROM {$this->table} WHERE snapshot_at < :before"
        );
        $stmt->execute([':before' => $beforeDate]);
        return $stmt->rowCount();
    }

    /**
     * Hapus snapshot lebih lama dari N hari
     */
    public function pruneOld(int $days = 90): int
    {
        $days = (int) $days;
        $stmt = $this->db->prepare(
            "DELETE FROM {$this->table}
             WHERE snapshot_at < NOW() - INTERVAL {$days} DAY"
        );
        $stmt->execute();
        return $stmt->rowCount();
    }

    /**
     * Ringkasan harian
     */
    public function getDailySummary(string $date): array
    {
        $stmt = $this->db->prepare(
            "SELECT pelanggan_id, mac_address,
                    SUM(rx_bytes)  AS total_rx,
                    SUM(tx_bytes)  AS total_tx,
                    AVG(rx_mbps)   AS avg_rx_mbps,
                    AVG(tx_mbps)   AS avg_tx_mbps,
                    MAX(is_online) AS was_online
             FROM {$this->table}
             WHERE DATE(snapshot_at) = :date AND period = 'hourly'
             GROUP BY pelanggan_id, mac_address
             ORDER BY total_rx DESC"
        );
        $stmt->execute([':date' => $date]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // =========================================================================
    // CRON LOG
    // ✅ FIXED: Menggunakan 'ran_at' (bukan 'created_at')
    // ✅ FIXED: Menggunakan 'rows_affected' (bukan 'processed')
    // =========================================================================

    public function logCron(
        string $jobName,
        string $status,
        int    $processed = 0,
        int    $durationMs = 0,
        string $message = ''
    ): void {
        try {
            $this->db->prepare(
                "INSERT INTO cron_log (job_name, status, rows_affected, duration_ms, message, ran_at)
                 VALUES (:job, :status, :rows, :dur, :msg, NOW())"
            )->execute([
                ':job'    => $jobName,
                ':status' => $status,
                ':rows'   => $processed,
                ':dur'    => $durationMs,
                ':msg'    => mb_substr($message, 0, 1000),
            ]);
        } catch (\Throwable) {
            // Jangan throw — logger tidak boleh crash cron
        }
    }

    public function getCronLogs(int $limit = 100): array
    {
        $stmt = $this->db->prepare(
            "SELECT * FROM cron_log ORDER BY ran_at DESC LIMIT :lim"
        );
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getCronSummary(): array
    {
        return $this->db->query(
            "SELECT
                job_name,
                MAX(ran_at)            AS last_run,
                AVG(duration_ms)       AS avg_duration_ms,
                SUM(status='ok')       AS success_count,
                SUM(status='error')    AS error_count,
                COUNT(*)               AS total_runs
             FROM cron_log
             WHERE ran_at >= NOW() - INTERVAL 30 DAY
             GROUP BY job_name
             ORDER BY last_run DESC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function pruneCronLogs(int $days = 30): int
    {
        $days = (int) $days;
        $stmt = $this->db->prepare(
            "DELETE FROM cron_log WHERE ran_at < NOW() - INTERVAL {$days} DAY"
        );
        $stmt->execute();
        return $stmt->rowCount();
    }
}
