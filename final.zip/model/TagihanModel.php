<?php
declare(strict_types=1);

namespace Model;

use PDO;

class TagihanModel extends BaseModel
{
    protected string $table      = 'tagihan';
    protected string $primaryKey = 'id';

    public function __construct()
    {
        parent::__construct();
        $this->migrateStatus();
        $this->migrateColumns();
    }

    private function migrateStatus(): void
    {
        try {
            $this->db->exec(
                "ALTER TABLE tagihan MODIFY COLUMN status
                 ENUM('paid','unpaid','suspend','cancel') NOT NULL DEFAULT 'unpaid'"
            );
        } catch (\Throwable) {}
    }

    private function migrateColumns(): void
    {
        $alters = [
            "ALTER TABLE tagihan ADD COLUMN metode_pembayaran VARCHAR(50)  NULL DEFAULT NULL",
            "ALTER TABLE tagihan ADD COLUMN penerima          VARCHAR(100) NULL DEFAULT NULL",
            "ALTER TABLE tagihan ADD COLUMN tipe      ENUM('paket','pemasangan','perbaikan','lainnya') NOT NULL DEFAULT 'paket'",
            "ALTER TABLE tagihan ADD COLUMN deskripsi VARCHAR(255) NULL DEFAULT NULL",
        ];
        foreach ($alters as $sql) {
            try { $this->db->exec($sql); } catch (\Throwable) {}
        }
    }

    public function getAll(): array
    {
        return $this->castRows($this->db->query(
            "SELECT t.*, p.nama_lengkap, p.no_telp, p.alamat,
                    pk.nama_paket, pk.harga, pk.kecepatan
             FROM tagihan t
             JOIN pelanggan p  ON t.pelanggan_id = p.id
             JOIN paket     pk ON p.paket_id     = pk.id
             ORDER BY t.id DESC"
        )->fetchAll(\PDO::FETCH_ASSOC));
    }

    private function castRow(array $row): array
    {
        $row['total'] = (float)($row['total'] ?? 0);
        $row['harga'] = (float)($row['harga'] ?? 0);
        return $row;
    }

    private function castRows(array $rows): array
    {
        return array_map([$this, 'castRow'], $rows);
    }

    public function getRecent(int $limit = 10): array
    {
        $result = $this->db->query(
            "SELECT t.*, p.nama_lengkap, pk.nama_paket
             FROM tagihan t
             JOIN pelanggan p  ON t.pelanggan_id = p.id
             JOIN paket     pk ON p.paket_id      = pk.id
             ORDER BY t.id DESC LIMIT $limit"
        )->fetchAll(PDO::FETCH_ASSOC);
        return $this->castRows($result);
    }

    public function totalPendapatanBulanIni(): float
    {
        $sql = "SELECT COALESCE(SUM(total),0) FROM tagihan
                WHERE status='paid'
                AND MONTH(tgl_bayar)=MONTH(CURDATE())
                AND YEAR(tgl_bayar)=YEAR(CURDATE())";
        return (float) $this->db->query($sql)->fetchColumn();
    }

    public function countPaid(): int
    {
        return (int) $this->db->query("SELECT COUNT(*) FROM tagihan WHERE status = 'paid'")->fetchColumn();
    }

    public function countUnpaid(): int
    {
        return (int) $this->db->query("SELECT COUNT(*) FROM tagihan WHERE status = 'unpaid'")->fetchColumn();
    }

    public function totalPiutang(): float
    {
        return (float) $this->db->query("SELECT COALESCE(SUM(total),0) FROM tagihan WHERE status='unpaid'")->fetchColumn();
    }

    public function getFiltered(?string $status, ?string $bulan, ?string $tipe = null): array
    {
        $where  = [];
        $params = [];

        if ($status) { $where[] = "t.status = :status";       $params['status'] = $status; }
        if ($bulan)  { $where[] = "t.periode_bulan = :bulan"; $params['bulan']  = $bulan; }
        if ($tipe)   { $where[] = "t.tipe = :tipe";           $params['tipe']   = $tipe; }

        $sql = "SELECT t.*, p.nama_lengkap, p.no_telp, p.alamat,
                       pk.nama_paket, pk.harga, pk.kecepatan
                FROM tagihan t
                JOIN pelanggan p  ON t.pelanggan_id = p.id
                JOIN paket     pk ON p.paket_id     = pk.id"
             . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
             . " ORDER BY t.id DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $this->castRows($stmt->fetchAll(\PDO::FETCH_ASSOC));
    }

    /** Detail satu tagihan */
    public function getDetail(int $id): ?array
    {
        $stmt = $this->db->prepare(
            "SELECT t.*, p.nama_lengkap, p.no_telp, p.alamat,
                    pk.nama_paket, pk.harga, pk.kecepatan
             FROM tagihan t
             JOIN pelanggan p  ON t.pelanggan_id = p.id
             JOIN paket     pk ON p.paket_id     = pk.id
             WHERE t.id = :id LIMIT 1"
        );
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$row) return null;

        $row['total'] = (float)($row['total'] ?? 0);
        $row['harga'] = (float)($row['harga'] ?? 0);
        return $row;
    }

    /** Tandai tagihan sebagai lunas */
    public function tandaiLunas(int $id, string $metode = '', string $penerima = ''): bool
    {
        $stmt = $this->db->prepare(
            "UPDATE tagihan
             SET status='paid', tgl_bayar=NOW(),
                 metode_pembayaran = :metode,
                 penerima          = :penerima
             WHERE id=:id"
        );
        return $stmt->execute([
            'id'       => $id,
            'metode'   => $metode   ?: null,
            'penerima' => $penerima ?: null,
        ]);
    }

    public function getRekapPendapatanBulanan(int $months = 12): array
    {
        $stmt = $this->db->prepare(
            "SELECT
                DATE_FORMAT(jatuh_tempo, '%b %Y') AS bulan,
                COALESCE(SUM(CASE WHEN status='paid'   THEN total ELSE 0 END), 0) AS paid,
                COALESCE(SUM(CASE WHEN status='unpaid' THEN total ELSE 0 END), 0) AS unpaid
             FROM tagihan
             WHERE jatuh_tempo >= DATE_SUB(CURDATE(), INTERVAL :m MONTH)
             GROUP BY YEAR(jatuh_tempo), MONTH(jatuh_tempo),
                      DATE_FORMAT(jatuh_tempo, '%Y-%m'),
                      DATE_FORMAT(jatuh_tempo, '%b %Y')
             ORDER BY YEAR(jatuh_tempo) ASC, MONTH(jatuh_tempo) ASC"
        );
        $stmt->bindValue(':m', $months, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function isDuplicate(int $pelangganId, string $periodeBulan): bool
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM tagihan
             WHERE pelanggan_id = :pid AND periode_bulan = :bulan AND tipe = 'paket'"
        );
        $stmt->execute(['pid' => $pelangganId, 'bulan' => $periodeBulan]);
        return (int) $stmt->fetchColumn() > 0;
    }

    public function buat(int $pelangganId, string $tipe, string $deskripsi, string $periodeBulan, string $jatuhTempo, float $total): int
    {
        $stmt = $this->db->prepare(
            "INSERT INTO tagihan (pelanggan_id, tipe, deskripsi, periode_bulan, jatuh_tempo, total, status)
             VALUES (:pid, :tipe, :deskripsi, :bulan, :tempo, :total, 'unpaid')"
        );
        $ok = $stmt->execute([
            'pid'       => $pelangganId,
            'tipe'      => $tipe,
            'deskripsi' => $deskripsi ?: null,
            'bulan'     => $periodeBulan,
            'tempo'     => $jatuhTempo,
            'total'     => $total,
        ]);
        return $ok ? (int) $this->db->lastInsertId() : 0;
    }

    public function generateBulanan(string $bulan): int
    {
        $pelanggans = $this->db->query(
            "SELECT p.id, p.tgl_jatuh_tempo, pk.harga
             FROM pelanggan p
             JOIN paket pk ON p.paket_id = pk.id"
        )->fetchAll(\PDO::FETCH_ASSOC);

        $count = 0;
        [$y, $m] = explode('-', $bulan);

        foreach ($pelanggans as $p) {
            if ($this->isDuplicate((int) $p['id'], $bulan)) continue;
            $hari  = min((int) $p['tgl_jatuh_tempo'], (int) date('t', mktime(0, 0, 0, (int)$m, 1, (int)$y)));
            $tempo = sprintf('%04d-%02d-%02d', $y, $m, $hari);
            if ($this->buat((int) $p['id'], 'paket', '', $bulan, $tempo, (float) $p['harga'])) {
                $count++;
            }
        }

        return $count;
    }

    public function ubah(int $id, string $tipe, string $deskripsi, string $periodeBulan, string $jatuhTempo, float $total, string $status, string $metode = '', string $penerima = ''): bool
    {
        $stmt = $this->db->prepare(
            "UPDATE tagihan SET
                tipe              = :tipe,
                deskripsi         = :deskripsi,
                periode_bulan     = :bulan,
                jatuh_tempo       = :tempo,
                total             = :total,
                status            = :status,
                metode_pembayaran = CASE WHEN :s2='paid' THEN COALESCE(NULLIF(:metode,''), metode_pembayaran) ELSE metode_pembayaran END,
                penerima          = CASE WHEN :s3='paid' THEN COALESCE(NULLIF(:penerima,''), penerima) ELSE penerima END,
                tgl_bayar         = IF(:s4='paid', IFNULL(tgl_bayar, NOW()), NULL)
             WHERE id = :id"
        );
        return $stmt->execute([
            'tipe'      => $tipe,
            'deskripsi' => $deskripsi ?: null,
            'bulan'     => $periodeBulan,
            'tempo'     => $jatuhTempo,
            'total'     => $total,
            'status'    => $status,
            's2'        => $status,
            's3'        => $status,
            's4'        => $status,
            'metode'    => $metode,
            'penerima'  => $penerima,
            'id'        => $id,
        ]);
    }

    public function ubahStatus(int $id, string $status): bool
    {
        $stmt = $this->db->prepare(
            "UPDATE tagihan
             SET status    = :status,
                 tgl_bayar = IF(:status2 = 'paid', IFNULL(tgl_bayar, NOW()), NULL)
             WHERE id = :id"
        );
        return $stmt->execute([
            'status'  => $status,
            'status2' => $status,
            'id'      => $id,
        ]);
    }

    public function hapus(int $id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM tagihan WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
}
