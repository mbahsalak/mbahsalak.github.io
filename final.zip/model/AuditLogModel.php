<?php
/**
 * model/AuditLogModel.php
 */

declare(strict_types=1);

namespace Model;

use PDO;

class AuditLogModel extends BaseModel
{
    protected string $table      = 'audit_logs';
    protected string $primaryKey = 'id';

    /** Catat aktivitas + IP otomatis */
    public function log(int $userId, string $aktivitas): void
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? null;
        $this->insert([
            'user_id'    => $userId,
            'aktivitas'  => $aktivitas,
            'ip_address' => $ip,
        ]);
    }

    /** Semua log (dengan JOIN ke users untuk username & role) */
    public function getAll(int $limit = 300): array
    {
        $stmt = $this->db->prepare(
            "SELECT al.*, u.username, u.role
             FROM audit_logs al
             LEFT JOIN users u ON al.user_id = u.id
             ORDER BY al.created_at DESC LIMIT :lim"
        );
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Filter by rentang tanggal, opsional filter user_id */
    public function getByDateRange(string $from, string $to, ?int $userId = null): array
    {
        $where  = ["DATE(al.created_at) BETWEEN :from AND :to"];
        $params = ['from' => $from, 'to' => $to];

        if ($userId !== null) {
            $where[]           = "al.user_id = :uid";
            $params['uid']     = $userId;
        }

        $stmt = $this->db->prepare(
            "SELECT al.*, u.username, u.role
             FROM audit_logs al
             LEFT JOIN users u ON al.user_id = u.id
             WHERE " . implode(' AND ', $where) . "
             ORDER BY al.created_at DESC"
        );
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Log milik satu user */
    public function getByUser(int $userId, int $limit = 50): array
    {
        $stmt = $this->db->prepare(
            "SELECT al.*, u.username, u.role
             FROM audit_logs al
             LEFT JOIN users u ON al.user_id = u.id
             WHERE al.user_id = :uid
             ORDER BY al.created_at DESC LIMIT :lim"
        );
        $stmt->bindValue(':uid', $userId, PDO::PARAM_INT);
        $stmt->bindValue(':lim', $limit,  PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Alias untuk tampilan dashboard */
    public function getRecent(int $limit = 100): array
    {
        return $this->getAll($limit);
    }

    /** Hapus log lebih lama dari N hari, kembalikan jumlah baris terhapus */
    public function pruneOlderThan(int $days): int
    {
        $stmt = $this->db->prepare(
            "DELETE FROM audit_logs
             WHERE created_at < NOW() - INTERVAL :days DAY"
        );
        $stmt->bindValue(':days', $days, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->rowCount();
    }
}
