<?php
declare(strict_types=1);

namespace Model;

use PDO;

class SettingModel
{
    private PDO $db;

    private array $defaults = [
        ['key' => 'app_name',        'value' => 'Billing ISP',                              'label' => 'Nama Aplikasi',        'group' => 'app',     'type' => 'text'],
        ['key' => 'app_tagline',     'value' => 'Sistem Billing Internet Service Provider', 'label' => 'Tagline',              'group' => 'app',     'type' => 'text'],
        ['key' => 'app_description', 'value' => '',  'label' => 'Deskripsi Website',  'group' => 'app',     'type' => 'textarea'],
        ['key' => 'app_favicon',     'value' => '',  'label' => 'Favicon',            'group' => 'app',     'type' => 'text'],
        ['key' => 'app_logo',        'value' => '',  'label' => 'Logo ISP',           'group' => 'app',     'type' => 'image'],
        ['key' => 'company_name',    'value' => '', 'label' => 'Nama Perusahaan',  'group' => 'company', 'type' => 'text'],
        ['key' => 'company_address', 'value' => '', 'label' => 'Alamat Kantor',    'group' => 'company', 'type' => 'textarea'],
        ['key' => 'company_phone',   'value' => '', 'label' => 'No. Telepon',      'group' => 'company', 'type' => 'text'],
        ['key' => 'company_email',   'value' => '', 'label' => 'Email',            'group' => 'company', 'type' => 'email'],
        ['key' => 'company_website', 'value' => '', 'label' => 'Website',          'group' => 'company', 'type' => 'text'],
        ['key' => 'company_npwp',    'value' => '', 'label' => 'NPWP',             'group' => 'company', 'type' => 'text'],
        ['key' => 'billing_due_day',        'value' => '5',    'label' => 'Hari Jatuh Tempo',          'group' => 'billing', 'type' => 'number'],
        ['key' => 'billing_late_fee',       'value' => '5000', 'label' => 'Denda Terlambat (Rp)',      'group' => 'billing', 'type' => 'number'],
        ['key' => 'billing_isolir_day',     'value' => '3',    'label' => 'Toleransi Isolir (hari)',   'group' => 'billing', 'type' => 'number'],
        ['key' => 'billing_tax_pct',        'value' => '0',    'label' => 'Pajak/PPN (%)',             'group' => 'billing', 'type' => 'number'],
        ['key' => 'billing_invoice_footer', 'value' => 'Terima kasih telah membayar tepat waktu.', 'label' => 'Footer Invoice', 'group' => 'billing', 'type' => 'textarea'],
        ['key' => 'msg_tagihan_baru',  'label' => 'Template Tagihan Baru',  'group' => 'pesan', 'type' => 'textarea',
         'value' => "Yth. {nama_pelanggan},\nTagihan internet Anda periode {periode} telah terbit.\nTotal: Rp {total}\nJatuh Tempo: {jatuh_tempo}\nSilakan lakukan pembayaran sebelum tanggal tersebut.\nTerima kasih, {nama_perusahaan}"],
        ['key' => 'msg_tagihan_lunas', 'label' => 'Template Konfirmasi Lunas', 'group' => 'pesan', 'type' => 'textarea',
         'value' => "Yth. {nama_pelanggan},\nPembayaran tagihan periode {periode} sebesar Rp {total} telah kami terima.\nTerima kasih telah membayar tepat waktu.\n{nama_perusahaan}"],
        ['key' => 'msg_jatuh_tempo',  'label' => 'Template Pengingat Jatuh Tempo', 'group' => 'pesan', 'type' => 'textarea',
         'value' => "Yth. {nama_pelanggan},\nTagihan internet Anda senilai Rp {total} akan jatuh tempo pada {jatuh_tempo}.\nSegera lakukan pembayaran untuk menghindari pemutusan layanan.\n{nama_perusahaan}"],
        ['key' => 'msg_isolir',       'label' => 'Template Notifikasi Isolir', 'group' => 'pesan', 'type' => 'textarea',
         'value' => "Yth. {nama_pelanggan},\nLayanan internet Anda telah diisolir karena tagihan belum dibayar sejak {jatuh_tempo}.\nHubungi kami untuk reaktivasi setelah melakukan pembayaran.\n{nama_perusahaan}"],
        ['key' => 'msg_wa_prefix',    'label' => 'Prefix Nomor WA (kode negara)', 'group' => 'pesan', 'type' => 'text', 'value' => '62'],
        ['key' => 'msg_footer',       'label' => 'Footer Pesan (tanda tangan)', 'group' => 'pesan', 'type' => 'text', 'value' => 'CS: {company_phone}'],
        ['key' => 'auth_banner_title',  'label' => 'Judul Banner Login',       'group' => 'auth', 'type' => 'text',     'value' => 'Selamat Datang'],
        ['key' => 'auth_banner_desc',   'label' => 'Deskripsi Banner Login',   'group' => 'auth', 'type' => 'textarea', 'value' => 'Kelola tagihan internet pelanggan Anda dengan mudah dan efisien.'],
        ['key' => 'auth_banner_image',  'label' => 'Gambar Banner (URL/path)', 'group' => 'auth', 'type' => 'text',     'value' => ''],
        ['key' => 'auth_show_register', 'label' => 'Tampilkan Link Register',  'group' => 'auth', 'type' => 'select',   'value' => 'no', 'options' => ['yes' => 'Ya', 'no' => 'Tidak']],
        ['key' => 'auth_info_title',    'label' => 'Judul Info Box',           'group' => 'auth', 'type' => 'text',     'value' => 'Billing ISP'],
        ['key' => 'auth_info_body',     'label' => 'Isi Info Box',             'group' => 'auth', 'type' => 'textarea', 'value' => 'Sistem manajemen tagihan internet terpadu untuk ISP lokal.'],
        ['key' => 'auth_primary_color', 'label' => 'Warna Utama Login',        'group' => 'auth', 'type' => 'color',    'value' => '#2563eb'],
    ];

    public function __construct()
    {
        // ✅ Sesuaikan dengan cara project Anda mendapatkan koneksi PDO
        // Jika menggunakan Core\Database singleton:
        $this->db = \Core\Database::getConnection();
        
        // ATAU jika membuat koneksi langsung:
        // $this->db = new PDO(
        //     'mysql:host=' . $_ENV['DB_HOST'] . ';dbname=' . $_ENV['DB_NAME'] . ';charset=utf8mb4',
        //     $_ENV['DB_USER'],
        //     $_ENV['DB_PASS'],
        //     [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        // );
    }

    /**
     * Pastikan semua default key ada di database.
     * Key baru ditambahkan tanpa menimpa value yang sudah ada.
     */
    public function mergeDefaults(): void
    {
        $stmtCheck = $this->db->prepare("SELECT COUNT(*) FROM settings WHERE setting_key = :k");
        $stmtInsert = $this->db->prepare("
            INSERT INTO settings (setting_key, value, label, group_name, type, options)
            VALUES (:key, :value, :label, :group_name, :type, :options)
        ");

        foreach ($this->defaults as $row) {
            $stmtCheck->execute([':k' => $row['key']]);
            if ((int) $stmtCheck->fetchColumn() === 0) {
                $stmtInsert->execute([
                    ':key'        => $row['key'],
                    ':value'      => $row['value'],
                    ':label'      => $row['label'],
                    ':group_name' => $row['group'],
                    ':type'       => $row['type'],
                    ':options'    => isset($row['options']) ? json_encode($row['options']) : null,
                ]);
            }
        }
    }

    public function get(string $key, mixed $default = null): mixed
    {
        $stmt = $this->db->prepare("SELECT value FROM settings WHERE setting_key = :k LIMIT 1");
        $stmt->execute([':k' => $key]);
        $row = $stmt->fetch();
        return $row ? $row['value'] : $default;
    }

    public function set(string $key, mixed $value): bool
    {
        $stmt = $this->db->prepare("
            INSERT INTO settings (setting_key, value) VALUES (:k, :v)
            ON DUPLICATE KEY UPDATE value = :v2
        ");
        return $stmt->execute([':k' => $key, ':v' => $value, ':v2' => $value]);
    }

    public function setMany(array $input): bool
    {
        $stmt = $this->db->prepare("
            INSERT INTO settings (setting_key, value) VALUES (:k, :v)
            ON DUPLICATE KEY UPDATE value = :v2
        ");

        $this->db->beginTransaction();
        try {
            foreach ($input as $key => $value) {
                $stmt->execute([':k' => $key, ':v' => $value, ':v2' => $value]);
            }
            $this->db->commit();
            return true;
        } catch (\Throwable $e) {
            $this->db->rollBack();
            error_log("SettingModel::setMany() ERROR: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Kembalikan semua setting dengan metadata lengkap.
     * Digunakan oleh SettingController::index() untuk tampilan tab.
     */
    public function getAllWithMeta(): array
    {
        $stmt = $this->db->query("
            SELECT setting_key AS `key`, value, label, group_name AS `group`, type, options
            FROM settings
            ORDER BY FIELD(group_name, 'app','company','billing','pesan','auth'), id ASC
        ");
        $rows = $stmt->fetchAll();

        // Decode options JSON kembali ke array
        foreach ($rows as &$row) {
            if (!empty($row['options']) && is_string($row['options'])) {
                $row['options'] = json_decode($row['options'], true);
            }
        }

        return $rows;
    }

    /**
     * Kembalikan pasangan key => value saja.
     * Digunakan oleh AuthController dan layout auth.php.
     */
    public function getAllKV(): array
    {
        $stmt = $this->db->query("SELECT setting_key, value FROM settings");
        $result = [];
        while ($row = $stmt->fetch()) {
            $result[$row['setting_key']] = $row['value'];
        }
        return $result;
    }
}
