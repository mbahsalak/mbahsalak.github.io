<?php
/**
 * model/PengaduanModel.php
 * ✅ Full support: latitude & longitude untuk lokasi pengaduan
 * ✅ Konsisten dengan Leaflet Maps di view
 */

declare(strict_types=1);

namespace Model;

use PDO;

class PengaduanModel extends BaseModel
{
    protected string $table      = 'pengaduan';
    protected string $primaryKey = 'id';

    /**
     * Ambil semua tiket dengan data pelanggan & paket
     * ✅ latitude & longitude otomatis terambil via pg.*
     */
    public function getAll(): array
    {
        return $this->db->query(
            "SELECT pg.*, 
                    p.nama_lengkap, p.no_telp, p.alamat,
                    u.username,
                    pk.nama_paket, pk.kecepatan
             FROM pengaduan pg
             JOIN pelanggan p   ON pg.pelanggan_id = p.id
             JOIN users     u   ON p.user_id       = u.id
             LEFT JOIN paket pk ON p.paket_id      = pk.id
             ORDER BY pg.id DESC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Detail tiket single
     * ✅ latitude & longitude otomatis terambil via pg.*
     */
    public function getDetail(int $id): ?array
    {
        $stmt = $this->db->prepare(
            "SELECT pg.*, 
                    p.nama_lengkap, p.no_telp, p.alamat,
                    p.latitude AS pelanggan_lat, p.longitude AS pelanggan_lng,
                    u.username,
                    pk.nama_paket, pk.kecepatan
             FROM pengaduan pg
             JOIN pelanggan p   ON pg.pelanggan_id = p.id
             JOIN users     u   ON p.user_id       = u.id
             LEFT JOIN paket pk ON p.paket_id      = pk.id
             WHERE pg.id = :id 
             LIMIT 1"
        );
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /**
     * Tiket open + proses untuk dashboard admin/teknisi
     */
    public function getOpenDanProses(int $limit = 10): array
    {
        $stmt = $this->db->prepare(
            "SELECT pg.*, p.nama_lengkap, p.no_telp
             FROM pengaduan pg
             JOIN pelanggan p ON pg.pelanggan_id = p.id
             WHERE pg.status IN ('open','proses')
             ORDER BY pg.id DESC 
             LIMIT :lim"
        );
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Tiket milik pelanggan tertentu
     */
    public function getByPelanggan(int $pelangganId): array
    {
        $stmt = $this->db->prepare(
            "SELECT pg.*, pk.nama_paket
             FROM pengaduan pg
             LEFT JOIN paket pk ON pg.paket_id = pk.id
             WHERE pg.pelanggan_id = :id 
             ORDER BY pg.id DESC"
        );
        $stmt->execute(['id' => $pelangganId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Buat tiket baru
     * ✅ Support latitude & longitude
     */
    public function create(array $data): int
    {
        // Sanitasi input
        $pelangganId = (int)($data['pelanggan_id'] ?? 0);
        $judul       = trim($data['judul'] ?? '');
        $deskripsi   = trim($data['deskripsi'] ?? '');
        
        // Sanitasi koordinat
        $latitude  = $this->sanitizeCoordinate($data['latitude'] ?? null);
        $longitude = $this->sanitizeCoordinate($data['longitude'] ?? null);

        // Validasi
        if ($pelangganId <= 0) {
            throw new \InvalidArgumentException('Pelanggan harus dipilih.');
        }
        if (strlen($judul) < 3) {
            throw new \InvalidArgumentException('Judul minimal 3 karakter.');
        }
        if (strlen($deskripsi) < 10) {
            throw new \InvalidArgumentException('Deskripsi minimal 10 karakter.');
        }

        // Pastikan latitude & longitude diisi bersamaan
        if (($latitude === null) !== ($longitude === null)) {
            $latitude = null;
            $longitude = null;
        }

        // Validasi rentang koordinat
        if ($latitude !== null && $longitude !== null) {
            if ($latitude < -90 || $latitude > 90) {
                throw new \InvalidArgumentException('Latitude tidak valid (harus -90 s/d 90).');
            }
            if ($longitude < -180 || $longitude > 180) {
                throw new \InvalidArgumentException('Longitude tidak valid (harus -180 s/d 180).');
            }
        }

        $stmt = $this->db->prepare(
            "INSERT INTO pengaduan 
                (pelanggan_id, judul, deskripsi, status, latitude, longitude, created_at, updated_at)
             VALUES 
                (:pelanggan_id, :judul, :deskripsi, 'open', :latitude, :longitude, NOW(), NOW())"
        );
        
        $stmt->execute([
            'pelanggan_id' => $pelangganId,
            'judul'        => $judul,
            'deskripsi'    => $deskripsi,
            'latitude'     => $latitude,
            'longitude'    => $longitude,
        ]);

        return (int)$this->db->lastInsertId();
    }

    /**
     * Update status tiket
     */
    public function updateStatus(int $id, string $status): bool
    {
        $allowed = ['open', 'proses', 'selesai'];
        if (!in_array($status, $allowed, true)) {
            throw new \InvalidArgumentException('Status tidak valid.');
        }

        $stmt = $this->db->prepare(
            "UPDATE pengaduan SET status = :status, updated_at = NOW() WHERE id = :id"
        );
        return $stmt->execute([
            'status' => $status,
            'id'     => $id,
        ]);
    }

    /**
     * Update lokasi tiket (jika diperlukan)
     */
    public function updateLocation(int $id, ?float $latitude, ?float $longitude): bool
    {
        $stmt = $this->db->prepare(
            "UPDATE pengaduan 
             SET latitude = :lat, longitude = :lng, updated_at = NOW() 
             WHERE id = :id"
        );
        return $stmt->execute([
            'lat' => $latitude,
            'lng' => $longitude,
            'id'  => $id,
        ]);
    }

    /**
     * Hitung tiket open
     */
    public function countOpen(): int
    {
        return (int)$this->db->query(
            "SELECT COUNT(*) FROM pengaduan WHERE status = 'open'"
        )->fetchColumn();
    }

    /**
     * Hitung tiket proses
     */
    public function countProses(): int
    {
        return (int)$this->db->query(
            "SELECT COUNT(*) FROM pengaduan WHERE status = 'proses'"
        )->fetchColumn();
    }

    /**
     * Hitung tiket selesai
     */
    public function countSelesai(): int
    {
        return (int)$this->db->query(
            "SELECT COUNT(*) FROM pengaduan WHERE status = 'selesai'"
        )->fetchColumn();
    }

    /**
     * Ambil semua tiket yang punya lokasi (untuk peta)
     */
    public function getAllWithLocation(): array
    {
        return $this->db->query(
            "SELECT pg.id, pg.judul, pg.status, pg.latitude, pg.longitude, pg.created_at,
                    p.nama_lengkap, p.no_telp
             FROM pengaduan pg
             JOIN pelanggan p ON pg.pelanggan_id = p.id
             WHERE pg.latitude IS NOT NULL AND pg.longitude IS NOT NULL
             ORDER BY pg.id DESC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Helper: Sanitasi koordinat
     */
    private function sanitizeCoordinate(mixed $value): ?float
    {
        if ($value === null || $value === '' || $value === false) {
            return null;
        }
        
        if (is_numeric($value)) {
            return (float)$value;
        }
        
        // Coba parse string
        $clean = preg_replace('/[^0-9.\-]/', '', (string)$value);
        return is_numeric($clean) ? (float)$clean : null;
    }

}
