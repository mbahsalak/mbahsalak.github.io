<?php
/**
 * model/ODPModel.php
 * Model ODP (Optical Distribution Point)
 * Schema: id, nama_odp, latitude, longitude, kapasitas, terpasang
 */

declare(strict_types=1);

namespace Model;

use PDO;

class ODPModel extends BaseModel
{
    protected string $table      = 'odp';
    protected string $primaryKey = 'id';

    public function getAll(): array
    {
        return $this->db->query(
            "SELECT * FROM odp ORDER BY nama_odp ASC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function create(array $data): int         { return $this->insert($data); }
    public function edit(int $id, array $data): bool  { return $this->update($id, $data); }
    public function hapus(int $id): bool              { return $this->delete($id); }

    /**
     * count() — total ODP (dipanggil Dashboard: $odpM->count())
     * Override BaseModel::count() agar eksplisit
     */
    public function count(): int
    {
        return (int) $this->db->query(
            "SELECT COUNT(*) FROM odp"
        )->fetchColumn();
    }

    /**
     * countAktif() — schema tidak punya kolom status,
     * jadi anggap semua ODP = aktif → sama dengan count()
     */
    public function countAktif(): int
    {
        return $this->count();
    }

    public function incrementTerpasang(int $id): void
    {
        $this->db->prepare(
            "UPDATE odp SET terpasang = terpasang + 1 WHERE id = :id"
        )->execute(['id' => $id]);
    }

    public function decrementTerpasang(int $id): void
    {
        $this->db->prepare(
            "UPDATE odp SET terpasang = GREATEST(terpasang - 1, 0) WHERE id = :id"
        )->execute(['id' => $id]);
    }

    public function getOptions(): array
    {
        return $this->db->query(
            "SELECT id, nama_odp, kapasitas, terpasang FROM odp ORDER BY nama_odp ASC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAllKoordinat(): array
    {
        return $this->db->query(
            "SELECT id, nama_odp, latitude, longitude, kapasitas, terpasang
             FROM odp
             WHERE latitude IS NOT NULL AND longitude IS NOT NULL"
        )->fetchAll(PDO::FETCH_ASSOC);
    }
}
