<?php
/**
 * model/PelangganModel.php
 * Model untuk mengelola data pelanggan
 */

declare(strict_types=1);

namespace Model;

use PDO;

class PelangganModel extends BaseModel
{
    protected string $table      = 'pelanggan';
    protected string $primaryKey = 'id';

    public function __construct()
    {
        parent::__construct();
        $this->migrateColumns();
    }

    private function migrateColumns(): void
    {
        // Tambah kolom status_internet jika belum ada
        try {
            $this->db->exec(
                "ALTER TABLE pelanggan
                 ADD COLUMN IF NOT EXISTS status_internet
                 ENUM('active','isolir','suspend') NOT NULL DEFAULT 'active'"
            );
        } catch (\Throwable) {}
    }

    /**
     * Mengambil semua data pelanggan dengan join ke user dan paket
     */
    public function getAll(): array
    {
        return $this->db->query(
            "SELECT p.*, u.username, u.status AS status_akun,
                    pk.nama_paket, pk.kecepatan, pk.harga,
                    o.nama_odp,
                    u.created_at AS tgl_install
             FROM pelanggan p
             LEFT JOIN users   u  ON p.user_id  = u.id
             LEFT JOIN paket   pk ON p.paket_id = pk.id
             LEFT JOIN odp     o  ON p.odp_id   = o.id
             ORDER BY p.id DESC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Mengambil detail satu pelanggan beserta informasi terkait
     */
    public function getDetail(int $id): ?array
    {
        $stmt = $this->db->prepare(
            "SELECT p.*, u.username, u.status AS status_akun,
                    pk.nama_paket, pk.kecepatan, pk.harga, pk.deskripsi AS paket_deskripsi
             FROM pelanggan p
             LEFT JOIN users   u  ON p.user_id  = u.id
             LEFT JOIN paket   pk ON p.paket_id = pk.id
             LEFT JOIN odp     o  ON p.odp_id   = o.id
             WHERE p.id = :id LIMIT 1"
        );
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function findByUserId(int $userId): ?array
    {
        return $this->whereFirst('user_id', $userId);
    }

    public function create(array $data): int
    {
        return $this->insert($data);
    }

    public function edit(int $id, array $data): bool
    {
        return $this->update($id, $data);
    }

    public function hapus(int $id): bool
    {
        return $this->delete($id);
    }

    public function count(): int
    {
        return (int) $this->db->query(
            "SELECT COUNT(*) FROM pelanggan"
        )->fetchColumn();
    }

    public function countBaruBulanIni(): int
    {
        return (int) $this->db->query(
            "SELECT COUNT(*) FROM pelanggan p
             JOIN users u ON p.user_id = u.id
             WHERE MONTH(u.created_at) = MONTH(CURDATE())
             AND   YEAR(u.created_at)  = YEAR(CURDATE())"
        )->fetchColumn();
    }

    /**
     * Mengambil koordinat untuk keperluan pemetaan
     */
    public function getAllKoordinat(): array
    {
        return $this->db->query(
            "SELECT p.id, p.nama_lengkap, p.latitude, p.longitude,
                    pk.nama_paket, p.mac_address
             FROM pelanggan p
             LEFT JOIN paket pk ON p.paket_id = pk.id
             WHERE p.latitude IS NOT NULL AND p.longitude IS NOT NULL"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Import pelanggan dari array CSV rows.
     * Support format export (nama lengkap, no. telepon, dst)
     * maupun format template (nama_lengkap, no_telp, dst).
     * Mengembalikan ['imported'=>int, 'skipped'=>int, 'errors'=>array]
     */
    public function importFromCsv(array $rows, \Model\UserModel $userModel): array
    {
        $imported = 0;
        $skipped  = 0;
        $errors   = [];

        // Mapping alias header → key standar
        // Key = berbagai kemungkinan nama kolom (lowercase, trimmed)
        $aliases = [
            'nama_lengkap'    => ['nama_lengkap', 'nama lengkap', 'nama', 'full name'],
            'username'        => ['username', 'user name', 'user'],
            'password'        => ['password', 'pass', 'kata sandi'],
            'no_telp'         => ['no_telp', 'no. telepon', 'no telepon', 'no. telp', 'no telp',
                                  'no. whatsapp', 'no whatsapp', 'telepon', 'phone', 'hp'],
            'alamat'          => ['alamat', 'address', 'alamat lengkap'],
            'paket_id'        => ['paket_id'],
            'odp_id'          => ['odp_id'],
            'tgl_jatuh_tempo' => ['tgl_jatuh_tempo', 'jatuh tempo', 'tgl jatuh tempo'],
            'koordinat'       => ['koordinat (lat,lng)', 'koordinat', 'lat,lng', 'koordinat(lat,lng)'],
            'latitude'        => ['latitude', 'lat'],
            'longitude'       => ['longitude', 'lng', 'long'],
        ];

        // Bangun map dari header aktual → key standar
        $firstRow = $rows[0] ?? [];
        $headerKeys = array_keys($firstRow);
        $keyMap = [];
        foreach ($aliases as $stdKey => $aliasList) {
            foreach ($aliasList as $alias) {
                if (in_array($alias, $headerKeys, true)) {
                    $keyMap[$stdKey] = $alias;
                    break;
                }
            }
        }

        // Helper ambil nilai dari row berdasarkan key standar
        $get = function(array $row, string $stdKey) use ($keyMap): string {
            if (isset($keyMap[$stdKey]) && array_key_exists($keyMap[$stdKey], $row)) {
                return trim($row[$keyMap[$stdKey]] ?? '');
            }
            return '';
        };

        // Cek apakah ada kolom paket & odp berdasarkan nama (bukan ID)
        $hasPaketNama = in_array('paket', $headerKeys) || in_array('nama_paket', $headerKeys) || in_array('nama paket', $headerKeys);
        $paketNamaKey = in_array('paket', $headerKeys) ? 'paket'
                      : (in_array('nama_paket', $headerKeys) ? 'nama_paket' : 'nama paket');

        $hasOdpNama   = in_array('odp', $headerKeys) || in_array('nama_odp', $headerKeys);
        $odpNamaKey   = in_array('odp', $headerKeys) ? 'odp' : 'nama_odp';

        foreach ($rows as $lineNo => $row) {
            $line = $lineNo + 2;

            $nama     = $get($row, 'nama_lengkap');
            $username = $get($row, 'username');
            $password = $get($row, 'password');
            $no_telp  = $get($row, 'no_telp');
            $alamat   = $get($row, 'alamat');
            $jatuh_tempo = (int)($get($row, 'tgl_jatuh_tempo') ?: 5);

            // Parse koordinat — bisa dari kolom gabungan "lat,lng" atau kolom terpisah
            $lat = $get($row, 'latitude');
            $lng = $get($row, 'longitude');
            if ((!$lat || !$lng) && $get($row, 'koordinat') !== '') {
                $parts = explode(',', $get($row, 'koordinat'), 2);
                if (count($parts) === 2) {
                    $lat = trim($parts[0]);
                    $lng = trim($parts[1]);
                }
            }
            $lat = ($lat !== '' && $lat !== null) ? (float)$lat : null;
            $lng = ($lng !== '' && $lng !== null) ? (float)$lng : null;

            // Password otomatis dari no_telp jika tidak diisi
            if (!$password && $no_telp) {
                $password = preg_replace('/\D/', '', $no_telp); // hanya angka
            }
            // Fallback: nama depan + 123
            if (!$password && $nama) {
                $password = strtolower(explode(' ', trim($nama))[0]) . '123';
            }

            // Resolve paket_id: dari kolom paket_id langsung, atau lookup nama paket
            $paket_id = (int)$get($row, 'paket_id');
            if (!$paket_id && $hasPaketNama && !empty($row[$paketNamaKey])) {
                $paket_id = $this->findPaketIdByNama(trim($row[$paketNamaKey]));
            }

            // Resolve odp_id: dari kolom odp_id langsung, atau lookup nama odp
            $odp_id = (int)$get($row, 'odp_id') ?: null;
            if (!$odp_id && $hasOdpNama && !empty($row[$odpNamaKey])) {
                $odp_id = $this->findOdpIdByNama(trim($row[$odpNamaKey]));
            }

            // Validasi kolom wajib
            if (!$nama) {
                $errors[] = "Baris {$line}: kolom nama tidak ditemukan atau kosong.";
                $skipped++; continue;
            }
            if (!$username) {
                $errors[] = "Baris {$line}: kolom username tidak ditemukan atau kosong.";
                $skipped++; continue;
            }
            if (!$no_telp) {
                $errors[] = "Baris {$line}: kolom no_telp tidak ditemukan atau kosong.";
                $skipped++; continue;
            }

            if ($userModel->isUsernameTaken($username)) {
                $errors[] = "Baris {$line}: username \"{$username}\" sudah digunakan, dilewati.";
                $skipped++; continue;
            }

            try {
                $userId = $userModel->create([
                    'username' => $username,
                    'password' => \Core\Auth::hashPassword($password),
                    'role'     => 'pelanggan',
                    'status'   => 'active',
                ]);

                $this->insert([
                    'user_id'         => $userId,
                    'nama_lengkap'    => $nama,
                    'no_telp'         => $no_telp,
                    'alamat'          => $alamat,
                    'latitude'        => $lat,
                    'longitude'       => $lng,
                    'paket_id'        => $paket_id ?: null,
                    'odp_id'          => $odp_id,
                    'tgl_jatuh_tempo' => $jatuh_tempo,
                ]);

                $imported++;
            } catch (\Throwable $e) {
                $errors[] = "Baris {$line}: gagal import — " . $e->getMessage();
                $skipped++;
            }
        }

        return compact('imported', 'skipped', 'errors');
    }

    private function findPaketIdByNama(string $nama): int
    {
        try {
            $stmt = $this->db->prepare("SELECT id FROM paket WHERE nama_paket = ? LIMIT 1");
            $stmt->execute([$nama]);
            return (int)($stmt->fetchColumn() ?: 0);
        } catch (\Throwable) { return 0; }
    }

    private function findOdpIdByNama(string $nama): ?int
    {
        try {
            $stmt = $this->db->prepare("SELECT id FROM odp WHERE nama_odp = ? LIMIT 1");
            $stmt->execute([$nama]);
            $id = $stmt->fetchColumn();
            return $id ? (int)$id : null;
        } catch (\Throwable) { return null; }
    }

    public function updateStatusInternet(int $id, string $status): void
    {
        $stmt = $this->db->prepare(
            "UPDATE pelanggan SET status_internet = ? WHERE id = ?"
        );
        $stmt->execute([$status, $id]);
    }

    /** Semua pelanggan + nama paket + harga, untuk dropdown form tagihan */
    public function getAllWithPaket(): array
    {
        return $this->db->query(
            "SELECT p.id, p.nama_lengkap, p.no_telp, p.tgl_jatuh_tempo,
                    pk.nama_paket, pk.harga
             FROM pelanggan p
             JOIN paket pk ON p.paket_id = pk.id
             ORDER BY p.nama_lengkap ASC"
        )->fetchAll(\PDO::FETCH_ASSOC);
    }
    /**
 * Mengambil data penggunaan hari ini dari database untuk pelanggan tertentu
 */
public function getUsageTodayFromDb(int $pelangganId): array
{
    try {
        // Ambil total hari ini
        $stmt = $this->db->prepare("
            SELECT 
                COALESCE(rx_bytes, 0) AS rx_bytes,
                COALESCE(tx_bytes, 0) AS tx_bytes
            FROM usage_daily_summary 
            WHERE pelanggan_id = :id AND tanggal = CURDATE()
            LIMIT 1
        ");
        $stmt->execute([':id' => $pelangganId]);
        $daily = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['rx_bytes' => 0, 'tx_bytes' => 0];
        
        // Ambil data hourly untuk grafik
        $hourlyStmt = $this->db->prepare("
            SELECT 
                HOUR(snapshot_at) as hour,
                MAX(rx_bytes) as rx_bytes,
                MAX(tx_bytes) as tx_bytes
            FROM usage_log 
            WHERE pelanggan_id = :id AND DATE(snapshot_at) = CURDATE()
            GROUP BY HOUR(snapshot_at)
            ORDER BY hour ASC
        ");
        $hourlyStmt->execute([':id' => $pelangganId]);
        $hourly = $hourlyStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Isi jam yang kosong dengan 0
        $fullHourly = [];
        for ($h = 0; $h < 24; $h++) {
            $found = false;
            foreach ($hourly as $row) {
                if ((int)$row['hour'] === $h) {
                    $fullHourly[] = $row;
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                $fullHourly[] = ['hour' => $h, 'rx_bytes' => 0, 'tx_bytes' => 0];
            }
        }
        
        return [
            'rx_bytes' => (int)$daily['rx_bytes'],
            'tx_bytes' => (int)$daily['tx_bytes'],
            'hourly' => $fullHourly
        ];
    } catch (\Throwable $e) {
        \Core\Logger::error('PelangganModel', "getUsageTodayFromDb({$pelangganId}): " . $e->getMessage());
        return ['rx_bytes' => 0, 'tx_bytes' => 0, 'hourly' => []];
    }
}

/**
 * Mengambil data penggunaan bulan ini dari database untuk pelanggan tertentu
 */
public function getUsageMonthFromDb(int $pelangganId): array
{
    try {
        $ym = date('Y-m');
        
        // Ambil total bulan ini
        $stmt = $this->db->prepare("
            SELECT 
                COALESCE(total_rx_bytes, 0) AS rx_bytes,
                COALESCE(total_tx_bytes, 0) AS tx_bytes
            FROM usage_monthly_summary 
            WHERE pelanggan_id = :id AND month_year = :ym
            LIMIT 1
        ");
        $stmt->execute([':id' => $pelangganId, ':ym' => $ym]);
        $monthly = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['rx_bytes' => 0, 'tx_bytes' => 0];
        
        // Ambil data daily untuk grafik
        $dailyStmt = $this->db->prepare("
            SELECT 
                tanggal as date,
                COALESCE(rx_bytes, 0) as rx_bytes,
                COALESCE(tx_bytes, 0) as tx_bytes
            FROM usage_daily_summary 
            WHERE pelanggan_id = :id AND MONTH(tanggal) = MONTH(CURDATE()) AND YEAR(tanggal) = YEAR(CURDATE())
            ORDER BY tanggal ASC
        ");
        $dailyStmt->execute([':id' => $pelangganId]);
        $daily = $dailyStmt->fetchAll(PDO::FETCH_ASSOC);
        
        return [
            'rx_bytes' => (int)$monthly['rx_bytes'],
            'tx_bytes' => (int)$monthly['tx_bytes'],
            'daily' => $daily
        ];
    } catch (\Throwable $e) {
        \Core\Logger::error('PelangganModel', "getUsageMonthFromDb({$pelangganId}): " . $e->getMessage());
        return ['rx_bytes' => 0, 'tx_bytes' => 0, 'daily' => []];
    }
}

/**
 * Cek status online terakhir dari database
 */
public function isOnlineFromDb(int $pelangganId): bool
{
    try {
        $stmt = $this->db->prepare("
            SELECT is_online 
            FROM usage_log 
            WHERE pelanggan_id = :id 
            ORDER BY snapshot_at DESC 
            LIMIT 1
        ");
        $stmt->execute([':id' => $pelangganId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return (bool)($row['is_online'] ?? false);
    } catch (\Throwable $e) {
        \Core\Logger::error('PelangganModel', "isOnlineFromDb({$pelangganId}): " . $e->getMessage());
        return false;
    }
}

}
