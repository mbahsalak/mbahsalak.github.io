<?php
declare(strict_types=1);

namespace Model;

use Config\Database;
use PDO;

class KasModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    public function getFiltered(array $filters = []): array
    {
        $where  = [];
        $params = [];

        if (!empty($filters['bulan'])) {
            $where[] = "DATE_FORMAT(created_at, '%Y-%m') = :bulan";
            $params[':bulan'] = $filters['bulan'];
        }
        if (!empty($filters['tipe'])) {
            $where[] = "tipe = :tipe";
            $params[':tipe'] = $filters['tipe'];
        }
        if (!empty($filters['metode'])) {
            $where[] = "metode_pembayaran = :metode";
            $params[':metode'] = $filters['metode'];
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $stmt = $this->db->prepare("SELECT * FROM kas {$whereClause} ORDER BY created_at DESC, id DESC");
        $stmt->execute($params);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmtSum = $this->db->prepare("
            SELECT
                COALESCE(SUM(CASE WHEN tipe = 'masuk'  THEN jumlah ELSE 0 END), 0) AS masuk,
                COALESCE(SUM(CASE WHEN tipe = 'keluar' THEN jumlah ELSE 0 END), 0) AS keluar
            FROM kas {$whereClause}
        ");
        $stmtSum->execute($params);
        $sum = $stmtSum->fetch(PDO::FETCH_ASSOC);

        $masuk  = (float)($sum['masuk']  ?? 0);
        $keluar = (float)($sum['keluar'] ?? 0);

        return [
            'list'    => $list,
            'summary' => ['masuk' => $masuk, 'keluar' => $keluar, 'saldo' => $masuk - $keluar],
            'total'   => count($list),
        ];
    }

    public function getAll(): array
    {
        return $this->getFiltered([]);
    }

    public function getById(int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM kas WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    public function create(array $data): int
    {
        $stmt = $this->db->prepare("
            INSERT INTO kas (tipe, jumlah, keterangan, metode_pembayaran)
            VALUES (:tipe, :jumlah, :keterangan, :metode_pembayaran)
        ");
        $stmt->execute([
            ':tipe'               => $data['tipe'] ?? 'masuk',
            ':jumlah'             => (float)($data['jumlah'] ?? 0),
            ':keterangan'         => $data['keterangan'] ?? '',
            ':metode_pembayaran'  => $data['metode_pembayaran'] ?? null,
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id, array $data): bool
    {
        $stmt = $this->db->prepare("
            UPDATE kas SET
                tipe = :tipe,
                jumlah = :jumlah,
                keterangan = :keterangan,
                metode_pembayaran = :metode_pembayaran
            WHERE id = :id
        ");
        return $stmt->execute([
            ':tipe'               => $data['tipe'] ?? 'masuk',
            ':jumlah'             => (float)($data['jumlah'] ?? 0),
            ':keterangan'         => $data['keterangan'] ?? '',
            ':metode_pembayaran'  => $data['metode_pembayaran'] ?? null,
            ':id'                 => $id,
        ]);
    }

    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM kas WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    public function getSummary(): array
    {
        $stmt = $this->db->query("
            SELECT
                COALESCE(SUM(CASE WHEN tipe = 'masuk'  THEN jumlah ELSE 0 END), 0) AS masuk,
                COALESCE(SUM(CASE WHEN tipe = 'keluar' THEN jumlah ELSE 0 END), 0) AS keluar
            FROM kas
        ");
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $masuk  = (float)($row['masuk']  ?? 0);
        $keluar = (float)($row['keluar'] ?? 0);
        return ['masuk' => $masuk, 'keluar' => $keluar, 'saldo' => $masuk - $keluar];
    }

    // =========================================================================
    // LAPORAN BULANAN — untuk halaman laporan
    // =========================================================================

    public function getLaporanBulanan(int $tahun): array
    {
        $stmt = $this->db->prepare("
            SELECT
                MONTH(created_at) AS bulan,
                COALESCE(SUM(CASE WHEN tipe = 'masuk'  THEN jumlah ELSE 0 END), 0) AS masuk,
                COALESCE(SUM(CASE WHEN tipe = 'keluar' THEN jumlah ELSE 0 END), 0) AS keluar,
                COUNT(*) AS total_transaksi
            FROM kas
            WHERE YEAR(created_at) = :tahun
            GROUP BY MONTH(created_at)
            ORDER BY bulan ASC
        ");
        $stmt->execute([':tahun' => $tahun]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $namaBulan = [
            1=>'Januari',2=>'Februari',3=>'Maret',4=>'April',
            5=>'Mei',6=>'Juni',7=>'Juli',8=>'Agustus',
            9=>'September',10=>'Oktober',11=>'November',12=>'Desember'
        ];

        $data = [];
        foreach ($namaBulan as $b => $nama) {
            $data[$b] = [
                'bulan'           => $b,
                'nama_bulan'      => $nama,
                'masuk'           => 0,
                'keluar'          => 0,
                'saldo'           => 0,
                'total_transaksi' => 0,
            ];
        }
        foreach ($rows as $r) {
            $b = (int)$r['bulan'];
            $data[$b]['masuk']           = (float)$r['masuk'];
            $data[$b]['keluar']          = (float)$r['keluar'];
            $data[$b]['saldo']           = (float)$r['masuk'] - (float)$r['keluar'];
            $data[$b]['total_transaksi'] = (int)$r['total_transaksi'];
        }

        $totalMasuk = $totalKeluar = $totalTrx = 0;
        foreach ($data as $d) {
            $totalMasuk += $d['masuk'];
            $totalKeluar += $d['keluar'];
            $totalTrx += $d['total_transaksi'];
        }

        return [
            'data' => $data,
            'total' => [
                'masuk'           => $totalMasuk,
                'keluar'          => $totalKeluar,
                'saldo'           => $totalMasuk - $totalKeluar,
                'total_transaksi' => $totalTrx,
            ],
        ];
    }

    public function getTahunTersedia(): array
    {
        $stmt = $this->db->query("
            SELECT DISTINCT YEAR(created_at) AS tahun
            FROM kas
            WHERE created_at IS NOT NULL
            ORDER BY tahun DESC
        ");
        $rows = $stmt->fetchAll(PDO::FETCH_COLUMN);

        $years = array_map('intval', $rows);
        if (empty($years)) $years = [(int)date('Y')];
        if (!in_array((int)date('Y'), $years)) array_unshift($years, (int)date('Y'));
        return $years;
    }
}
