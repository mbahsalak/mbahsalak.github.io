<?php

declare(strict_types=1);

namespace Service;

use Core\MikrotikClient;
use Core\Logger;

/**
 * Service layer antara MikrotikController dan MikrotikClient.
 * Mengolah data mentah dari API menjadi format yang dibutuhkan controller.
 */
class MikrotikService
{
    private MikrotikClient $client;

    public function __construct(?MikrotikClient $client = null)
    {
        $this->client = $client ?? new MikrotikClient();
    }

    // =========================================================================
    // TEST KONEKSI
    // =========================================================================

    /**
     * Test koneksi ke MikroTik API server.
     * Return: ['success' => bool, 'message' => string, ...]
     */
    public function testConnection(): array
    {
        try {
            $connected = $this->client->isConnected;

            if ($connected) {
                // Coba ambil system resource sebagai validasi tambahan
                $resource = $this->client->get('/api/system/resource');
                return [
                    'success'  => true,
                    'message'  => 'Terhubung ke MikroTik API',
                    'identity' => $resource['board-name'] ?? 'MikroTik',
                    'version'  => $resource['version'] ?? '-',
                    'uptime'   => $resource['uptime'] ?? '-',
                    'url'      => $this->client->baseUrl,
                ];
            }

            return [
                'success' => false,
                'message' => 'Server tidak merespons. Pastikan Flask dummy berjalan: python 1.py',
                'url'     => $this->client->baseUrl,
            ];
        } catch (\Throwable $e) {
            Logger::error('MikrotikService', 'testConnection gagal: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => $e->getMessage(),
                'url'     => $this->client->baseUrl,
            ];
        }
    }

    // =========================================================================
    // DETAIL ROUTER BY MAC ADDRESS
    // =========================================================================

    /**
     * Ambil detail router berdasarkan MAC Address.
     * Return: ['success' => bool, 'data' => array|null, 'error' => string|null]
     */
    public function getRouterDetail(string $macAddress): array
    {
        try {
            // Validasi MAC address
            $mac = MikrotikClient::normalizeMac($macAddress);

            if (empty($mac) || strlen(preg_replace('/[^a-fA-F0-9]/', '', $mac)) !== 12) {
                return [
                    'success' => false,
                    'data'    => null,
                    'error'   => "Format MAC address tidak valid: {$macAddress}",
                ];
            }

            Logger::info('MikrotikService', "Fetching router detail for MAC: {$mac}");

            $data = $this->client->getRouterByMac($mac);

            // Normalisasi response ke format yang diharapkan controller
            return [
                'success' => true,
                'data'    => [
                    'mac_address'     => $data['mac_address']      ?? $mac,
                    'identity'        => $data['identity']          ?? 'Unknown',
                    'board_name'      => $data['board_name']        ?? $data['board-name'] ?? '-',
                    'version'         => $data['ros_version']       ?? $data['version'] ?? '-',
                    'architecture'    => $data['architecture_name'] ?? '-',
                    'uptime'          => $data['uptime']            ?? '-',
                    'uptime_seconds'  => $data['uptime_seconds']    ?? 0,
                    'cpu_count'       => $data['cpu_count']         ?? 1,
                    'cpu_load'        => $data['cpu_load']          ?? 0,
                    'cpu_frequency'   => $data['cpu_frequency']     ?? '-',
                    'total_memory'    => $data['total_memory']      ?? 0,
                    'free_memory'     => $data['free_memory']       ?? 0,
                    'total_hdd_space' => $data['total_hdd_space']   ?? 0,
                    'free_hdd_space'  => $data['free_hdd_space']    ?? 0,
                    'bandwidth_usage' => $data['bandwidth_usage']   ?? [
                        'rx_mbps' => 0,
                        'tx_mbps' => 0,
                    ],
                    'traffic'         => $data['traffic']           ?? [],
                    'interfaces'      => $data['interfaces']        ?? [],
                    'active_pppoe'    => $data['active_pppoe']      ?? 0,
                    'total_secrets'   => $data['total_secrets']     ?? 0,
                ],
                'error'   => null,
            ];
        } catch (\Throwable $e) {
            Logger::error('MikrotikService', "getRouterDetail({$macAddress}) gagal: " . $e->getMessage());
            return [
                'success' => false,
                'data'    => null,
                'error'   => $e->getMessage(),
            ];
        }
    }

    // =========================================================================
    // ACTIVE CLIENTS (MAC-based detection, BUKAN PPPoE)
    // =========================================================================

    /**
     * Ambil daftar klien aktif berdasarkan MAC address.
     * Sumber: DHCP lease + ARP + wireless (bukan PPPoE).
     *
     * Return: array of clients, setiap item punya key:
     *   mac_address, ip_address, hostname, interface, uptime,
     *   rx_bytes, tx_bytes, rx_human, tx_human, signal, source
     */
    public function getActiveSessions(): array
    {
        try {
            $clients = $this->client->getConnectedClients();

            return array_map(fn(array $c) => [
                'mac_address'  => strtoupper(trim(
                    $c['mac-address'] ?? $c['mac_address'] ?? ''
                )),
                'ip_address'   => $c['ip-address']  ?? $c['ip_address']  ?? '-',
                'hostname'     => $c['hostname']     ?? '-',
                'interface'    => $c['interface']    ?? '-',
                'uptime'       => $c['uptime']       ?? '-',
                'rx_bytes'     => (int) ($c['rx-bytes'] ?? $c['rx_bytes'] ?? 0),
                'tx_bytes'     => (int) ($c['tx-bytes'] ?? $c['tx_bytes'] ?? 0),
                'rx_human'     => $c['rx-bytes-human'] ?? $c['rx_human'] ?? '-',
                'tx_human'     => $c['tx-bytes-human'] ?? $c['tx_human'] ?? '-',
                'signal'       => $c['signal']       ?? '',
                'source'       => $c['source']       ?? 'unknown',
            ], is_array($clients) ? $clients : []);

        } catch (\Throwable $e) {
            Logger::error('MikrotikService', 'getActiveSessions gagal: ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Putus koneksi klien berdasarkan MAC address
     */
    public function kickClientByMac(string $macAddress): bool
    {
        return $this->client->kickClientByMac($macAddress);
    }

    

    // =========================================================================
    // SIMPLE QUEUES
    // =========================================================================

    /**
     * Ambil daftar Simple Queue.
     * Return: array of queues
     */
    public function getSimpleQueues(): array
    {
        try {
            $queues = $this->client->getSimpleQueues();
            return is_array($queues) ? $queues : [];
        } catch (\Throwable $e) {
            Logger::error('MikrotikService', 'getSimpleQueues gagal: ' . $e->getMessage());
            throw $e;
        }
    }

    // =========================================================================
    // PPPoE SECRETS
    // =========================================================================

    public function getPppoeSecrets(): array
    {
        try {
            return $this->client->getPppoeSecrets();
        } catch (\Throwable $e) {
            Logger::error('MikrotikService', 'getPppoeSecrets gagal: ' . $e->getMessage());
            throw $e;
        }
    }

    public function addPppoeSecret(
        string $username,
        string $password,
        string $profile = 'default',
        string $service = 'pppoe',
        string $comment = ''
    ): bool {
        return $this->client->addPppoeSecret($username, $password, $profile, $service, $comment);
    }

    public function updatePppoePassword(string $username, string $newPassword): bool
    {
        return $this->client->updatePppoePassword($username, $newPassword);
    }

    public function togglePppoeSecret(string $username): bool
    {
        return $this->client->togglePppoeSecret($username);
    }

    public function deletePppoeSecret(string $username): bool
    {
        return $this->client->deletePppoeSecret($username);
    }

    public function kickPppoeSession(string $username): bool
    {
        return $this->client->kickPppoeSession($username);
    }

    // =========================================================================
    // QUEUE MANAGEMENT
    // =========================================================================

    public function addSimpleQueue(
        string $name,
        string $target,
        string $maxLimit = '10M/10M',
        string $comment  = ''
    ): bool {
        return $this->client->addSimpleQueue($name, $target, $maxLimit, $comment);
    }

    public function updateSimpleQueue(string $name, string $maxLimit): bool
    {
        return $this->client->updateSimpleQueue($name, $maxLimit);
    }

    public function deleteSimpleQueue(string $name): bool
    {
        return $this->client->deleteSimpleQueue($name);
    }
        // =========================================================================
    // HELPER: FORMAT BYTES
    // =========================================================================

    /**
     * Format bytes ke human-readable (B, KB, MB, GB, TB)
     *
     * Contoh:
     *   formatBytes(0)            → "0 B"
     *   formatBytes(1024)         → "1.00 KB"
     *   formatBytes(1536000)      → "1.46 MB"
     *   formatBytes(1073741824)   → "1.00 GB"
     *   formatBytes(274877906944) → "256.00 GB"
     */
    public static function formatBytes(int|float|string $bytes, int $precision = 2): string
    {
        $bytes = (float) $bytes;

        if ($bytes <= 0) {
            return '0 B';
        }

        $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
        $base  = 1024;

        $i = (int) floor(log($bytes, $base));
        $i = min($i, count($units) - 1); // batas maksimal unit

        $value = $bytes / ($base ** $i);

        return round($value, $precision) . ' ' . $units[$i];
    }

    /**
     * Format bits per second ke human-readable (bps, Kbps, Mbps, Gbps)
     *
     * Contoh:
     *   formatBitsPerSecond(500)        → "500 bps"
     *   formatBitsPerSecond(1500000)    → "1.50 Mbps"
     *   formatBitsPerSecond(1000000000) → "1.00 Gbps"
     */
    public static function formatBitsPerSecond(int|float|string $bps, int $precision = 2): string
    {
        $bps = (float) $bps;

        if ($bps <= 0) {
            return '0 bps';
        }

        $units = ['bps', 'Kbps', 'Mbps', 'Gbps', 'Tbps'];
        $base  = 1000; // bit pakai base 1000 (SI), bukan 1024

        $i = (int) floor(log($bps, $base));
        $i = min($i, count($units) - 1);

        $value = $bps / ($base ** $i);

        return round($value, $precision) . ' ' . $units[$i];
    }
    // =========================================================================
    // PER-CLIENT DATA (by MAC Address)
    // =========================================================================

    /**
     * Status uptime klien — return format yang diharapkan JS frontend
     * { status, uptime_human, uptime, ip, identity, mode, signal, connected_at }
     */
    public function getUptimeByMac(string $macAddress): array
    {
        try {
            $data = $this->client->getClientUptime($macAddress);
            return [
                'status'       => $data['status']       ?? 'offline',
                'uptime'       => $data['uptime']        ?? '0',
                'uptime_human' => $data['uptime_human']  ?? '-',
                'ip'           => $data['ip']            ?? null,
                'identity'     => $data['identity']      ?? null,
                'mode'         => $data['mode']          ?? 'unknown',
                'signal'       => $data['signal']        ?? '',
                'connected_at' => $data['connected_at']  ?? null,
                'last_seen'    => $data['last_seen']     ?? null,
                'interface'    => $data['interface']     ?? null,
            ];
        } catch (\Throwable $e) {
            Logger::error('MikrotikService', "getUptimeByMac({$macAddress}) gagal: " . $e->getMessage());
            return [
                'status'    => 'offline',
                'uptime'    => '0',
                'last_seen' => null,
                'ip'        => null,
                'identity'  => null,
                'error'     => $e->getMessage(),
            ];
        }
    }

    /**
     * Bandwidth real-time — return format yang diharapkan JS frontend
     * { ok, rx_rate (bytes/s), tx_rate (bytes/s), rx_byte, tx_byte, ip, queue_name, mode, max_mbps }
     */
    public function getBandwidthByMac(string $macAddress): array
    {
        try {
            $data = $this->client->getClientBandwidth($macAddress);
            return [
                'ok'         => $data['ok']         ?? false,
                'rx_rate'    => (int) ($data['rx_rate'] ?? 0),
                'tx_rate'    => (int) ($data['tx_rate'] ?? 0),
                'rx_byte'    => $data['rx_byte']    ?? '0',
                'tx_byte'    => $data['tx_byte']    ?? '0',
                'ip'         => $data['ip']         ?? null,
                'queue_name' => $data['queue_name'] ?? null,
                'mode'       => $data['mode']       ?? 'unknown',
                'max_mbps'   => (int) ($data['max_mbps'] ?? 100),
            ];
        } catch (\Throwable $e) {
            Logger::error('MikrotikService', "getBandwidthByMac({$macAddress}) gagal: " . $e->getMessage());
            return ['ok' => false, 'rx_rate' => 0, 'tx_rate' => 0, 'error' => $e->getMessage()];
        }
    }

    /**
     * Penggunaan hari ini — return format yang diharapkan JS frontend
     * { rx_bytes, tx_bytes, hourly: [{hour, rx_bytes, tx_bytes}] }
     */
    public function getUsageTodayByMac(string $macAddress): array
    {
        try {
            $data = $this->client->getClientUsageToday($macAddress);
            return [
                'rx_bytes' => (int) ($data['rx_bytes'] ?? 0),
                'tx_bytes' => (int) ($data['tx_bytes'] ?? 0),
                'hourly'   => is_array($data['hourly'] ?? null) ? $data['hourly'] : [],
            ];
        } catch (\Throwable $e) {
            Logger::error('MikrotikService', "getUsageTodayByMac({$macAddress}) gagal: " . $e->getMessage());
            return ['rx_bytes' => 0, 'tx_bytes' => 0, 'hourly' => []];
        }
    }

    /**
     * Penggunaan bulan ini — return format yang diharapkan JS frontend
     * { rx_bytes, tx_bytes, daily: [{date, rx_bytes, tx_bytes}] }
     */
    public function getUsageMonthByMac(string $macAddress): array
    {
        try {
            $data = $this->client->getClientUsageMonth($macAddress);
            return [
                'rx_bytes' => (int) ($data['rx_bytes'] ?? 0),
                'tx_bytes' => (int) ($data['tx_bytes'] ?? 0),
                'daily'    => is_array($data['daily'] ?? null) ? $data['daily'] : [],
            ];
        } catch (\Throwable $e) {
            Logger::error('MikrotikService', "getUsageMonthByMac({$macAddress}) gagal: " . $e->getMessage());
            return ['rx_bytes' => 0, 'tx_bytes' => 0, 'daily' => []];
        }
    }
    /**
     * Ambil info sistem router (resource, uptime, dll)
     */
    public function getSystemInfo(): array
    {
        try {
            return $this->client->get('/api/system/info');
        } catch (\Throwable $e) {
            \Core\Logger::error('MikrotikService', 'getSystemInfo gagal: ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Ambil identitas router
     */
    public function getIdentity(): string
    {
        try {
            $data = $this->client->get('/api/system/identity');
            return $data['name'] ?? $data['identity'] ?? '-';
        } catch (\Throwable $e) {
            return '-';
        }
    }

    /**
     * Ambil daftar interface
     */
    public function getInterfaces(): array
    {
        try {
            $data = $this->client->get('/api/interfaces');
            return is_array($data) ? $data : [];
        } catch (\Throwable $e) {
            \Core\Logger::error('MikrotikService', 'getInterfaces gagal: ' . $e->getMessage());
            return [];
        }
    }

}
