<?php
/**
 * Service/UsageLogService.php
 * ✅ FINAL — Menggunakan getClientUsageToday() & getClientUsageMonth()
 *
 * Response MikroTik yang benar:
 *   getClientUsageToday($mac) → ['rx_bytes' => int, 'tx_bytes' => int, 'hourly' => [...]]
 *   getClientUsageMonth($mac) → ['rx_bytes' => int, 'tx_bytes' => int, 'daily' => [...]]
 *   getConnectedClients()     → [['mac-address' => ..., 'rx-bytes' => ..., ...]]
 */

declare(strict_types=1);

namespace Service;

use Model\UsageLogModel;
use Core\MikrotikClient;
use Core\Logger;
use PDO;

class UsageLogService
{
    private UsageLogModel  $model;
    private PDO            $db;
    private MikrotikClient $client;

    public function __construct(PDO $db)
    {
        $this->db     = $db;
        $this->model  = new UsageLogModel($db);
        $this->client = new MikrotikClient(
            $_ENV['MIKROTIK_URL']     ?? 'http://localhost:5000',
            $_ENV['MIKROTIK_USER']    ?? 'admin',
            $_ENV['MIKROTIK_PASS']    ?? 'admin123',
            (int)($_ENV['MIKROTIK_TIMEOUT'] ?? 10)
        );
    }

    // ═══════════════════════════════════════════════════════════════
    //  COLLECT ALL — Cron job utama
    //  ✅ Pakai getClientUsageToday() + getClientUsageMonth()
    // ═══════════════════════════════════════════════════════════════

    public function collectAll(): array
    {
        $result = ['ok' => 0, 'skip' => 0, 'error' => 0, 'errors' => []];

        $pelList = $this->model->getPelangganWithMac();
        if (empty($pelList)) {
            Logger::info('UsageLogService', 'Tidak ada pelanggan dengan MAC.');
            return $result;
        }

        // Cek apakah MikroTik online
        $connectedMacs  = [];
        $mikrotikOnline = false;

        try {
            $clients = $this->client->getConnectedClients();
            $mikrotikOnline = true;
            foreach ($clients as $c) {
                $mac = strtoupper($c['mac-address'] ?? $c['mac_address'] ?? '');
                if ($mac) $connectedMacs[$mac] = $c;
            }
        } catch (\Throwable $e) {
            Logger::warning('UsageLogService', 'MikroTik down: ' . $e->getMessage());
            $result['errors'][] = 'MikroTik: ' . $e->getMessage();
        }

        $now   = date('Y-m-d H:i:s');
        $today = date('Y-m-d');

        foreach ($pelList as $pel) {
            $pelId = (int)$pel['id'];
            $mac   = strtoupper(trim($pel['mac_address']));
            if (!$mac) continue;

            // Skip kalau sudah snapshot dalam 50 menit
            if ($this->model->hasRecentSnapshot($pelId, 50)) {
                $result['skip']++;
                continue;
            }

            $isOnline = $mikrotikOnline && isset($connectedMacs[$mac]);

            try {
                $rxToday = 0;
                $txToday = 0;
                $rxMonth = 0;
                $txMonth = 0;
                $rxMbps  = 0.0;
                $txMbps  = 0.0;

                if ($isOnline) {
                    // ┌──────────────────────────────────────────────────────┐
                    // │ ✅ AMBIL DATA HARI INI dari getClientUsageToday()    │
                    // └──────────────────────────────────────────────────────┘
                    try {
                        $todayData = $this->client->getClientUsageToday($mac);
                        $rxToday   = (int)($todayData['rx_bytes'] ?? 0);
                        $txToday   = (int)($todayData['tx_bytes'] ?? 0);
                    } catch (\Throwable $e) {
                        Logger::warning('UsageLogService', "getUsageToday({$mac}): " . $e->getMessage());
                    }

                    // ┌──────────────────────────────────────────────────────┐
                    // │ ✅ AMBIL DATA BULAN INI dari getClientUsageMonth()   │
                    // └──────────────────────────────────────────────────────┘
                    try {
                        $monthData = $this->client->getClientUsageMonth($mac);
                        $rxMonth   = (int)($monthData['rx_bytes'] ?? 0);
                        $txMonth   = (int)($monthData['tx_bytes'] ?? 0);
                    } catch (\Throwable $e) {
                        Logger::warning('UsageLogService', "getUsageMonth({$mac}): " . $e->getMessage());
                    }

                    // Hitung speed dari getConnectedClients
                    $clientInfo = $connectedMacs[$mac] ?? null;
                    if ($clientInfo) {
                        $rxBytesConn = (int)($clientInfo['rx-bytes'] ?? 0);
                        $txBytesConn = (int)($clientInfo['tx-bytes'] ?? 0);
                        $uptimeSec   = $this->parseUptime($clientInfo['uptime'] ?? '0s');
                        if ($uptimeSec > 0) {
                            $rxMbps = round(($rxBytesConn * 8) / ($uptimeSec * 1_000_000), 2);
                            $txMbps = round(($txBytesConn * 8) / ($uptimeSec * 1_000_000), 2);
                        }
                    }

                } else {
                    // ── OFFLINE: Ambil data terakhir dari DB ──
                    $lastToday = $this->getTodayFromDB($pelId);
                    $lastMonth = $this->getMonthFromDB($pelId);

                    $rxToday = $lastToday['rx_bytes'] ?? 0;
                    $txToday = $lastToday['tx_bytes'] ?? 0;
                    $rxMonth = $lastMonth['rx_bytes'] ?? 0;
                    $txMonth = $lastMonth['tx_bytes'] ?? 0;
                }

                // ── Simpan snapshot ke usage_log ──
                $this->model->insertSnapshot([
                    'pelanggan_id' => $pelId,
                    'mac_address'  => $mac,
                    'rx_bytes'     => $rxToday,
                    'tx_bytes'     => $txToday,
                    'rx_mbps'      => $rxMbps,
                    'tx_mbps'      => $txMbps,
                    'is_online'    => $isOnline ? 1 : 0,
                    'period'       => 'hourly',
                    'snapshot_at'  => $now,
                ]);

                // ── Simpan ringkasan harian (total hari ini, BUKAN akumulasi) ──
                if ($rxToday > 0 || $txToday > 0) {
                    $this->upsertDailySummary(
                        $pelId, $today,
                        $rxToday, $txToday, $rxMbps, $txMbps,
                        $isOnline ? 60 : 0
                    );
                }

                // ── Simpan ringkasan bulanan ──
                if ($rxMonth > 0 || $txMonth > 0) {
                    $this->upsertMonthlySummary($pelId, $rxMonth, $txMonth, $isOnline);
                }

                $result['ok']++;

                Logger::info('UsageLogService', sprintf(
                    '%s [%d] %s — Hari ini: RX=%s TX=%s | Bulan ini: RX=%s TX=%s',
                    $isOnline ? '🟢' : '🔴',
                    $pelId,
                    $pel['nama_lengkap'],
                    self::formatBytes($rxToday),
                    self::formatBytes($txToday),
                    self::formatBytes($rxMonth),
                    self::formatBytes($txMonth)
                ));

            } catch (\Throwable $e) {
                $result['error']++;
                $result['errors'][] = "MAC {$mac}: " . $e->getMessage();
                Logger::error('UsageLogService', "MAC {$mac}: " . $e->getMessage());
            }
        }

        return $result;
    }

    // ═══════════════════════════════════════════════════════════════
    //  GET USAGE TODAY — Prioritas: DB → MikroTik live
    // ═══════════════════════════════════════════════════════════════

    public function getUsageToday(int $pelId, ?string $mac = null): array
    {
        // 1. Coba dari daily summary (data tersimpan, tetap ada saat MikroTik down)
        $stmt = $this->db->prepare("
            SELECT rx_bytes, tx_bytes, online_minutes, peak_rx_bps, peak_tx_bps
            FROM usage_daily_summary
            WHERE pelanggan_id = :id AND tanggal = CURDATE()
        ");
        $stmt->execute([':id' => $pelId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row && ((int)$row['rx_bytes'] > 0 || (int)$row['tx_bytes'] > 0)) {
            return $this->buildResponse(
                (int)$row['rx_bytes'],
                (int)$row['tx_bytes'],
                round((int)$row['peak_rx_bps'] / 1_000_000, 2),
                round((int)$row['peak_tx_bps'] / 1_000_000, 2),
                (int)$row['online_minutes'],
                'db_daily',
                true
            );
        }

        // 2. Coba dari usage_log hari ini
        $stmt2 = $this->db->prepare("
            SELECT rx_bytes, tx_bytes, rx_mbps, tx_mbps
            FROM usage_log
            WHERE pelanggan_id = :id AND DATE(snapshot_at) = CURDATE()
            ORDER BY snapshot_at DESC LIMIT 1
        ");
        $stmt2->execute([':id' => $pelId]);
        $log = $stmt2->fetch(PDO::FETCH_ASSOC);

        if ($log && ((int)$log['rx_bytes'] > 0 || (int)$log['tx_bytes'] > 0)) {
            return $this->buildResponse(
                (int)$log['rx_bytes'],
                (int)$log['tx_bytes'],
                (float)$log['rx_mbps'],
                (float)$log['tx_mbps'],
                0, 'db_log',
                false
            );
        }

        // 3. Fallback ke MikroTik live
        if ($mac) {
            try {
                $todayData = $this->client->getClientUsageToday(strtoupper($mac));
                $rx = (int)($todayData['rx_bytes'] ?? 0);
                $tx = (int)($todayData['tx_bytes'] ?? 0);
                if ($rx > 0 || $tx > 0) {
                    return $this->buildResponse($rx, $tx, 0, 0, 0, 'live', true);
                }
            } catch (\Throwable) {}
        }

        return $this->emptyUsage();
    }

    // ═══════════════════════════════════════════════════════════════
    //  GET USAGE MONTH — Prioritas: DB → MikroTik live
    // ═══════════════════════════════════════════════════════════════

    public function getUsageMonth(int $pelId, ?string $mac = null, ?string $ym = null): array
    {
        $ym = $ym ?? date('Y-m');
        [$y, $m] = explode('-', $ym);

        // 1. Coba dari monthly summary
        $stmt = $this->db->prepare("
            SELECT total_rx_bytes, total_tx_bytes, days_active, last_updated
            FROM usage_monthly_summary
            WHERE pelanggan_id = :id AND month_year = :ym
        ");
        $stmt->execute([':id' => $pelId, ':ym' => $ym]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row && ((int)$row['total_rx_bytes'] > 0 || (int)$row['total_tx_bytes'] > 0)) {
            return $this->buildResponse(
                (int)$row['total_rx_bytes'],
                (int)$row['total_tx_bytes'],
                0, 0,
                (int)$row['days_active'] * 60,
                'db_monthly',
                false,
                $row['last_updated']
            );
        }

        // 2. Hitung dari daily summary
        $stmt2 = $this->db->prepare("
            SELECT
                COALESCE(SUM(rx_bytes), 0)       AS rx_bytes,
                COALESCE(SUM(tx_bytes), 0)       AS tx_bytes,
                COALESCE(SUM(online_minutes), 0) AS online_minutes
            FROM usage_daily_summary
            WHERE pelanggan_id = :id
            AND YEAR(tanggal) = :y AND MONTH(tanggal) = :m
        ");
        $stmt2->execute([':id' => $pelId, ':y' => (int)$y, ':m' => (int)$m]);
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);

        if ($row2 && ((int)$row2['rx_bytes'] > 0 || (int)$row2['tx_bytes'] > 0)) {
            return $this->buildResponse(
                (int)$row2['rx_bytes'],
                (int)$row2['tx_bytes'],
                0, 0,
                (int)$row2['online_minutes'],
                'db_daily_sum',
                false
            );
        }

        // 3. Fallback ke MikroTik live
        if ($mac) {
            try {
                $monthData = $this->client->getClientUsageMonth(strtoupper($mac));
                $rx = (int)($monthData['rx_bytes'] ?? 0);
                $tx = (int)($monthData['tx_bytes'] ?? 0);
                if ($rx > 0 || $tx > 0) {
                    return $this->buildResponse($rx, $tx, 0, 0, 0, 'live', true);
                }
            } catch (\Throwable) {}
        }

        return $this->emptyUsage();
    }

    // ═══════════════════════════════════════════════════════════════
    //  GET BOTH TODAY + MONTH (untuk tampilan dashboard)
    // ═══════════════════════════════════════════════════════════════

    public function getUsageDashboard(int $pelId, ?string $mac = null): array
    {
        return [
            'today' => $this->getUsageToday($pelId, $mac),
            'month' => $this->getUsageMonth($pelId, $mac),
        ];
    }

    // ═══════════════════════════════════════════════════════════════
    //  UPSERT DAILY SUMMARY
    //  ✅ Pakai SET = VALUES() karena data dari MikroTik SUDAH total harian
    // ═══════════════════════════════════════════════════════════════

    private function upsertDailySummary(
        int    $pelId,
        string $tanggal,
        int    $rxBytes,
        int    $txBytes,
        float  $rxMbps,
        float  $txMbps,
        int    $onlineMin = 60
    ): void {
        $rxBps = (int)round($rxMbps * 1_000_000);
        $txBps = (int)round($txMbps * 1_000_000);

        $this->db->prepare("
            INSERT INTO usage_daily_summary
                (pelanggan_id, tanggal, rx_bytes, tx_bytes, online_minutes, peak_rx_bps, peak_tx_bps)
            VALUES
                (:pid, :tgl, :rx, :tx, :om, :prx, :ptx)
            ON DUPLICATE KEY UPDATE
                rx_bytes       = VALUES(rx_bytes),
                tx_bytes       = VALUES(tx_bytes),
                online_minutes = online_minutes + VALUES(online_minutes),
                peak_rx_bps    = GREATEST(peak_rx_bps, VALUES(peak_rx_bps)),
                peak_tx_bps    = GREATEST(peak_tx_bps, VALUES(peak_tx_bps))
        ")->execute([
            ':pid' => $pelId,
            ':tgl' => $tanggal,
            ':rx'  => $rxBytes,
            ':tx'  => $txBytes,
            ':om'  => $onlineMin,
            ':prx' => $rxBps,
            ':ptx' => $txBps,
        ]);
    }

    // ═══════════════════════════════════════════════════════════════
    //  UPSERT MONTHLY SUMMARY
    //  ✅ Pakai SET = VALUES() karena data dari MikroTik SUDAH total bulanan
    // ═══════════════════════════════════════════════════════════════

    private function upsertMonthlySummary(
        int  $pelId,
        int  $rxMonth,
        int  $txMonth,
        bool $isOnline
    ): void {
        $monthYear = date('Y-m');
        $now       = date('Y-m-d H:i:s');

        $this->db->prepare("
            INSERT INTO usage_monthly_summary
                (pelanggan_id, month_year, total_rx_bytes, total_tx_bytes, total_bytes, days_active, last_seen, last_updated)
            VALUES
                (:pid, :ym, :rx, :tx, :total, :da, :ls, :lu)
            ON DUPLICATE KEY UPDATE
                total_rx_bytes = VALUES(total_rx_bytes),
                total_tx_bytes = VALUES(total_tx_bytes),
                total_bytes    = VALUES(total_bytes),
                days_active    = VALUES(days_active),
                last_seen      = VALUES(last_seen),
                last_updated   = VALUES(last_updated)
        ")->execute([
            ':pid'   => $pelId,
            ':ym'    => $monthYear,
            ':rx'    => $rxMonth,
            ':tx'    => $txMonth,
            ':total' => $rxMonth + $txMonth,
            ':da'    => $isOnline ? (int)date('j') : 0,
            ':ls'    => $isOnline ? $now : null,
            ':lu'    => $now,
        ]);
    }

    // ═══════════════════════════════════════════════════════════════
    //  AMBIL DATA TERAKHIR DARI DB (fallback saat offline)
    // ═══════════════════════════════════════════════════════════════

    private function getTodayFromDB(int $pelId): array
    {
        $stmt = $this->db->prepare("
            SELECT rx_bytes, tx_bytes
            FROM usage_daily_summary
            WHERE pelanggan_id = :id AND tanggal = CURDATE()
        ");
        $stmt->execute([':id' => $pelId]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: ['rx_bytes' => 0, 'tx_bytes' => 0];
    }

    private function getMonthFromDB(int $pelId): array
    {
        $ym = date('Y-m');
        $stmt = $this->db->prepare("
            SELECT total_rx_bytes AS rx_bytes, total_tx_bytes AS tx_bytes
            FROM usage_monthly_summary
            WHERE pelanggan_id = :id AND month_year = :ym
        ");
        $stmt->execute([':id' => $pelId, ':ym' => $ym]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: ['rx_bytes' => 0, 'tx_bytes' => 0];
    }

    // ═══════════════════════════════════════════════════════════════
    //  MONTHLY SUMMARY ALL (untuk halaman admin)
    // ═══════════════════════════════════════════════════════════════

    public function getMonthlySummaryAll(string $ym): array
    {
        $stmt = $this->db->prepare("
            SELECT
                ms.pelanggan_id,
                p.nama_lengkap,
                p.mac_address,
                pk.nama_paket,
                pk.kecepatan,
                ms.total_rx_bytes  AS rx_bytes,
                ms.total_tx_bytes  AS tx_bytes,
                ms.total_bytes,
                ms.days_active,
                ms.last_seen       AS last_active
            FROM usage_monthly_summary ms
            LEFT JOIN pelanggan p  ON ms.pelanggan_id = p.id
            LEFT JOIN paket     pk ON p.paket_id = pk.id
            WHERE ms.month_year = :ym
            ORDER BY ms.total_bytes DESC
        ");
        $stmt->execute([':ym' => $ym]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return array_map(function (array $r): array {
            $rx  = (int)$r['rx_bytes'];
            $tx  = (int)$r['tx_bytes'];
            return array_merge($r, [
                'rx_human'     => self::formatBytes($rx),
                'tx_human'     => self::formatBytes($tx),
                'total_human'  => self::formatBytes($rx + $tx),
                'online_human' => $r['days_active'] . ' hari aktif',
            ]);
        }, $rows);
    }

    // ═══════════════════════════════════════════════════════════════
    //  CRUD PASSTHROUGH
    // ═══════════════════════════════════════════════════════════════

    public function getLogsBySnapshot(string $snapshotAt): array
    {
        return $this->model->getBySnapshot($snapshotAt);
    }

    public function getLogsByPelanggan(int $pelangganId, int $limit = 50): array
    {
        return $this->model->getByPelanggan($pelangganId, $limit);
    }

    public function createLog(array $data): bool
    {
        if (empty($data['pelanggan_id']) || empty($data['mac_address'])) {
            throw new \InvalidArgumentException('pelanggan_id dan mac_address wajib diisi');
        }
        return (bool)$this->model->insert($data);
    }

    public function pruneOldLogs(string $beforeDate): int
    {
        return $this->model->pruneOlderThan($beforeDate);
    }

    public function getTotalLogs(): int
    {
        return $this->model->count();
    }

    public function getDailySummary(string $date): array
    {
        return $this->model->getDailySummary($date);
    }

    public function bulkCreateLogs(array $logsData): int
    {
        $count = 0;
        $this->db->beginTransaction();
        try {
            foreach ($logsData as $data) {
                if ($this->model->insert($data)) $count++;
            }
            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
        return $count;
    }

    // ═══════════════════════════════════════════════════════════════
    //  HELPERS
    // ═══════════════════════════════════════════════════════════════

    public static function formatBytes(int $bytes): string
    {
        if ($bytes <= 0) return '0 B';
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $i = min((int)floor(log($bytes, 1024)), count($units) - 1);
        return round($bytes / (1024 ** $i), 2) . ' ' . $units[$i];
    }

    private function parseUptime(string $uptime): int
    {
        $total = 0;
        if (preg_match('/(\d+)w/', $uptime, $m)) $total += (int)$m[1] * 604800;
        if (preg_match('/(\d+)d/', $uptime, $m)) $total += (int)$m[1] * 86400;
        if (preg_match('/(\d+):(\d+):(\d+)/', $uptime, $m)) {
            $total += (int)$m[1] * 3600 + (int)$m[2] * 60 + (int)$m[3];
        }
        return $total;
    }

    private function buildResponse(
        int $rx, int $tx, float $rxMbps, float $txMbps,
        int $onlineMin, string $source, bool $isOnline = false,
        ?string $lastActive = null
    ): array {
        $h   = intdiv($onlineMin, 60);
        $onl = $h >= 24
            ? intdiv($h, 24) . ' hari ' . ($h % 24) . ' jam'
            : "{$h} jam " . ($onlineMin % 60) . " menit";

        return [
            'rx_bytes'     => $rx,
            'tx_bytes'     => $tx,
            'total_bytes'  => $rx + $tx,
            'rx_mbps'      => $rxMbps,
            'tx_mbps'      => $txMbps,
            'rx_human'     => self::formatBytes($rx),
            'tx_human'     => self::formatBytes($tx),
            'total_human'  => self::formatBytes($rx + $tx),
            'online_human' => $onl,
            'last_active'  => $lastActive,
            'source'       => $source,
            'is_online'    => $isOnline,
        ];
    }

    private function emptyUsage(): array
    {
        return [
            'rx_bytes'    => 0,
            'tx_bytes'    => 0,
            'total_bytes' => 0,
            'rx_mbps'     => 0.0,
            'tx_mbps'     => 0.0,
            'rx_human'    => '0 B',
            'tx_human'    => '0 B',
            'total_human' => '0 B',
            'online_human' => '0 menit',
            'last_active' => null,
            'source'      => 'no_data',
            'is_online'   => false,
        ];
    }
        /**
     * COLLECT ALL FORCE — Abaikan hasRecentSnapshot, collect ulang semua
     * Dipakai dengan flag --force
     */
    public function collectAllForce(): array
    {
        $result = ['ok' => 0, 'skip' => 0, 'error' => 0, 'errors' => []];

        $pelList = $this->model->getPelangganWithMac();
        if (empty($pelList)) {
            Logger::info('UsageLogService', 'Tidak ada pelanggan dengan MAC.');
            return $result;
        }

        // Koneksi MikroTik
        $connectedMacs  = [];
        $mikrotikOnline = false;

        try {
            $clients = $this->client->getConnectedClients();
            $mikrotikOnline = true;
            foreach ($clients as $c) {
                $mac = strtoupper($c['mac-address'] ?? $c['mac_address'] ?? '');
                if ($mac) $connectedMacs[$mac] = $c;
            }
        } catch (\Throwable $e) {
            Logger::warning('UsageLogService', 'MikroTik down: ' . $e->getMessage());
            $result['errors'][] = 'MikroTik: ' . $e->getMessage();
        }

        $now   = date('Y-m-d H:i:s');
        $today = date('Y-m-d');

        foreach ($pelList as $pel) {
            $pelId = (int)$pel['id'];
            $mac   = strtoupper(trim($pel['mac_address']));
            if (!$mac) continue;

            // ⚡ FORCE: Tidak ada pengecekan hasRecentSnapshot!

            $isOnline = $mikrotikOnline && isset($connectedMacs[$mac]);

            try {
                $rxToday = 0;
                $txToday = 0;
                $rxMonth = 0;
                $txMonth = 0;
                $rxMbps  = 0.0;
                $txMbps  = 0.0;

                if ($isOnline) {
                    // Ambil usage hari ini
                    try {
                        $todayData = $this->client->getClientUsageToday($mac);
                        $rxToday   = (int)($todayData['rx_bytes'] ?? 0);
                        $txToday   = (int)($todayData['tx_bytes'] ?? 0);
                    } catch (\Throwable $e) {
                        Logger::warning('UsageLogService', "getUsageToday({$mac}): " . $e->getMessage());
                    }

                    // Ambil usage bulan ini
                    try {
                        $monthData = $this->client->getClientUsageMonth($mac);
                        $rxMonth   = (int)($monthData['rx_bytes'] ?? 0);
                        $txMonth   = (int)($monthData['tx_bytes'] ?? 0);
                    } catch (\Throwable $e) {
                        Logger::warning('UsageLogService', "getUsageMonth({$mac}): " . $e->getMessage());
                    }

                    // Hitung speed
                    $clientInfo = $connectedMacs[$mac] ?? null;
                    if ($clientInfo) {
                        $rxBytesConn = (int)($clientInfo['rx-bytes'] ?? 0);
                        $txBytesConn = (int)($clientInfo['tx-bytes'] ?? 0);
                        $uptimeSec   = $this->parseUptime($clientInfo['uptime'] ?? '0s');
                        if ($uptimeSec > 0) {
                            $rxMbps = round(($rxBytesConn * 8) / ($uptimeSec * 1_000_000), 2);
                            $txMbps = round(($txBytesConn * 8) / ($uptimeSec * 1_000_000), 2);
                        }
                    }

                } else {
                    // Offline: ambil dari DB
                    $lastToday = $this->getTodayFromDB($pelId);
                    $lastMonth = $this->getMonthFromDB($pelId);
                    $rxToday = $lastToday['rx_bytes'] ?? 0;
                    $txToday = $lastToday['tx_bytes'] ?? 0;
                    $rxMonth = $lastMonth['rx_bytes'] ?? 0;
                    $txMonth = $lastMonth['tx_bytes'] ?? 0;
                }

                // Simpan snapshot
                $this->model->insertSnapshot([
                    'pelanggan_id' => $pelId,
                    'mac_address'  => $mac,
                    'rx_bytes'     => $rxToday,
                    'tx_bytes'     => $txToday,
                    'rx_mbps'      => $rxMbps,
                    'tx_mbps'      => $txMbps,
                    'is_online'    => $isOnline ? 1 : 0,
                    'period'       => 'hourly',
                    'snapshot_at'  => $now,
                ]);

                // Daily summary
                if ($rxToday > 0 || $txToday > 0) {
                    $this->upsertDailySummary(
                        $pelId, $today,
                        $rxToday, $txToday, $rxMbps, $txMbps,
                        $isOnline ? 60 : 0
                    );
                }

                // Monthly summary
                if ($rxMonth > 0 || $txMonth > 0) {
                    $this->upsertMonthlySummary($pelId, $rxMonth, $txMonth, $isOnline);
                }

                $result['ok']++;

                Logger::info('UsageLogService', sprintf(
                    '%s [%d] %s — Hari ini: RX=%s TX=%s | Bulan: RX=%s TX=%s',
                    $isOnline ? 'ONLINE' : 'OFFLINE',
                    $pelId, $pel['nama_lengkap'],
                    self::formatBytes($rxToday), self::formatBytes($txToday),
                    self::formatBytes($rxMonth), self::formatBytes($txMonth)
                ));

            } catch (\Throwable $e) {
                $result['error']++;
                $result['errors'][] = "MAC {$mac}: " . $e->getMessage();
            }
        }

        return $result;
    }
/**
 * GET MONTHLY GROWTH — Data 12 bulan untuk dashboard admin
 * Prioritas: DB → MikroTik live
 */
public function getMonthlyGrowth(int $months = 12): array
{
    // 1. Coba dari DB: usage_monthly_summary
    $stmt = $this->db->prepare("
        SELECT 
            month_year,
            SUM(total_rx_bytes) AS total_rx,
            SUM(total_tx_bytes) AS total_tx,
            SUM(total_bytes)    AS total,
            COUNT(DISTINCT pelanggan_id) AS client_count
        FROM usage_monthly_summary
        GROUP BY month_year
        ORDER BY month_year DESC
        LIMIT :months
    ");
    $stmt->bindValue(':months', $months, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($rows) >= 2) {
        // Reverse supaya dari lama ke baru
        $rows = array_reverse($rows);
        
        $monthly = [];
        $prev_total = 0;
        
        foreach ($rows as $r) {
            $total = (int)$r['total'];
            $growth = $prev_total > 0 
                ? round((($total - $prev_total) / $prev_total) * 100, 1) 
                : 0.0;
            
            [$y, $m] = explode('-', $r['month_year']);
            $dt = mktime(0, 0, 0, (int)$m, 1, (int)$y);
            
            $monthly[] = [
                'month'        => $r['month_year'],
                'month_name'   => date('F Y', $dt),
                'rx_bytes'     => (int)$r['total_rx'],
                'tx_bytes'     => (int)$r['total_tx'],
                'total_bytes'  => $total,
                'rx_human'     => self::formatBytes((int)$r['total_rx']),
                'tx_human'     => self::formatBytes((int)$r['total_tx']),
                'total_human'  => self::formatBytes($total),
                'client_count' => (int)$r['client_count'],
                'growth_pct'   => $growth,
                'growth_direction' => $growth > 0 ? 'up' : ($growth < 0 ? 'down' : 'flat'),
            ];
            
            $prev_total = $total;
        }
        
        $grand = array_sum(array_column($monthly, 'total_bytes'));
        $growths = array_filter(array_column($monthly, 'growth_pct'));
        
        return [
            'source'    => 'db',
            'months'    => count($monthly),
            'monthly'   => $monthly,
            'grand_total' => $grand,
            'grand_total_human' => self::formatBytes($grand),
            'avg_growth_pct' => $growths ? round(array_sum($growths) / count($growths), 1) : 0,
        ];
    }

    // 2. Fallback ke MikroTik live
    try {
        $data = $this->client->getMonthlyUsageAll($months);
        return array_merge($data, ['source' => 'live']);
    } catch (\Throwable $e) {
        Logger::warning('UsageLogService', 'getMonthlyGrowth fallback failed: ' . $e->getMessage());
    }

    return [
        'source'   => 'no_data',
        'months'   => 0,
        'monthly'  => [],
        'grand_total' => 0,
        'grand_total_human' => '0 B',
        'avg_growth_pct' => 0,
    ];
}

/**
 * GET REALTIME TOTAL — Untuk gauge bandwidth di dashboard
 */
public function getRealtimeTotal(): array
{
    // Coba dari DB: snapshot terakhir
    $stmt = $this->db->prepare("
        SELECT 
            SUM(rx_mbps) AS total_rx_mbps,
            SUM(tx_mbps) AS total_tx_mbps,
            COUNT(*) AS online_count
        FROM usage_log
        WHERE snapshot_at >= DATE_SUB(NOW(), INTERVAL 10 MINUTE)
        AND is_online = 1
    ");
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row && (float)$row['total_rx_mbps'] > 0) {
        $rx = (float)$row['total_rx_mbps'];
        $tx = (float)$row['total_tx_mbps'];
        return [
            'source'        => 'db',
            'total_rx_mbps' => $rx,
            'total_tx_mbps' => $tx,
            'total_mbps'    => $rx + $tx,
            'online_clients' => (int)$row['online_count'],
        ];
    }

    // Fallback ke MikroTik
    try {
        $data = $this->client->getRealtimeUsage();
        return array_merge($data, ['source' => 'live']);
    } catch (\Throwable $e) {
        return [
            'source'         => 'no_data',
            'total_rx_mbps'  => 0,
            'total_tx_mbps'  => 0,
            'total_mbps'     => 0,
            'online_clients' => 0,
        ];
    }
}


}
