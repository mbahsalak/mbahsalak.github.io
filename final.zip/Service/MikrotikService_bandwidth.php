<?php
/**
 * Tambahkan method ini ke:
 * services/MikrotikService.php
 *
 * Method getBandwidth() mengambil TX/RX bytes per interface dari RouterOS
 * lalu mengembalikan array yang siap di-JSON-encode.
 *
 * Cara kerja kalkulasi kecepatan:
 *   - Karena RouterOS /interface/print hanya mengembalikan bytes KUMULATIF
 *     sejak boot, kalkulasi kecepatan (bps) dilakukan di sisi JS dengan
 *     cara: delta_bytes / delta_seconds × 8
 *   - PHP hanya perlu return snapshot bytes terkini + timestamp
 */

// =========================================================================
// Tambahkan di dalam class MikrotikService
// =========================================================================

/**
 * Ambil snapshot TX/RX bytes semua interface yang running.
 *
 * @return array<int, array{
 *     name: string,
 *     type: string,
 *     tx_byte: int,
 *     rx_byte: int,
 *     tx_packet: int,
 *     rx_packet: int,
 *     running: bool
 * }>
 */
public function getBandwidth(): array
{
    $client = $this->getClient(); // gunakan method existing yg sudah ada
    // Jika service Anda memakai connect() manual, sesuaikan dengan pola yang sudah ada

    $raw = $client->communicate([
        '/interface/print',
        '=stats=',          // minta kolom statistik (tx-byte, rx-byte, dll)
        '?running=true',    // hanya interface yang sedang UP
    ]);

    $result = [];
    foreach ($raw as $row) {
        // Skip baris kosong / control words
        if (empty($row['name'])) continue;

        $result[] = [
            'name'       => $row['name']       ?? '',
            'type'       => $row['type']       ?? 'ether',
            'tx_byte'    => (int)($row['tx-byte']    ?? 0),
            'rx_byte'    => (int)($row['rx-byte']    ?? 0),
            'tx_packet'  => (int)($row['tx-packet']  ?? 0),
            'rx_packet'  => (int)($row['rx-packet']  ?? 0),
            'running'    => ($row['running'] ?? 'false') === 'true',
        ];
    }

    return $result;
}
