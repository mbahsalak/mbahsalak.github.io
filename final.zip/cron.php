<?php declare(strict_types=1);
/**
 * cron.php - Entry Point Cron Job FiberNet
 * Lokasi: ~/htdocs/final/cron.php (Root Project)
 * 
 * Penggunaan Termux:
 *   cd ~/htdocs/final && php cron.php --force
 *   cd ~/htdocs/final && php cron.php --job=tagihan
 *   cd ~/htdocs/final && php cron.php --list
 */

// ── 1. Proteksi Akses & Environment ─────────────────────────
$isCli = (php_sapi_name() === 'cli');

if (!$isCli) {
    // Jika diakses via browser, wajib pakai secret key
    $secret = getenv('CRON_SECRET') ?: 'FIBERNET_CRON_SECRET_2024';
    $key    = $_GET['key'] ?? $_SERVER['HTTP_X_CRON_KEY'] ?? '';
    
    if (!hash_equals($secret, $key)) {
        http_response_code(403);
        die(json_encode(['error' => 'Forbidden: Invalid cron secret key']));
    }
    header('Content-Type: application/json; charset=utf-8');
}

// Set limit waktu eksekusi (10 menit)
@set_time_limit(600);
error_reporting(E_ALL);
ini_set('display_errors', $isCli ? '1' : '0');
ini_set('log_errors', '1');

// ── 2. Auto-detect Base Path (Fix untuk Termux/Cron) ────────
define('BASE_PATH', __DIR__);
define('STORAGE_PATH', BASE_PATH . '/storage');

// Pastikan folder storage dan logs ada
foreach ([STORAGE_PATH, STORAGE_PATH . '/logs', STORAGE_PATH . '/cron', STORAGE_PATH . '/backups'] as $dir) {
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
}

// ── 3. Bootstrap Aplikasi ───────────────────────────────────
try {
    // Sesuaikan path config/database.php jika struktur folder berbeda
    $dbConfig = BASE_PATH . '/config/database.php';
    $appConfig = BASE_PATH . '/config/app.php';
    
    if (file_exists($dbConfig)) require_once $dbConfig;
    if (file_exists($appConfig)) require_once $appConfig;
    
    // Autoload class Cron
    spl_autoload_register(function ($class) {
        $prefix = 'App\\Cron\\';
        if (strpos($class, $prefix) === 0) {
            $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
            $file = BASE_PATH . '/app/Cron/' . $relative . '.php';
            if (file_exists($file)) require_once $file;
        }
    });
    
} catch (\Throwable $e) {
    $msg = "BOOTSTRAP ERROR: " . $e->getMessage();
    if ($isCli) {
        fwrite(STDERR, $msg . "\n");
        exit(1);
    }
    http_response_code(500);
    die(json_encode(['error' => $msg]));
}

// ── 4. Parse Arguments ──────────────────────────────────────
$options = [
    'job'   => null,
    'force' => false,
    'list'  => false,
];

if ($isCli) {
    foreach ($argv as $arg) {
        if (str_starts_with($arg, '--job='))   $options['job']   = substr($arg, 6);
        if ($arg === '--force')                $options['force'] = true;
        if ($arg === '--list')                 $options['list']  = true;
    }
} else {
    $options['job']   = $_GET['job']   ?? null;
    $options['force'] = isset($_GET['force']);
    $options['list']  = isset($_GET['list']);
}

// ── 5. Eksekusi CronManager ─────────────────────────────────
try {
    if (!class_exists('App\\Cron\\CronManager')) {
        throw new \RuntimeException(
            "Class CronManager tidak ditemukan. Pastikan file app/Cron/CronManager.php ada."
        );
    }
    
    $cron = new App\Cron\CronManager();
    
    if ($options['list']) {
        $result = $cron->listJobs();
    } elseif ($options['job']) {
        $result = $cron->runJob($options['job'], $options['force']);
    } else {
        $result = $cron->runScheduled($options['force']);
    }
    
    // Output hasil
    if ($isCli) {
        echo "\n" . str_repeat('=', 60) . "\n";
        echo " FIBERNET CRON RESULT | " . date('Y-m-d H:i:s') . "\n";
        echo str_repeat('=', 60) . "\n";
        
        foreach ($result as $r) {
            $icon = match($r['status']) {
                'success' => '✓',
                'skipped' => '○',
                default   => '✗',
            };
            printf("  [%s] %-28s %s (%.2fs)\n", 
                $icon, 
                $r['job'], 
                $r['message'],
                $r['duration']
            );
        }
        echo str_repeat('=', 60) . "\n\n";
    } else {
        echo json_encode([
            'success'   => true,
            'timestamp' => date('Y-m-d H:i:s'),
            'results'   => $result
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
    
} catch (\Throwable $e) {
    $errorMsg = $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine();
    
    // Log error ke file
    @file_put_contents(
        STORAGE_PATH . '/logs/cron_error.log',
        "[" . date('Y-m-d H:i:s') . "] " . $errorMsg . "\n",
        FILE_APPEND | LOCK_EX
    );
    
    if ($isCli) {
        fwrite(STDERR, "FATAL ERROR: " . $errorMsg . "\n");
        exit(1);
    }
    
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $errorMsg]);
}
