<?php
/**
 * routes/web.php
 * Definisi rute aplikasi Billing ISP
 * PHP 8.4 Native Semi-Framework
 */

declare(strict_types=1);

use Core\Router;
use Core\AuthMiddleware;
use Core\GuestMiddleware;
use Controller\Auth\AuthController;
use Controller\Auth\ProfileController;
use Controller\Master\DashboardController;
use Controller\Master\PelangganController;
use Controller\Master\UserController;
use Controller\Master\PaketController;
use Controller\Master\AuditLogController;
use Controller\Master\SettingController;
use Controller\Keuangan\TagihanController;
use Controller\Keuangan\LaporanKasController;
use Controller\Keuangan\KasController;
use Controller\Keuangan\LaporanController;
use Controller\Layanan\TicketingController;
use Controller\Teknis\TeknikController;
use Controller\Teknis\MikrotikController;
use Controller\Master\UsageLogController;

$router = new Router();
// Portal Pelanggan
$router->get('/layanan-saya',               [Controller\Layanan\PelangganPortalController::class, 'layanan']);
$router->get('/pembayaran',                 [Controller\Layanan\PelangganPortalController::class, 'pembayaran']);
$router->get('/tagihan',                    [Controller\Layanan\PelangganPortalController::class, 'tagihan']);
$router->get('/pelanggan/ticketing',                  [Controller\Layanan\PelangganPortalController::class, 'pengaduan']);
$router->get('/pelanggan/ticketing/buat',             [Controller\Layanan\PelangganPortalController::class, 'pengaduanBuat']);
$router->post('/pelanggan/ticketing/store',           [Controller\Layanan\PelangganPortalController::class, 'pengaduanStore']);
$router->get('/pelanggan/ticketing/{id}',             [Controller\Layanan\PelangganPortalController::class, 'pengaduanDetail']);

// ============================================================================
// USAGE LOG — ringkasan bandwidth & cron history (Admin & Teknisi)
// ============================================================================

$router->get('/usage-log',               [UsageLogController::class, 'index'],     [AuthMiddleware::class]);
$router->get('/usage-log/cron',          [UsageLogController::class, 'cronLog'],   [AuthMiddleware::class]);
$router->post('/usage-log/cron/prune',   [UsageLogController::class, 'cronPrune'], [AuthMiddleware::class]);
$router->get('/usage-log/export',        [UsageLogController::class, 'export'],    [AuthMiddleware::class]);
// ============================================================================
// PUBLIK — tamu saja, redirect ke /dashboard jika sudah login
// ============================================================================
$router->get('/login',     [AuthController::class, 'showLogin'],    [GuestMiddleware::class]);
$router->post('/login',    [AuthController::class, 'login'],        [GuestMiddleware::class]);

// ====== PENDAFTARAN (publik) ======
// Form pendaftaran pelanggan baru. Akun baru otomatis status_internet = 'pending'.
// '/pendaftaran' & '/daftar' mengarah ke controller & view yang sama (alias).
$router->get('/daftar',              [PelangganController::class, 'pendaftaran'],      [GuestMiddleware::class]);
$router->get('/pendaftaran',         [PelangganController::class, 'pendaftaran'],      [GuestMiddleware::class]);
$router->post('/daftar',             [PelangganController::class, 'storePendaftaran'], [GuestMiddleware::class]);
$router->get('/daftar/cek-username', [PelangganController::class, 'cekUsername'],      [GuestMiddleware::class]);

// ====== DASHBOARD STATUS PELANGGAN (admin/kasir) ======
$router->get('/pelanggan/status',              [PelangganController::class, 'status'],       [AuthMiddleware::class]);
$router->post('/pelanggan/status/update/{id}', [PelangganController::class, 'updateStatus'], [AuthMiddleware::class]);

// ============================================================================
// DASHBOARD & AUTH — semua role yang sudah login
// ============================================================================

$router->get('/',          [DashboardController::class, 'index'],  [AuthMiddleware::class]);
$router->get('/dashboard', [DashboardController::class, 'index'],  [AuthMiddleware::class]);
$router->get('/logout',    [AuthController::class,      'logout'], [AuthMiddleware::class]);
$router->post('/logout',    [AuthController::class,      'logout'], [AuthMiddleware::class]);
 


// ============================================================================
// PROFIL & GANTI PASSWORD
// ============================================================================

$router->get('/profile',                 [ProfileController::class, 'index'],           [AuthMiddleware::class]);
$router->post('/profile/update',         [ProfileController::class, 'update'],          [AuthMiddleware::class]);
$router->get('/profile/ganti-password',  [ProfileController::class, 'changePassword'],  [AuthMiddleware::class]);
$router->post('/profile/ganti-password', [ProfileController::class, 'doChangePassword'],[AuthMiddleware::class]);

// ============================================================================
// MANAJEMEN USER — Admin only (roleGuard di controller)
// Rute spesifik harus di atas /{id}
// ============================================================================

$router->get('/users',                      [UserController::class, 'index'],          [AuthMiddleware::class]);
$router->get('/users/tambah',               [UserController::class, 'create'],         [AuthMiddleware::class]);
$router->post('/users/simpan',              [UserController::class, 'store'],          [AuthMiddleware::class]);
$router->get('/users/export',               [UserController::class, 'exportExcel'],    [AuthMiddleware::class]);
$router->get('/users/edit/{id}',            [UserController::class, 'edit'],           [AuthMiddleware::class]);
$router->post('/users/update/{id}',         [UserController::class, 'update'],         [AuthMiddleware::class]);
$router->post('/users/status/{id}',         [UserController::class, 'toggleStatus'],   [AuthMiddleware::class]);
$router->get('/users/reset-password/{id}',  [UserController::class, 'resetPassword'],  [AuthMiddleware::class]);
$router->post('/users/reset-password/{id}', [UserController::class, 'doResetPassword'],[AuthMiddleware::class]);
$router->post('/users/hapus/{id}',          [UserController::class, 'hapus'],          [AuthMiddleware::class]);
$router->get('/users/{id}',                 [UserController::class, 'show'],           [AuthMiddleware::class]);

// ============================================================================
// PAKET INTERNET — Admin & Kasir
// ============================================================================

$router->get('/paket',              [PaketController::class, 'index'],  [AuthMiddleware::class]);
$router->get('/paket/tambah',       [PaketController::class, 'create'], [AuthMiddleware::class]);
$router->post('/paket/simpan',      [PaketController::class, 'store'],  [AuthMiddleware::class]);
$router->get('/paket/edit/{id}',    [PaketController::class, 'edit'],   [AuthMiddleware::class]);
$router->post('/paket/update/{id}', [PaketController::class, 'update'], [AuthMiddleware::class]);
$router->post('/paket/hapus/{id}',  [PaketController::class, 'hapus'],  [AuthMiddleware::class]);

// ============================================================================
// PELANGGAN — Admin & Kasir
// Rute spesifik harus di atas /{id}
// ============================================================================

$router->get('/pelanggan',               [PelangganController::class, 'index'],       [AuthMiddleware::class]);
$router->get('/pelanggan/export',        [PelangganController::class, 'exportExcel'],  [AuthMiddleware::class]);
$router->get('/pelanggan/tambah',        [PelangganController::class, 'create'],      [AuthMiddleware::class]);
$router->post('/pelanggan/simpan',       [PelangganController::class, 'store'],       [AuthMiddleware::class]);
$router->get('/pelanggan/edit/{id}',     [PelangganController::class, 'edit'],        [AuthMiddleware::class]);
$router->post('/pelanggan/update/{id}',  [PelangganController::class, 'update'],      [AuthMiddleware::class]);
$router->post('/pelanggan/hapus/{id}',   [PelangganController::class, 'delete'],      [AuthMiddleware::class]);
$router->get('/pelanggan/{id}',          [PelangganController::class, 'show'],        [AuthMiddleware::class]);
$router->get('/pelanggan/{id}/uptime',      [PelangganController::class, 'uptimeApi']);
$router->get('/pelanggan/{id}/bandwidth',   [PelangganController::class, 'bandwidthApi']);
$router->get('/pelanggan/{id}/usageToday',  [PelangganController::class, 'usageTodayApi']);
$router->get('/pelanggan/{id}/usageMonth',  [PelangganController::class, 'usageMonthApi']);
$router->get('/pelanggan/{id}/usageTotal', [PelangganController::class, 'usageTotalApi'], [AuthMiddleware::class]);
$router->get('/pelanggan/{id}/usageTrend', [PelangganController::class, 'usageTrendApi'], [AuthMiddleware::class]);
$router->get('/pelanggan/{id}/usageToday',  [UsageLogController::class, 'usageToday'],  [AuthMiddleware::class]);
$router->get('/pelanggan/{id}/usageMonth',  [UsageLogController::class, 'usageMonth'],  [AuthMiddleware::class]);
$router->get('/pelanggan/import/template', [PelangganController::class, 'importTemplate']);
$router->post('/pelanggan/import', [PelangganController::class, 'importProcess']);
// ============================================================================
// TAGIHAN — Admin & Kasir
// Rute spesifik harus di atas /{id}
// ============================================================================

$router->get('/tagihan',              [TagihanController::class, 'index'],        [AuthMiddleware::class]);
$router->get('/tagihan/buat',         [TagihanController::class, 'buat'],         [AuthMiddleware::class]);
$router->post('/tagihan/simpan',      [TagihanController::class, 'simpan'],       [AuthMiddleware::class]);
$router->get('/tagihan/generate',     [TagihanController::class, 'generate'],     [AuthMiddleware::class]);
$router->get('/tagihan/edit/{id}',    [TagihanController::class, 'edit'],         [AuthMiddleware::class]);
$router->post('/tagihan/update/{id}', [TagihanController::class, 'update'],       [AuthMiddleware::class]);
$router->post('/tagihan/hapus/{id}',  [TagihanController::class, 'hapus'],        [AuthMiddleware::class]);
$router->get('/tagihan/bayar/{id}',   [TagihanController::class, 'bayar'],        [AuthMiddleware::class]);
$router->post('/tagihan/bayar/{id}',  [TagihanController::class, 'prosesBayar'],  [AuthMiddleware::class]);
$router->get('/tagihan/cetak/{id}',   [TagihanController::class, 'cetakInvoice'], [AuthMiddleware::class]);
$router->get('/tagihan/{id}',         [TagihanController::class, 'show'],         [AuthMiddleware::class]);

// ============================================================================
// KAS & KEUANGAN — Admin & Kasir
// ============================================================================

// ============================================================================
// KAS & KEUANGAN — Admin & Kasir
// ============================================================================

$router->get('/kas',              [KasController::class, 'index'],   [AuthMiddleware::class]);
$router->get('/kas/export',       [KasController::class, 'export'],  [AuthMiddleware::class]);
$router->get('/kas/tambah',       [KasController::class, 'create'],  [AuthMiddleware::class]);
$router->post('/kas/simpan',      [KasController::class, 'store'],   [AuthMiddleware::class]);
$router->get('/kas/edit/{id}',    [KasController::class, 'edit'],    [AuthMiddleware::class]);
$router->post('/kas/update/{id}', [KasController::class, 'update'],  [AuthMiddleware::class]);
$router->post('/kas/hapus/{id}',  [KasController::class, 'destroy'], [AuthMiddleware::class]);

// ============================================================================
// TICKETING — Semua role
// Rute spesifik harus di atas /{id}
// ============================================================================

$router->get('/ticketing',              [TicketingController::class, 'index'],       [AuthMiddleware::class]);
$router->get('/ticketing/buat',         [TicketingController::class, 'create'],      [AuthMiddleware::class]);
$router->post('/ticketing/buat',        [TicketingController::class, 'createTicket'],[AuthMiddleware::class]);
$router->post('/ticketing/update/{id}', [TicketingController::class, 'updateStatus'],[AuthMiddleware::class]);
$router->get('/ticketing/{id}',         [TicketingController::class, 'show'],        [AuthMiddleware::class]);

// ============================================================================
// LAPORAN
// ============================================================================

$router->get('/laporan/pembayaran', [LaporanController::class, 'pembayaran'], [AuthMiddleware::class]);
$router->get('/laporan/tagihan',    [LaporanController::class, 'tagihan'],    [AuthMiddleware::class]);
$router->get('/laporan/kas', [LaporanKasController::class, 'index'], [AuthMiddleware::class]);
$router->get('/laporan/kas/export',    [LaporanKasController::class, 'export'],    [AuthMiddleware::class]);


// ============================================================================
// TEKNIS — ODP & Peta Jaringan
// ============================================================================

$router->get('/teknis',      [TeknikController::class, 'index'], [AuthMiddleware::class]);
$router->get('/teknis/odp',  [TeknikController::class, 'odp'],   [AuthMiddleware::class]);
$router->get('/teknis/maps',     [TeknikController::class, 'maps'],     [AuthMiddleware::class]);


// ============================================================================
// MIKROTIK API — Admin & Teknisi
// Rute tanpa parameter harus di atas rute berparameter
// ============================================================================

$router->get('/mikrotik',                   [MikrotikController::class, 'index'],        [AuthMiddleware::class]);
$router->get('/mikrotik/test',              [MikrotikController::class, 'testConnection'],[AuthMiddleware::class]);
$router->get('/mikrotik/testpage', [MikrotikController::class, 'testPage'], [AuthMiddleware::class]);
$router->get('/mikrotik/status',            [MikrotikController::class, 'status'],        [AuthMiddleware::class]);

// VLAN Management
$router->get('/mikrotik/vlan',              [MikrotikController::class, 'vlan'],          [AuthMiddleware::class]);
$router->post('/mikrotik/vlan/update',      [MikrotikController::class, 'vlanUpdate'],    [AuthMiddleware::class]);

// Simple Queue (pakai method queue, bukan queues)
$router->get('/mikrotik/services', [MikrotikController::class, 'services'], [AuthMiddleware::class]);
// Active Connections (MAC-based)
$router->get('/mikrotik/active',               [MikrotikController::class, 'active'],      [AuthMiddleware::class]);
$router->get('/mikrotik/active/kick/{mac}',    [MikrotikController::class, 'kickByMac'],   [AuthMiddleware::class]);
$router->get('/mikrotik/queues',   [MikrotikController::class, 'queues'],   [AuthMiddleware::class]);
$router->post('/mikrotik/queue/update',     [MikrotikController::class, 'queueUpdate'],   [AuthMiddleware::class]);

// Toggle status isolir
$router->post('/mikrotik/toggle-status',    [MikrotikController::class, 'toggleStatus'],  [AuthMiddleware::class]);

// Detail per MAC
$router->get('/mikrotik/detail/{mac}',      [MikrotikController::class, 'detail'],        [AuthMiddleware::class]);

// ============================================================================
// DASHBOARD API — bandwidth total (AJAX)
// ============================================================================

$router->get('/dashboard/bandwidth-total', [DashboardController::class, 'bandwidthTotal'], [AuthMiddleware::class]);
$router->post('/dashboard/switch-mode', [Controller\Master\DashboardController::class, 'switchMode']);
$router->post('/dashboard/settings',    [Controller\Master\DashboardController::class, 'saveSettings']);

// ============================================================================
// AUDIT LOG — Admin only
// ============================================================================

$router->get('/audit-log',        [AuditLogController::class, 'index'], [AuthMiddleware::class]);
$router->post('/audit-log/prune', [AuditLogController::class, 'prune'], [AuthMiddleware::class]);

// ============================================================================
// PENGATURAN — Admin only
// ============================================================================

$router->get('/setting',         [SettingController::class, 'index'],     [AuthMiddleware::class]);
$router->post('/setting/update', [SettingController::class, 'update'],    [AuthMiddleware::class]);
$router->post('/setting/logo',   [SettingController::class, 'uploadLogo'],[AuthMiddleware::class]);

// ============================================================================
// Jalankan router
// ============================================================================

$router->resolve();
