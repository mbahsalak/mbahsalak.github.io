<?php
declare(strict_types=1);

namespace Config;

class Autoloader
{
    private static array $namespaceMap = [
        'Core'       => 'core',
        'Controller' => 'controller',
        'Model'      => 'model',
        'Config'     => 'config',
        'Service'    => 'Service',
    ];

    public static function register(): void
    {
        spl_autoload_register([self::class, 'load']);
    }

    public static function load(string $class): void
    {
        if (!defined('APP_ROOT')) {
            define('APP_ROOT', dirname(__DIR__));
        }

        foreach (self::$namespaceMap as $prefix => $baseDir) {
            if (!str_starts_with($class, $prefix . '\\')) continue;

            $relativeClass = substr($class, strlen($prefix) + 1);
            $relativePath = str_replace('\\', DIRECTORY_SEPARATOR, $relativeClass) . '.php';
            $fullPath = APP_ROOT . DIRECTORY_SEPARATOR . $baseDir . DIRECTORY_SEPARATOR . $relativePath;

            if (file_exists($fullPath)) {
                require_once $fullPath;
                return;
            }
        }
    }
}

// ── PERBAIKAN: Panggil register secara otomatis saat file di-load ──
Autoloader::register();
