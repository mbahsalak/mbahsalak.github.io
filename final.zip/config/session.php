<?php
/**
 * config/session.php
 * Konfigurasi session — Login bertahan 12 jam
 */

declare(strict_types=1);

// ── KONFIGURASI SESSION ──────────────────────────────────────────
// 12 jam = 43200 detik
// 24 jam = 86400 detik
// 7 hari = 604800 detik

$sessionLifetime = 43200; // 12 jam dalam detik

// Cookie lifetime — berapa lama cookie bertahan di browser
ini_set('session.cookie_lifetime', (string)$sessionLifetime);

// GC maxlifetime — berapa lama data session disimpan di server
ini_set('session.gc_maxlifetime', (string)$sessionLifetime);

// Keamanan cookie
ini_set('session.cookie_httponly', '1');       // Tidak bisa diakses JavaScript
ini_set('session.cookie_samesite', 'Strict');   // Mencegah CSRF
ini_set('session.cookie_secure', '0');          // Set '1' jika pakai HTTPS
ini_set('session.use_only_cookies', '1');       // Hanya pakai cookie, bukan URL
ini_set('session.use_strict_mode', '1');        // Tolak session ID yang tidak dikenal

// Simpan session di folder khusus (lebih aman dari default /tmp)
$savePath = __DIR__ . '/../storage/sessions';
if (!is_dir($savePath)) {
    mkdir($savePath, 0755, true);
}
ini_set('session.save_path', $savePath);

// Nama session (hindari nama default PHPSESSID)
session_name('FIBERNET_SID');

// ── START SESSION ──
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ── REGENERATE SESSION ID ──
// Regenerate setiap 30 menit untuk mencegah session fixation
if (!isset($_SESSION['_last_regeneration'])) {
    session_regenerate_id(true);
    $_SESSION['_last_regeneration'] = time();
} elseif (time() - $_SESSION['_last_regeneration'] > 1800) { // 30 menit
    session_regenerate_id(true);
    $_SESSION['_last_regeneration'] = time();
}

// ── CEK EXPIRY MANUAL (Double Check) ──
// Meskipun cookie sudah di-set 12 jam, kita tambahkan pengecekan di server
if (isset($_SESSION['_login_time'])) {
    if (time() - $_SESSION['_login_time'] > $sessionLifetime) {
        // Session sudah expired, hapus semua data
        $_SESSION = [];
        session_destroy();
        
        // Mulai session baru untuk flash message
        session_start();
        $_SESSION['flash'] = [
            'type' => 'warning',
            'message' => 'Sesi Anda telah berakhir. Silakan login kembali.'
        ];
        
        // Redirect ke login
        $appUrl = rtrim($_ENV['APP_URL'] ?? '', '/');
        header('Location: ' . $appUrl . '/login');
        exit;
    }
    
    // Update last activity (sliding expiry)
    $_SESSION['_last_activity'] = time();
}
