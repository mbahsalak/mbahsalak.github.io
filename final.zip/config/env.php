<?php
/**
 * Simple Environment Loader (Class Version)
 * Membaca file .env dan memasukkannya ke dalam $_ENV
 */

declare(strict_types=1);

namespace Config;

class Env
{
    /**
     * Membaca file .env dan memasukkannya ke dalam PHP global $_ENV & $_SERVER
     */
    public static function load(string $path): void
    {
        if (!file_exists($path)) {
            return;
        }

        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            // Abaikan komentar
            if (str_starts_with(trim($line), '#')) {
                continue;
            }

            // Pisahkan key dan value
            if (str_contains($line, '=')) {
                [$key, $value] = explode('=', $line, 2);
                $key = trim($key);
                $value = trim($value);

                // Bersihkan tanda kutip jika ada
                $value = trim($value, '"\'');

                if (!self::arrayKeyWithValueExists($key)) {
                    putenv("{$key}={$value}");
                    $_ENV[$key] = $value;
                    $_SERVER[$key] = $value;
                }
            }
        }
    }

    /**
     * Memeriksa apakah key sudah terdaftar di $_ENV atau $_SERVER
     */
    private static function arrayKeyWithValueExists(string $key): bool
    {
        return array_key_exists($key, $_ENV) || array_key_exists($key, $_SERVER);
    }
}

// Otomatis jalankan load file .env dari root project saat file ini dipanggil via autoloader
Env::load(dirname(__DIR__) . '/.env');

// --- Auto-detect APP_URL jika belum di-set di .env ---
// Karena index.php ada di public/, APP_URL harus menunjuk ke folder public/
if (empty($_ENV['APP_URL'])) {
    $scheme   = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host     = $_SERVER['HTTP_HOST'] ?? 'localhost';
    // Hitung subfolder: ambil path script tanpa /index.php
    $basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
    $appUrl   = $scheme . '://' . $host . $basePath;
    $_ENV['APP_URL']    = $appUrl;
    $_SERVER['APP_URL'] = $appUrl;
    putenv("APP_URL={$appUrl}");
}

   