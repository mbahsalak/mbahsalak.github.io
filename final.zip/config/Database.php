<?php
/**
 * Database Connection - PDO Singleton Pattern
 */

declare(strict_types=1);

namespace Config;

use PDO;
use PDOException;
use RuntimeException;

class Database
{
    private static ?PDO $instance = null;

    /**
     * Private constructor untuk mencegah instalasi langsung via kata kunci 'new'
     */
    private function __construct() {}

    /**
     * Mengambil instance tunggal dari koneksi database PDO
     */
    public static function getConnection(): PDO
    {
        if (self::$instance === null) {
            // Ambil konfigurasi dari $_ENV (hasil load env.php)
            $host    = $_ENV['DB_HOST'] ?? '127.0.0.1';
            $port    = $_ENV['DB_PORT'] ?? '3306';
            $db      = $_ENV['DB_NAME'] ?? 'dina_net';
            $user    = $_ENV['DB_USER'] ?? 'root';
            $pass    = $_ENV['DB_PASS'] ?? '';
            $charset = 'utf8mb4';

            $dsn = "mysql:host={$host};port={$port};dbname={$db};charset={$charset}";

            // PHP 8.4-: PDO::MYSQL_ATTR_INIT_COMMAND
            // PHP 8.5+: Pdo\Mysql::ATTR_INIT_COMMAND (non-deprecated)
            $initCmd = class_exists(\Pdo\Mysql::class)
                ? \Pdo\Mysql::ATTR_INIT_COMMAND
                : PDO::MYSQL_ATTR_INIT_COMMAND;

            // Konfigurasi driver PDO demi keamanan dan kestabilan data
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Melempar error berupa Exception
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Hasil fetch otomatis berupa Array Asosiatif
                PDO::ATTR_EMULATE_PREPARES   => false,                  // Menonaktifkan emulasi, native prepare SQL demi keamanan SQL Injection
                $initCmd                     => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
            ];

            try {
                self::$instance = new PDO($dsn, $user, $pass, $options);
            } catch (PDOException $e) {
                // Jangan tampilkan detail kredensial mentah ke user demi keamanan cyber
                throw new RuntimeException("Koneksi Database Gagal: " . $e->getMessage(), (int)$e->getCode());
            }
        }

        return self::$instance;
    }

    /**
     * Mencegah duplikasi objek via cloning
     */
    private function __clone() {}

    /**
     * Mencegah restore via unserialize
     */
    public function __wakeup()
    {
        throw new RuntimeException("Tidak dapat menyatukan kembali instance Singleton.");
    }
}
