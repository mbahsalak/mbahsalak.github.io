<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'Login' ?> — FiberNet</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --primary:        #3b82f6;
            --primary-dark:   #2563eb;
            --primary-ring:   rgba(59,130,246,.18);
            --bg:             #f1f5f9;
            --card:           #ffffff;
            --border:         #e2e8f0;
            --text:           #0f172a;
            --text-2:         #334155;
            --muted:          #64748b;
            --danger:         #dc2626;
            --danger-bg:      #fef2f2;
            --danger-border:  #fecaca;
            --success:        #16a34a;
            --success-bg:     #f0fdf4;
            --success-border: #bbf7d0;
            --radius:         .625rem;
            --radius-sm:      .375rem;
            --shadow:         0 4px 6px -1px rgba(0,0,0,.07), 0 2px 4px -2px rgba(0,0,0,.05);
            --shadow-lg:      0 20px 40px rgba(0,0,0,.10);
        }

        body {
            font-family: 'Inter', system-ui, sans-serif;
            font-size: .9375rem;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1.5rem;
        }

        /* ── Card ── */
        .auth-card {
            width: 100%;
            max-width: 420px;
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow-lg);
            padding: 2.5rem 2.25rem;
        }

        /* ── Brand ── */
        .auth-brand {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: .75rem;
            margin-bottom: 2rem;
        }
        .auth-brand__icon {
            width: 2.75rem;
            height: 2.75rem;
            border-radius: var(--radius-sm);
            background: var(--primary);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            flex-shrink: 0;
        }
        .auth-brand__name  { font-size: 1.15rem; font-weight: 700; color: var(--text); line-height: 1.2; }
        .auth-brand__sub   { font-size: .72rem;  color: var(--muted); }

        /* ── Heading ── */
        .auth-heading { text-align: center; margin-bottom: 1.75rem; }
        .auth-heading h1 { font-size: 1.3rem; font-weight: 700; margin-bottom: .3rem; }
        .auth-heading p  { font-size: .84rem; color: var(--muted); }

        /* ── Alert ── */
        .auth-alert {
            display: flex;
            align-items: flex-start;
            gap: .55rem;
            padding: .72rem .9rem;
            border-radius: var(--radius-sm);
            font-size: .84rem;
            line-height: 1.5;
            margin-bottom: 1.25rem;
        }
        .auth-alert i { margin-top: .15rem; flex-shrink: 0; }
        .auth-alert--error   { background: var(--danger-bg);  border: 1px solid var(--danger-border);  color: var(--danger); }
        .auth-alert--success { background: var(--success-bg); border: 1px solid var(--success-border); color: var(--success); }

        /* ── Form ── */
        .form-group { margin-bottom: 1.2rem; }

        label {
            display: block;
            font-size: .8rem;
            font-weight: 600;
            color: var(--text-2);
            margin-bottom: .45rem;
            letter-spacing: .01em;
        }
        label i { color: var(--primary); margin-right: .35rem; }

        input[type="text"],
        input[type="password"],
        input[type="email"] {
            width: 100%;
            padding: .65rem .9rem;
            font-family: inherit;
            font-size: .9rem;
            border: 1.5px solid var(--border);
            border-radius: var(--radius-sm);
            background: #f8fafc;
            color: var(--text);
            transition: border-color .18s, box-shadow .18s, background .18s;
            outline: none;
        }
        input:focus {
            border-color: var(--primary);
            background: #fff;
            box-shadow: 0 0 0 3px var(--primary-ring);
        }
        input::placeholder { color: #b0bec5; }

        /* ── Button ── */
        .btn-primary {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: .5rem;
            width: 100%;
            padding: .72rem 1rem;
            background: var(--primary);
            color: #fff;
            font-family: inherit;
            font-size: .9rem;
            font-weight: 600;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            transition: background .18s, box-shadow .18s, transform .1s;
            margin-top: .5rem;
        }
        .btn-primary:hover  { background: var(--primary-dark); box-shadow: 0 4px 12px rgba(59,130,246,.35); }
        .btn-primary:active { transform: translateY(1px); }

        /* ── Footer ── */
        .auth-footer {
            text-align: center;
            margin-top: 1.75rem;
            font-size: .78rem;
            color: var(--muted);
        }

        /* ── Divider ── */
        .auth-divider {
            border: none;
            border-top: 1px solid var(--border);
            margin: 1.5rem 0;
        }
    </style>
</head>
<body>

<div class="auth-card">

    <!-- Brand -->
    <div class="auth-brand">
        <span class="auth-brand__icon"><i class="fa-solid fa-wifi"></i></span>
        <div>
            <div class="auth-brand__name">FiberNet</div>
            <div class="auth-brand__sub">Billing System</div>
        </div>
    </div>

    <!-- Flash dari controller -->
    <?php if (isset($flash)): ?>
    <div class="auth-alert auth-alert--<?= $flash['type'] === 'success' ? 'success' : 'error' ?>">
        <i class="fa-solid fa-<?= $flash['type'] === 'success' ? 'circle-check' : 'circle-exclamation' ?>"></i>
        <span><?= htmlspecialchars($flash['message']) ?></span>
    </div>
    <?php endif; ?>

    <?= $content ?? '' ?>

</div>

</body>
</html>
