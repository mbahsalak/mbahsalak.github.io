<?php
/**
 * views/layouts/auth.php
 * Layout untuk halaman auth (login/register)
 */
declare(strict_types=1);

$appUrl  = rtrim($_ENV['APP_URL'] ?? '', '/');
$appName = $appSettings['app_name']    ?? 'Billing ISP';
$appLogo = $appSettings['app_logo']    ?? '';
$tagline = $appSettings['app_tagline'] ?? 'Sistem Billing Internet Service Provider';

$bannerImg = $authSettings['auth_banner_image']  ?? '';
$infoTitle = $authSettings['auth_info_title']    ?? '';
$infoBody  = $authSettings['auth_info_body']     ?? '';
$primary   = $authSettings['auth_primary_color'] ?? '#6366f1';

// ✅ Helper normalisasi URL: mencegah double slash & mendukung URL absolut
$assetUrl = function(string $path) use ($appUrl): string {
    if ($path === '') return '';
    if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
        return $path;
    }
    return $appUrl . '/' . ltrim($path, '/');
};

$logoUrl   = $assetUrl($appLogo);
$bannerUrl = $assetUrl($bannerImg);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title ?? 'Login') ?> — <?= htmlspecialchars($appName) ?></title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        *, *::before, *::after { box-sizing: border-box; }
        body { margin: 0; font-family: 'Inter', system-ui, sans-serif; }

        .auth-input:focus {
            border-color: <?= htmlspecialchars($primary) ?> !important;
            background: #fff !important;
            box-shadow: 0 0 0 3px <?= htmlspecialchars($primary) ?>22 !important;
        }
        .auth-input::placeholder { color: #b0bec5; }
        .auth-submit:hover  { filter: brightness(1.08); }
        .auth-submit:active { transform: translateY(1px); }
        .auth-link:hover    { text-decoration: underline; }

        @media (max-width: 480px) {
            .auth-card { padding: 1.75rem 1.25rem !important; }
        }
    </style>
</head>
<body style="background:#f1f5f9;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:2rem 1rem;">

<div style="width:100%;max-width:420px;">

    <div class="auth-card" style="background:#fff;border:1px solid #e5e7eb;border-radius:16px;
                box-shadow:0 20px 60px rgba(0,0,0,.12);padding:2.5rem 2.25rem;">

        <?php if ($bannerUrl): ?>
            <div style="margin:-2.5rem -2.25rem 1.5rem;border-radius:16px 16px 0 0;overflow:hidden;">
                <img src="<?= htmlspecialchars($bannerUrl) ?>" alt="Banner"
                     style="width:100%;height:180px;object-fit:cover;display:block;"
                     onerror="this.parentElement.style.display='none'">
            </div>
        <?php endif; ?>

        <!-- Brand -->
        <div style="display:flex;align-items:center;justify-content:center;gap:.75rem;margin-bottom:2rem;">
            <?php if ($logoUrl): ?>
                <img src="<?= htmlspecialchars($logoUrl) ?>"
                     alt="<?= htmlspecialchars($appName) ?>"
                     style="width:40px;height:40px;border-radius:8px;object-fit:contain;flex-shrink:0;"
                     onerror="this.onerror=null;this.style.display='none';this.nextElementSibling.style.display='flex';">
                <!-- Fallback icon (tersembunyi kecuali img error) -->
                <span style="display:none;width:40px;height:40px;border-radius:8px;background:<?= htmlspecialchars($primary) ?>;
                             color:#fff;align-items:center;justify-content:center;
                             font-size:1.1rem;flex-shrink:0;">
                    <i class="fa-solid fa-wifi"></i>
                </span>
            <?php else: ?>
                <span style="width:40px;height:40px;border-radius:8px;background:<?= htmlspecialchars($primary) ?>;
                             color:#fff;display:flex;align-items:center;justify-content:center;
                             font-size:1.1rem;flex-shrink:0;">
                    <i class="fa-solid fa-wifi"></i>
                </span>
            <?php endif; ?>
            <div>
                <div style="font-size:1.1rem;font-weight:700;color:#0f172a;line-height:1.2;">
                    <?= htmlspecialchars($appName) ?>
                </div>
                <div style="font-size:.7rem;color:#64748b;"><?= htmlspecialchars($tagline) ?></div>
            </div>
        </div>

        <?php if (!empty($flash)): ?>
            <div style="display:flex;align-items:flex-start;gap:.55rem;padding:.72rem .9rem;border-radius:8px;
                        font-size:.83rem;line-height:1.5;margin-bottom:1.25rem;
                        background:<?= ($flash['type'] ?? '') === 'success' ? '#f0fdf4' : '#fef2f2' ?>;
                        border:1px solid <?= ($flash['type'] ?? '') === 'success' ? '#bbf7d0' : '#fecaca' ?>;
                        color:<?= ($flash['type'] ?? '') === 'success' ? '#16a34a' : '#dc2626' ?>;">
                <i class="fa-solid fa-<?= ($flash['type'] ?? '') === 'success' ? 'circle-check' : 'circle-exclamation' ?>"
                   style="margin-top:.15rem;flex-shrink:0;"></i>
                <span><?= htmlspecialchars($flash['message'] ?? '') ?></span>
            </div>
        <?php endif; ?>

        <?= $content ?? '' ?>

    </div>

    <?php if ($infoBody): ?>
        <div style="text-align:center;margin-top:1.5rem;padding:0 1rem;">
            <?php if ($infoTitle): ?>
                <div style="font-size:.78rem;font-weight:700;color:#334155;margin-bottom:.25rem;">
                    <?= htmlspecialchars($infoTitle) ?>
                </div>
            <?php endif; ?>
            <div style="font-size:.75rem;color:#64748b;line-height:1.5;"><?= htmlspecialchars($infoBody) ?></div>
        </div>
    <?php endif; ?>

    <div style="text-align:center;margin-top:1.5rem;font-size:.75rem;color:#94a3b8;">
        <?= htmlspecialchars($appName) ?> &copy; <?= date('Y') ?>
    </div>

</div>

</body>
</html>
