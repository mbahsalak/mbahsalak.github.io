<?php
/**
 * views/layouts/main.php
 * PHP 8.4 — Logout FIXED di sidebar & topbar
 */

declare(strict_types=1);

$title      = $title      ?? 'Dashboard';
$activeMenu = $activeMenu ?? '';
$content    = $content    ?? '';
$appUrl     = rtrim($_ENV['APP_URL'] ?? '', '/');

// Baca user dari session
$sessionUser = $_SESSION['user'] ?? [];
$userNama    = $sessionUser['nama_lengkap'] ?? $sessionUser['username'] ?? 'User';
$userRole    = $sessionUser['role'] ?? 'guest';
$userInisial = mb_strtoupper(mb_substr($userNama, 0, 1));
$csrf        = $_SESSION['csrf_token'] ?? '';

$esc = fn(string $s): string => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="id" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $esc($title) ?> — FiberNet</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com/3.4.16"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'system-ui', 'sans-serif'],
                        mono: ['JetBrains Mono', 'monospace'],
                    },
                    colors: {
                        primary: '#6366f1',
                        sidebar: '#0f172a',
                    },
                    animation: {
                        'fade-in-down': 'fadeInDown 0.3s ease-out',
                    },
                    keyframes: {
                        fadeInDown: {
                            '0%':   { opacity: '0', transform: 'translateY(-10px)' },
                            '100%': { opacity: '1', transform: 'translateY(0)' },
                        }
                    }
                }
            }
        }
    </script>

    <style>
        #sidebarNav::-webkit-scrollbar { width: 4px; }
        #sidebarNav::-webkit-scrollbar-track { background: transparent; }
        #sidebarNav::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 2px; }
        #sidebarNav::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.2); }
        .flash-hide { opacity: 0; transform: translateY(-10px); transition: all 0.3s ease; }
    </style>
</head>

<body class="h-full bg-slate-50 dark:bg-slate-800 font-sans antialiased text-slate-700 dark:text-slate-200">

    <div class="flex h-full min-h-screen">

        <!-- SIDEBAR -->
        <?php include __DIR__ . '/sidebar.php'; ?>

        <!-- MAIN CONTENT WRAPPER -->
        <div class="flex-1 flex flex-col min-w-0 lg:ml-0">

            <!-- TOPBAR -->
            <header class="sticky top-0 z-30 h-16 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-4 lg:px-6 shrink-0">

                <!-- Left -->
                <div class="flex items-center gap-3">
                    <button id="sidebarOpenBtn" class="lg:hidden w-10 h-10 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors" aria-label="Buka menu">
                        <i class="fa-solid fa-bars text-lg"></i>
                    </button>
                    <h1 class="hidden sm:block text-lg font-semibold text-slate-800 dark:text-white truncate">
                        <?= $esc($title) ?>
                    </h1>
                </div>

                <!-- Right -->
                <div class="flex items-center gap-2">
                    <!-- Theme Toggle -->
                    <button id="themeToggle" class="w-10 h-10 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 transition-colors" title="Ganti tema">
                        <i class="fa-solid fa-moon dark:hidden"></i>
                        <i class="fa-solid fa-sun hidden dark:inline"></i>
                    </button>

                    <!-- User Dropdown -->
                    <div class="relative" id="userDropdownWrapper">
                        <button id="userDropdownBtn" class="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                            <div class="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold shrink-0">
                                <?= $esc($userInisial) ?>
                            </div>
                            <div class="hidden sm:block text-left leading-tight">
                                <span class="block text-sm font-medium text-slate-700 dark:text-slate-200 truncate max-w-[120px]"><?= $esc($userNama) ?></span>
                                <span class="block text-[10px] text-slate-400 capitalize"><?= $esc($userRole) ?></span>
                            </div>
                            <i class="fa-solid fa-chevron-down text-[10px] text-slate-400 ml-1"></i>
                        </button>

                        <!-- Dropdown Menu -->
                        <div id="userDropdownMenu" class="hidden absolute right-0 top-full mt-2 w-56 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 py-2 animate-fade-in-down z-50">
                            <a href="<?= $esc($appUrl) ?>/profil" class="flex items-center gap-3 px-4 py-2.5 text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                                <i class="fa-solid fa-circle-user w-5 text-center text-slate-400"></i>
                                <span>Profil Saya</span>
                            </a>
                            <a href="<?= $esc($appUrl) ?>/ubah-password" class="flex items-center gap-3 px-4 py-2.5 text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                                <i class="fa-solid fa-key w-5 text-center text-slate-400"></i>
                                <span>Ubah Password</span>
                            </a>
                            <hr class="my-2 border-slate-200 dark:border-slate-700">

                            <!-- ✅ LOGOUT TOPBAR — TANPA display:contents -->
                            <form id="logoutFormTopbar"
                                  action="<?= $esc($appUrl) ?>/logout"
                                  method="POST"
                                  class="w-full px-0 py-0"
                                  onsubmit="return handleLogout(event, this)">
                                <input type="hidden" name="csrf_token" value="<?= $esc($csrf) ?>">
                                <button type="submit"
                                        class="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors text-left cursor-pointer border-0 bg-transparent">
                                    <i class="fa-solid fa-arrow-right-from-bracket w-5 text-center"></i>
                                    <span>Keluar</span>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </header>

            <!-- PAGE CONTENT -->
            <main class="flex-1 p-4 lg:p-6 overflow-y-auto">
                <?= $content ?>
            </main>

            <!-- FOOTER -->
            <footer class="shrink-0 px-4 lg:px-6 py-4 border-t border-slate-200 dark:border-slate-700 text-center">
                <p class="text-xs text-slate-400">
                    &copy; <?= date('Y') ?> FiberNet Billing System &middot; PHP <?= PHP_VERSION ?>
                </p>
            </footer>

        </div>
    </div>

    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <!-- App Scripts -->
    <script>
    (() => {
        'use strict';

        const sidebar     = document.getElementById('sidebar');
        const overlay     = document.getElementById('sidebarOverlay');
        const openBtn     = document.getElementById('sidebarOpenBtn');
        const closeBtn    = document.getElementById('sidebarCloseBtn');
        const themeToggle = document.getElementById('themeToggle');
        const userDropBtn = document.getElementById('userDropdownBtn');
        const userDropMenu = document.getElementById('userDropdownMenu');

        // ── SIDEBAR TOGGLE ──
        const openSidebar = () => {
            sidebar?.classList.remove('-translate-x-full');
            sidebar?.classList.add('translate-x-0');
            overlay?.classList.remove('hidden');
            setTimeout(() => overlay?.classList.remove('opacity-0'), 10);
        };

        const closeSidebar = () => {
            sidebar?.classList.remove('translate-x-0');
            sidebar?.classList.add('-translate-x-full');
            overlay?.classList.add('opacity-0');
            setTimeout(() => overlay?.classList.add('hidden'), 300);
        };

        openBtn?.addEventListener('click', openSidebar);
        closeBtn?.addEventListener('click', closeSidebar);
        overlay?.addEventListener('click', closeSidebar);

        document.querySelectorAll('#sidebar .sidebar-link').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 1024) closeSidebar();
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth >= 1024) closeSidebar();
        });

        // ── THEME TOGGLE ──
        const applyTheme = (theme) => {
            document.documentElement.classList.toggle('dark', theme === 'dark');
        };

        const savedTheme = localStorage.getItem('theme');
        if (savedTheme) {
            applyTheme(savedTheme);
        } else if (window.matchMedia?.('(prefers-color-scheme: dark)').matches) {
            applyTheme('dark');
        }

        themeToggle?.addEventListener('click', () => {
            const isDark = document.documentElement.classList.contains('dark');
            const newTheme = isDark ? 'light' : 'dark';
            applyTheme(newTheme);
            localStorage.setItem('theme', newTheme);
        });

        // ── USER DROPDOWN ──
        userDropBtn?.addEventListener('click', (e) => {
            e.stopPropagation();
            userDropMenu?.classList.toggle('hidden');
        });

        document.addEventListener('click', (e) => {
            if (!document.getElementById('userDropdownWrapper')?.contains(e.target)) {
                userDropMenu?.classList.add('hidden');
            }
        });

        // ── FLASH MESSAGE AUTO-DISMISS ──
        document.querySelectorAll('[data-flash]').forEach(el => {
            setTimeout(() => {
                el.classList.add('flash-hide');
                setTimeout(() => el.remove(), 300);
            }, 5000);
        });

    })();
    </script>

</body>
</html>
