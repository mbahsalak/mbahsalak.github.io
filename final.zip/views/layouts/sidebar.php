<?php
/**
 * views/layouts/sidebar.php
 * PHP 8.4 Compatible — Logout FIXED
 * ✅ Navigasi pelanggan dibedakan: aktif / isolir / nonaktif / pending
 */

declare(strict_types=1);

// ── BACA LANGSUNG DARI SESSION ──
$sessionUser = $_SESSION['user'] ?? [];
$activeMenu  = $activeMenu ?? '';
$role        = $sessionUser['role'] ?? 'guest';
$appUrl      = rtrim($_ENV['APP_URL'] ?? '', '/');

$nama    = $sessionUser['nama_lengkap'] ?? $sessionUser['username'] ?? 'User';
$inisial = mb_strtoupper(mb_substr($nama, 0, 1));
$csrf    = $_SESSION['csrf_token'] ?? '';

// ── Untuk role pelanggan: baca status_internet ──
// ── Untuk role pelanggan: baca status_internet ──
$pelangganStatus = 'pending'; // Default aman
if ($role === 'pelanggan') {
    // ✅ Ambil pelanggan_id dari session, atau cari via user_id
    $pid = $sessionUser['pelanggan_id'] ?? null;
    $uid = $sessionUser['id'] ?? null;
    
    if (!$pid && $uid) {
        try {
            $db = \Config\Database::getConnection();
            $stmt = $db->prepare("SELECT id FROM pelanggan WHERE user_id = ? LIMIT 1");
            $stmt->execute([$uid]);
            $pid = $stmt->fetchColumn();
        } catch (\Throwable) {
            $pid = null;
        }
    }
    
    if ($pid) {
        try {
            $db   = \Config\Database::getConnection();
            $stmt = $db->prepare("SELECT status_internet FROM pelanggan WHERE id = ? LIMIT 1");
            $stmt->execute([$pid]);
            $raw = $stmt->fetchColumn();
            
            // ✅ Normalisasi status
            if ($raw === false || $raw === null || trim((string)$raw) === '') {
                $pelangganStatus = 'pending';
            } else {
                $rawStr = trim(strtolower((string)$raw));
                $pelangganStatus = match (true) {
                    in_array($rawStr, ['aktif', 'active']) => 'aktif',
                    in_array($rawStr, ['isolir', 'isolated', 'suspend', 'suspended']) => 'isolir',
                    in_array($rawStr, ['nonaktif', 'inactive', 'non-aktif']) => 'nonaktif',
                    in_array($rawStr, ['pending', 'menunggu']) => 'pending',
                    default => 'aktif',
                };
            }
        } catch (\Throwable $e) {
            $pelangganStatus = 'pending';
            error_log("[Sidebar] Status check failed: " . $e->getMessage());
        }
    }
}



// Normalisasi status (pastikan konsisten)
$pelangganStatus = match (true) {
    in_array($pelangganStatus, ['isolir', 'isolated', 'suspend', 'suspended'], true) => 'isolir',
    in_array($pelangganStatus, ['nonaktif', 'inactive', 'non-aktif'], true)           => 'nonaktif',
    in_array($pelangganStatus, ['pending', 'menunggu'], true)                          => 'pending',
    default                                                                            => 'aktif',
};

// ── DEFINISI MENU — PHP 8.4 match expression ──
$menus = match ($role) {
    'admin' => [
        [
            'label' => 'UTAMA',
            'items' => [
                ['key' => 'dashboard',  'icon' => 'fa-gauge',               'label' => 'Dashboard',       'href' => '/dashboard',     'children' => []],
                ['key' => 'pelanggan',  'icon' => 'fa-users',               'label' => 'Pelanggan',        'href' => '/pelanggan',     'children' => []],
                ['key' => 'tagihan',    'icon' => 'fa-file-invoice-dollar', 'label' => 'Tagihan',          'href' => '/tagihan',       'children' => []],
            ],
        ],
        [
            'label' => 'KEUANGAN',
            'items' => [
                ['key' => 'kas',        'icon' => 'fa-money-bill-trend-up', 'label' => 'Kas & Keuangan',   'href' => '/kas',           'children' => []],
                ['key' => 'laporan',    'icon' => 'fa-chart-bar',           'label' => 'Laporan',          'href' => '#',
                    'children' => [
                        ['key' => 'laporan_pendapatan', 'label' => 'Pendapatan',  'href' => '/laporan/pembayaran'],
                        ['key' => 'laporan_tagihan',    'label' => 'Tagihan',     'href' => '/laporan/tagihan'],
                        ['key' => 'laporan_pengaduan',  'label' => 'Pengaduan',   'href' => '/laporan/pengaduan'],
                    ],
                ],
            ],
        ],
        [
            'label' => 'LAYANAN',
            'items' => [
                ['key' => 'ticketing',    'icon' => 'fa-headset',  'label' => 'Pengaduan',        'href' => '/ticketing',         'children' => []],
                ['key' => 'pendaftaran',  'icon' => 'fa-headset',  'label' => 'Status Pelanggan',  'href' => '/pelanggan/status',  'children' => []],
            ],
        ],
        [
            'label' => 'TEKNIS & JARINGAN',
            'items' => [
                ['key' => 'jaringan',   'icon' => 'fa-network-wired', 'label' => 'Teknis & Jaringan', 'href' => '#',
                    'children' => [
                        ['key' => 'odp',        'label' => 'ODP / ODC',     'href' => '/teknis'],
                        ['key' => 'maps',       'label' => 'Maps',          'href' => '/teknis/maps'],
                        ['key' => 'mikrotik',   'label' => 'MikroTik',      'href' => '/mikrotik'],
                        ['key' => 'monitoring', 'label' => 'Monitoring',    'href' => '/mikrotik/active'],
                    ],
                ],
            ],
        ],
        [
            'label' => 'Administrator',
            'items' => [
                ['key' => 'admin_panel', 'icon' => 'fa-shield-halved', 'label' => 'Administrasi', 'href' => '#',
                    'children' => [
                        ['key' => 'users',    'label' => 'Manajemen User',  'href' => '/users'],
                        ['key' => 'settings', 'label' => 'Pengaturan',      'href' => '/setting'],
                        ['key' => 'paket',    'icon' => 'fa-wifi', 'label' => 'Paket Internet', 'href' => '/paket', 'children' => []],
                    ],
                ],
            ],
        ],
    ],

    'teknisi' => [
        [
            'label' => 'UTAMA',
            'items' => [
                ['key' => 'dashboard',   'icon' => 'fa-gauge',   'label' => 'Dashboard',     'href' => '/dashboard',     'children' => []],
                ['key' => 'ticketing',   'icon' => 'fa-headset', 'label' => 'Pengaduan',     'href' => '/ticketing',     'children' => []],
                ['key' => 'pelanggan',   'icon' => 'fa-users',   'label' => 'Pelanggan',      'href' => '/pelanggan',     'children' => []],
                ['key' => 'pendaftaran', 'icon' => 'fa-users',   'label' => 'Status Pelanggan',    'href' => '/pelanggan/status',   'children' => []],
            ],
        ],
    ],

    'kasir' => [
        [
            'label' => 'UTAMA',
            'items' => [
                ['key' => 'dashboard',  'icon' => 'fa-gauge',   'label' => 'Dashboard',     'href' => '/dashboard', 'children' => []],
                ['key' => 'pelanggan',  'icon' => 'fa-users',   'label' => 'Pelanggan',      'href' => '/pelanggan', 'children' => []],
            ],
        ],
        [
            'label' => 'KEUANGAN',
            'items' => [
                ['key' => 'tagihan', 'icon' => 'fa-file-invoice-dollar', 'label' => 'Tagihan',        'href' => '/tagihan', 'children' => []],
                ['key' => 'kas',     'icon' => 'fa-money-bill-trend-up', 'label' => 'Kas & Keuangan', 'href' => '/kas',     'children' => []],
                ['key' => 'laporan', 'icon' => 'fa-chart-bar',           'label' => 'Laporan',        'href' => '#',
                    'children' => [
                        ['key' => 'laporan_pendapatan', 'label' => 'Pendapatan', 'href' => '/laporan/pembayaran'],
                        ['key' => 'laporan_tagihan',    'label' => 'Tagihan',    'href' => '/laporan/tagihan'],
                    ],
                ],
            ],
        ],
        [
            'label' => 'LAYANAN',
            'items' => [
                ['key' => 'ticketing', 'icon' => 'fa-headset', 'label' => 'Ticketing', 'href' => '/ticketing', 'children' => []],
            ],
        ],
    ],

    // ══════════════════════════════════════════════════════════════
    //  PELANGGAN — 4 STATUS BERBEDA
    // ══════════════════════════════════════════════════════════════

    default => match ($pelangganStatus) {

        // ── AKTIF: Menu lengkap ──
        'aktif' => [
            [
                'label' => 'MENU',
                'items' => [
                    ['key' => 'dashboard',    'icon' => 'fa-gauge',               'label' => 'Dashboard',      'href' => '/dashboard',     'children' => []],
                    ['key' => 'layanan_saya', 'icon' => 'fa-wifi',                'label' => 'Layanan Saya',   'href' => '/layanan-saya',  'children' => []],
                    ['key' => 'tagihan',      'icon' => 'fa-file-invoice-dollar', 'label' => 'Tagihan',        'href' => '/tagihan',       'children' => []],
                    ['key' => 'pembayaran',   'icon' => 'fa-credit-card',         'label' => 'Pembayaran',     'href' => '/pembayaran',    'children' => []],
                ],
            ],
            [
                'label' => 'BANTUAN',
                'items' => [
                    ['key' => 'ticketing', 'icon' => 'fa-headset', 'label' => 'Bantuan', 'href' => '/ticketing', 'children' => []],
                ],
            ],
        ],

        // ── ISOLIR: Bisa lihat tagihan & bayar, tapi tidak ada layanan ──
        'isolir' => [
            [
                'label' => 'MENU',
                'items' => [
                    ['key' => 'dashboard',  'icon' => 'fa-gauge', 'label' => 'Dashboard', 'href' => '/dashboard', 'children' => []],
                ],
            ],
            [
                'label' => 'TAGIHAN TERTUNDA',
                'items' => [
                    ['key' => 'tagihan',    'icon' => 'fa-file-invoice-dollar', 'label' => 'Tagihan Saya',   'href' => '/tagihan',     'children' => []],
                    ['key' => 'pembayaran', 'icon' => 'fa-credit-card',         'label' => 'Bayar Sekarang', 'href' => '/pembayaran',  'children' => []],
                ],
            ],
            [
                'label' => 'BANTUAN',
                'items' => [
                    ['key' => 'ticketing', 'icon' => 'fa-headset', 'label' => 'Hubungi Admin', 'href' => '/ticketing', 'children' => []],
                ],
            ],
        ],

        // ── NONAKTIF: Hanya dashboard & bantuan ──
        'nonaktif' => [
            
            [
                'label' => 'BANTUAN',
                'items' => [
                    ['key' => 'ticketing', 'icon' => 'fa-headset', 'label' => 'Hubungi Admin', 'href' => '/ticketing', 'children' => []],
                ],
            ],
        ],

        // ── PENDING: Hanya dashboard & bantuan (menunggu aktivasi) ──
        'pending' => [
            
            [
                'label' => 'BANTUAN',
                'items' => [
                    ['key' => 'ticketing', 'icon' => 'fa-headset', 'label' => 'Hubungi Admin', 'href' => '/ticketing', 'children' => []],
                ],
            ],
        ],
    },
};

// ── Status badge config ──
$statusBadge = match ($pelangganStatus) {
    'aktif'    => ['cls' => 'bg-emerald-500/20 text-emerald-300', 'icon' => 'fa-circle-check', 'label' => 'Aktif'],
    'isolir'   => ['cls' => 'bg-orange-500/20 text-orange-300',   'icon' => 'fa-triangle-exclamation', 'label' => 'Terisolir'],
    'nonaktif' => ['cls' => 'bg-red-500/20 text-red-300',         'icon' => 'fa-circle-xmark', 'label' => 'Nonaktif'],
    'pending'  => ['cls' => 'bg-amber-500/20 text-amber-300',     'icon' => 'fa-clock', 'label' => 'Pending'],
    default    => ['cls' => 'bg-slate-500/20 text-slate-300',     'icon' => 'fa-circle', 'label' => ucfirst($pelangganStatus)],
};

// ── Helper closures ──
$isGroupActive = function (array $items) use ($activeMenu): bool {
    foreach ($items as $item) {
        if (($item['key'] ?? '') === $activeMenu) return true;
        foreach (($item['children'] ?? []) as $child) {
            if (($child['key'] ?? '') === $activeMenu) return true;
        }
    }
    return false;
};

$esc = fn(string $s): string => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
?>

<!-- ===== SIDEBAR ===== -->
<aside id="sidebar" class="fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white flex flex-col shadow-xl transform -translate-x-full lg:translate-x-0 lg:static transition-transform duration-300 ease-in-out">

    <!-- HEADER -->
    <div class="h-16 flex items-center justify-between px-4 border-b border-white/10 shrink-0">
        <a href="<?= $esc($appUrl) ?>/dashboard" class="flex items-center gap-3 no-underline group">
            <div class="w-9 h-9 rounded-lg bg-indigo-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30">
                <i class="fa-solid fa-wifi text-sm"></i>
            </div>
            <div class="leading-tight">
                <span class="block text-sm font-bold tracking-wide text-white">FiberNet</span>
                <span class="block text-[10px] text-slate-400 uppercase tracking-wider">Billing System</span>
            </div>
        </a>
        <button id="sidebarCloseBtn" class="lg:hidden w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10" aria-label="Tutup sidebar">
            <i class="fa-solid fa-xmark text-lg"></i>
        </button>
    </div>

    <!-- USER CHIP -->
    <div class="px-4 py-4 border-b border-white/10 shrink-0">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-sm font-bold ring-2 ring-white/10 shrink-0">
                <?= $esc($inisial) ?>
            </div>
            <div class="min-w-0 flex-1">
                <span class="block text-sm font-medium text-white truncate"><?= $esc($nama) ?></span>
                <span class="inline-flex items-center gap-1.5 mt-1 flex-wrap">
                    <span class="px-2 py-0.5 rounded text-[10px] font-semibold bg-white/10 text-slate-300 capitalize">
                        <?= $esc(ucfirst($role)) ?>
                    </span>
                    <?php if ($role === 'pelanggan'): ?>
                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold <?= $statusBadge['cls'] ?>">
                            <i class="fa-solid <?= $statusBadge['icon'] ?> text-[8px]"></i> <?= $esc($statusBadge['label']) ?>
                        </span>
                    <?php endif; ?>
                </span>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════════════
         BANNER PERINGATAN — Hanya muncul untuk status tertentu
         ═══════════════════════════════════════════════════════════ -->
    <?php if ($role === 'pelanggan' && $pelangganStatus === 'isolir'): ?>
    <div class="mx-3 mt-3 p-3 rounded-lg bg-orange-500/10 border border-orange-500/20">
        <div class="flex items-start gap-2">
            <i class="fa-solid fa-triangle-exclamation text-orange-400 text-sm mt-0.5"></i>
            <div>
                <p class="text-xs font-semibold text-orange-300">Layanan Terisolir</p>
                <p class="text-[10px] text-orange-400/80 mt-0.5 leading-relaxed">
                    Silakan lakukan pembayaran untuk mengaktifkan kembali layanan Anda.
                </p>
                <a href="<?= $esc($appUrl) ?>/pembayaran"
                   class="inline-flex items-center gap-1 mt-2 px-2.5 py-1 rounded text-[10px] font-bold bg-orange-500/20 text-orange-300 hover:bg-orange-500/30 transition-colors">
                    <i class="fa-solid fa-credit-card text-[8px]"></i> Bayar Sekarang
                </a>
            </div>
        </div>
    </div>
    <?php elseif ($role === 'pelanggan' && $pelangganStatus === 'nonaktif'): ?>
    <div class="mx-3 mt-3 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
        <div class="flex items-start gap-2">
            <i class="fa-solid fa-circle-xmark text-red-400 text-sm mt-0.5"></i>
            <div>
                <p class="text-xs font-semibold text-red-300">Akun Nonaktif</p>
                <p class="text-[10px] text-red-400/80 mt-0.5 leading-relaxed">
                    Layanan Anda telah dinonaktifkan. Hubungi admin untuk informasi lebih lanjut.
                </p>
            </div>
        </div>
    </div>
    <?php elseif ($role === 'pelanggan' && $pelangganStatus === 'pending'): ?>
    <div class="mx-3 mt-3 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
        <div class="flex items-start gap-2">
            <i class="fa-solid fa-clock text-amber-400 text-sm mt-0.5"></i>
            <div>
                <p class="text-xs font-semibold text-amber-300">Menunggu Aktivasi</p>
                <p class="text-[10px] text-amber-400/80 mt-0.5 leading-relaxed">
                    Pendaftaran Anda sedang diproses. Tim kami akan segera menghubungi Anda.
                </p>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- NAVIGASI -->
    <nav id="sidebarNav" class="flex-1 overflow-y-auto py-4 px-3 space-y-6">
        <?php foreach ($menus as $group): ?>
            <div>
                <span class="block px-3 mb-2 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
                    <?= $esc($group['label']) ?>
                </span>
                <div class="space-y-0.5">
                    <?php foreach ($group['items'] as $item): ?>
                        <?php
                        $hasChildren = !empty($item['children']);
                        $groupActive = $hasChildren && $isGroupActive([$item]);
                        $itemActive  = ($activeMenu === $item['key']);
                        $activeClass = ($itemActive || $groupActive)
                            ? 'bg-indigo-500/15 text-indigo-400'
                            : 'text-slate-400 hover:bg-white/5 hover:text-white';
                        ?>

                        <?php if ($hasChildren): ?>
                            <div class="sidebar-dropdown">
                                <button type="button"
                                        onclick="toggleSidebarDD(this)"
                                        class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 <?= $activeClass ?>">
                                    <span class="w-5 text-center text-base"><i class="fa-solid <?= $item['icon'] ?>"></i></span>
                                    <span class="flex-1 text-left"><?= $esc($item['label']) ?></span>
                                    <i class="fa-solid fa-chevron-down text-[10px] opacity-60 transition-transform duration-200 dd-chevron <?= $groupActive ? 'rotate-180' : '' ?>"></i>
                                </button>
                                <div class="dd-body overflow-hidden transition-all duration-300 <?= $groupActive ? 'open' : '' ?>"
                                     style="max-height:<?= $groupActive ? '500px' : '0' ?>;">
                                    <div class="mt-0.5 pl-4 space-y-0.5 border-l border-white/5 ml-5 py-1">
                                        <?php foreach ($item['children'] as $child): ?>
                                            <?php $childActive = ($activeMenu === $child['key']); ?>
                                            <a href="<?= $esc($appUrl . $child['href']) ?>"
                                               class="sidebar-link flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors <?= $childActive ? 'bg-indigo-500/15 text-indigo-400' : 'text-slate-500 hover:text-slate-300 hover:bg-white/5' ?>">
                                                <span class="w-4 text-center"><i class="fa-solid fa-circle text-[5px]"></i></span>
                                                <span><?= $esc($child['label']) ?></span>
                                            </a>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <a href="<?= $esc($appUrl . $item['href']) ?>"
                               class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 <?= $activeClass ?>">
                                <span class="w-5 text-center text-base"><i class="fa-solid <?= $item['icon'] ?>"></i></span>
                                <span class="flex-1"><?= $esc($item['label']) ?></span>
                            </a>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </nav>

    <!-- FOOTER — LOGOUT -->
    <div class="p-3 border-t border-white/10 space-y-0.5 shrink-0">
        <a href="<?= $esc($appUrl) ?>/profil"
           class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors <?= $activeMenu === 'profil' ? 'bg-indigo-500/15 text-indigo-400' : 'text-slate-400 hover:bg-white/5 hover:text-white' ?>">
            <span class="w-5 text-center text-base"><i class="fa-solid fa-circle-user"></i></span>
            <span>Profil Saya</span>
        </a>

        <form id="logoutFormSidebar"
              action="<?= $esc($appUrl) ?>/logout"
              method="POST"
              class="w-full"
              onsubmit="return handleLogout(event, this)">
            <input type="hidden" name="csrf_token" value="<?= $esc($csrf) ?>">
            <button type="submit"
                    class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors text-red-400 hover:bg-red-500/10 hover:text-red-300 text-left cursor-pointer border-0 bg-transparent">
                <span class="w-5 text-center text-base"><i class="fa-solid fa-arrow-right-from-bracket"></i></span>
                <span>Keluar</span>
            </button>
        </form>
    </div>
</aside>

<!-- Mobile Overlay -->
<div id="sidebarOverlay" class="fixed inset-0 bg-black/60 z-40 hidden lg:hidden transition-opacity duration-300 opacity-0"></div>

<!-- ===== SCRIPTS ===== -->
<script>
function toggleSidebarDD(btn) {
    const dd   = btn.closest('.sidebar-dropdown');
    const body = dd.querySelector('.dd-body');
    const chev = btn.querySelector('.dd-chevron');
    if (body.classList.contains('open')) {
        body.style.maxHeight = '0';
        body.classList.remove('open');
        chev.classList.remove('rotate-180');
    } else {
        body.style.maxHeight = body.scrollHeight + 'px';
        body.classList.add('open');
        chev.classList.add('rotate-180');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.dd-body.open').forEach(b => {
        b.style.maxHeight = b.scrollHeight + 'px';
    });
});

function handleLogout(e, form) {
    e.preventDefault();
    if (!confirm('Yakin ingin keluar?')) return false;

    try {
        const btn = form.querySelector('button[type="submit"]');
        btn.disabled = true;
        btn.innerHTML = '<span class="w-5 text-center text-base"><i class="fa-solid fa-spinner fa-spin"></i></span><span>Memproses...</span>';
        form.submit();
        setTimeout(() => { window.location.href = form.action; }, 2000);
    } catch (err) {
        console.warn('Form submit gagal, fallback redirect:', err);
        window.location.href = form.action;
    }
    return false;
}
</script>
