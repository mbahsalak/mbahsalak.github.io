<?php
/**
 * views/layouts/topbar.php
 * Topbar navigasi — breadcrumb, search, notifikasi, theme toggle
 */
$appUrl     = $appUrl ?? ($_ENV['APP_URL'] ?? '');
$activeMenu = $activeMenu ?? '';

// Mapping Breadcrumb berdasarkan activeMenu
$breadcrumbMap = [
    'dashboard'          => [['label' => 'Dashboard', 'url' => "$appUrl/dashboard"]],
    'pelanggan'          => [['label' => 'Dashboard', 'url' => "$appUrl/dashboard"], ['label' => 'Pelanggan', 'url' => "$appUrl/pelanggan"]],
    'paket'              => [['label' => 'Dashboard', 'url' => "$appUrl/dashboard"], ['label' => 'Paket Internet', 'url' => "$appUrl/paket"]],
    'tagihan'            => [['label' => 'Dashboard', 'url' => "$appUrl/dashboard"], ['label' => 'Tagihan', 'url' => "$appUrl/tagihan"]],
    'kas'                => [['label' => 'Dashboard', 'url' => "$appUrl/dashboard"], ['label' => 'Kas & Keuangan', 'url' => "$appUrl/kas"]],
    'laporan_pendapatan' => [['label' => 'Dashboard', 'url' => "$appUrl/dashboard"], ['label' => 'Laporan', 'url' => '#'], ['label' => 'Pendapatan', 'url' => "$appUrl/laporan/pendapatan"]],
    'laporan_tagihan'    => [['label' => 'Dashboard', 'url' => "$appUrl/dashboard"], ['label' => 'Laporan', 'url' => '#'], ['label' => 'Tagihan', 'url' => "$appUrl/laporan/tagihan"]],
    'laporan_kas'        => [['label' => 'Dashboard', 'url' => "$appUrl/dashboard"], ['label' => 'Laporan', 'url' => '#'], ['label' => 'Kas', 'url' => "$appUrl/laporan/kas"]],
    'ticketing'          => [['label' => 'Dashboard', 'url' => "$appUrl/dashboard"], ['label' => 'Ticketing', 'url' => "$appUrl/ticketing"]],
    'odp'                => [['label' => 'Dashboard', 'url' => "$appUrl/dashboard"], ['label' => 'Jaringan', 'url' => '#'], ['label' => 'ODP / ODC', 'url' => "$appUrl/jaringan/odp"]],
    'mikrotik'           => [['label' => 'Dashboard', 'url' => "$appUrl/dashboard"], ['label' => 'Jaringan', 'url' => '#'], ['label' => 'MikroTik', 'url' => "$appUrl/jaringan/mikrotik"]],
    'monitoring'         => [['label' => 'Dashboard', 'url' => "$appUrl/dashboard"], ['label' => 'Jaringan', 'url' => '#'], ['label' => 'Monitoring', 'url' => "$appUrl/jaringan/monitoring"]],
    'users'              => [['label' => 'Dashboard', 'url' => "$appUrl/dashboard"], ['label' => 'Administrasi', 'url' => '#'], ['label' => 'Manajemen User', 'url' => "$appUrl/admin/users"]],
    'settings'           => [['label' => 'Dashboard', 'url' => "$appUrl/dashboard"], ['label' => 'Administrasi', 'url' => '#'], ['label' => 'Pengaturan', 'url' => "$appUrl/admin/settings"]],
    'profil'             => [['label' => 'Dashboard', 'url' => "$appUrl/dashboard"], ['label' => 'Profil Saya', 'url' => "$appUrl/profil"]],
];
$breadcrumbs = $breadcrumbMap[$activeMenu] ?? [['label' => 'Dashboard', 'url' => "$appUrl/dashboard"]];
?>

<header x-data="{ searchOpen: false, notifOpen: false }" 
        class="h-16 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between px-4 lg:px-6 sticky top-0 z-30 shrink-0">
    
    <!-- Left: Mobile Menu + Breadcrumb -->
    <div class="flex items-center gap-4">
        <button id="mobileMenuBtn" class="lg:hidden w-9 h-9 rounded-lg flex items-center justify-center text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700 transition-colors">
            <i class="fa-solid fa-bars text-lg"></i>
        </button>
        
        <nav class="hidden sm:flex items-center text-sm text-gray-500 dark:text-gray-400 overflow-x-auto whitespace-nowrap scrollbar-none">
            <?php foreach ($breadcrumbs as $i => $crumb): ?>
                <?php if ($i < count($breadcrumbs) - 1): ?>
                    <a href="<?= $crumb['url'] ?>" class="hover:text-primary transition-colors shrink-0"><?= htmlspecialchars($crumb['label']) ?></a>
                    <i class="fa-solid fa-chevron-right mx-2 text-[10px] opacity-50 shrink-0"></i>
                <?php else: ?>
                    <span class="font-semibold text-gray-800 dark:text-gray-200 shrink-0"><?= htmlspecialchars($crumb['label']) ?></span>
                <?php endif; ?>
            <?php endforeach; ?>
        </nav>
    </div>

    <!-- Right: Search + Notif + Theme -->
    <div class="flex items-center gap-2 lg:gap-3">
        
        <!-- Global Search -->
        <div class="relative hidden md:block group">
            <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-primary transition-colors pointer-events-none"></i>
            <input type="text" id="globalSearch" placeholder="Cari pelanggan, tagihan..." 
                   @focus="searchOpen = true" @click.away="searchOpen = false"
                   class="w-56 lg:w-64 pl-9 pr-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-700 border border-transparent focus:border-primary focus:bg-white dark:focus:bg-gray-800 text-sm focus:ring-2 focus:ring-primary/20 outline-none transition-all" 
                   autocomplete="off">
            
            <!-- Search Results Dropdown -->
            <div x-show="searchOpen" x-transition 
                 id="searchResults" 
                 class="absolute right-0 mt-2 w-full bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-100 dark:border-gray-700 hidden z-50 overflow-hidden">
                <div class="p-4 text-center text-sm text-gray-400">
                    <i class="fa-solid fa-magnifying-glass mb-2 text-lg opacity-50"></i>
                    <p>Ketik untuk mencari...</p>
                </div>
            </div>
        </div>

        <!-- Notifications -->
        <div class="relative" id="notifTrigger">
            <button @click="notifOpen = !notifOpen" @click.away="notifOpen = false"
                    class="w-9 h-9 rounded-lg flex items-center justify-center text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700 transition-colors relative">
                <i class="fa-solid fa-bell text-lg"></i>
                <?php if (!empty($notifCount) && $notifCount > 0): ?>
                    <span class="absolute top-1.5 right-1.5 w-4 h-4 bg-red-500 text-white text-[9px] font-bold flex items-center justify-center rounded-full ring-2 ring-white dark:ring-gray-800">
                        <?= $notifCount > 9 ? '9+' : $notifCount ?>
                    </span>
                <?php endif; ?>
            </button>
            
            <!-- Notif Dropdown -->
            <div x-show="notifOpen" x-transition 
                 id="notifDropdown" 
                 class="absolute right-0 mt-2 w-80 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-100 dark:border-gray-700 z-50 overflow-hidden">
                <div class="px-4 py-3 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center">
                    <span class="font-semibold text-sm text-gray-800 dark:text-gray-200">Notifikasi</span>
                    <a href="#" class="text-xs text-primary hover:underline">Tandai semua dibaca</a>
                </div>
                <div class="max-h-80 overflow-y-auto">
                    <?php if (!empty($notifications)): ?>
                        <?php foreach (array_slice($notifications, 0, 5) as $notif): ?>
                            <div class="px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors border-b border-gray-50 dark:border-gray-700/50 last:border-0 <?= empty($notif['read']) ? 'bg-blue-50/50 dark:bg-blue-900/10' : '' ?>">
                                <div class="flex gap-3">
                                    <div class="mt-0.5 w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-gray-500 dark:text-gray-400 shrink-0">
                                        <i class="fa-solid fa-<?= $notif['icon'] ?? 'circle-info' ?> text-xs"></i>
                                    </div>
                                    <div class="min-w-0">
                                        <p class="text-sm text-gray-700 dark:text-gray-300 line-clamp-2"><?= htmlspecialchars($notif['message']) ?></p>
                                        <time class="text-[10px] text-gray-400 mt-1 block"><?= $notif['time'] ?></time>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="py-8 text-center text-gray-400">
                            <i class="fa-regular fa-bell-slash text-2xl mb-2 opacity-50"></i>
                            <p class="text-sm">Tidak ada notifikasi</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Theme Toggle -->
        <button id="themeToggle" 
                class="w-9 h-9 rounded-lg flex items-center justify-center text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700 transition-colors" 
                aria-label="Toggle tema">
            <i class="fa-solid fa-moon text-lg" id="themeIcon"></i>
        </button>
    </div>
</header>
