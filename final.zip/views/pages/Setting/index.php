<?php declare(strict_types=1);
/**
 * views/pages/Setting/index.php
 * Tab: Aplikasi | Perusahaan | Billing | Pesan | Auth | Logo
 * ✅ Tailwind CSS Version
 */

// Helper: ambil value setting dari $groups
$sv = function(string $key) use ($groups): string {
    foreach ($groups as $rows) {
        foreach ($rows as $row) {
            if ($row['key'] === $key) return htmlspecialchars((string)($row['value'] ?? ''));
        }
    }
    return '';
};

// Label grup
$groupLabels = [
    'app'     => ['icon' => 'fa-globe',        'label' => 'Aplikasi'],
    'company' => ['icon' => 'fa-building',     'label' => 'Perusahaan'],
    'billing' => ['icon' => 'fa-file-invoice', 'label' => 'Billing'],
    'pesan'   => ['icon' => 'fa-comment-dots', 'label' => 'Template Pesan'],
    'auth'    => ['icon' => 'fa-lock',         'label' => 'Login & Register'],
];

$activeTab = $_GET['tab'] ?? 'app';
?>

<!-- Page Header -->
<div class="mb-6">
    <h1 class="text-2xl font-bold text-gray-900">Pengaturan Aplikasi</h1>
    <p class="text-sm text-gray-500 mt-1">Kelola konfigurasi sistem, tampilan, dan template pesan</p>
</div>

<!-- Flash Messages -->
<?php if (!empty($flash['success'])): ?>
<div class="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-700 text-sm flex items-center gap-2">
    <i class="fa-solid fa-circle-check"></i>
    <?= htmlspecialchars($flash['success']) ?>
</div>
<?php elseif (!empty($flash['error'])): ?>
<div class="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm flex items-center gap-2">
    <i class="fa-solid fa-circle-exclamation"></i>
    <?= htmlspecialchars($flash['error']) ?>
</div>
<?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-6 items-start">

    <!-- ── Sidebar Tab ── -->
    <nav class="bg-white border border-gray-200 rounded-xl overflow-hidden lg:sticky lg:top-4">
        <?php foreach ($groupLabels as $gKey => $gMeta): ?>
        <a href="?tab=<?= $gKey ?>"
           class="flex items-center gap-2.5 px-4 py-3 text-sm font-medium border-l-[3px] transition-all
                  <?= $activeTab === $gKey
                      ? 'bg-blue-50 text-blue-600 border-l-blue-600 font-semibold'
                      : 'text-gray-600 border-l-transparent hover:bg-gray-50 hover:text-blue-600' ?>">
            <i class="fa-solid <?= $gMeta['icon'] ?> w-4 text-center"></i>
            <?= $gMeta['label'] ?>
        </a>
        <?php endforeach; ?>
        <a href="?tab=logo"
           class="flex items-center gap-2.5 px-4 py-3 text-sm font-medium border-l-[3px] transition-all
                  <?= $activeTab === 'logo'
                      ? 'bg-blue-50 text-blue-600 border-l-blue-600 font-semibold'
                      : 'text-gray-600 border-l-transparent hover:bg-gray-50 hover:text-blue-600' ?>">
            <i class="fa-solid fa-image w-4 text-center"></i>
            Logo ISP
        </a>
    </nav>

    <!-- ── Content ── -->
    <div class="min-w-0">

        <!-- ════════════════════════════════
             TAB: APLIKASI
             ════════════════════════════════ -->
        <?php if ($activeTab === 'app'): ?>
        <form method="POST" action="/setting/update">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
            
            <div class="bg-white border border-gray-200 rounded-xl overflow-hidden mb-5">
                <div class="px-5 py-3.5 text-sm font-bold text-gray-600 bg-gray-50 border-b border-gray-200 flex items-center gap-2">
                    <i class="fa-solid fa-globe text-blue-600"></i> Informasi Aplikasi
                </div>
                <div class="p-5 space-y-5">
                    <!-- Nama Aplikasi -->
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5">Nama Aplikasi / Website</label>
                        <input type="text" name="app_name"
                               class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                               value="<?= $sv('app_name') ?>" placeholder="Billing ISP">
                        <p class="text-xs text-gray-400 mt-1">Muncul di judul browser, header, dan email</p>
                    </div>
                    <!-- Tagline -->
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5">Tagline / Deskripsi Singkat</label>
                        <input type="text" name="app_tagline"
                               class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                               value="<?= $sv('app_tagline') ?>"
                               placeholder="Sistem Billing Internet Service Provider">
                        <p class="text-xs text-gray-400 mt-1">Tampil di bawah nama aplikasi pada halaman login</p>
                    </div>
                    <!-- Deskripsi -->
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5">Deskripsi Website</label>
                        <textarea name="app_description" rows="3"
                                  class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition resize-y min-h-[80px] leading-relaxed"
                                  placeholder="Deskripsi singkat tentang layanan ISP Anda..."><?= $sv('app_description') ?></textarea>
                        <p class="text-xs text-gray-400 mt-1">Untuk meta description SEO dan halaman about</p>
                    </div>
                    <!-- Favicon -->
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5">Favicon URL / Path</label>
                        <input type="text" name="app_favicon"
                               class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                               value="<?= $sv('app_favicon') ?>"
                               placeholder="public/assets/images/favicon.ico">
                    </div>
                </div>
            </div>

            <div class="flex justify-end pt-1">
                <button type="submit" class="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white text-sm font-semibold rounded-lg hover:bg-blue-700 active:bg-blue-800 transition shadow-sm">
                    <i class="fa-solid fa-floppy-disk"></i> Simpan Pengaturan Aplikasi
                </button>
            </div>
        </form>

        <!-- ════════════════════════════════
             TAB: PERUSAHAAN
             ════════════════════════════════ -->
        <?php elseif ($activeTab === 'company'): ?>
        <form method="POST" action="/setting/update">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
            
            <div class="bg-white border border-gray-200 rounded-xl overflow-hidden mb-5">
                <div class="px-5 py-3.5 text-sm font-bold text-gray-600 bg-gray-50 border-b border-gray-200 flex items-center gap-2">
                    <i class="fa-solid fa-building text-blue-600"></i> Data Perusahaan
                </div>
                <div class="p-5 space-y-5">
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5">Nama Perusahaan / ISP</label>
                        <input type="text" name="company_name"
                               class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                               value="<?= $sv('company_name') ?>"
                               placeholder="PT. Internet Nusantara">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5">Alamat Kantor</label>
                        <textarea name="company_address" rows="3"
                                  class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition resize-y min-h-[80px]"
                                  placeholder="Jl. Merdeka No. 1, Kota..."><?= $sv('company_address') ?></textarea>
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 mb-1.5">No. Telepon / WhatsApp CS</label>
                            <input type="text" name="company_phone"
                                   class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                                   value="<?= $sv('company_phone') ?>"
                                   placeholder="0812-3456-7890">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 mb-1.5">Email Perusahaan</label>
                            <input type="email" name="company_email"
                                   class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                                   value="<?= $sv('company_email') ?>"
                                   placeholder="cs@isp.co.id">
                        </div>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5">Website</label>
                        <input type="text" name="company_website"
                               class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                               value="<?= $sv('company_website') ?>"
                               placeholder="https://isp.co.id">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5">NPWP</label>
                        <input type="text" name="company_npwp"
                               class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                               value="<?= $sv('company_npwp') ?>"
                               placeholder="00.000.000.0-000.000">
                    </div>
                </div>
            </div>

            <div class="flex justify-end pt-1">
                <button type="submit" class="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white text-sm font-semibold rounded-lg hover:bg-blue-700 active:bg-blue-800 transition shadow-sm">
                    <i class="fa-solid fa-floppy-disk"></i> Simpan Data Perusahaan
                </button>
            </div>
        </form>

        <!-- ════════════════════════════════
             TAB: BILLING
             ════════════════════════════════ -->
        <?php elseif ($activeTab === 'billing'): ?>
        <form method="POST" action="/setting/update">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
            
            <div class="bg-white border border-gray-200 rounded-xl overflow-hidden mb-5">
                <div class="px-5 py-3.5 text-sm font-bold text-gray-600 bg-gray-50 border-b border-gray-200 flex items-center gap-2">
                    <i class="fa-solid fa-file-invoice text-blue-600"></i> Konfigurasi Billing
                </div>
                <div class="p-5 space-y-5">
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 mb-1.5">Hari Jatuh Tempo Default</label>
                            <input type="number" name="billing_due_day"
                                   class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                                   value="<?= $sv('billing_due_day') ?>"
                                   min="1" max="28" placeholder="5">
                            <p class="text-xs text-gray-400 mt-1">Tanggal setiap bulan (1–28)</p>
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 mb-1.5">Denda Keterlambatan (Rp)</label>
                            <input type="number" name="billing_late_fee"
                                   class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                                   value="<?= $sv('billing_late_fee') ?>"
                                   min="0" placeholder="5000">
                        </div>
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 mb-1.5">Hari Toleransi Sebelum Isolir</label>
                            <input type="number" name="billing_isolir_day"
                                   class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                                   value="<?= $sv('billing_isolir_day') ?>"
                                   min="0" placeholder="3">
                            <p class="text-xs text-gray-400 mt-1">Hari setelah jatuh tempo sebelum isolir otomatis</p>
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 mb-1.5">Pajak / PPN (%)</label>
                            <input type="number" name="billing_tax_pct"
                                   class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                                   value="<?= $sv('billing_tax_pct') ?>"
                                   min="0" max="100" step="0.1" placeholder="0">
                            <p class="text-xs text-gray-400 mt-1">Kosongkan / isi 0 jika tidak ada pajak</p>
                        </div>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5">Footer Invoice / Kwitansi</label>
                        <textarea name="billing_invoice_footer" rows="3"
                                  class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition resize-y min-h-[80px]"
                                  placeholder="Terima kasih telah membayar tepat waktu..."><?= $sv('billing_invoice_footer') ?></textarea>
                        <p class="text-xs text-gray-400 mt-1">Teks yang muncul di bagian bawah invoice cetak</p>
                    </div>
                </div>
            </div>

            <div class="flex justify-end pt-1">
                <button type="submit" class="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white text-sm font-semibold rounded-lg hover:bg-blue-700 active:bg-blue-800 transition shadow-sm">
                    <i class="fa-solid fa-floppy-disk"></i> Simpan Konfigurasi Billing
                </button>
            </div>
        </form>

        <!-- ════════════════════════════════
             TAB: TEMPLATE PESAN
             ════════════════════════════════ -->
        <?php elseif ($activeTab === 'pesan'): ?>
        <form method="POST" action="/setting/update">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
            
            <!-- Variabel chips -->
            <div class="flex flex-wrap items-center gap-1.5 mb-4 p-3 bg-white border border-gray-200 rounded-lg text-xs">
                <span class="font-semibold text-gray-400 shrink-0">Variabel tersedia:</span>
                <?php foreach (['{nama_pelanggan}','{periode}','{total}','{jatuh_tempo}','{nama_perusahaan}','{company_phone}'] as $v): ?>
                <span class="var-chip px-2.5 py-1 rounded-full bg-blue-50 text-blue-600 border border-blue-200 font-mono cursor-pointer hover:bg-blue-600 hover:text-white transition select-none"
                      onclick="insertVar(this)" title="Klik untuk salin"><?= $v ?></span>
                <?php endforeach; ?>
            </div>

            <div class="bg-white border border-gray-200 rounded-xl overflow-hidden mb-5">
                <div class="px-5 py-3.5 text-sm font-bold text-gray-600 bg-gray-50 border-b border-gray-200 flex items-center gap-2">
                    <i class="fa-solid fa-comment-dots text-blue-600"></i> Template Pesan WhatsApp / Notifikasi
                </div>
                <div class="p-5 space-y-5">

                    <!-- Tagihan Baru -->
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5 flex items-center gap-1.5">
                            <i class="fa-solid fa-bell text-blue-600"></i> Tagihan Baru Terbit
                        </label>
                        <textarea name="msg_tagihan_baru" rows="5"
                                  class="msg-area w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition resize-y min-h-[80px] font-mono leading-relaxed"
                                  id="msg_tagihan_baru"><?= $sv('msg_tagihan_baru') ?></textarea>
                        <div class="flex gap-2 mt-1.5">
                            <button type="button" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-gray-600 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition"
                                    onclick="previewMsg('msg_tagihan_baru')">
                                <i class="fa-solid fa-eye"></i> Preview
                            </button>
                            <button type="button" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-gray-600 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition"
                                    onclick="openWa('msg_tagihan_baru')">
                                <i class="fa-brands fa-whatsapp"></i> Test WA
                            </button>
                        </div>
                    </div>

                    <!-- Tagihan Lunas -->
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5 flex items-center gap-1.5">
                            <i class="fa-solid fa-circle-check text-emerald-500"></i> Konfirmasi Pembayaran Lunas
                        </label>
                        <textarea name="msg_tagihan_lunas" rows="5"
                                  class="msg-area w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition resize-y min-h-[80px] font-mono leading-relaxed"
                                  id="msg_tagihan_lunas"><?= $sv('msg_tagihan_lunas') ?></textarea>
                        <div class="flex gap-2 mt-1.5">
                            <button type="button" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-gray-600 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition"
                                    onclick="previewMsg('msg_tagihan_lunas')">
                                <i class="fa-solid fa-eye"></i> Preview
                            </button>
                        </div>
                    </div>

                    <!-- Jatuh Tempo -->
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5 flex items-center gap-1.5">
                            <i class="fa-solid fa-clock text-amber-500"></i> Pengingat Jatuh Tempo
                        </label>
                        <textarea name="msg_jatuh_tempo" rows="5"
                                  class="msg-area w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition resize-y min-h-[80px] font-mono leading-relaxed"
                                  id="msg_jatuh_tempo"><?= $sv('msg_jatuh_tempo') ?></textarea>
                        <div class="flex gap-2 mt-1.5">
                            <button type="button" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-gray-600 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition"
                                    onclick="previewMsg('msg_jatuh_tempo')">
                                <i class="fa-solid fa-eye"></i> Preview
                            </button>
                        </div>
                    </div>

                    <!-- Isolir -->
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5 flex items-center gap-1.5">
                            <i class="fa-solid fa-ban text-red-500"></i> Notifikasi Isolir
                        </label>
                        <textarea name="msg_isolir" rows="5"
                                  class="msg-area w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition resize-y min-h-[80px] font-mono leading-relaxed"
                                  id="msg_isolir"><?= $sv('msg_isolir') ?></textarea>
                        <div class="flex gap-2 mt-1.5">
                            <button type="button" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-gray-600 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition"
                                    onclick="previewMsg('msg_isolir')">
                                <i class="fa-solid fa-eye"></i> Preview
                            </button>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 mb-1.5">Kode Negara WA (tanpa +)</label>
                            <input type="text" name="msg_wa_prefix"
                                   class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                                   value="<?= $sv('msg_wa_prefix') ?>" placeholder="62" maxlength="5">
                            <p class="text-xs text-gray-400 mt-1">Indonesia = 62</p>
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 mb-1.5">Footer / Tanda Tangan Pesan</label>
                            <input type="text" name="msg_footer"
                                   class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                                   value="<?= $sv('msg_footer') ?>"
                                   placeholder="CS: {company_phone}">
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex justify-end pt-1">
                <button type="submit" class="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white text-sm font-semibold rounded-lg hover:bg-blue-700 active:bg-blue-800 transition shadow-sm">
                    <i class="fa-solid fa-floppy-disk"></i> Simpan Template Pesan
                </button>
            </div>
        </form>

        <!-- Modal preview pesan -->
        <div class="fixed inset-0 bg-black/45 flex items-center justify-center z-[9999] hidden" id="msgModal" onclick="this.classList.add('hidden')">
            <div class="bg-white rounded-xl w-[90%] max-w-[420px] shadow-2xl overflow-hidden" onclick="event.stopPropagation()">
                <div class="flex items-center justify-between px-4 py-3 bg-[#25d366] text-white text-sm font-bold">
                    <span class="flex items-center gap-2"><i class="fa-brands fa-whatsapp"></i> Preview Pesan</span>
                    <button class="hover:bg-white/20 rounded p-1 transition" onclick="document.getElementById('msgModal').classList.add('hidden')">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>
                <div class="m-4 p-4 bg-[#dcf8c6] rounded-tl-none rounded-tr-xl rounded-bl-xl rounded-br-xl text-sm leading-7 whitespace-pre-wrap text-gray-900 max-h-80 overflow-y-auto" id="msgBubble"></div>
            </div>
        </div>

        <!-- ════════════════════════════════
             TAB: AUTH / LOGIN
             ════════════════════════════════ -->
        <?php elseif ($activeTab === 'auth'): ?>
        <form method="POST" action="/setting/update">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
            
            <div class="bg-white border border-gray-200 rounded-xl overflow-hidden mb-5">
                <div class="px-5 py-3.5 text-sm font-bold text-gray-600 bg-gray-50 border-b border-gray-200 flex items-center gap-2">
                    <i class="fa-solid fa-lock text-blue-600"></i> Tampilan Halaman Login
                </div>
                <div class="p-5">
                    <div class="flex flex-col lg:flex-row gap-5">
                        <div class="flex-1 space-y-5">
                            <div>
                                <label class="block text-xs font-semibold text-gray-500 mb-1.5">Judul Banner</label>
                                <input type="text" name="auth_banner_title"
                                       class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                                       value="<?= $sv('auth_banner_title') ?>"
                                       placeholder="Selamat Datang" id="inp_banner_title">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-gray-500 mb-1.5">Deskripsi Banner</label>
                                <textarea name="auth_banner_desc" rows="3"
                                          class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition resize-y min-h-[80px]"
                                          id="inp_banner_desc"
                                          placeholder="Kelola tagihan internet pelanggan Anda..."><?= $sv('auth_banner_desc') ?></textarea>
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-gray-500 mb-1.5">URL Gambar Banner (opsional)</label>
                                <input type="text" name="auth_banner_image"
                                       class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                                       value="<?= $sv('auth_banner_image') ?>"
                                       placeholder="https://... atau public/assets/images/...">
                                <p class="text-xs text-gray-400 mt-1">Kosongkan untuk pakai ilustrasi default</p>
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-gray-500 mb-1.5">Warna Utama Login</label>
                                <div class="flex items-center gap-3">
                                    <input type="color" name="auth_primary_color"
                                           class="w-12 h-10 border border-gray-300 rounded-lg cursor-pointer p-0.5 bg-gray-50"
                                           value="<?= $sv('auth_primary_color') ?: '#2563eb' ?>"
                                           id="inp_primary_color">
                                    <input type="text"
                                           class="w-28 px-3 py-2.5 text-sm font-mono border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                                           id="inp_primary_color_hex"
                                           value="<?= $sv('auth_primary_color') ?: '#2563eb' ?>"
                                           maxlength="7">
                                </div>
                            </div>
                        </div>

                        <!-- Preview mini login card -->
                        <div class="w-48 shrink-0 self-start" id="authPreview">
                            <div class="bg-white border border-gray-200 rounded-lg p-4 shadow-lg">
                                <!-- Brand -->
                                <div class="flex items-center gap-2 mb-3">
                                    <div class="w-7 h-7 rounded-md flex items-center justify-center text-white text-xs shrink-0" id="prev_icon"
                                         style="background: <?= $sv('auth_primary_color') ?: '#2563eb' ?>">
                                        <i class="fa-solid fa-wifi"></i>
                                    </div>
                                    <div>
                                        <div class="text-[11px] font-bold text-gray-900" id="prev_appname"><?= $sv('app_name') ?: 'BillingISP' ?></div>
                                        <div class="text-[9px] text-gray-400" id="prev_tagline"><?= $sv('app_tagline') ?: 'Billing System' ?></div>
                                    </div>
                                </div>
                                <!-- Heading -->
                                <div class="text-xs font-bold text-gray-900 mb-1" id="prev_banner_title"><?= $sv('auth_banner_title') ?: 'Selamat Datang' ?></div>
                                <div class="text-[10px] text-gray-500 mb-3 leading-relaxed" id="prev_banner_desc"><?= $sv('auth_banner_desc') ?: 'Login untuk melanjutkan.' ?></div>
                                <!-- Fields -->
                                <div class="h-5 bg-gray-100 border border-gray-200 rounded mb-2"></div>
                                <div class="h-5 bg-gray-100 border border-gray-200 rounded mb-2"></div>
                                <!-- Button -->
                                <div class="h-6 rounded flex items-center justify-center text-[10px] font-semibold text-white mt-2" id="prev_btn"
                                     style="background: <?= $sv('auth_primary_color') ?: '#2563eb' ?>">Masuk</div>
                            </div>
                        </div>
                    </div>

                    <hr class="my-5 border-gray-200">

                    <div class="text-xs font-bold text-gray-600 mb-4 flex items-center gap-1.5">
                        <i class="fa-solid fa-circle-info text-blue-600"></i> Info Box & Register
                    </div>

                    <div class="space-y-5">
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 mb-1.5">Judul Info Box</label>
                            <input type="text" name="auth_info_title"
                                   class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition"
                                   value="<?= $sv('auth_info_title') ?>"
                                   placeholder="Billing ISP">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 mb-1.5">Isi Info Box</label>
                            <textarea name="auth_info_body" rows="3"
                                      class="w-full px-3.5 py-2.5 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition resize-y min-h-[80px]"
                                      placeholder="Sistem manajemen tagihan internet..."><?= $sv('auth_info_body') ?></textarea>
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 mb-2">Tampilkan Link Register di Halaman Login?</label>
                            <div class="flex items-center gap-3">
                                <label class="relative inline-block w-11 h-6 shrink-0 cursor-pointer">
                                    <input type="hidden" name="auth_show_register" value="no">
                                    <input type="checkbox" name="auth_show_register" value="yes"
                                           class="peer sr-only"
                                           <?= $sv('auth_show_register') === 'yes' ? 'checked' : '' ?>>
                                    <span class="absolute inset-0 bg-gray-300 rounded-full peer-checked:bg-blue-600 transition-colors duration-200 after:content-[''] after:absolute after:left-[3px] after:top-[3px] after:w-[18px] after:h-[18px] after:bg-white after:rounded-full after:shadow after:transition-transform after:duration-200 peer-checked:after:translate-x-5"></span>
                                </label>
                                <span class="text-sm text-gray-600">Tampilkan tombol daftar / register</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex justify-end pt-1">
                <button type="submit" class="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white text-sm font-semibold rounded-lg hover:bg-blue-700 active:bg-blue-800 transition shadow-sm">
                    <i class="fa-solid fa-floppy-disk"></i> Simpan Pengaturan Login
                </button>
            </div>
        </form>

        <!-- ════════════════════════════════
             TAB: LOGO
             ════════════════════════════════ -->
        <?php elseif ($activeTab === 'logo'): ?>
        <div class="bg-white border border-gray-200 rounded-xl overflow-hidden mb-5">
            <div class="px-5 py-3.5 text-sm font-bold text-gray-600 bg-gray-50 border-b border-gray-200 flex items-center gap-2">
                <i class="fa-solid fa-image text-blue-600"></i> Upload Logo ISP
            </div>
            <div class="p-5">

                <!-- Current logo -->
                <?php $logoPath = $sv('app_logo'); ?>
                <?php if ($logoPath && file_exists(APP_ROOT . '/' . $logoPath)): ?>
                <div class="flex items-center gap-4 p-3.5 bg-gray-50 border border-gray-200 rounded-lg mb-4">
                    <img src="/<?= htmlspecialchars($logoPath) ?>" alt="Logo saat ini" class="max-h-16 max-w-40 object-contain">
                    <span class="text-sm text-gray-400">Logo saat ini</span>
                </div>
                <?php else: ?>
                <div class="flex flex-col items-center py-8 text-gray-400 gap-2">
                    <i class="fa-regular fa-image text-3xl"></i>
                    <p class="text-sm">Belum ada logo yang diunggah</p>
                </div>
                <?php endif; ?>

                <form method="POST" action="/setting/logo" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
                    
                    <div class="relative flex flex-col items-center gap-2 p-8 border-2 border-dashed border-gray-300 rounded-lg bg-gray-50 cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition text-center text-sm text-gray-400"
                         id="logoDropzone">
                        <i class="fa-solid fa-cloud-arrow-up text-3xl text-blue-600"></i>
                        <p>Klik atau drag & drop file logo</p>
                        <p class="text-xs text-gray-400">JPG, PNG, SVG, WEBP · Maks. 2 MB</p>
                        <input type="file" name="logo" id="logoInput" accept=".jpg,.jpeg,.png,.svg,.webp"
                               class="absolute inset-0 opacity-0 cursor-pointer">
                    </div>

                    <div id="logoPreviewWrap" class="hidden mt-4 text-center">
                        <img id="logoPreview" class="max-h-28 rounded-lg mx-auto">
                        <p class="text-xs text-gray-400 mt-2" id="logoFileName"></p>
                    </div>

                    <div class="flex justify-end mt-4">
                        <button type="submit" id="btnUploadLogo" disabled
                                class="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white text-sm font-semibold rounded-lg hover:bg-blue-700 active:bg-blue-800 transition shadow-sm disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-blue-600">
                            <i class="fa-solid fa-upload"></i> Upload Logo
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>

    </div><!-- /.content -->
</div><!-- /.grid -->

<!-- ================================================================
     SCRIPTS
     ================================================================ -->
<script>
// ── Variabel klik → salin ke clipboard ──
function insertVar(el) {
    navigator.clipboard?.writeText(el.textContent).then(() => {
        const orig = el.textContent;
        el.textContent = '✓ Disalin';
        el.classList.add('!bg-blue-600', '!text-white');
        setTimeout(() => {
            el.textContent = orig;
            el.classList.remove('!bg-blue-600', '!text-white');
        }, 1200);
    });
}

// ── Preview pesan dengan data dummy ──
const DUMMY = {
    '{nama_pelanggan}': 'Budi Santoso',
    '{periode}':        'Juni 2026',
    '{total}':          'Rp 200.000',
    '{jatuh_tempo}':    '5 Juli 2026',
    '{nama_perusahaan}':'PT. Internet Nusantara',
    '{company_phone}':  '0812-3456-7890',
};

function previewMsg(id) {
    let tpl = document.getElementById(id)?.value || '';
    Object.entries(DUMMY).forEach(([k,v]) => { tpl = tpl.replaceAll(k, v); });
    document.getElementById('msgBubble').textContent = tpl;
    document.getElementById('msgModal').classList.remove('hidden');
}

function openWa(id) {
    let tpl = document.getElementById(id)?.value || '';
    Object.entries(DUMMY).forEach(([k,v]) => { tpl = tpl.replaceAll(k, v); });
    window.open('https://wa.me/?text=' + encodeURIComponent(tpl), '_blank');
}

// ── Auth preview live update ──
(function () {
    const fields = {
        'inp_banner_title': 'prev_banner_title',
        'inp_banner_desc':  'prev_banner_desc',
    };
    Object.entries(fields).forEach(([src, dst]) => {
        const el = document.getElementById(src);
        if (!el) return;
        el.addEventListener('input', () => {
            document.getElementById(dst).textContent = el.value || '—';
        });
    });

    // Color picker sync
    const picker = document.getElementById('inp_primary_color');
    const hex    = document.getElementById('inp_primary_color_hex');
    if (picker && hex) {
        function applyColor(c) {
            const icon = document.getElementById('prev_icon');
            const btn  = document.getElementById('prev_btn');
            if (icon) icon.style.background = c;
            if (btn)  btn.style.background  = c;
        }
        picker.addEventListener('input', () => { hex.value = picker.value; applyColor(picker.value); });
        hex.addEventListener('change', () => {
            if (/^#[0-9a-f]{6}$/i.test(hex.value)) {
                picker.value = hex.value; applyColor(hex.value);
            }
        });
        applyColor(picker.value);
    }
})();

// ── Logo upload preview ──
document.getElementById('logoInput')?.addEventListener('change', function () {
    const file = this.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
        document.getElementById('logoPreview').src = e.target.result;
        document.getElementById('logoFileName').textContent = file.name + ' (' + (file.size/1024).toFixed(1) + ' KB)';
        document.getElementById('logoPreviewWrap').classList.remove('hidden');
        document.getElementById('btnUploadLogo').disabled = false;
    };
    reader.readAsDataURL(file);
});

// Drag & drop logo
const dz = document.getElementById('logoDropzone');
if (dz) {
    ['dragover','dragenter'].forEach(e => dz.addEventListener(e, ev => {
        ev.preventDefault();
        dz.classList.add('!border-blue-500', '!bg-blue-50');
    }));
    ['dragleave','drop'].forEach(e => dz.addEventListener(e, () => {
        dz.classList.remove('!border-blue-500', '!bg-blue-50');
    }));
    dz.addEventListener('drop', ev => {
        ev.preventDefault();
        const inp = document.getElementById('logoInput');
        inp.files = ev.dataTransfer.files;
        inp.dispatchEvent(new Event('change'));
    });
}
</script>
