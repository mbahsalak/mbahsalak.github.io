<?php
/**
 * views/pages/AuditLog/index.php
 * Riwayat Aktivitas Sistem (Audit Log)
 * Variabel: $title, $logs (array), $users (array), $filter (array), $flash
 */
?>

<div class="page-header d-flex justify-content-between align-items-start mb-4">
    <div>
        <h2 class="fw-bold mb-0"><?= htmlspecialchars($title) ?></h2>
        <p class="text-muted mb-0 small">Rekam jejak semua aktivitas admin di sistem</p>
    </div>
</div>

<?php if ($flash): ?>
    <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show mb-4">
        <i class="bi bi-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-triangle' ?> me-2"></i>
        <?= htmlspecialchars($flash['message']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <form method="GET" action="<?= $_ENV['APP_URL'] ?>/audit-log"
              class="row g-2 align-items-end">
            <div class="col-sm-3">
                <label class="form-label small fw-semibold mb-1">Dari Tanggal</label>
                <input type="date" name="from" class="form-control form-control-sm"
                       value="<?= htmlspecialchars($filter['from']) ?>">
            </div>
            <div class="col-sm-3">
                <label class="form-label small fw-semibold mb-1">Sampai Tanggal</label>
                <input type="date" name="to" class="form-control form-control-sm"
                       value="<?= htmlspecialchars($filter['to']) ?>">
            </div>
            <div class="col-sm-3">
                <label class="form-label small fw-semibold mb-1">Filter User</label>
                <select name="user_id" class="form-select form-select-sm">
                    <option value="">— Semua User —</option>
                    <?php foreach ($users as $u): ?>
                        <option value="<?= $u['id'] ?>"
                            <?= (string)($filter['user_id'] ?? '') === (string)$u['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($u['username']) ?> (<?= $u['role'] ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-sm-3 d-flex gap-2">
                <button type="submit" class="btn btn-primary btn-sm">
                    <i class="bi bi-funnel me-1"></i> Filter
                </button>
                <a href="<?= $_ENV['APP_URL'] ?>/audit-log" class="btn btn-outline-secondary btn-sm">
                    Reset
                </a>
            </div>
        </form>
    </div>
</div>


<div class="card border-0 shadow-sm">
    <div class="card-header bg-transparent px-4 py-3 border-bottom d-flex justify-content-between align-items-center">
        <span class="fw-semibold">
            <i class="bi bi-clock-history me-2 text-muted"></i>Log Aktivitas
        </span>
        <div class="d-flex align-items-center gap-3">
            <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle">
                <?= count($logs) ?> entri
            </span>
         
            <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#pruneModal">
                <i class="bi bi-trash me-1"></i> Bersihkan Log Lama
            </button>
        </div>
    </div>
    <div class="card-body p-0">
        <?php if (empty($logs)): ?>
            <div class="text-center py-5 text-muted">
                <i class="bi bi-journal-x fs-2 d-block mb-2"></i>
                Tidak ada log
                <?= ($filter['from'] || $filter['to'] || $filter['user_id']) ? 'untuk filter ini.' : 'saat ini.' ?>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" id="tblLog">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4" style="width:50px">#</th>
                            <th style="width:160px">Waktu</th>
                            <th style="width:140px">User</th>
                            <th style="width:80px">Role</th>
                            <th>Aktivitas</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($logs as $i => $log): ?>
                        <tr>
                            <td class="ps-4 text-muted small"><?= $i + 1 ?></td>
                            <td class="text-muted small" style="white-space:nowrap">
                                <?= date('d M Y', strtotime($log['created_at'])) ?>
                                <span class="d-block text-muted" style="font-size:.72rem">
                                    <?= date('H:i:s', strtotime($log['created_at'])) ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($log['username']): ?>
                                    <a href="<?= $_ENV['APP_URL'] ?>/users/<?= $log['user_id'] ?? '' ?>"
                                       class="text-decoration-none fw-semibold small">
                                        <?= htmlspecialchars($log['username']) ?>
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted small">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($log['role'] ?? null): ?>
                                <?php
                                $roleColor = match($log['role'] ?? '') {
                                    'admin'     => 'danger',
                                    'kasir'     => 'warning',
                                    'teknisi'   => 'info',
                                    'pelanggan' => 'primary',
                                    default     => 'secondary',
                                };
                                ?>
                                <span class="badge bg-<?= $roleColor ?>-subtle text-<?= $roleColor ?> border border-<?= $roleColor ?>-subtle">
                                    <?= ucfirst($log['role'] ?? '') ?>
                                </span>
                                <?php endif; ?>
                            </td>
                            <td class="small"><?= htmlspecialchars($log['aktivitas']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
    <?php if (!empty($logs)): ?>
    <div class="card-footer bg-transparent text-muted small px-4 py-2">
        Menampilkan <strong><?= count($logs) ?></strong> entri terbaru
    </div>
    <?php endif; ?>
</div>

<div class="modal fade" id="pruneModal" tabindex="-1" aria-labelledby="pruneModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold" id="pruneModalLabel">
                    <i class="bi bi-trash text-danger me-2"></i>Bersihkan Log Lama
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="<?= $_ENV['APP_URL'] ?>/audit-log/prune"
                  onsubmit="return confirm('Yakin menghapus log lama? Tindakan ini tidak dapat dibatalkan.')">
                <?= $this->csrfField() ?>
                <div class="modal-body">
                    <p class="text-muted small mb-3">
                        Hapus semua entri log yang lebih lama dari jumlah hari berikut.
                        Log terbaru tetap disimpan.
                    </p>
                    <div class="mb-3">
                        <label for="prunedays" class="form-label fw-semibold small">
                            Hapus log lebih lama dari
                        </label>
                        <div class="input-group">
                            <input type="number" id="prunedays" name="days"
                                   class="form-control" value="90" min="1" max="3650">
                            <span class="input-group-text">hari</span>
                        </div>
                        <div class="form-text">Default: 90 hari (3 bulan)</div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-outline-secondary btn-sm"
                            data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-danger btn-sm">
                        <i class="bi bi-trash me-1"></i> Hapus Log Lama
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
