<?php
/**
 * views/pages/UsageLog/cron_log.php
 * Log dan ringkasan eksekusi cron job bandwidth collector.
 */
$appUrl = $_ENV['APP_URL'] ?? '';

// Helper format durasi
function fmtDur(int $ms): string {
    if ($ms < 1000) return $ms . 'ms';
    $s = round($ms / 1000, 1);
    return $s . 's';
}
?>

<div class="d-flex justify-between align-center mb-4">
  <div>
    <h4 class="page-title">
      <i class="fa-solid fa-clock-rotate-left" style="color:var(--clr-primary);margin-right:.5rem"></i>
      Cron Log — Bandwidth Collector
    </h4>
    <p class="text-muted" style="font-size:.82rem;margin-top:.15rem">
      Log eksekusi otomatis pengumpulan data bandwidth pelanggan
    </p>
  </div>
  <div class="d-flex gap-2">
    <a href="<?= $appUrl ?>/usage-log" class="btn btn--ghost btn--sm">
      <i class="fa-solid fa-arrow-left"></i> Kembali
    </a>
    <a href="<?= $appUrl ?>/usage-log/cron/export" class="btn btn--ghost btn--sm">
      <i class="fa-solid fa-download"></i> Export CSV
    </a>
  </div>
</div>

<!-- Ringkasan per job -->
<?php if (!empty($summary)): ?>
<div class="card mb-4">
  <div class="card__header">
    <span class="card__title">Ringkasan Cron Job (30 hari terakhir)</span>
  </div>
  <div class="card__body" style="padding:0">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:1rem;padding:1rem">
      <?php foreach ($summary as $s): ?>
      <?php
          $lastRunOk = ($s['success_count'] ?? 0) > 0;
          $totalRuns = $s['total_runs'] ?? 0;
          $successCount = $s['success_count'] ?? 0;
          $errorCount = $s['error_count'] ?? 0;
          $avgDuration = $s['avg_duration_ms'] ?? 0;
      ?>
      <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:var(--radius-md);padding:1rem">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:.75rem">
          <strong style="font-size:1.1rem;color:var(--txt-primary)"><?= htmlspecialchars($s['job_name'] ?? '') ?></strong>
          <span style="width:10px;height:10px;border-radius:50%;background:<?= $lastRunOk ? '#10b981' : '#ef4444' ?>;display:inline-block"></span>
        </div>
        
        <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:.75rem;font-size:.85rem">
          <div>
            <div style="color:var(--txt-muted);font-weight:600">Total run:</div>
            <div style="color:var(--txt-primary);font-weight:700"><?= $totalRuns ?></div>
          </div>
          <div>
            <div style="color:var(--txt-muted);font-weight:600">OK:</div>
            <div style="color:#10b981;font-weight:700"><?= $successCount ?></div>
          </div>
          <div>
            <div style="color:var(--txt-muted);font-weight:600">Error:</div>
            <div style="color:#ef4444;font-weight:700"><?= $errorCount ?></div>
          </div>
          <div>
            <div style="color:var(--txt-muted);font-weight:600">Avg durasi:</div>
            <div style="color:var(--txt-primary);font-weight:700"><?= fmtDur((int)$avgDuration) ?></div>
          </div>
        </div>
        
        <?php if (!empty($s['last_run'])): ?>
        <div style="margin-top:.75rem;padding-top:.75rem;border-top:1px solid var(--border);font-size:.75rem;color:var(--txt-muted)">
          <i class="fa-solid fa-clock"></i> Terakhir: <?= date('d/m/Y H:i:s', strtotime($s['last_run'])) ?>
        </div>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Tabel log detail -->
<div class="card">
  <div class="card__header">
    <span class="card__title">Log Detail (<?= count($logs) ?> baris)</span>
    <div class="d-flex gap-2">
      <button class="btn btn--sm btn--ghost" onclick="location.reload()">
        <i class="fa-solid fa-rotate"></i> Refresh
      </button>
    </div>
  </div>
  <div class="table-wrap">
    <table class="table">
      <thead>
        <tr>
          <th style="width:60px">#</th>
          <th>Job</th>
          <th>Status</th>
          <th>Rows Affected</th>
          <th>Durasi</th>
          <th>Message</th>
          <th>Waktu</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($logs as $i => $log): ?>
        <tr style="<?= $log['status'] === 'error' ? 'background:#fef2f2' : '' ?>">
          <td class="text-muted" style="font-size:.75rem"><?= $i + 1 ?></td>
          <td style="font-weight:600;font-size:.85rem;color:var(--txt-primary)"><?= htmlspecialchars($log['job_name'] ?? '') ?></td>
          <td>
            <?php
            $status = $log['status'] ?? 'ok';
            $statusColor = $status === 'ok' ? '#10b981' : ($status === 'error' ? '#ef4444' : '#f59e0b');
            $statusText = $status === 'ok' ? 'OK' : ($status === 'error' ? 'ERROR' : 'SKIP');
            ?>
            <span style="padding:.25rem .75rem;border-radius:20px;font-size:.75rem;font-weight:700;background:<?= $statusColor ?>15;color:<?= $statusColor ?>">
              <?= $statusText ?>
            </span>
          </td>
          <td class="text-right">
            <span style="font-size:.85rem;font-weight:600;color:var(--txt-primary)"><?= $log['rows_affected'] ?? 0 ?></span>
          </td>
          <td class="text-right">
            <span style="font-size:.85rem;font-weight:600;color:var(--txt-primary)"><?= fmtDur((int)($log['duration_ms'] ?? 0)) ?></span>
          </td>
          <td style="font-size:.8rem;color:var(--txt-muted);max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
            <?= htmlspecialchars($log['message'] ?? '') ?>
          </td>
          <td style="font-size:.8rem;color:var(--txt-muted);white-space:nowrap">
            <?= date('d/m/Y H:i:s', strtotime($log['ran_at'] ?? '')) ?>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($logs)): ?>
        <tr>
          <td colspan="7" class="text-center text-muted" style="padding:2rem">
            <i class="fa-solid fa-inbox" style="font-size:2rem;opacity:.3;display:block;margin-bottom:.5rem"></i>
            Belum ada log cron job.
          </td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<style>
.card__header { display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:1rem 1.25rem;background:var(--bg-surface);border-bottom:1px solid var(--border); }
.card__title { font-size:1.1rem;font-weight:700;color:var(--txt-primary); }
.card__body { padding:1.25rem;background:var(--bg-body); }
.table-wrap { overflow-x:auto; }
.table { width:100%;border-collapse:collapse; }
.table thead th { padding:.75rem 1rem;background:var(--bg-surface);border-bottom:2px solid var(--border);text-align:left;font-weight:700;font-size:.8rem;text-transform:uppercase;letter-spacing:.05em;color:var(--txt-muted); }
.table tbody td { padding:.75rem 1rem;border-bottom:1px solid var(--border);font-size:.85rem;color:var(--txt-primary); }
.table tbody tr:hover { background:var(--bg-surface); }
.text-muted { color:var(--txt-muted) !important; }
.text-right { text-align:right !important; }
</style>
