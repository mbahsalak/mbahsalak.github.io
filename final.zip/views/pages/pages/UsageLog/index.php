<?php
/**
 * views/pages/UsageLog/index.php
 * Ringkasan penggunaan bandwidth bulanan semua pelanggan.
 */
use Service\MikrotikService;

$appUrl = $_ENV['APP_URL'] ?? '';

// Helper format bytes
function fmtBytes(int $b): string {
    if ($b <= 0)     return '0 B';
    if ($b < 1e3)    return $b . ' B';
    if ($b < 1e6)    return round($b/1e3, 1) . ' KB';
    if ($b < 1e9)    return round($b/1e6, 1) . ' MB';
    if ($b < 1e12)   return round($b/1e9, 2) . ' GB';
    return round($b/1e12, 2) . ' TB';
}
function fmtMin(int $m): string {
    if ($m <= 0) return '—';
    $h = intdiv($m, 60); $mn = $m % 60;
    return $h > 0 ? "{$h}j {$mn}m" : "{$mn}m";
}

// Bulan pilihan (12 bulan ke belakang)
$months = [];
for ($i = 0; $i < 12; $i++) {
    $months[] = date('Y-m', strtotime("-{$i} months"));
}

// Totals
$grandTotal = ($totalRx ?? 0) + ($totalTx ?? 0);
?>

<div class="d-flex justify-between align-center mb-4">
  <div>
    <h4 class="page-title">
      <i class="fa-solid fa-chart-line" style="color:var(--clr-primary);margin-right:.5rem"></i>
      Penggunaan Bandwidth
    </h4>
    <p class="text-muted" style="font-size:.82rem;margin-top:.15rem">
      Ringkasan konsumsi data semua pelanggan per bulan
    </p>
  </div>
  <div class="d-flex gap-2">
    <a href="<?= $appUrl ?>/usage-log/export?ym=<?= htmlspecialchars($ym) ?>"
       class="btn btn--ghost btn--sm">
      <i class="fa-solid fa-download"></i> CSV
    </a>
    <a href="<?= $appUrl ?>/usage-log/cron" class="btn btn--ghost btn--sm">
      <i class="fa-solid fa-clock-rotate-left"></i> Cron Log
    </a>
  </div>
</div>

<!-- Filter bulan -->
<div class="card mb-4">
  <div class="card__body" style="padding:.75rem 1rem">
    <form method="GET" action="<?= $appUrl ?>/usage-log" class="d-flex align-center gap-3">
      <label style="font-size:.82rem;font-weight:600;color:var(--txt-muted);white-space:nowrap">
        <i class="fa-solid fa-calendar"></i> Periode:
      </label>
      <select name="ym" class="form-control form-control--sm" style="width:160px"
              onchange="this.form.submit()">
        <?php foreach ($months as $m): ?>
        <option value="<?= $m ?>" <?= $m === $ym ? 'selected' : '' ?>>
          <?= date('F Y', strtotime($m . '-01')) ?>
        </option>
        <?php endforeach; ?>
      </select>
      <span style="font-size:.8rem;color:var(--txt-muted)">
        <?= count($summary) ?> pelanggan
      </span>
    </form>
  </div>
</div>

<!-- Stats cards -->
<div class="stats-row mb-4" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem">
  <div class="stat-mini">
    <div class="stat-mini__icon" style="background:rgba(59,130,246,.1);color:#3b82f6">
      <i class="fa-solid fa-arrow-down"></i>
    </div>
    <div>
      <div class="stat-mini__val"><?= fmtBytes((int)($totalRx ?? 0)) ?></div>
      <div class="stat-mini__lbl">Total Download</div>
    </div>
  </div>
  <div class="stat-mini">
    <div class="stat-mini__icon" style="background:rgba(16,185,129,.1);color:#10b981">
      <i class="fa-solid fa-arrow-up"></i>
    </div>
    <div>
      <div class="stat-mini__val"><?= fmtBytes((int)($totalTx ?? 0)) ?></div>
      <div class="stat-mini__lbl">Total Upload</div>
    </div>
  </div>
  <div class="stat-mini">
    <div class="stat-mini__icon" style="background:rgba(124,58,237,.1);color:#7c3aed">
      <i class="fa-solid fa-database"></i>
    </div>
    <div>
      <div class="stat-mini__val"><?= fmtBytes($grandTotal) ?></div>
      <div class="stat-mini__lbl">Grand Total</div>
    </div>
  </div>
  <div class="stat-mini">
    <div class="stat-mini__icon" style="background:rgba(245,158,11,.1);color:#f59e0b">
      <i class="fa-solid fa-users"></i>
    </div>
    <div>
      <div class="stat-mini__val"><?= count(array_filter($summary, fn($r) => ($r['rx_bytes'] ?? 0) > 0)) ?></div>
      <div class="stat-mini__lbl">Pelanggan Aktif</div>
    </div>
  </div>
</div>

<!-- Cron status strip -->
<?php if (!empty($cronSum)): ?>
<div class="card mb-4">
  <div class="card__header" style="padding:.6rem 1rem">
    <span style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--txt-muted)">
      <i class="fa-solid fa-robot"></i> Status Cron Job
    </span>
  </div>
  <div class="card__body" style="padding:.75rem 1rem;display:flex;flex-wrap:wrap;gap:.75rem">
    <?php foreach ($cronSum as $c): ?>
    <?php 
        $lastRunOk = ($c['success_count'] ?? 0) > 0; 
        $totalRuns = $c['total_runs'] ?? 0;
    ?>
    <div style="display:flex;align-items:center;gap:.5rem;padding:.4rem .8rem;border-radius:20px;border:1px solid var(--border);background:var(--bg-body);font-size:.75rem">
      <span style="width:8px;height:8px;border-radius:50%;background:<?= $lastRunOk ? '#10b981' : '#ef4444' ?>;flex-shrink:0"></span>
      <strong><?= htmlspecialchars($c['job_name'] ?? '') ?></strong>
      <span style="color:var(--txt-muted)">·</span>
      <span style="color:var(--txt-muted)"><?= $totalRuns ?>x run</span>
      <?php if (($c['error_count'] ?? 0) > 0): ?>
      <span style="color:#ef4444"><?= $c['error_count'] ?> error</span>
      <?php endif; ?>
      <span style="color:var(--txt-muted)">·</span>
      <span style="color:var(--txt-muted)"><?= $c['last_run'] ? date('d/m H:i', strtotime($c['last_run'])) : '—' ?></span>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<!-- Tabel data -->
<div class="card">
  <div class="card__header">
    <span class="card__title">
      Detail Penggunaan — <?= date('F Y', strtotime($ym . '-01')) ?>
    </span>
    <div class="d-flex gap-2">
      <input type="text" id="searchInput" class="form-control form-control--sm"
             placeholder="Cari pelanggan..." style="width:200px">
    </div>
  </div>
  <div class="table-wrap">
    <table class="table" id="usageTable">
      <thead>
        <tr>
          <th>#</th>
          <th>Pelanggan</th>
          <th>Paket</th>
          <th class="text-right sort-btn" data-col="rx">
            Download <i class="fa-solid fa-sort"></i>
          </th>
          <th class="text-right sort-btn" data-col="tx">
            Upload <i class="fa-solid fa-sort"></i>
          </th>
          <th class="text-right sort-btn" data-col="total">
            Total <i class="fa-solid fa-sort"></i>
          </th>
          <th class="text-center">Online</th>
          <th class="text-center">Bar</th>
          <th>Terakhir Aktif</th>
        </tr>
      </thead>
      <tbody>
        <?php
        // Hitung max total untuk bar chart proporsional
        $maxTotal = 1;
        foreach ($summary as $row) {
            $totalBytes = ($row['rx_bytes'] ?? 0) + ($row['tx_bytes'] ?? 0);
            if ($totalBytes > $maxTotal) $maxTotal = $totalBytes;
        }
        
        foreach ($summary as $i => $row):
            $rxBytes = $row['rx_bytes'] ?? 0;
            $txBytes = $row['tx_bytes'] ?? 0;
            $totalBytes = $rxBytes + $txBytes;
            $pct  = min(100, round(($totalBytes / max(1, $maxTotal)) * 100));
            $barColor = $pct > 80 ? '#ef4444' : ($pct > 50 ? '#f59e0b' : '#10b981');
            $onlineSnapshots = $row['online_snapshots'] ?? 0;
        ?>
        <tr class="usage-row"
            data-rx="<?= $rxBytes ?>"
            data-tx="<?= $txBytes ?>"
            data-total="<?= $totalBytes ?>">
          <td class="text-muted" style="font-size:.75rem"><?= $i + 1 ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:.6rem">
              <div style="width:30px;height:30px;border-radius:50%;background:var(--clr-primary-light);
                          display:flex;align-items:center;justify-content:center;
                          font-size:.72rem;font-weight:700;color:var(--clr-primary);flex-shrink:0">
                <?= strtoupper(substr($row['nama_lengkap'] ?? '', 0, 1)) ?>
              </div>
              <div>
                <a href="<?= $appUrl ?>/pelanggan/<?= $row['pelanggan_id'] ?>"
                   style="font-weight:600;font-size:.85rem;color:var(--txt-primary)">
                  <?= htmlspecialchars($row['nama_lengkap'] ?? '') ?>
                </a>
                <?php if (!empty($row['mac_address'])): ?>
                <div style="font-size:.68rem;color:var(--txt-muted);font-family:monospace">
                  <?= htmlspecialchars($row['mac_address']) ?>
                </div>
                <?php endif; ?>
              </div>
            </div>
          </td>
          <td style="font-size:.78rem;color:var(--txt-muted)">
            <?= htmlspecialchars($row['nama_paket'] ?? '') ?>
            <span style="font-size:.7rem;color:var(--txt-muted);opacity:.7">
              (<?= htmlspecialchars($row['kecepatan'] ?? '') ?>)
            </span>
          </td>
          <td class="text-right">
            <span class="bw-val" style="color:#3b82f6"><?= fmtBytes($rxBytes) ?></span>
          </td>
          <td class="text-right">
            <span class="bw-val" style="color:#10b981"><?= fmtBytes($txBytes) ?></span>
          </td>
          <td class="text-right">
            <strong class="bw-val"><?= fmtBytes($totalBytes) ?></strong>
          </td>
          <td class="text-center">
            <span style="font-size:.8rem;color:var(--txt-muted)"><?= $onlineSnapshots ?>x</span>
          </td>
          <td style="width:120px">
            <div style="background:var(--border);border-radius:4px;height:6px;overflow:hidden">
              <div style="width:<?= $pct ?>%;height:100%;background:<?= $barColor ?>;border-radius:4px;transition:width .3s"></div>
            </div>
            <div style="font-size:.65rem;color:var(--txt-muted);text-align:right;margin-top:2px"><?= $pct ?>%</div>
          </td>
          <td style="font-size:.75rem;color:var(--txt-muted)">
            <?= $row['last_active'] ? date('d/m/Y', strtotime($row['last_active'])) : '—' ?>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($summary)): ?>
        <tr>
          <td colspan="9" class="text-center text-muted" style="padding:2rem">
            <i class="fa-solid fa-inbox" style="font-size:2rem;opacity:.3;display:block;margin-bottom:.5rem"></i>
            Belum ada data untuk periode ini.
            <a href="<?= $appUrl ?>/usage-log/cron">Cek status cron job →</a>
          </td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<style>
.stat-mini { display:flex;align-items:center;gap:.75rem;padding:1rem;background:var(--bg-surface);border:1px solid var(--border);border-radius:var(--radius-md); }
.stat-mini__icon { width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:.9rem;flex-shrink:0; }
.stat-mini__val  { font-size:1.1rem;font-weight:700;color:var(--txt-primary);font-variant-numeric:tabular-nums; }
.stat-mini__lbl  { font-size:.7rem;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--txt-muted); }
.bw-val { font-size:.82rem;font-weight:600;font-variant-numeric:tabular-nums; }
.sort-btn { cursor:pointer;user-select:none;white-space:nowrap; }
.sort-btn:hover { color:var(--clr-primary); }
</style>

<script>
// ── Search ────────────────────────────────────────────────────────────────
document.getElementById('searchInput').addEventListener('input', function () {
    const q = this.value.toLowerCase();
    document.querySelectorAll('#usageTable .usage-row').forEach(tr => {
        tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
});

// ── Sort columns ──────────────────────────────────────────────────────────
let sortState = { col: 'total', dir: -1 };
document.querySelectorAll('.sort-btn').forEach(th => {
    th.addEventListener('click', function () {
        const col = this.dataset.col;
        if (sortState.col === col) sortState.dir *= -1;
        else { sortState.col = col; sortState.dir = -1; }

        const tbody  = document.querySelector('#usageTable tbody');
        const rows   = Array.from(tbody.querySelectorAll('.usage-row'));
        rows.sort((a, b) => {
            const av = parseInt(a.dataset[col] ?? 0);
            const bv = parseInt(b.dataset[col] ?? 0);
            return (av - bv) * sortState.dir;
        });
        rows.forEach(r => tbody.appendChild(r));

        document.querySelectorAll('.sort-btn i').forEach(i => i.className = 'fa-solid fa-sort');
        this.querySelector('i').className =
            'fa-solid fa-sort-' + (sortState.dir === -1 ? 'down' : 'up');
    });
});

// Default sort: total DESC
document.querySelector('[data-col="total"]')?.click();
</script>
