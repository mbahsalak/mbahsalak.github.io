<?php
/**
 * views/pages/Laporan/pembayaran.php
 * Laporan Pembayaran — Full Tailwind CSS
 */
$appUrl       = $_ENV['APP_URL'] ?? '';
$list         = $list         ?? [];
$filter       = $filter       ?? ['bulan' => date('Y-m'), 'status' => 'paid'];
$totalNominal = $totalNominal ?? 0;
$totalCount   = $totalCount   ?? 0;
?>
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5">
<!-- Header Section -->
<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
    <div>
        <h1 class="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <i class="fa-solid fa-money-bill-trend-up text-emerald-500"></i>
            Laporan Pembayaran
        </h1>
        <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">Rekap pembayaran tagihan pelanggan</p>
    </div>
    <div class="flex gap-2">
        <a href="<?= $appUrl ?>/laporan/tagihan"
           class="inline-flex items-center gap-1.5 px-4 py-2.5 text-sm font-semibold
                  border border-indigo-500 text-indigo-600 dark:text-indigo-400
                  bg-white dark:bg-gray-800 hover:bg-indigo-50 dark:hover:bg-indigo-900/20
                  rounded-lg transition-colors no-underline">
            <i class="fa-solid fa-file-invoice"></i> Laporan Tagihan
        </a>
        <button onclick="window.print()"
                class="inline-flex items-center gap-1.5 px-4 py-2.5 text-sm font-semibold
                       bg-gray-500 hover:bg-gray-600 text-white rounded-lg transition-colors border-0 cursor-pointer">
            <i class="fa-solid fa-print"></i> Cetak
        </button>
    </div>
</div>

<!-- Filter Card -->
<div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4 mb-5">
    <form method="GET" action="<?= $appUrl ?>/laporan/pembayaran"
          class="flex flex-wrap items-center gap-3">

        <span class="text-xs font-bold text-gray-500 dark:text-gray-400 flex items-center gap-1">
            <i class="fa-solid fa-filter"></i> Filter:
        </span>

        <!-- Bulan -->
        <input type="month" name="bulan" value="<?= htmlspecialchars($filter['bulan']) ?>"
               class="px-3 py-2 text-sm rounded-lg border border-gray-300 dark:border-gray-600
                      bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100
                      focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all">

        <!-- Status -->
        <select name="status"
                class="px-3 py-2 text-sm rounded-lg border border-gray-300 dark:border-gray-600
                       bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100
                       focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/20 outline-none cursor-pointer transition-all">
            <option value="paid"   <?= $filter['status'] === 'paid'   ? 'selected' : '' ?>>Sudah Lunas</option>
            <option value="unpaid" <?= $filter['status'] === 'unpaid' ? 'selected' : '' ?>>Belum Lunas</option>
            <option value=""       <?= $filter['status'] === ''       ? 'selected' : '' ?>>Semua Status</option>
        </select>

        <!-- Tipe -->
        <select name="tipe"
                class="px-3 py-2 text-sm rounded-lg border border-gray-300 dark:border-gray-600
                       bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100
                       focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/20 outline-none cursor-pointer transition-all">
            <option value="">Semua Tipe</option>
            <option value="paket"      <?= ($filter['tipe'] ?? '') === 'paket'      ? 'selected' : '' ?>>Paket Bulanan</option>
            <option value="pemasangan" <?= ($filter['tipe'] ?? '') === 'pemasangan' ? 'selected' : '' ?>>Pemasangan</option>
            <option value="perbaikan"  <?= ($filter['tipe'] ?? '') === 'perbaikan'  ? 'selected' : '' ?>>Perbaikan</option>
            <option value="lainnya"    <?= ($filter['tipe'] ?? '') === 'lainnya'    ? 'selected' : '' ?>>Lainnya</option>
        </select>

        <!-- Submit -->
        <button type="submit"
                class="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold
                       bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors border-0 cursor-pointer">
            <i class="fa-solid fa-magnifying-glass"></i> Tampilkan
        </button>

        <!-- Reset -->
        <a href="<?= $appUrl ?>/laporan/pembayaran"
           class="inline-flex items-center gap-1.5 px-3 py-2 text-sm rounded-lg
                  border border-gray-300 dark:border-gray-600 text-gray-500 dark:text-gray-400
                  hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors no-underline">
            <i class="fa-solid fa-xmark"></i> Reset
        </a>

        <!-- Search (pushed to right) -->
        <div class="relative ml-auto">
            <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xs pointer-events-none"></i>
            <input type="text" id="cariLaporan" placeholder="Cari pelanggan..." oninput="filterLaporan(this.value)"
                   class="pl-9 pr-3 py-2 text-sm rounded-lg border border-gray-300 dark:border-gray-600
                          bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100
                          focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all
                          w-48">
        </div>
    </form>
</div>

<!-- Summary Cards -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-5">
    <!-- Jumlah Transaksi -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden p-5 border-l-4 border-l-emerald-500">
        <div class="text-xs text-gray-600 dark:text-gray-400 mb-1 flex items-center gap-2">
            <i class="fa-solid fa-receipt text-emerald-500"></i>
            Jumlah Transaksi
        </div>
        <div class="text-2xl font-bold text-emerald-600 dark:text-emerald-400">
            <?= $totalCount ?>
        </div>
        <div class="text-xs text-gray-400 dark:text-gray-500 mt-1">transaksi bulan ini</div>
    </div>

    <!-- Total Pendapatan -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden p-5 border-l-4 border-l-indigo-500">
        <div class="text-xs text-gray-600 dark:text-gray-400 mb-1 flex items-center gap-2">
            <i class="fa-solid fa-coins text-indigo-500"></i>
            Total Pendapatan
        </div>
        <div class="text-2xl font-bold text-indigo-600 dark:text-indigo-400">
            Rp <?= number_format((float)$totalNominal, 0, ',', '.') ?>
        </div>
        <div class="text-xs text-gray-400 dark:text-gray-500 mt-1">
            <?= htmlspecialchars($filter['bulan']) ?>
        </div>
    </div>

    <!-- Rata-rata -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden p-5 border-l-4 border-l-amber-500">
        <div class="text-xs text-gray-600 dark:text-gray-400 mb-1 flex items-center gap-2">
            <i class="fa-solid fa-calculator text-amber-500"></i>
            Rata-rata / Transaksi
        </div>
        <div class="text-2xl font-bold text-amber-600 dark:text-amber-400">
            Rp <?= $totalCount > 0 ? number_format((float)$totalNominal / $totalCount, 0, ',', '.') : '0' ?>
        </div>
    </div>
</div>

<!-- Tabel Laporan -->
<div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">

    <!-- Table Header -->
    <div class="px-5 py-3.5 border-b border-gray-200 dark:border-gray-700 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <span class="font-bold text-sm text-gray-900 dark:text-white flex items-center gap-2">
            Rincian Pembayaran
            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold
                         bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                <?= $totalCount ?>
            </span>
        </span>
        <span class="text-xs text-gray-500 dark:text-gray-400">
            Periode: <strong class="text-gray-700 dark:text-gray-300"><?= htmlspecialchars($filter['bulan']) ?></strong>
        </span>
    </div>

    <!-- Table -->
    <div class="overflow-x-auto">
        <table class="w-full text-sm border-collapse" id="tabelLaporan">
            <thead>
                <tr class="bg-gray-50 dark:bg-gray-700/50">
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide w-10">#</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Pelanggan</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide hidden md:table-cell">Alamat</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide hidden sm:table-cell">Paket / Layanan</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide hidden lg:table-cell">Tipe</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide hidden lg:table-cell">Periode</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide hidden sm:table-cell">Tgl Bayar</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide hidden lg:table-cell">Metode</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide hidden xl:table-cell">Penerima</th>
                    <th class="px-4 py-3 text-right text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Nominal</th>
                    <th class="px-4 py-3 text-center text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Status</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                <?php if (empty($list)): ?>
                    <tr>
                        <td colspan="11" class="px-4 py-14 text-center text-gray-400 dark:text-gray-500">
                            <i class="fa-solid fa-inbox text-4xl block mb-3 opacity-30"></i>
                            <span class="text-sm">Tidak ada data pembayaran untuk periode ini.</span>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($list as $i => $row): ?>
                    <?php
                        // Tipe badge
                        $tipeColors = [
                            'paket'      => ['indigo',  'Paket'],
                            'pemasangan' => ['amber',   'Pasang'],
                            'perbaikan'  => ['red',     'Perbaikan'],
                            'lainnya'    => ['gray',    'Lainnya'],
                        ];
                        [$tipeColor, $tipeLabel] = $tipeColors[$row['tipe'] ?? 'paket'] ?? ['gray', '?'];

                        // Metode icon
                        $metode     = $row['metode_pembayaran'] ?? '';
                        $metodeIcon = match(strtolower($metode)) {
                            'transfer', 'bank transfer' => 'fa-building-columns',
                            'tunai', 'cash'            => 'fa-money-bill-wave',
                            'qris', 'qr'               => 'fa-qrcode',
                            default                    => 'fa-credit-card',
                        };

                        // Status badge
                        $status = $row['status'] ?? '';
                        $statusBadge = match($status) {
                            'paid'    => ['green',  'circle-check', 'Lunas'],
                            'suspend' => ['red',    'ban',          'Suspend'],
                            'cancel'  => ['gray',   'xmark',        'Batal'],
                            default   => ['amber',  'clock',        'Belum Lunas'],
                        };
                        [$sColor, $sIcon, $sLabel] = $statusBadge;
                    ?>
                    <tr class="lap-row hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                        <!-- No -->
                        <td class="px-4 py-3 text-gray-400 dark:text-gray-500 text-xs"><?= $i + 1 ?></td>

                        <!-- Pelanggan -->
                        <td class="px-4 py-3">
                            <div class="font-semibold text-gray-900 dark:text-white text-sm lap-name">
                                <?= htmlspecialchars($row['nama_lengkap'] ?? '') ?>
                            </div>
                            <?php if (!empty($row['no_telp'])): ?>
                                <div class="text-xs text-gray-400 dark:text-gray-500 flex items-center gap-1 mt-0.5">
                                    <i class="fa-solid fa-phone text-[9px]"></i>
                                    <?= htmlspecialchars($row['no_telp']) ?>
                                </div>
                            <?php endif; ?>
                        </td>

                        <!-- Alamat -->
                        <td class="px-4 py-3 text-gray-500 dark:text-gray-400 max-w-[160px] hidden md:table-cell">
                            <span class="block truncate" title="<?= htmlspecialchars($row['alamat'] ?? '') ?>">
                                <?= !empty($row['alamat']) ? htmlspecialchars($row['alamat']) : '<span class="text-gray-300 dark:text-gray-600">—</span>' ?>
                            </span>
                        </td>

                        <!-- Paket / Layanan -->
                        <td class="px-4 py-3 hidden sm:table-cell">
                            <div class="text-gray-700 dark:text-gray-300 text-sm">
                                <?= htmlspecialchars($row['nama_paket'] ?? '-') ?>
                            </div>
                            <?php if (!empty($row['deskripsi'])): ?>
                                <div class="text-[11px] text-gray-400 dark:text-gray-500 mt-0.5">
                                    <?= htmlspecialchars($row['deskripsi']) ?>
                                </div>
                            <?php endif; ?>
                        </td>

                        <!-- Tipe -->
                        <td class="px-4 py-3 hidden lg:table-cell">
                            <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold
                                         bg-<?= $tipeColor ?>-100 text-<?= $tipeColor ?>-700
                                         dark:bg-<?= $tipeColor ?>-900/30 dark:text-<?= $tipeColor ?>-400">
                                <?= $tipeLabel ?>
                            </span>
                        </td>

                        <!-- Periode -->
                        <td class="px-4 py-3 text-gray-600 dark:text-gray-400 text-sm hidden lg:table-cell">
                            <?= htmlspecialchars($row['periode_bulan'] ?? '-') ?>
                        </td>

                        <!-- Tgl Bayar -->
                        <td class="px-4 py-3 hidden sm:table-cell">
                            <?php if (!empty($row['tgl_bayar'])): ?>
                                <span class="text-sm text-gray-900 dark:text-white whitespace-nowrap">
                                    <?= date('d M Y', strtotime($row['tgl_bayar'])) ?>
                                </span>
                                <div class="text-[11px] text-gray-400 dark:text-gray-500">
                                    <?= date('H:i', strtotime($row['tgl_bayar'])) ?>
                                </div>
                            <?php else: ?>
                                <span class="text-gray-300 dark:text-gray-600">—</span>
                            <?php endif; ?>
                        </td>

                        <!-- Metode -->
                        <td class="px-4 py-3 hidden lg:table-cell">
                            <?php if ($metode): ?>
                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md
                                             bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-xs">
                                    <i class="fa-solid <?= $metodeIcon ?>"></i>
                                    <?= htmlspecialchars($metode) ?>
                                </span>
                            <?php else: ?>
                                <span class="text-gray-300 dark:text-gray-600">—</span>
                            <?php endif; ?>
                        </td>

                        <!-- Penerima -->
                        <td class="px-4 py-3 text-gray-700 dark:text-gray-300 text-sm hidden xl:table-cell">
                            <?= !empty($row['penerima']) ? htmlspecialchars($row['penerima']) : '<span class="text-gray-300 dark:text-gray-600">—</span>' ?>
                        </td>

                        <!-- Nominal -->
                        <td class="px-4 py-3 text-right font-semibold text-gray-900 dark:text-white text-sm whitespace-nowrap">
                            Rp <?= number_format((float)($row['total'] ?? 0), 0, ',', '.') ?>
                        </td>

                        <!-- Status -->
                        <td class="px-4 py-3 text-center">
                            <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold
                                         bg-<?= $sColor ?>-100 text-<?= $sColor ?>-700
                                         dark:bg-<?= $sColor ?>-900/30 dark:text-<?= $sColor ?>-400">
                                <i class="fa-solid fa-<?= $sIcon ?> text-[9px]"></i>
                                <?= $sLabel ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>

                    <!-- Total Row -->
                    <tr class="bg-gray-50 dark:bg-gray-700/50 border-t-2 border-gray-200 dark:border-gray-600">
                        <td colspan="9" class="px-4 py-3 font-bold text-sm text-right text-gray-700 dark:text-gray-300">
                            Total Pembayaran (<?= $totalCount ?> transaksi)
                        </td>
                        <td class="px-4 py-3 text-right font-bold text-base text-emerald-600 dark:text-emerald-400 whitespace-nowrap">
                            Rp <?= number_format((float)$totalNominal, 0, ',', '.') ?>
                        </td>
                        <td></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Table Footer -->
    <?php if (!empty($list)): ?>
    <div class="px-5 py-2.5 border-t border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/30 text-xs text-gray-400 dark:text-gray-500">
        Menampilkan <strong class="text-gray-600 dark:text-gray-300"><?= count($list) ?></strong> transaksi
        &middot; Periode <strong class="text-gray-600 dark:text-gray-300"><?= htmlspecialchars($filter['bulan']) ?></strong>
    </div>
    <?php endif; ?>
</div>
</div>

<!-- Script -->
<script>
function filterLaporan(q) {
    q = q.toLowerCase();
    document.querySelectorAll('#tabelLaporan .lap-row').forEach(row => {
        const name = row.querySelector('.lap-name')?.textContent.toLowerCase() ?? '';
        row.style.display = name.includes(q) ? '' : 'none';
    });
}
</script>

<!-- Print Styles -->
<style>
@media print {
    /* Sembunyikan elemen interaktif saat cetak */
    .page-header button,
    form,
    #cariLaporan,
    a[href*="laporan"] {
        display: none !important;
    }
    /* Hilangkan shadow & border radius */
    .bg-white, .dark\:bg-gray-800 {
        box-shadow: none !important;
        border-radius: 0 !important;
    }
    /* Tampilkan semua kolom saat cetak */
    .hidden { display: table-cell !important; }
}
</style>
