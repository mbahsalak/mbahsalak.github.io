<?php
/**
 * views/pages/Laporan/tagihan.php
 */
$appUrl    = $_ENV['APP_URL'] ?? '';
$list      = $list      ?? [];
$filter    = $filter    ?? ['bulan' => date('Y-m'), 'status' => ''];
$nomPaid   = $nomPaid   ?? 0;
$cntPaid   = $cntPaid   ?? 0;
$nomUnpaid = $nomUnpaid ?? 0;
$cntUnpaid = $cntUnpaid ?? 0;
$total     = $nomPaid + $nomUnpaid;
$pctPaid   = $total > 0 ? round($nomPaid / $total * 100) : 0;
?>
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5">
<div class="page-header" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem;">
    <div>
        <h1 class="page-title">
            <i class="fa-solid fa-file-invoice-dollar" style="color:#6366f1;margin-right:.5rem;"></i>
            Laporan Tagihan
        </h1>
        <p class="page-subtitle" style="margin:0;color:var(--text-muted,#6b7280);font-size:.875rem;">
            Rekap tagihan dan status pembayaran pelanggan
        </p>
    </div>
    <div style="display:flex;gap:.5rem;">
        <a href="<?= $appUrl ?>/laporan/pembayaran"
           style="padding:.5rem 1rem;border-radius:8px;border:1px solid #10b981;color:#10b981;background:#fff;
                  font-size:.875rem;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:.4rem;">
            <i class="fa-solid fa-money-bill-trend-up"></i> Laporan Pembayaran
        </a>
        <button onclick="window.print()"
                style="padding:.5rem 1rem;border-radius:8px;border:none;background:#6b7280;color:#fff;
                       font-size:.875rem;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;gap:.4rem;">
            <i class="fa-solid fa-print"></i> Cetak
        </button>
    </div>
</div>

<!-- Filter -->
<div class="card" style="border-radius:12px;padding:1rem 1.25rem;margin-bottom:1.25rem;">
    <form method="GET" action="<?= $appUrl ?>/laporan/tagihan"
          style="display:flex;gap:.75rem;align-items:center;flex-wrap:wrap;">
        <span style="font-size:.8rem;font-weight:700;color:var(--text-muted,#6b7280);">
            <i class="fa-solid fa-filter" style="margin-right:.3rem;"></i>Filter:
        </span>
        <input type="month" name="bulan" value="<?= htmlspecialchars($filter['bulan']) ?>"
               style="padding:.45rem .75rem;border-radius:8px;border:1.5px solid var(--border,#e5e7eb);
                      font-size:.875rem;background:var(--surface,#fff);outline:none;">
        <select name="status"
                style="padding:.45rem .75rem;border-radius:8px;border:1.5px solid var(--border,#e5e7eb);
                       font-size:.875rem;background:var(--surface,#fff);cursor:pointer;outline:none;">
            <option value=""       <?= $filter['status'] === ''       ? 'selected' : '' ?>>Semua Status</option>
            <option value="unpaid" <?= $filter['status'] === 'unpaid' ? 'selected' : '' ?>>Belum Lunas</option>
            <option value="paid"   <?= $filter['status'] === 'paid'   ? 'selected' : '' ?>>Sudah Lunas</option>
        </select>
        <button type="submit"
                style="padding:.45rem 1rem;border-radius:8px;border:none;background:#6366f1;color:#fff;
                       font-size:.875rem;font-weight:600;cursor:pointer;">
            <i class="fa-solid fa-magnifying-glass" style="margin-right:.3rem;"></i>Tampilkan
        </button>
        <a href="<?= $appUrl ?>/laporan/tagihan"
           style="padding:.45rem .75rem;border-radius:8px;border:1.5px solid var(--border,#e5e7eb);
                  color:var(--text-muted,#6b7280);text-decoration:none;font-size:.875rem;">
            <i class="fa-solid fa-xmark"></i> Reset
        </a>
        <div style="margin-left:auto;position:relative;">
            <i class="fa-solid fa-magnifying-glass"
               style="position:absolute;left:.75rem;top:50%;transform:translateY(-50%);
                      color:var(--text-muted,#9ca3af);font-size:.8rem;pointer-events:none;"></i>
            <input type="text" id="cariTagihan" placeholder="Cari pelanggan..." oninput="filterTagihan(this.value)"
                   style="padding:.45rem .75rem .45rem 2.25rem;border-radius:8px;
                          border:1.5px solid var(--border,#e5e7eb);font-size:.875rem;width:190px;outline:none;">
        </div>
    </form>
</div>

<!-- Summary Cards -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem;margin-bottom:1.25rem;">
    <div class="card" style="border-radius:12px;padding:1.25rem;border-left:4px solid #10b981;">
        <div style="font-size:.8rem;color:var(--text-muted,#6b7280);margin-bottom:.4rem;">
            <i class="fa-solid fa-circle-check" style="color:#10b981;margin-right:.4rem;"></i>Sudah Lunas
        </div>
        <div style="font-size:1.5rem;font-weight:700;color:#10b981;"><?= $cntPaid ?></div>
        <div style="font-size:.8rem;color:var(--text-muted,#6b7280);">Rp <?= number_format((float)$nomPaid, 0, ',', '.') ?></div>
    </div>
    <div class="card" style="border-radius:12px;padding:1.25rem;border-left:4px solid #ef4444;">
        <div style="font-size:.8rem;color:var(--text-muted,#6b7280);margin-bottom:.4rem;">
            <i class="fa-solid fa-clock" style="color:#ef4444;margin-right:.4rem;"></i>Belum Lunas
        </div>
        <div style="font-size:1.5rem;font-weight:700;color:#ef4444;"><?= $cntUnpaid ?></div>
        <div style="font-size:.8rem;color:var(--text-muted,#6b7280);">Rp <?= number_format((float)$nomUnpaid, 0, ',', '.') ?></div>
    </div>
    <div class="card" style="border-radius:12px;padding:1.25rem;border-left:4px solid #6366f1;">
        <div style="font-size:.8rem;color:var(--text-muted,#6b7280);margin-bottom:.4rem;">
            <i class="fa-solid fa-list" style="color:#6366f1;margin-right:.4rem;"></i>Total Tagihan
        </div>
        <div style="font-size:1.5rem;font-weight:700;color:#6366f1;"><?= $cntPaid + $cntUnpaid ?></div>
        <div style="font-size:.8rem;color:var(--text-muted,#6b7280);">Rp <?= number_format((float)$total, 0, ',', '.') ?></div>
    </div>
    <!-- Progress collection rate -->
    <div class="card" style="border-radius:12px;padding:1.25rem;border-left:4px solid #f59e0b;">
        <div style="font-size:.8rem;color:var(--text-muted,#6b7280);margin-bottom:.4rem;">
            <i class="fa-solid fa-chart-pie" style="color:#f59e0b;margin-right:.4rem;"></i>Collection Rate
        </div>
        <div style="font-size:1.5rem;font-weight:700;color:#f59e0b;"><?= $pctPaid ?>%</div>
        <div style="background:#e5e7eb;border-radius:4px;height:6px;margin-top:.5rem;">
            <div style="width:<?= $pctPaid ?>%;height:6px;border-radius:4px;
                        background:<?= $pctPaid >= 80 ? '#10b981' : ($pctPaid >= 50 ? '#f59e0b' : '#ef4444') ?>;"></div>
        </div>
    </div>
</div>

<!-- Tabel -->
<div class="card" style="border-radius:12px;overflow:hidden;">
    <div style="padding:.9rem 1.25rem;border-bottom:1px solid var(--border,#e5e7eb);
                display:flex;justify-content:space-between;align-items:center;">
        <span style="font-weight:700;font-size:.9rem;">
            Rincian Tagihan
            <span style="padding:.15rem .55rem;border-radius:99px;background:#ede9fe;color:#6d28d9;
                         font-size:.75rem;font-weight:700;margin-left:.4rem;"><?= count($list) ?></span>
        </span>
        <span style="font-size:.8rem;color:var(--text-muted,#6b7280);">
            Periode: <strong><?= htmlspecialchars($filter['bulan']) ?: 'Semua' ?></strong>
        </span>
    </div>
    <div style="overflow-x:auto;">
        <table style="width:100%;border-collapse:collapse;font-size:.875rem;" id="tabelTagihan">
            <thead>
                <tr style="background:var(--surface-alt,#f9fafb);">
                    <th style="padding:.75rem 1rem;text-align:left;font-weight:600;color:var(--text-muted,#6b7280);">#</th>
                    <th style="padding:.75rem 1rem;text-align:left;font-weight:600;color:var(--text-muted,#6b7280);">Pelanggan</th>
                    <th style="padding:.75rem 1rem;text-align:left;font-weight:600;color:var(--text-muted,#6b7280);">Paket</th>
                    <th style="padding:.75rem 1rem;text-align:left;font-weight:600;color:var(--text-muted,#6b7280);">Periode</th>
                    <th style="padding:.75rem 1rem;text-align:left;font-weight:600;color:var(--text-muted,#6b7280);">Jatuh Tempo</th>
                    <th style="padding:.75rem 1rem;text-align:right;font-weight:600;color:var(--text-muted,#6b7280);">Total</th>
                    <th style="padding:.75rem 1rem;text-align:center;font-weight:600;color:var(--text-muted,#6b7280);">Status</th>
                    <th style="padding:.75rem 1rem;text-align:center;font-weight:600;color:var(--text-muted,#6b7280);">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($list)): ?>
                    <tr>
                        <td colspan="8" style="padding:3rem;text-align:center;color:var(--text-muted,#6b7280);">
                            <i class="fa-solid fa-inbox" style="font-size:2rem;display:block;margin-bottom:.75rem;opacity:.4;"></i>
                            Tidak ada data tagihan untuk periode ini.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($list as $i => $row):
                        $isPaid    = $row['status'] === 'paid';
                        $isOverdue = !$isPaid && strtotime($row['jatuh_tempo']) < time();
                    ?>
                    <tr class="tag-row" style="border-top:1px solid var(--border,#e5e7eb);">
                        <td style="padding:.75rem 1rem;color:var(--text-muted,#6b7280);"><?= $i + 1 ?></td>
                        <td style="padding:.75rem 1rem;">
                            <div style="font-weight:600;" class="tag-name"><?= htmlspecialchars($row['nama_lengkap']) ?></div>
                            <?php if (!empty($row['no_telp'])): ?>
                                <div style="font-size:.75rem;color:var(--text-muted,#9ca3af);"><?= htmlspecialchars($row['no_telp']) ?></div>
                            <?php endif; ?>
                        </td>
                        <td style="padding:.75rem 1rem;color:var(--text-muted,#6b7280);"><?= htmlspecialchars($row['nama_paket'] ?? '-') ?></td>
                        <td style="padding:.75rem 1rem;"><?= htmlspecialchars($row['periode_bulan'] ?? '-') ?></td>
                        <td style="padding:.75rem 1rem;">
                            <span style="color:<?= $isOverdue ? '#ef4444' : 'inherit' ?>;">
                                <?php if ($isOverdue): ?>
                                    <i class="fa-solid fa-triangle-exclamation" style="margin-right:.3rem;"></i>
                                <?php endif; ?>
                                <?= date('d M Y', strtotime($row['jatuh_tempo'])) ?>
                            </span>
                        </td>
                        <td style="padding:.75rem 1rem;text-align:right;font-weight:600;">
                            Rp <?= number_format((float)$row['total'], 0, ',', '.') ?>
                        </td>
                        <td style="padding:.75rem 1rem;text-align:center;">
                            <?php if ($isPaid): ?>
                                <span style="padding:.2rem .65rem;border-radius:99px;font-size:.75rem;font-weight:600;background:#dcfce7;color:#16a34a;">
                                    <i class="fa-solid fa-circle-check" style="margin-right:.2rem;"></i>Lunas
                                </span>
                            <?php else: ?>
                                <span style="padding:.2rem .65rem;border-radius:99px;font-size:.75rem;font-weight:600;
                                             background:<?= $isOverdue ? '#fee2e2' : '#fef3c7' ?>;
                                             color:<?= $isOverdue ? '#dc2626' : '#d97706' ?>;">
                                    <i class="fa-solid fa-<?= $isOverdue ? 'triangle-exclamation' : 'clock' ?>"
                                       style="margin-right:.2rem;"></i>
                                    <?= $isOverdue ? 'Jatuh Tempo' : 'Belum Lunas' ?>
                                </span>
                            <?php endif; ?>
                        </td>
                        <td style="padding:.75rem 1rem;text-align:center;">
                            <div style="display:inline-flex;gap:.35rem;">
                                <a href="<?= $appUrl ?>/tagihan/<?= $row['id'] ?>" title="Detail"
                                   style="padding:.35rem .6rem;border-radius:6px;border:1.5px solid #6366f1;
                                          color:#6366f1;text-decoration:none;font-size:.8rem;">
                                    <i class="fa-solid fa-eye"></i>
                                </a>
                                <?php if (!$isPaid): ?>
                                <a href="<?= $appUrl ?>/tagihan/bayar/<?= $row['id'] ?>" title="Bayar"
                                   style="padding:.35rem .6rem;border-radius:6px;border:1.5px solid #10b981;
                                          color:#10b981;text-decoration:none;font-size:.8rem;">
                                    <i class="fa-solid fa-money-bill-wave"></i>
                                </a>
                                <?php endif; ?>
                                <a href="<?= $appUrl ?>/tagihan/cetak/<?= $row['id'] ?>" title="Cetak"
                                   style="padding:.35rem .6rem;border-radius:6px;border:1.5px solid #6b7280;
                                          color:#6b7280;text-decoration:none;font-size:.8rem;">
                                    <i class="fa-solid fa-print"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <!-- Total Row -->
                    <tr style="border-top:2px solid var(--border,#e5e7eb);background:var(--surface-alt,#f9fafb);">
                        <td colspan="5" style="padding:.75rem 1rem;font-weight:700;text-align:right;">
                            Total (<?= count($list) ?> tagihan)
                        </td>
                        <td style="padding:.75rem 1rem;text-align:right;font-weight:700;font-size:1rem;color:#6366f1;">
                            Rp <?= number_format((float)$total, 0, ',', '.') ?>
                        </td>
                        <td colspan="2"></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</div>
<script>
function filterTagihan(q) {
    q = q.toLowerCase();
    document.querySelectorAll('#tabelTagihan .tag-row').forEach(row => {
        row.style.display = row.querySelector('.tag-name')?.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
}
</script>

<style>
@media print {
    .page-header button, .card form { display: none !important; }
    .card { box-shadow: none !important; border: 1px solid #e5e7eb !important; }
}
</style>
