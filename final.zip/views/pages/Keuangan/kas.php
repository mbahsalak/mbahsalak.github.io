<?php
$appUrl       = $_ENV['APP_URL'] ?? '';
$filterBulan  = $_GET['bulan']  ?? date('Y-m');
$filterTipe   = $_GET['tipe']   ?? '';
$filterMetode = $_GET['metode'] ?? '';
$masuk  = (float)($summary['masuk']  ?? 0);
$keluar = (float)($summary['keluar'] ?? 0);
$saldo  = (float)($summary['saldo']  ?? 0);
?>
<div class="max-w-7xl mx-auto space-y-5 p-4 sm:p-6">

    <!-- HEADER -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
            <h1 class="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <i class="fa-solid fa-cash-register text-emerald-500"></i>Kas &amp; Arus Kas
            </h1>
            <p class="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Pencatatan pemasukan dan pengeluaran</p>
        </div>
        <div class="flex items-center gap-2">
            <a href="<?= $appUrl ?>/kas/export?<?= http_build_query(['bulan'=>$filterBulan,'tipe'=>$filterTipe,'metode'=>$filterMetode]) ?>"
               class="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-lg no-underline transition-colors shadow-sm shadow-emerald-500/30">
                <i class="fa-solid fa-file-excel"></i> Export XLS
            </a>
            <a href="<?= $appUrl ?>/kas/tambah"
               class="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-lg no-underline transition-colors shadow-sm shadow-indigo-500/30">
                <i class="fa-solid fa-plus"></i> Tambah Transaksi
            </a>
        </div>
    </div>

    <!-- FLASH MESSAGE -->
    <?php if (!empty($flash)): ?>
    <div class="p-3 rounded-lg text-sm font-medium
        <?= $flash['type']==='success' ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800' : '' ?>
        <?= $flash['type']==='danger'  ? 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 border border-red-200 dark:border-red-800' : '' ?>">
        <i class="fa-solid fa-<?= $flash['type']==='success'?'circle-check':'circle-exclamation' ?> mr-1"></i>
        <?= htmlspecialchars($flash['message']) ?>
    </div>
    <?php endif; ?>

    <!-- RINGKASAN -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center shrink-0">
                    <i class="fa-solid fa-arrow-down text-emerald-600 dark:text-emerald-400"></i>
                </div>
                <div class="min-w-0">
                    <span class="text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Pemasukan</span>
                    <p class="text-lg font-bold text-emerald-600 dark:text-emerald-400 mt-0 mb-0 truncate tabular-nums">Rp <?= number_format($masuk,0,',','.') ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-red-100 dark:bg-red-900/30 flex items-center justify-center shrink-0">
                    <i class="fa-solid fa-arrow-up text-red-600 dark:text-red-400"></i>
                </div>
                <div class="min-w-0">
                    <span class="text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Pengeluaran</span>
                    <p class="text-lg font-bold text-red-600 dark:text-red-400 mt-0 mb-0 truncate tabular-nums">Rp <?= number_format($keluar,0,',','.') ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg <?= $saldo>=0?'bg-blue-100 dark:bg-blue-900/30':'bg-red-100 dark:bg-red-900/30' ?> flex items-center justify-center shrink-0">
                    <i class="fa-solid fa-wallet <?= $saldo>=0?'text-blue-600 dark:text-blue-400':'text-red-600 dark:text-red-400' ?>"></i>
                </div>
                <div class="min-w-0">
                    <span class="text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Saldo</span>
                    <p class="text-lg font-bold <?= $saldo>=0?'text-blue-600 dark:text-blue-400':'text-red-600 dark:text-red-400' ?> mt-0 mb-0 truncate tabular-nums">Rp <?= number_format($saldo,0,',','.') ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- FILTER -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
        <form method="GET" action="<?= $appUrl ?>/kas" class="flex flex-col sm:flex-row flex-wrap gap-3 items-end">
            <div class="flex-1 min-w-[140px]">
                <label class="block text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-1">
                    <i class="fa-solid fa-calendar mr-1"></i>Periode
                </label>
                <input type="month" name="bulan" value="<?= htmlspecialchars($filterBulan) ?>"
                       class="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg text-sm bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition">
            </div>
            <div class="flex-1 min-w-[130px]">
                <label class="block text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-1">
                    <i class="fa-solid fa-filter mr-1"></i>Tipe
                </label>
                <select name="tipe" class="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg text-sm bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition">
                    <option value="">Semua</option>
                    <option value="masuk"  <?= $filterTipe==='masuk'?'selected':'' ?>>Pemasukan</option>
                    <option value="keluar" <?= $filterTipe==='keluar'?'selected':'' ?>>Pengeluaran</option>
                </select>
            </div>
            <div class="flex-1 min-w-[140px]">
                <label class="block text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-1">
                    <i class="fa-solid fa-credit-card mr-1"></i>Metode
                </label>
                <select name="metode" class="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg text-sm bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition">
                    <option value="">Semua</option>
                    <?php foreach(['Tunai','Transfer Bank','E-Wallet','QRIS','Debit','Kredit'] as $m): ?>
                    <option value="<?= $m ?>" <?= $filterMetode===$m?'selected':'' ?>><?= $m ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="flex gap-2">
                <button type="submit" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-lg transition-colors shadow-sm shadow-indigo-500/30 cursor-pointer">
                    <i class="fa-solid fa-search"></i> Filter
                </button>
                <a href="<?= $appUrl ?>/kas" class="px-4 py-2 border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700 text-sm font-semibold rounded-lg no-underline transition-colors" title="Reset">
                    <i class="fa-solid fa-rotate-left"></i>
                </a>
            </div>
        </form>
    </div>

    <!-- TABEL -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div class="px-5 py-3.5 border-b border-gray-100 dark:border-gray-700">
            <span class="text-sm font-bold text-gray-800 dark:text-gray-200">
                <i class="fa-solid fa-list text-gray-400 mr-1.5"></i>Daftar Transaksi
                <span class="text-xs font-normal text-gray-400 dark:text-gray-500 ml-2">(<?= number_format($total ?? 0) ?> data)</span>
            </span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-600">
                        <th class="px-4 py-3 text-left text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">No</th>
                        <th class="px-4 py-3 text-left text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Tanggal</th>
                        <th class="px-4 py-3 text-left text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Tipe</th>
                        <th class="px-4 py-3 text-left text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Keterangan</th>
                        <th class="px-4 py-3 text-left text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Metode</th>
                        <th class="px-4 py-3 text-right text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Jumlah</th>
                        <th class="px-4 py-3 text-center text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                    <?php if (empty($list)): ?>
                    <tr><td colspan="7" class="px-4 py-10 text-center text-gray-400 dark:text-gray-500">
                        <i class="fa-solid fa-inbox text-2xl mb-2 block"></i>Tidak ada data transaksi
                    </td></tr>
                    <?php else: ?>
                    <?php foreach ($list as $i => $row):
                        $tipe    = $row['tipe'] ?? '';
                        $isMasuk = $tipe === 'masuk';
                        $metode  = $row['metode_pembayaran'] ?? '';
                        $tgl     = $row['created_at'] ?? 'now';
                        $mIcons  = ['Tunai'=>'fa-money-bill-wave','Transfer Bank'=>'fa-building-columns','E-Wallet'=>'fa-mobile-screen','QRIS'=>'fa-qrcode','Debit'=>'fa-credit-card','Kredit'=>'fa-credit-card'];
                        $mIcon   = $mIcons[$metode] ?? 'fa-money-check';
                    ?>
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                        <td class="px-4 py-3 text-gray-500 dark:text-gray-400 font-mono text-xs"><?= $i + 1 ?></td>
                        <td class="px-4 py-3 text-gray-700 dark:text-gray-300 whitespace-nowrap">
                            <?= date('d M Y', strtotime($tgl)) ?>
                            <span class="block text-[10px] text-gray-400 dark:text-gray-500"><?= date('H:i', strtotime($tgl)) ?></span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider
                                <?= $isMasuk
                                    ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800'
                                    : 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 border border-red-200 dark:border-red-800' ?>">
                                <i class="fa-solid fa-arrow-<?= $isMasuk ? 'down' : 'up' ?> text-[8px]"></i>
                                <?= $isMasuk ? 'Masuk' : 'Keluar' ?>
                            </span>
                        </td>
                        <td class="px-4 py-3 text-gray-800 dark:text-gray-200 max-w-[250px]">
                            <span class="block truncate" title="<?= htmlspecialchars($row['keterangan'] ?? '') ?>"><?= htmlspecialchars($row['keterangan'] ?? '—') ?></span>
                        </td>
                        <td class="px-4 py-3">
                            <?php if ($metode): ?>
                            <span class="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-semibold bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-gray-600">
                                <i class="fa-solid <?= $mIcon ?> text-[9px]"></i><?= htmlspecialchars($metode) ?>
                            </span>
                            <?php else: ?>
                            <span class="text-[10px] text-gray-400 dark:text-gray-500 italic">—</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3 text-right whitespace-nowrap">
                            <span class="font-bold tabular-nums <?= $isMasuk ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400' ?>">
                                <?= $isMasuk ? '+' : '-' ?> Rp <?= number_format((float)($row['jumlah'] ?? 0), 0, ',', '.') ?>
                            </span>
                        </td>
                        <td class="px-4 py-3 text-center whitespace-nowrap">
                            <div class="flex items-center justify-center gap-1.5">
                                <a href="<?= $appUrl ?>/kas/edit/<?= $row['id'] ?>"
                                   class="inline-flex items-center justify-center w-7 h-7 rounded-md border border-amber-200 dark:border-amber-700 text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-900/20 no-underline transition-colors" title="Edit">
                                    <i class="fa-solid fa-pen text-[10px]"></i>
                                </a>
                                <form method="POST" action="<?= $appUrl ?>/kas/hapus/<?= $row['id'] ?>" class="inline" onsubmit="return confirm('Hapus transaksi ini?')">
                                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
                                    <button type="submit" class="inline-flex items-center justify-center w-7 h-7 rounded-md border border-red-200 dark:border-red-700 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors cursor-pointer" title="Hapus">
                                        <i class="fa-solid fa-trash text-[10px]"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
