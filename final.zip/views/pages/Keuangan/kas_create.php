<?php
$appUrl = $_ENV['APP_URL'] ?? '';
$old    = $old ?? [];
$errors = $errors ?? [];
?>
<div class="max-w-2xl mx-auto space-y-4 p-4 sm:p-6">

    <a href="<?= $appUrl ?>/kas" class="inline-flex items-center gap-1.5 text-sm text-gray-400 hover:text-indigo-500 dark:hover:text-indigo-400 no-underline transition-colors w-fit">
        <i class="fa-solid fa-arrow-left"></i> Kembali
    </a>

    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div class="h-1 bg-indigo-600"></div>
        <div class="px-5 py-4 border-b border-gray-100 dark:border-gray-700">
            <h2 class="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <i class="fa-solid fa-plus-circle text-indigo-500"></i> Tambah Transaksi
            </h2>
        </div>

        <?php if (!empty($errors)): ?>
        <div class="mx-5 mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
            <?php foreach ($errors as $err): ?>
            <p class="text-sm text-red-600 dark:text-red-400 my-0.5"><i class="fa-solid fa-circle-exclamation mr-1"></i><?= htmlspecialchars($err) ?></p>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <form method="POST" action="<?= $appUrl ?>/kas/simpan" class="p-5 space-y-5">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">

            <!-- Tipe -->
            <div>
                <label class="block text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-2">Tipe Transaksi <span class="text-red-500">*</span></label>
                <div class="grid grid-cols-2 gap-3">
                    <label class="flex items-center gap-2 px-4 py-3 rounded-lg border-2 cursor-pointer transition-all
                        <?= ($old['tipe']??'masuk')==='masuk' ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20' : 'border-gray-200 dark:border-gray-600 hover:border-emerald-300' ?>">
                        <input type="radio" name="tipe" value="masuk" <?= ($old['tipe']??'masuk')==='masuk'?'checked':'' ?> class="accent-emerald-600">
                        <span class="text-sm font-semibold text-emerald-700 dark:text-emerald-400"><i class="fa-solid fa-arrow-down mr-1"></i>Pemasukan</span>
                    </label>
                    <label class="flex items-center gap-2 px-4 py-3 rounded-lg border-2 cursor-pointer transition-all
                        <?= ($old['tipe']??'')==='keluar' ? 'border-red-500 bg-red-50 dark:bg-red-900/20' : 'border-gray-200 dark:border-gray-600 hover:border-red-300' ?>">
                        <input type="radio" name="tipe" value="keluar" <?= ($old['tipe']??'')==='keluar'?'checked':'' ?> class="accent-red-600">
                        <span class="text-sm font-semibold text-red-700 dark:text-red-400"><i class="fa-solid fa-arrow-up mr-1"></i>Pengeluaran</span>
                    </label>
                </div>
            </div>

            <!-- Jumlah -->
            <div>
                <label class="block text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-1.5"><i class="fa-solid fa-money-bill mr-1"></i>Jumlah (Rp) <span class="text-red-500">*</span></label>
                <input type="text" name="jumlah" id="inputJumlah" value="<?= htmlspecialchars($old['jumlah']??'') ?>" placeholder="Contoh: 150000" required
                       class="w-full px-3 py-2.5 border border-gray-200 dark:border-gray-600 rounded-lg text-sm bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition">
                <span class="text-xs text-gray-400 dark:text-gray-500 mt-1 block" id="jumlahPreview"></span>
            </div>

            <!-- Metode Pembayaran -->
            <div>
                <label class="block text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-1.5"><i class="fa-solid fa-credit-card mr-1"></i>Metode Pembayaran</label>
                <select name="metode_pembayaran"
                        class="w-full px-3 py-2.5 border border-gray-200 dark:border-gray-600 rounded-lg text-sm bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition">
                    <option value="">-- Pilih Metode --</option>
                    <?php foreach(['Tunai','Transfer Bank','E-Wallet','QRIS','Debit','Kredit'] as $m): ?>
                    <option value="<?= $m ?>" <?= ($old['metode_pembayaran']??'')===$m?'selected':'' ?>><?= $m ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Keterangan -->
            <div>
                <label class="block text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-1.5"><i class="fa-solid fa-note-sticky mr-1"></i>Keterangan</label>
                <textarea name="keterangan" rows="3" placeholder="Deskripsi transaksi..."
                          class="w-full px-3 py-2.5 border border-gray-200 dark:border-gray-600 rounded-lg text-sm bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 placeholder-gray-400 dark:placeholder-gray-500 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition resize-y"><?= htmlspecialchars($old['keterangan']??'') ?></textarea>
            </div>

            <!-- Buttons -->
            <div class="flex gap-3 justify-end pt-2">
                <a href="<?= $appUrl ?>/kas" class="px-5 py-2.5 border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700 text-sm font-semibold rounded-lg no-underline transition-colors inline-flex items-center gap-1.5">
                    <i class="fa-solid fa-xmark"></i> Batal
                </a>
                <button type="submit" class="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-lg transition-colors shadow-sm shadow-indigo-500/30 inline-flex items-center gap-1.5 cursor-pointer">
                    <i class="fa-solid fa-floppy-disk"></i> Simpan
                </button>
            </div>
        </form>
    </div>
</div>

<script>
(function(){
    var input=document.getElementById('inputJumlah'),preview=document.getElementById('jumlahPreview');
    function fmt(n){return'Rp '+n.toLocaleString('id-ID')}
    function cln(s){return s.replace(/[^\d]/g,'')}
    input.addEventListener('input',function(){var r=cln(this.value);if(r){this.value=Number(r).toLocaleString('id-ID');preview.textContent=fmt(Number(r))}else{this.value='';preview.textContent=''}});
    input.closest('form').addEventListener('submit',function(){input.value=cln(input.value)});
    if(input.value){var r=cln(input.value);if(r){input.value=Number(r).toLocaleString('id-ID');preview.textContent=fmt(Number(r))}}
})();
</script>
