<?php
$appUrl      = $_ENV['APP_URL'] ?? '';
$filterTahun = $filterTahun ?? (int)date('Y');
$tahunList   = $tahunList ?? [(int)date('Y')];
$data        = $laporan['data']  ?? [];
$total       = $laporan['total'] ?? ['masuk' => 0, 'keluar' => 0, 'saldo' => 0, 'total_transaksi' => 0];

// Pastikan data array 12 bulan
if (empty($data)) {
    $namaBulan = [
        1=>'Januari',2=>'Februari',3=>'Maret',4=>'April',
        5=>'Mei',6=>'Juni',7=>'Juli',8=>'Agustus',
        9=>'September',10=>'Oktober',11=>'November',12=>'Desember'
    ];
    foreach ($namaBulan as $b => $nama) {
        $data[$b] = [
            'bulan' => $b, 'nama_bulan' => $nama,
            'masuk' => 0, 'keluar' => 0, 'saldo' => 0, 'total_transaksi' => 0,
        ];
    }
}

// Siapkan data untuk chart
$labels     = [];
$masukArr   = [];
$keluarArr  = [];
$trxArr     = [];
$runningSaldo = [];
$akumulasi = 0;

foreach ($data as $d) {
    $labels[]       = substr($d['nama_bulan'], 0, 3);
    $masukArr[]     = (float)$d['masuk'];
    $keluarArr[]    = (float)$d['keluar'];
    $trxArr[]       = (int)$d['total_transaksi'];
    $akumulasi     += ((float)$d['masuk'] - (float)$d['keluar']);
    $runningSaldo[] = $akumulasi;
}

// Hitung bulan terbaik & terburuk
$bestMonth  = '-';
$worstMonth = '-';
$maxMasuk  = 0;
$maxKeluar = 0;
foreach ($data as $d) {
    if ((float)$d['masuk'] > $maxMasuk) {
        $maxMasuk  = (float)$d['masuk'];
        $bestMonth = substr($d['nama_bulan'], 0, 3);
    }
    if ((float)$d['keluar'] > $maxKeluar) {
        $maxKeluar  = (float)$d['keluar'];
        $worstMonth = substr($d['nama_bulan'], 0, 3);
    }
}
if ($maxMasuk == 0)  $bestMonth  = '-';
if ($maxKeluar == 0) $worstMonth = '-';

// Persentase proporsi
$totalSemua = (float)$total['masuk'] + (float)$total['keluar'];
$pctMasuk   = $totalSemua > 0 ? round(((float)$total['masuk'] / $totalSemua) * 100, 1) : 0;
$pctKeluar  = $totalSemua > 0 ? round(((float)$total['keluar'] / $totalSemua) * 100, 1) : 0;

// Rata-rata per bulan
$avgMasuk  = count($data) > 0 ? round((float)$total['masuk'] / count($data)) : 0;
$avgKeluar = count($data) > 0 ? round((float)$total['keluar'] / count($data)) : 0;
?>

<div class="max-w-7xl mx-auto space-y-5 p-4 sm:p-6">

    <!-- HEADER -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
            <h1 class="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <i class="fa-solid fa-chart-pie text-indigo-500"></i>Laporan Kas — Diagram
            </h1>
            <p class="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Visualisasi arus kas tahun <?= $filterTahun ?></p>
        </div>
        <div class="flex items-center gap-2">
            <a href="<?= $appUrl ?>/laporan/kas/export?tahun=<?= $filterTahun ?>"
               class="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-lg no-underline transition-colors shadow-sm shadow-emerald-500/30">
                <i class="fa-solid fa-file-excel"></i> Export XLS
            </a>
        </div>
    </div>

    <!-- FLASH MESSAGE -->
    <?php if (!empty($flash)): ?>
    <div class="p-3 rounded-lg text-sm font-medium
        <?= ($flash['type'] ?? '') === 'success' ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800' : '' ?>
        <?= ($flash['type'] ?? '') === 'danger'  ? 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 border border-red-200 dark:border-red-800' : '' ?>">
        <i class="fa-solid fa-<?= ($flash['type'] ?? '') === 'success' ? 'circle-check' : 'circle-exclamation' ?> mr-1"></i>
        <?= htmlspecialchars($flash['message'] ?? '') ?>
    </div>
    <?php endif; ?>

    <!-- FILTER TAHUN -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
        <form method="GET" action="<?= $appUrl ?>/laporan/kas" class="flex flex-wrap gap-3 items-end">
            <div class="flex-1 min-w-[140px]">
                <label class="block text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-1">
                    <i class="fa-solid fa-calendar mr-1"></i>Pilih Tahun
                </label>
                <select name="tahun"
                        class="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg text-sm bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition">
                    <?php foreach ($tahunList as $t): ?>
                    <option value="<?= $t ?>" <?= $filterTahun === (int)$t ? 'selected' : '' ?>><?= $t ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-lg transition-colors shadow-sm shadow-indigo-500/30 cursor-pointer">
                <i class="fa-solid fa-search"></i> Tampilkan
            </button>
        </form>
    </div>

    <!-- KPI CARDS — 6 kartu -->
    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <!-- 1. Pemasukan -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
            <div class="flex items-center gap-2 mb-2">
                <div class="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                    <i class="fa-solid fa-arrow-down text-emerald-600 dark:text-emerald-400 text-xs"></i>
                </div>
                <span class="text-[9px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Pemasukan</span>
            </div>
            <p class="text-base font-bold text-emerald-600 dark:text-emerald-400 mt-0 mb-0 tabular-nums truncate">
                Rp <?= number_format((float)$total['masuk'], 0, ',', '.') ?>
            </p>
            <p class="text-[10px] text-gray-400 dark:text-gray-500 mt-1 mb-0">
                Rata²: Rp <?= number_format($avgMasuk, 0, ',', '.') ?>/bln
            </p>
        </div>

        <!-- 2. Pengeluaran -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
            <div class="flex items-center gap-2 mb-2">
                <div class="w-8 h-8 rounded-lg bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                    <i class="fa-solid fa-arrow-up text-red-600 dark:text-red-400 text-xs"></i>
                </div>
                <span class="text-[9px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Pengeluaran</span>
            </div>
            <p class="text-base font-bold text-red-600 dark:text-red-400 mt-0 mb-0 tabular-nums truncate">
                Rp <?= number_format((float)$total['keluar'], 0, ',', '.') ?>
            </p>
            <p class="text-[10px] text-gray-400 dark:text-gray-500 mt-1 mb-0">
                Rata²: Rp <?= number_format($avgKeluar, 0, ',', '.') ?>/bln
            </p>
        </div>

        <!-- 3. Saldo -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
            <div class="flex items-center gap-2 mb-2">
                <div class="w-8 h-8 rounded-lg <?= (float)$total['saldo'] >= 0 ? 'bg-blue-100 dark:bg-blue-900/30' : 'bg-red-100 dark:bg-red-900/30' ?> flex items-center justify-center">
                    <i class="fa-solid fa-wallet <?= (float)$total['saldo'] >= 0 ? 'text-blue-600 dark:text-blue-400' : 'text-red-600 dark:text-red-400' ?> text-xs"></i>
                </div>
                <span class="text-[9px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Saldo</span>
            </div>
            <p class="text-base font-bold <?= (float)$total['saldo'] >= 0 ? 'text-blue-600 dark:text-blue-400' : 'text-red-600 dark:text-red-400' ?> mt-0 mb-0 tabular-nums truncate">
                Rp <?= number_format((float)$total['saldo'], 0, ',', '.') ?>
            </p>
            <p class="text-[10px] text-gray-400 dark:text-gray-500 mt-1 mb-0">
                <?= (float)$total['saldo'] >= 0 ? 'Surplus' : 'Defisit' ?>
            </p>
        </div>

        <!-- 4. Total Transaksi -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
            <div class="flex items-center gap-2 mb-2">
                <div class="w-8 h-8 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                    <i class="fa-solid fa-receipt text-purple-600 dark:text-purple-400 text-xs"></i>
                </div>
                <span class="text-[9px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Transaksi</span>
            </div>
            <p class="text-base font-bold text-gray-800 dark:text-gray-100 mt-0 mb-0 tabular-nums">
                <?= number_format((int)$total['total_transaksi']) ?>
            </p>
            <p class="text-[10px] text-gray-400 dark:text-gray-500 mt-1 mb-0">
                <?= count($data) > 0 ? round((int)$total['total_transaksi'] / count(array_filter($trxArr, fn($t) => $t > 0)) ?: 1) : 0 ?> trx/bln aktif
            </p>
        </div>

        <!-- 5. Bulan Pemasukan Tertinggi -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
            <div class="flex items-center gap-2 mb-2">
                <div class="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                    <i class="fa-solid fa-trophy text-emerald-600 dark:text-emerald-400 text-xs"></i>
                </div>
                <span class="text-[9px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Bulan Terbaik</span>
            </div>
            <p class="text-base font-bold text-emerald-600 dark:text-emerald-400 mt-0 mb-0">
                <?= $bestMonth ?>
            </p>
            <p class="text-[10px] text-gray-400 dark:text-gray-500 mt-1 mb-0">
                Rp <?= number_format($maxMasuk, 0, ',', '.') ?>
            </p>
        </div>

        <!-- 6. Bulan Pengeluaran Tertinggi -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
            <div class="flex items-center gap-2 mb-2">
                <div class="w-8 h-8 rounded-lg bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                    <i class="fa-solid fa-triangle-exclamation text-red-600 dark:text-red-400 text-xs"></i>
                </div>
                <span class="text-[9px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Bulan Terboros</span>
            </div>
            <p class="text-base font-bold text-red-600 dark:text-red-400 mt-0 mb-0">
                <?= $worstMonth ?>
            </p>
            <p class="text-[10px] text-gray-400 dark:text-gray-500 mt-1 mb-0">
                Rp <?= number_format($maxKeluar, 0, ',', '.') ?>
            </p>
        </div>
    </div>

    <!-- ROW 1: BAR CHART + DOUGHNUT -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-5">

        <!-- BAR CHART — 2/3 width -->
        <div class="lg:col-span-2 bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5">
            <h3 class="text-sm font-bold text-gray-800 dark:text-gray-200 mb-1 flex items-center gap-2">
                <i class="fa-solid fa-chart-column text-indigo-500"></i>Pemasukan vs Pengeluaran
            </h3>
            <p class="text-xs text-gray-400 dark:text-gray-500 mb-4">Perbandingan arus kas setiap bulan</p>
            <div style="position:relative;height:320px;">
                <canvas id="chartBar"></canvas>
            </div>
            <div id="chartBarError" class="hidden text-center py-10 text-gray-400 dark:text-gray-500">
                <i class="fa-solid fa-chart-column text-3xl mb-2 block"></i>
                <p class="text-sm">Grafik tidak dapat dimuat</p>
            </div>
        </div>

        <!-- DOUGHNUT — 1/3 width -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5">
            <h3 class="text-sm font-bold text-gray-800 dark:text-gray-200 mb-1 flex items-center gap-2">
                <i class="fa-solid fa-chart-pie text-purple-500"></i>Proporsi Tahunan
            </h3>
            <p class="text-xs text-gray-400 dark:text-gray-500 mb-4">Rasio pemasukan terhadap pengeluaran</p>
            <div style="position:relative;height:220px;">
                <canvas id="chartDoughnut"></canvas>
            </div>
            <div class="mt-4 space-y-2">
                <div class="flex items-center justify-between text-sm">
                    <span class="flex items-center gap-2">
                        <span class="w-3 h-3 rounded-full bg-emerald-500 inline-block"></span>
                        <span class="text-gray-600 dark:text-gray-400">Masuk</span>
                    </span>
                    <div class="text-right">
                        <span class="font-bold text-emerald-600 dark:text-emerald-400 tabular-nums"><?= $pctMasuk ?>%</span>
                        <span class="text-[10px] text-gray-400 dark:text-gray-500 block">Rp <?= number_format((float)$total['masuk'], 0, ',', '.') ?></span>
                    </div>
                </div>
                <div class="flex items-center justify-between text-sm">
                    <span class="flex items-center gap-2">
                        <span class="w-3 h-3 rounded-full bg-red-500 inline-block"></span>
                        <span class="text-gray-600 dark:text-gray-400">Keluar</span>
                    </span>
                    <div class="text-right">
                        <span class="font-bold text-red-600 dark:text-red-400 tabular-nums"><?= $pctKeluar ?>%</span>
                        <span class="text-[10px] text-gray-400 dark:text-gray-500 block">Rp <?= number_format((float)$total['keluar'], 0, ',', '.') ?></span>
                    </div>
                </div>
                <!-- Progress bar visual -->
                <div class="mt-2 h-3 rounded-full overflow-hidden flex bg-gray-200 dark:bg-gray-700">
                    <div class="bg-emerald-500 h-full transition-all" style="width:<?= $pctMasuk ?>%"></div>
                    <div class="bg-red-500 h-full transition-all" style="width:<?= $pctKeluar ?>%"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- ROW 2: LINE CHART (SALDO BERJALAN) -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5">
        <h3 class="text-sm font-bold text-gray-800 dark:text-gray-200 mb-1 flex items-center gap-2">
            <i class="fa-solid fa-chart-line text-blue-500"></i>Tren Saldo Berjalan
        </h3>
        <p class="text-xs text-gray-400 dark:text-gray-500 mb-4">Akumulasi saldo kas dari bulan ke bulan</p>
        <div style="position:relative;height:300px;">
            <canvas id="chartLine"></canvas>
        </div>
    </div>

    <!-- ROW 3: NET BAR + TRANSAKSI -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">

        <!-- NET BAR -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5">
            <h3 class="text-sm font-bold text-gray-800 dark:text-gray-200 mb-1 flex items-center gap-2">
                <i class="fa-solid fa-arrow-right-arrow-left text-amber-500"></i>Net Arus Kas per Bulan
            </h3>
            <p class="text-xs text-gray-400 dark:text-gray-500 mb-4">Hijau = surplus, Merah = defisit</p>
            <div style="position:relative;height:280px;">
                <canvas id="chartNet"></canvas>
            </div>
        </div>

        <!-- JUMLAH TRANSAKSI -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5">
            <h3 class="text-sm font-bold text-gray-800 dark:text-gray-200 mb-1 flex items-center gap-2">
                <i class="fa-solid fa-signal text-teal-500"></i>Jumlah Transaksi per Bulan
            </h3>
            <p class="text-xs text-gray-400 dark:text-gray-500 mb-4">Volume aktivitas kas setiap bulan</p>
            <div style="position:relative;height:280px;">
                <canvas id="chartTrx"></canvas>
            </div>
        </div>
    </div>

    <!-- TABEL DETAIL -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div class="px-5 py-3.5 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
            <span class="text-sm font-bold text-gray-800 dark:text-gray-200">
                <i class="fa-solid fa-table text-gray-400 mr-1.5"></i>Detail Per Bulan
            </span>
            <span class="text-xs text-gray-400 dark:text-gray-500"><?= count($data) ?> bulan</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-600">
                        <th class="px-4 py-3 text-left text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">#</th>
                        <th class="px-4 py-3 text-left text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Bulan</th>
                        <th class="px-4 py-3 text-right text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Pemasukan</th>
                        <th class="px-4 py-3 text-right text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Pengeluaran</th>
                        <th class="px-4 py-3 text-right text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Net</th>
                        <th class="px-4 py-3 text-right text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Saldo</th>
                        <th class="px-4 py-3 text-center text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Trx</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                    <?php
                    $runSaldo = 0;
                    $no = 0;
                    foreach ($data as $d):
                        $no++;
                        $net = (float)$d['masuk'] - (float)$d['keluar'];
                        $runSaldo += $net;
                    ?>
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                        <td class="px-4 py-3 text-gray-400 dark:text-gray-500 text-xs"><?= $no ?></td>
                        <td class="px-4 py-3 font-semibold text-gray-800 dark:text-gray-200"><?= htmlspecialchars($d['nama_bulan']) ?></td>
                        <td class="px-4 py-3 text-right font-bold tabular-nums text-emerald-600 dark:text-emerald-400">
                            Rp <?= number_format((float)$d['masuk'], 0, ',', '.') ?>
                        </td>
                        <td class="px-4 py-3 text-right font-bold tabular-nums text-red-600 dark:text-red-400">
                            Rp <?= number_format((float)$d['keluar'], 0, ',', '.') ?>
                        </td>
                        <td class="px-4 py-3 text-right font-bold tabular-nums <?= $net >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400' ?>">
                            <?= $net >= 0 ? '+' : '-' ?>Rp <?= number_format(abs($net), 0, ',', '.') ?>
                        </td>
                        <td class="px-4 py-3 text-right font-bold tabular-nums <?= $runSaldo >= 0 ? 'text-blue-600 dark:text-blue-400' : 'text-red-600 dark:text-red-400' ?>">
                            Rp <?= number_format($runSaldo, 0, ',', '.') ?>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <span class="inline-flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold
                                <?= (int)$d['total_transaksi'] > 0
                                    ? 'bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400'
                                    : 'bg-gray-100 dark:bg-gray-700 text-gray-400 dark:text-gray-500' ?>">
                                <?= (int)$d['total_transaksi'] ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr class="bg-gray-50 dark:bg-gray-700/50 border-t-2 border-gray-200 dark:border-gray-600 font-bold">
                        <td class="px-4 py-3" colspan="2">
                            <span class="text-gray-800 dark:text-gray-200">TOTAL <?= $filterTahun ?></span>
                        </td>
                        <td class="px-4 py-3 text-right tabular-nums text-emerald-600 dark:text-emerald-400">
                            Rp <?= number_format((float)$total['masuk'], 0, ',', '.') ?>
                        </td>
                        <td class="px-4 py-3 text-right tabular-nums text-red-600 dark:text-red-400">
                            Rp <?= number_format((float)$total['keluar'], 0, ',', '.') ?>
                        </td>
                        <td class="px-4 py-3 text-right tabular-nums <?= (float)$total['saldo'] >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400' ?>">
                            <?= (float)$total['saldo'] >= 0 ? '+' : '-' ?>Rp <?= number_format(abs((float)$total['saldo']), 0, ',', '.') ?>
                        </td>
                        <td class="px-4 py-3 text-right tabular-nums <?= (float)$total['saldo'] >= 0 ? 'text-blue-600 dark:text-blue-400' : 'text-red-600 dark:text-red-400' ?>">
                            Rp <?= number_format((float)$total['saldo'], 0, ',', '.') ?>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <span class="inline-flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400">
                                <?= (int)$total['total_transaksi'] ?>
                            </span>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

</div>

<!-- Chart.js — load dengan fallback -->
<script>
(function(){
    // ========== DATA dari PHP ==========
    var chartData = {
        labels:     <?= json_encode($labels) ?>,
        masuk:      <?= json_encode($masukArr) ?>,
        keluar:     <?= json_encode($keluarArr) ?>,
        trx:        <?= json_encode($trxArr) ?>,
        runSaldo:   <?= json_encode($runningSaldo) ?>,
        totalMasuk: <?= json_encode((float)$total['masuk']) ?>,
        totalKeluar:<?= json_encode((float)$total['keluar']) ?>
    };

    // Net per bulan
    chartData.net = chartData.masuk.map(function(v, i) { return v - chartData.keluar[i]; });

    // ========== LOAD Chart.js ==========
    function loadChartJS(callback) {
        // Cek apakah Chart.js sudah ada
        if (typeof Chart !== 'undefined') {
            callback();
            return;
        }

        var script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js';
        script.onload = function() { callback(); };
        script.onerror = function() {
            // Fallback CDN
            var fallback = document.createElement('script');
            fallback.src = 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.7/chart.umd.min.js';
            fallback.onload = function() { callback(); };
            fallback.onerror = function() {
                console.error('Gagal memuat Chart.js dari semua CDN');
                showChartError();
            };
            document.head.appendChild(fallback);
        };
        document.head.appendChild(script);
    }

    function showChartError() {
        var canvases = document.querySelectorAll('canvas[id^="chart"]');
        canvases.forEach(function(c) {
            c.style.display = 'none';
            var div = document.createElement('div');
            div.className = 'text-center py-10 text-gray-400 dark:text-gray-500';
            div.innerHTML = '<i class="fa-solid fa-chart-column text-3xl mb-2 block"></i><p class="text-sm">Grafik tidak dapat dimuat.<br>Pastikan koneksi internet aktif.</p>';
            c.parentNode.appendChild(div);
        });
    }

    // ========== INIT CHARTS ==========
    loadChartJS(function() {
        if (typeof Chart === 'undefined') {
            showChartError();
            return;
        }

        // Helpers
        function rpFormat(value) {
            var abs = Math.abs(value);
            if (abs >= 1000000) return 'Rp ' + (value / 1000000).toFixed(1) + 'jt';
            if (abs >= 1000)    return 'Rp ' + (value / 1000).toFixed(0) + 'rb';
            return 'Rp ' + value;
        }

        var tooltipRp = {
            callbacks: {
                label: function(ctx) {
                    return ctx.dataset.label + ': Rp ' + Number(ctx.parsed.y).toLocaleString('id-ID');
                }
            }
        };

        var gridColor = 'rgba(156, 163, 175, 0.12)';
        var tickColor = '#9CA3AF';

        // ===== 1. BAR CHART =====
        try {
            new Chart(document.getElementById('chartBar'), {
                type: 'bar',
                data: {
                    labels: chartData.labels,
                    datasets: [
                        {
                            label: 'Pemasukan',
                            data: chartData.masuk,
                            backgroundColor: 'rgba(16, 185, 129, 0.75)',
                            borderColor: 'rgba(16, 185, 129, 1)',
                            borderWidth: 1,
                            borderRadius: 6,
                            borderSkipped: false
                        },
                        {
                            label: 'Pengeluaran',
                            data: chartData.keluar,
                            backgroundColor: 'rgba(239, 68, 68, 0.75)',
                            borderColor: 'rgba(239, 68, 68, 1)',
                            borderWidth: 1,
                            borderRadius: 6,
                            borderSkipped: false
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: { intersect: false, mode: 'index' },
                    plugins: {
                        legend: { position: 'top', labels: { usePointStyle: true, padding: 16 } },
                        tooltip: tooltipRp
                    },
                    scales: {
                        x: { grid: { display: false }, ticks: { color: tickColor } },
                        y: {
                            beginAtZero: true,
                            grid: { color: gridColor },
                            ticks: { color: tickColor, callback: function(v) { return rpFormat(v); } }
                        }
                    }
                }
            });
        } catch(e) { console.error('chartBar error:', e); }

        // ===== 2. DOUGHNUT CHART =====
        try {
            var doughnutCtx = document.getElementById('chartDoughnut');
            new Chart(doughnutCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Pemasukan', 'Pengeluaran'],
                    datasets: [{
                        data: [chartData.totalMasuk, chartData.totalKeluar],
                        backgroundColor: ['rgba(16, 185, 129, 0.85)', 'rgba(239, 68, 68, 0.85)'],
                        borderColor: ['rgba(16, 185, 129, 1)', 'rgba(239, 68, 68, 1)'],
                        borderWidth: 2,
                        hoverOffset: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '65%',
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: function(ctx) {
                                    var total = ctx.dataset.data.reduce(function(a, b) { return a + b; }, 0);
                                    var pct = total > 0 ? ((ctx.parsed / total) * 100).toFixed(1) : 0;
                                    return ctx.label + ': Rp ' + Number(ctx.parsed).toLocaleString('id-ID') + ' (' + pct + '%)';
                                }
                            }
                        }
                    }
                },
                plugins: [{
                    id: 'centerText',
                    beforeDraw: function(chart) {
                        var width = chart.width;
                        var height = chart.height;
                        var ctx2 = chart.ctx;
                        var total = chartData.totalMasuk + chartData.totalKeluar;
                        ctx2.save();
                        ctx2.font = 'bold 10px sans-serif';
                        ctx2.fillStyle = '#9CA3AF';
                        ctx2.textAlign = 'center';
                        ctx2.textBaseline = 'middle';
                        ctx2.fillText('TOTAL', width / 2, height / 2 - 10);
                        ctx2.font = 'bold 13px sans-serif';
                        ctx2.fillStyle = '#374151';
                        var displayVal = total >= 1000000
                            ? (total / 1000000).toFixed(1) + 'jt'
                            : total >= 1000 ? (total / 1000).toFixed(0) + 'rb' : total;
                        ctx2.fillText('Rp ' + displayVal, width / 2, height / 2 + 10);
                        ctx2.restore();
                    }
                }]
            });
        } catch(e) { console.error('chartDoughnut error:', e); }

        // ===== 3. LINE CHART — SALDO BERJALAN =====
        try {
            new Chart(document.getElementById('chartLine'), {
                type: 'line',
                data: {
                    labels: chartData.labels,
                    datasets: [{
                        label: 'Saldo Berjalan',
                        data: chartData.runSaldo,
                        borderColor: 'rgba(59, 130, 246, 1)',
                        backgroundColor: 'rgba(59, 130, 246, 0.15)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4,
                        pointBackgroundColor: 'rgba(59, 130, 246, 1)',
                        pointBorderColor: '#fff',
                        pointBorderWidth: 2,
                        pointRadius: 5,
                        pointHoverRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: { intersect: false, mode: 'index' },
                    plugins: {
                        legend: { display: true, position: 'top', labels: { usePointStyle: true, padding: 16 } },
                        tooltip: tooltipRp
                    },
                    scales: {
                        x: { grid: { display: false }, ticks: { color: tickColor } },
                        y: {
                            grid: { color: gridColor },
                            ticks: { color: tickColor, callback: function(v) { return rpFormat(v); } }
                        }
                    }
                }
            });
        } catch(e) { console.error('chartLine error:', e); }

        // ===== 4. NET BAR CHART =====
        try {
            var netColors = chartData.net.map(function(v) {
                return v >= 0 ? 'rgba(16, 185, 129, 0.8)' : 'rgba(239, 68, 68, 0.8)';
            });
            var netBorders = chartData.net.map(function(v) {
                return v >= 0 ? 'rgba(16, 185, 129, 1)' : 'rgba(239, 68, 68, 1)';
            });

            new Chart(document.getElementById('chartNet'), {
                type: 'bar',
                data: {
                    labels: chartData.labels,
                    datasets: [{
                        label: 'Net Arus Kas',
                        data: chartData.net,
                        backgroundColor: netColors,
                        borderColor: netBorders,
                        borderWidth: 1,
                        borderRadius: 6,
                        borderSkipped: false
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: { intersect: false, mode: 'index' },
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: function(ctx) {
                                    var val = ctx.parsed.y;
                                    return 'Net: ' + (val >= 0 ? '+' : '') + 'Rp ' + Number(val).toLocaleString('id-ID');
                                }
                            }
                        }
                    },
                    scales: {
                        x: { grid: { display: false }, ticks: { color: tickColor } },
                        y: {
                            grid: { color: gridColor },
                            ticks: { color: tickColor, callback: function(v) { return rpFormat(v); } }
                        }
                    }
                }
            });
        } catch(e) { console.error('chartNet error:', e); }

        // ===== 5. TRANSAKSI BAR CHART =====
        try {
            new Chart(document.getElementById('chartTrx'), {
                type: 'bar',
                data: {
                    labels: chartData.labels,
                    datasets: [{
                        label: 'Jumlah Transaksi',
                        data: chartData.trx,
                        backgroundColor: 'rgba(20, 184, 166, 0.75)',
                        borderColor: 'rgba(20, 184, 166, 1)',
                        borderWidth: 1,
                        borderRadius: 6,
                        borderSkipped: false
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: { intersect: false, mode: 'index' },
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: function(ctx) {
                                    return ctx.parsed.y + ' transaksi';
                                }
                            }
                        }
                    },
                    scales: {
                        x: { grid: { display: false }, ticks: { color: tickColor } },
                        y: {
                            beginAtZero: true,
                            grid: { color: gridColor },
                            ticks: {
                                color: tickColor,
                                stepSize: 1,
                                callback: function(v) { return Number.isInteger(v) ? v : ''; }
                            }
                        }
                    }
                }
            });
        } catch(e) { console.error('chartTrx error:', e); }
    });
})();
</script>
