<?php declare(strict_types=1); ?>
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <div class="bg-white p-5 rounded-xl shadow h-fit">
        <h4 class="font-bold text-gray-700 mb-4 border-b pb-2">Input Kas Buku Besar</h4>
        <form action="<?= $_ENV['APP_URL'] ?>/kas/simpan" method="POST" class="space-y-4">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
            
            <div>
                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Jenis Transaksi</label>
                <select name="tipe" class="w-full border p-2 text-sm rounded focus:ring focus:ring-indigo-200">
                    <option value="masuk">Pemasukan (Debet)</option>
                    <option value="keluar">Pengeluaran (Kredit)</option>
                </select>
            </div>
            <div>
                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Jumlah (Rupiah)</label>
                <input type="number" name="jumlah" required class="w-full border p-2 text-sm rounded focus:ring focus:ring-indigo-200" placeholder="Contoh: 150000">
            </div>
            <div>
                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Keterangan Catatan</label>
                <textarea name="keterangan" rows="3" required class="w-full border p-2 text-sm rounded focus:ring focus:ring-indigo-200" placeholder="Detail keperluan..."></textarea>
            </div>
            <button type="submit" class="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold uppercase rounded tracking-wider">Simpan Buku Kas</button>
        </form>
    </div>

    <div class="lg:col-span-2 bg-white rounded-xl shadow overflow-hidden">
        <div class="p-5 border-b flex justify-between items-center bg-gray-50">
            <h3 class="font-bold text-gray-700">Jurnal Mutasi Keuangan</h3>
            <div class="text-right">
                <span class="text-xs text-gray-400 font-medium block">Total Kas Bersih</span>
                <span class="text-lg font-bold font-mono text-emerald-600">Rp <?= number_format($saldo, 0, ',', '.') ?></span>
            </div>
        </div>

        <div class="overflow-x-auto max-h-[400px]">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-slate-100 text-slate-500 text-[10px] uppercase font-bold border-b sticky top-0">
                        <th class="px-4 py-2.5">Tanggal</th>
                        <th class="px-4 py-2.5">Keterangan</th>
                        <th class="px-4 py-2.5 text-right">Nominal</th>
                    </tr>
                </thead>
                <tbody class="text-xs divide-y">
                    <?php foreach ($logs as $log): ?>
                        <tr class="hover:bg-slate-50">
                            <td class="px-4 py-3 text-gray-400 font-mono"><?= $log['created_at'] ?></td>
                            <td class="px-4 py-3 font-medium text-gray-700"><?= htmlspecialchars($log['keterangan']) ?></td>
                            <td class="px-4 py-3 text-right font-mono font-bold <?= $log['tipe'] === 'masuk' ? 'text-emerald-600' : 'text-rose-600' ?>">
                                <?= $log['tipe'] === 'masuk' ? '+' : '-' ?> Rp <?= number_format((float)$log['jumlah'], 0, ',', '.') ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
