<!DOCTYPE html>
<?php
/**
 * views/pages/Auth/register.php
 * Form pendaftaran pelanggan baru (publik / tamu).
 *
 * Dipanggil oleh:
 *   GET  /pendaftaran, /daftar   PelangganController::pendaftaran()
 *   POST /daftar                 PelangganController::storePendaftaran()
 *
 * Pelanggan yang mendaftar lewat form ini akan otomatis tersimpan
 * dengan status_internet = 'pending' (menunggu survei & aktivasi admin).
 *
 * Variabel yang dikirim controller:
 *   $title              string
 *   $pakets             array   � dari PaketModel::getAll()
 *   $old                array   � input lama saat validasi gagal
 *   $errors             array   � daftar pesan error
 *   $errorFields        array   � nama field yang error (untuk highlight merah)
 *   $success            bool    � true setelah berhasil daftar
 *   $registeredName     string  (hanya saat success)
 *   $registeredUsername string  (hanya saat success)
 *   $registeredTelp     string  (hanya saat success)
 */
$appUrl      = $_ENV['APP_URL'] ?? '';
$pakets      = $pakets      ?? [];
$old         = $old         ?? [];
$errors      = $errors      ?? [];
$errorFields = $errorFields ?? [];
$success     = $success     ?? false;
?>
<html lang="id" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($title ?? 'Daftar Layanan Internet') ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
        * { font-family: 'Plus Jakarta Sans', sans-serif; }

        @keyframes fadeUp { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
        .fade-up { animation: fadeUp .35s ease both; }

        .input-field {
            width:100%; padding:.55rem .875rem; border-radius:.625rem;
            border:1.5px solid #E5E7EB; background:#fff;
            font-size:.875rem; color:#111827; outline:none;
            transition:border-color .15s, box-shadow .15s;
        }
        .input-field:focus { border-color:#4F46E5; box-shadow:0 0 0 3px rgba(79,70,229,.12); }
        .input-field.err   { border-color:#EF4444; box-shadow:0 0 0 3px rgba(239,68,68,.1); }

        .paket-card {
            border:2px solid #E5E7EB; border-radius:1rem; padding:1rem;
            cursor:pointer; transition:border-color .15s, box-shadow .15s, transform .15s; user-select:none;
        }
        .paket-card:hover  { border-color:#818CF8; transform:translateY(-1px); }
        .paket-card.chosen { border-color:#4F46E5; box-shadow:0 0 0 3px rgba(79,70,229,.12); }

        .step-circle    { transition:background .2s, color .2s; }
        .step-active    { background:#4F46E5; color:#fff; }
        .step-done      { background:#10B981; color:#fff; }
        .step-inactive  { background:#E5E7EB; color:#9CA3AF; }
        .step-line      { flex:1; height:2px; background:#E5E7EB; margin:0 .5rem; transition:background .3s; }
        .step-line.done { background:#10B981; }
    </style>
</head>
<body class="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50/30 to-slate-100">

<!--  HEADER  -->
<header class="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-gray-100 shadow-sm">
    <div class="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between">
        <a href="<?= $appUrl ?>/" class="flex items-center gap-2 no-underline">
            <div class="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                <i class="fa-solid fa-wifi text-white text-sm"></i>
            </div>
            <span class="font-bold text-gray-900">NetISP</span>
        </a>
        <a href="<?= $appUrl ?>/login"
           class="text-sm font-medium text-indigo-600 hover:text-indigo-700 no-underline transition-colors">
            Sudah punya akun? <span class="underline underline-offset-2">Masuk</span>
        </a>
    </div>
</header>

<main class="max-w-2xl mx-auto px-4 py-10">

<?php if ($success): ?>
<!-- 
     SUCCESS STATE � Akun baru berstatus PENDING
 -->
<div class="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden fade-up">
    <div class="bg-gradient-to-r from-emerald-500 to-teal-600 px-8 py-10 text-center">
        <div class="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <i class="fa-solid fa-circle-check text-white text-3xl"></i>
        </div>
        <h1 class="text-2xl font-bold text-white mb-1">Pendaftaran Berhasil!</h1>
        <p class="text-emerald-100 text-sm">Terima kasih, data Anda sudah kami terima.</p>
    </div>

    <div class="p-8 space-y-5">

        <!-- Status pending box -->
        <div class="bg-amber-50 border border-amber-200 rounded-xl p-4 flex gap-3">
            <i class="fa-solid fa-clock text-amber-500 mt-0.5 shrink-0"></i>
            <div>
                <p class="font-semibold text-amber-800 text-sm mb-0.5">
                    Status Akun: <span class="uppercase">Pending</span> � Menunggu Aktivasi
                </p>
                <p class="text-amber-700 text-sm leading-relaxed">
                    Pendaftaran Anda sedang ditinjau oleh tim kami. Tim teknisi akan melakukan survei lokasi
                    dan mengaktifkan layanan dalam <strong>1�2 hari kerja</strong>. Anda akan dihubungi via
                    WhatsApp segera setelah akun diaktifkan.
                </p>
            </div>
        </div>

        <!-- Ringkasan data -->
        <div class="grid grid-cols-2 gap-3 text-sm">
            <div class="bg-gray-50 rounded-xl p-3">
                <p class="text-gray-400 text-xs uppercase tracking-wide font-semibold mb-1">Nama</p>
                <p class="font-semibold text-gray-900"><?= htmlspecialchars($registeredName ?? '') ?></p>
            </div>
            <div class="bg-gray-50 rounded-xl p-3">
                <p class="text-gray-400 text-xs uppercase tracking-wide font-semibold mb-1">Username</p>
                <p class="font-semibold text-gray-900 font-mono"><?= htmlspecialchars($registeredUsername ?? '') ?></p>
            </div>
            <div class="bg-gray-50 rounded-xl p-3">
                <p class="text-gray-400 text-xs uppercase tracking-wide font-semibold mb-1">WhatsApp</p>
                <p class="font-semibold text-gray-900"><?= htmlspecialchars($registeredTelp ?? '') ?></p>
            </div>
            <div class="bg-gray-50 rounded-xl p-3">
                <p class="text-gray-400 text-xs uppercase tracking-wide font-semibold mb-1">Status</p>
                <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold
                             bg-amber-100 text-amber-700">
                    <i class="fa-regular fa-clock text-[9px]"></i> Pending
                </span>
            </div>
        </div>

        <a href="<?= $appUrl ?>/login"
           class="block w-full text-center bg-indigo-600 hover:bg-indigo-700 text-white
                  font-semibold py-3 rounded-xl transition-colors no-underline text-sm">
            Ke Halaman Login
        </a>
    </div>
</div>

<?php else: ?>
<!-- 
     FORM PENDAFTARAN (4 langkah)
 -->

<div class="text-center mb-8 fade-up">
    <h1 class="text-3xl font-extrabold text-gray-900 tracking-tight mb-2">Daftar Layanan Internet</h1>
    <p class="text-gray-500 text-sm">Isi data dengan benar. Akun baru akan berstatus <strong>Pending</strong> sampai diverifikasi tim kami.</p>
</div>

<!-- Step progress -->
<div class="flex items-center mb-8 fade-up">
    <?php
    $stepDefs = [
        ['Pribadi', 'fa-user'], ['Alamat', 'fa-location-dot'],
        ['Paket',   'fa-wifi'], ['Konfirmasi', 'fa-check'],
    ];
    foreach ($stepDefs as $sIdx => [$sLabel, $sIcon]):
        $sNum = $sIdx + 1;
    ?>
    <?php if ($sIdx > 0): ?><div class="step-line" id="line-<?= $sIdx ?>"></div><?php endif; ?>
    <div class="flex flex-col items-center gap-1 shrink-0">
        <div id="sc-<?= $sNum ?>"
             class="step-circle w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold
                    <?= $sNum === 1 ? 'step-active' : 'step-inactive' ?>">
            <i class="fa-solid <?= $sIcon ?> text-xs"></i>
        </div>
        <span id="sl-<?= $sNum ?>"
              class="text-xs font-medium hidden sm:block
                     <?= $sNum === 1 ? 'text-indigo-600' : 'text-gray-400' ?>">
            <?= $sLabel ?>
        </span>
    </div>
    <?php endforeach; ?>
</div>

<!-- Error summary -->
<?php if (!empty($errors)): ?>
<div class="mb-5 bg-red-50 border border-red-200 rounded-xl px-4 py-3 fade-up">
    <p class="flex items-center gap-2 font-semibold text-red-700 text-sm mb-1">
        <i class="fa-solid fa-circle-exclamation"></i> Mohon perbaiki:
    </p>
    <ul class="text-sm text-red-600 list-disc list-inside space-y-0.5 ml-1">
        <?php foreach ($errors as $e): ?>
        <li><?= htmlspecialchars($e) ?></li>
        <?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>

<!-- FORM -->
<form method="POST" action="<?= $appUrl ?>/daftar" id="regForm" novalidate
      class="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden fade-up">

    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">

    <!--  STEP 1: Informasi Pribadi  -->
    <div id="step1" class="step-panel p-6 sm:p-8 space-y-4">
        <div class="pb-3 border-b border-gray-100">
            <h2 class="font-bold text-gray-900 flex items-center gap-2">
                <span class="w-6 h-6 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center text-xs font-bold">1</span>
                Informasi Pribadi
            </h2>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div class="sm:col-span-2">
                <label class="block text-sm font-semibold text-gray-700 mb-1.5">Nama Lengkap <span class="text-red-500">*</span></label>
                <input type="text" name="nama_lengkap" id="f_nama"
                       placeholder="Sesuai KTP"
                       value="<?= htmlspecialchars($old['nama_lengkap'] ?? '') ?>"
                       class="input-field <?= in_array('nama_lengkap', $errorFields) ? 'err' : '' ?>">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1.5">Username <span class="text-red-500">*</span></label>
                <div class="relative">
                    <input type="text" name="username" id="f_username"
                           placeholder="min. 4 karakter"
                           value="<?= htmlspecialchars($old['username'] ?? '') ?>"
                           class="input-field pr-9 <?= in_array('username', $errorFields) ? 'err' : '' ?>"
                           oninput="cekUsername(this.value)">
                    <span id="usernameIcon" class="absolute right-3 top-1/2 -translate-y-1/2 text-sm hidden"></span>
                </div>
                <p class="text-xs text-gray-400 mt-1">Huruf kecil, angka, titik, underscore saja</p>
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1.5">No. WhatsApp <span class="text-red-500">*</span></label>
                <input type="tel" name="no_telp" id="f_telp"
                       placeholder="08xxxxxxxxxx"
                       value="<?= htmlspecialchars($old['no_telp'] ?? '') ?>"
                       class="input-field <?= in_array('no_telp', $errorFields) ? 'err' : '' ?>">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1.5">Password <span class="text-red-500">*</span></label>
                <div class="relative">
                    <input type="password" name="password" id="f_pwd"
                           placeholder="min. 6 karakter"
                           class="input-field pr-9 <?= in_array('password', $errorFields) ? 'err' : '' ?>">
                    <button type="button" onclick="togglePwd('f_pwd','eyePwd')"
                            class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 border-0 bg-transparent cursor-pointer p-0">
                        <i id="eyePwd" class="fa-regular fa-eye text-sm"></i>
                    </button>
                </div>
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1.5">Konfirmasi Password <span class="text-red-500">*</span></label>
                <div class="relative">
                    <input type="password" name="password_confirm" id="f_pwd2"
                           placeholder="Ulangi password"
                           class="input-field pr-9"
                           oninput="cekPwd()">
                    <button type="button" onclick="togglePwd('f_pwd2','eyePwd2')"
                            class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 border-0 bg-transparent cursor-pointer p-0">
                        <i id="eyePwd2" class="fa-regular fa-eye text-sm"></i>
                    </button>
                </div>
                <p id="pwdMsg" class="text-xs mt-1 hidden"></p>
            </div>
        </div>
    </div>

    <!--  STEP 2: Alamat & Lokasi  -->
    <div id="step2" class="step-panel hidden p-6 sm:p-8 space-y-4">
        <div class="pb-3 border-b border-gray-100">
            <h2 class="font-bold text-gray-900 flex items-center gap-2">
                <span class="w-6 h-6 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center text-xs font-bold">2</span>
                Alamat & Lokasi
            </h2>
        </div>
        <div>
            <label class="block text-sm font-semibold text-gray-700 mb-1.5">Alamat Lengkap <span class="text-red-500">*</span></label>
            <textarea name="alamat" id="f_alamat" rows="3"
                      placeholder="Jl. Merdeka No. 10, RT 02/RW 03, Kel. Suka Maju�"
                      class="input-field resize-none <?= in_array('alamat', $errorFields) ? 'err' : '' ?>"><?= htmlspecialchars($old['alamat'] ?? '') ?></textarea>
        </div>
        <div>
            <label class="block text-sm font-semibold text-gray-700 mb-1.5">
                Koordinat GPS <span class="text-gray-400 font-normal text-xs">(opsional, membantu survei)</span>
            </label>
            <div class="flex gap-2">
                <input type="text" name="koordinat" id="f_koordinat"
                       placeholder="-6.200000, 106.816666"
                       value="<?= htmlspecialchars($old['koordinat'] ?? '') ?>"
                       class="input-field flex-1">
                <button type="button" id="btnGps" onclick="getGps()"
                        class="shrink-0 px-3 py-2 rounded-xl border border-gray-200 bg-gray-50
                               hover:bg-indigo-50 hover:border-indigo-300 text-gray-500 hover:text-indigo-600
                               text-sm font-medium cursor-pointer flex items-center gap-1.5 transition-all">
                    <i class="fa-solid fa-location-crosshairs"></i>
                    <span class="hidden sm:inline">Deteksi</span>
                </button>
            </div>
            <p class="text-xs text-gray-400 mt-1">Klik "Deteksi" untuk mengisi otomatis dari perangkat Anda</p>
        </div>
        <div>
            <label class="block text-sm font-semibold text-gray-700 mb-1.5">
                Catatan <span class="text-gray-400 font-normal text-xs">(opsional)</span>
            </label>
            <input type="text" name="catatan"
                   placeholder="Ciri rumah, patokan, dll."
                   value="<?= htmlspecialchars($old['catatan'] ?? '') ?>"
                   class="input-field">
        </div>
    </div>

    <!--  STEP 3: Pilih Paket  -->
    <div id="step3" class="step-panel hidden p-6 sm:p-8 space-y-4">
        <div class="pb-3 border-b border-gray-100">
            <h2 class="font-bold text-gray-900 flex items-center gap-2">
                <span class="w-6 h-6 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center text-xs font-bold">3</span>
                Pilih Paket Internet
            </h2>
        </div>

        <input type="hidden" name="paket_id" id="f_paket_id" value="<?= htmlspecialchars((string)($old['paket_id'] ?? '')) ?>">

        <?php if (empty($pakets)): ?>
        <div class="py-10 text-center text-gray-400">
            <i class="fa-solid fa-wifi text-4xl mb-3 text-gray-200 block"></i>
            <p class="font-medium">Paket belum tersedia</p>
            <p class="text-sm mt-1">Hubungi kami untuk info paket</p>
        </div>
        <?php else: ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <?php foreach ($pakets as $pk):
                $harga    = (int)($pk['harga'] ?? 0);
                $speed    = $pk['kecepatan'] ?? '';
                $desc     = $pk['deskripsi'] ?? '';
                $isChosen = (string)($old['paket_id'] ?? '') === (string)$pk['id'];
            ?>
            <div class="paket-card <?= $isChosen ? 'chosen' : '' ?>"
                 onclick="pilihPaket(<?= $pk['id'] ?>, this)"
                 data-id="<?= $pk['id'] ?>">
                <div class="flex items-start justify-between gap-2 mb-2">
                    <div>
                        <div class="font-bold text-gray-900 text-sm"><?= htmlspecialchars($pk['nama_paket']) ?></div>
                        <?php if ($speed): ?>
                        <div class="text-indigo-600 font-extrabold text-xl leading-tight"><?= htmlspecialchars($speed) ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="shrink-0 w-7 h-7 rounded-full border-2 border-gray-200 flex items-center justify-center
                                transition-all chk-paket <?= $isChosen ? 'bg-indigo-600 border-indigo-600' : '' ?>">
                        <i class="fa-solid fa-check text-white text-xs <?= $isChosen ? '' : 'opacity-0' ?>"></i>
                    </div>
                </div>
                <?php if ($desc): ?><p class="text-xs text-gray-500 mb-2"><?= htmlspecialchars($desc) ?></p><?php endif; ?>
                <div class="pt-2 border-t border-gray-100 flex justify-between items-center">
                    <span class="text-xs text-gray-400">per bulan</span>
                    <span class="font-bold text-gray-900 text-sm">Rp <?= number_format($harga, 0, ',', '.') ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <p class="text-xs text-gray-400 text-center">* Belum termasuk biaya pemasangan</p>
        <?php endif; ?>
    </div>

    <!--  STEP 4: Konfirmasi  -->
    <div id="step4" class="step-panel hidden p-6 sm:p-8 space-y-4">
        <div class="pb-3 border-b border-gray-100">
            <h2 class="font-bold text-gray-900 flex items-center gap-2">
                <span class="w-6 h-6 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center text-xs font-bold">4</span>
                Konfirmasi Pendaftaran
            </h2>
        </div>

        <div class="bg-gray-50 rounded-xl divide-y divide-gray-200 text-sm">
            <div class="px-4 py-3 flex justify-between">
                <span class="text-gray-500">Nama Lengkap</span>
                <span id="sum-nama" class="font-semibold text-gray-900 text-right max-w-[55%] truncate">�</span>
            </div>
            <div class="px-4 py-3 flex justify-between">
                <span class="text-gray-500">Username</span>
                <span id="sum-username" class="font-mono font-semibold text-indigo-600">�</span>
            </div>
            <div class="px-4 py-3 flex justify-between">
                <span class="text-gray-500">No. WhatsApp</span>
                <span id="sum-telp" class="font-semibold text-gray-900">�</span>
            </div>
            <div class="px-4 py-3 flex justify-between">
                <span class="text-gray-500">Alamat</span>
                <span id="sum-alamat" class="font-semibold text-gray-900 text-right max-w-[55%] leading-snug">�</span>
            </div>
            <div class="px-4 py-3 flex justify-between">
                <span class="text-gray-500">Paket</span>
                <span id="sum-paket" class="font-semibold text-indigo-700">�</span>
            </div>
            <div class="px-4 py-3 flex justify-between items-center">
                <span class="text-gray-500">Status Awal Akun</span>
                <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold
                             bg-amber-100 text-amber-700">
                    <i class="fa-regular fa-clock text-[9px]"></i> Pending
                </span>
            </div>
        </div>

        <div class="bg-indigo-50 border border-indigo-100 rounded-xl p-4 text-sm text-indigo-700 flex gap-3">
            <i class="fa-solid fa-circle-info text-indigo-400 mt-0.5 shrink-0"></i>
            <p class="leading-relaxed">
                Setelah mendaftar, akun Anda akan otomatis berstatus <strong>Pending</strong> sampai
                tim kami melakukan survei lokasi dan mengaktifkan layanan. Proses ini memakan waktu
                <strong>1�2 hari kerja</strong>.
            </p>
        </div>

        <label class="flex items-start gap-3 cursor-pointer">
            <input type="checkbox" name="setuju" id="f_setuju" required
                   class="mt-0.5 w-4 h-4 rounded border-gray-300 accent-indigo-600 cursor-pointer">
            <span class="text-sm text-gray-600 leading-relaxed">
                Saya menyatakan data yang diisi benar dan menyetujui
                <a href="#" class="text-indigo-600 underline underline-offset-2">syarat & ketentuan</a> layanan.
            </span>
        </label>
    </div>

    <!--  NAV BUTTONS  -->
    <div class="px-6 sm:px-8 py-5 bg-gray-50 border-t border-gray-100 flex justify-between items-center">
        <button type="button" id="btnBack" onclick="prevStep()"
                class="hidden items-center gap-2 px-5 py-2.5 rounded-xl border border-gray-200
                       bg-white text-gray-700 font-semibold text-sm hover:bg-gray-50
                       transition-all cursor-pointer">
            <i class="fa-solid fa-arrow-left text-xs"></i> Sebelumnya
        </button>
        <span></span>
        <button type="button" id="btnNext" onclick="nextStep()"
                class="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700
                       text-white font-semibold text-sm transition-all cursor-pointer
                       shadow-sm shadow-indigo-500/30">
            Lanjut <i class="fa-solid fa-arrow-right text-xs"></i>
        </button>
        <button type="submit" id="btnSubmit"
                class="hidden items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700
                       text-white font-semibold text-sm transition-all cursor-pointer
                       shadow-sm shadow-emerald-500/30">
            <i class="fa-solid fa-paper-plane text-xs"></i> Kirim Pendaftaran
        </button>
    </div>

</form><!-- /form -->

<p class="text-center text-xs text-gray-400 mt-6">
    Butuh bantuan?
    <a href="https://wa.me/" target="_blank" class="text-indigo-600 hover:underline no-underline">
        <i class="fa-brands fa-whatsapp"></i> Hubungi kami via WhatsApp
    </a>
</p>
<?php endif; ?>
</main>

<script>
/* 
   DATA PAKET (untuk ringkasan step 4)
 */
const paketData = <?= json_encode(array_map(fn($p) => [
    'id'    => $p['id'],
    'nama'  => $p['nama_paket'],
    'speed' => $p['kecepatan'] ?? '',
    'harga' => (int)($p['harga'] ?? 0),
], $pakets), JSON_UNESCAPED_UNICODE) ?>;

/* 
   MULTI-STEP NAVIGATION
 */
let step = 1;
const TOTAL = 4;

function showStep(n) {
    for (let i = 1; i <= TOTAL; i++) {
        document.getElementById('step' + i).classList.toggle('hidden', i !== n);
        const sc   = document.getElementById('sc-' + i);
        const sl   = document.getElementById('sl-' + i);
        const line = document.getElementById('line-' + (i - 1));
        sc.className = sc.className.replace(/step-active|step-done|step-inactive/g, '').trim();
        if (i < n)        { sc.classList.add('step-done');     sl && (sl.className = sl.className.replace(/text-\w+-\d+/g,'') + ' text-emerald-600'); line && line.classList.add('done'); }
        else if (i === n) { sc.classList.add('step-active');   sl && (sl.className = sl.className.replace(/text-\w+-\d+/g,'') + ' text-indigo-600'); }
        else               { sc.classList.add('step-inactive'); sl && (sl.className = sl.className.replace(/text-\w+-\d+/g,'') + ' text-gray-400');   line && line.classList.remove('done'); }
    }
    const back   = document.getElementById('btnBack');
    const next   = document.getElementById('btnNext');
    const submit = document.getElementById('btnSubmit');
    back.classList.toggle('hidden', n === 1);
    back.classList.toggle('flex',   n > 1);
    next.classList.toggle('hidden', n === TOTAL);
    next.classList.toggle('flex',   n < TOTAL);
    submit.classList.toggle('hidden', n !== TOTAL);
    submit.classList.toggle('flex',   n === TOTAL);
    if (n === TOTAL) fillSummary();
    step = n;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function nextStep() {
    if (!validateStep(step)) return;
    if (step < TOTAL) showStep(step + 1);
}
function prevStep() {
    if (step > 1) showStep(step - 1);
}

function validateStep(s) {
    if (s === 1) {
        if (!document.getElementById('f_nama').value.trim())    { alert('Nama lengkap wajib diisi.'); return false; }
        if (document.getElementById('f_username').value.trim().length < 4) { alert('Username minimal 4 karakter.'); return false; }
        if (!document.getElementById('f_telp').value.trim())    { alert('No. WhatsApp wajib diisi.'); return false; }
        const p = document.getElementById('f_pwd').value;
        if (p.length < 6)                                       { alert('Password minimal 6 karakter.'); return false; }
        if (p !== document.getElementById('f_pwd2').value)      { alert('Konfirmasi password tidak cocok.'); return false; }
    }
    if (s === 2 && !document.getElementById('f_alamat').value.trim()) {
        alert('Alamat wajib diisi.'); return false;
    }
    if (s === 3 && !document.getElementById('f_paket_id').value) {
        alert('Pilih paket terlebih dahulu.'); return false;
    }
    return true;
}

function fillSummary() {
    document.getElementById('sum-nama').textContent     = document.getElementById('f_nama').value     || '�';
    document.getElementById('sum-username').textContent = document.getElementById('f_username').value || '�';
    document.getElementById('sum-telp').textContent     = document.getElementById('f_telp').value     || '�';
    document.getElementById('sum-alamat').textContent   = document.getElementById('f_alamat').value   || '�';
    const pid = document.getElementById('f_paket_id').value;
    const pk  = paketData.find(p => String(p.id) === String(pid));
    document.getElementById('sum-paket').textContent = pk
        ? pk.nama + (pk.speed ? ' � ' + pk.speed : '') + ' (Rp ' + pk.harga.toLocaleString('id-ID') + '/bln)'
        : '� (belum dipilih)';
}

/* 
   CEK USERNAME (AJAX  GET /daftar/cek-username)
 */
let usernameTimer;
function cekUsername(val) {
    clearTimeout(usernameTimer);
    const el = document.getElementById('usernameIcon');
    if (val.length < 4) { el.classList.add('hidden'); return; }
    usernameTimer = setTimeout(() => {
        fetch('<?= $appUrl ?>/daftar/cek-username?u=' + encodeURIComponent(val))
            .then(r => r.json())
            .then(d => {
                el.classList.remove('hidden');
                el.innerHTML = d.available
                    ? '<i class="fa-solid fa-circle-check text-emerald-500"></i>'
                    : '<i class="fa-solid fa-circle-xmark text-red-500"></i>';
            }).catch(() => el.classList.add('hidden'));
    }, 500);
}

/* 
   PASSWORD MATCH
 */
function cekPwd() {
    const p1  = document.getElementById('f_pwd').value;
    const p2  = document.getElementById('f_pwd2').value;
    const msg = document.getElementById('pwdMsg');
    if (!p2) { msg.classList.add('hidden'); return; }
    msg.classList.remove('hidden');
    if (p1 === p2) {
        msg.className = 'text-xs mt-1 text-emerald-600 font-medium';
        msg.innerHTML = '<i class="fa-solid fa-check mr-1"></i>Cocok';
    } else {
        msg.className = 'text-xs mt-1 text-red-500 font-medium';
        msg.innerHTML = '<i class="fa-solid fa-xmark mr-1"></i>Tidak cocok';
    }
}

/* 
   TOGGLE PASSWORD VISIBILITY
 */
function togglePwd(fid, eid) {
    const f = document.getElementById(fid);
    const i = document.getElementById(eid);
    f.type = f.type === 'password' ? 'text' : 'password';
    i.className = f.type === 'text' ? 'fa-regular fa-eye-slash text-sm' : 'fa-regular fa-eye text-sm';
}

/* 
   GPS DETECTION
 */
function getGps() {
    const btn = document.getElementById('btnGps');
    if (!navigator.geolocation) { alert('Perangkat tidak mendukung GPS.'); return; }
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
    btn.disabled = true;
    navigator.geolocation.getCurrentPosition(pos => {
        document.getElementById('f_koordinat').value =
            pos.coords.latitude.toFixed(6) + ', ' + pos.coords.longitude.toFixed(6);
        btn.innerHTML = '<i class="fa-solid fa-check text-emerald-500"></i>';
        btn.disabled = false;
    }, err => {
        alert('GPS gagal: ' + err.message);
        btn.innerHTML = '<i class="fa-solid fa-location-crosshairs"></i><span class="hidden sm:inline ml-1.5">Deteksi</span>';
        btn.disabled = false;
    });
}

/* Init: mulai di step 1 (paling aman karena field step 1
   paling sering jadi sumber error validasi server) */
showStep(1);
</script>
</body>
</html>
