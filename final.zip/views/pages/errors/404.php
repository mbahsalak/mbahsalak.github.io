<?php declare(strict_types=1); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>404 Not Found</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 flex items-center justify-center min-h-screen text-center p-6">
    <div class="max-w-md bg-white p-8 rounded-2xl shadow-lg">
        <h1 class="text-7xl font-black text-indigo-600 font-mono">404</h1>
        <p class="text-xl font-bold text-gray-800 mt-4">Halaman Tidak Ditemukan</p>
        <p class="text-sm text-gray-500 mt-2">Maaf, tautan URL yang Anda cari tidak ada atau telah dipindahkan oleh administrator sistem.</p>
        <a href="javascript:history.back()" class="inline-block mt-6 px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded shadow"> kembali ke halaman sebelumnya </a>
    </div>
</body>
</html>
