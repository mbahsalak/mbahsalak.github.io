<?php declare(strict_types=1); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>403 Akses Dilarang</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-900 flex items-center justify-center min-h-screen text-center p-6">
    <div class="max-w-md bg-slate-800 p-8 rounded-2xl shadow-2xl border border-slate-700">
        <div class="text-red-500 text-5xl mb-2"><i class="shadow-sm border-red-500/10 fa-solid fa-hand"></i>🛑</div>
        <h1 class="text-4xl font-extrabold text-white tracking-tight">403 Forbidden</h1>
        <p class="text-sm text-slate-400 mt-3">Akses Ditolak! Anda tidak memiliki tingkat kredensial atau hak otoritas yang sah untuk melihat lembar data ini.</p>
        <a href="<?= $_ENV['APP_URL'] ?>/dashboard" class="inline-block mt-6 px-5 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded transition">Kembali ke Dashboard Anda</a>
    </div>
</body>
</html>
