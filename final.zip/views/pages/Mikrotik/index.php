<?php
/**
 * views/Mikrotik/index.php
 * Dashboard MikroTik
 *
 * @var array   $info       — system/resource dari MikroTik
 * @var string  $identity   — nama router
 * @var array   $interfaces — daftar interface
 * @var array   $pelanggans — pelanggan dengan MAC address
 * @var ?string $error      — pesan error jika ada
 */

$cpuLoad = (int)($info['cpu-load'] ?? 0);
$cpuClr  = $cpuLoad > 80 ? '#dc2626' : ($cpuLoad > 50 ? '#d97706' : '#16a34a');
?>

<?php if ($error): ?>
<div style="background:#fef2f2;border:1px solid #fecaca;border-radius:12px;padding:1.25rem 1.5rem;margin-bottom:1.5rem;display:flex;align-items:flex-start;gap:.875rem;box-shadow:0 1px 3px rgba(0,0,0,.04);">
    <div style="width:40px;height:40px;border-radius:10px;background:#fee2e2;display:grid;place-items:center;flex-shrink:0;">
        <i class="fa-solid fa-triangle-exclamation" style="color:#dc2626;font-size:1rem;"></i>
    </div>
    <div>
        <strong style="font-size:.9rem;color:#991b1b;display:block;margin-bottom:.25rem;">Gagal Mengambil Data</strong>
        <span style="font-size:.82rem;color:#b91c1c;line-height:1.5;"><?= htmlspecialchars($error) ?></span>
        <div style="margin-top:.75rem;">
            <button onclick="location.reload()" style="padding:.35rem .85rem;border:1px solid #fca5a5;border-radius:7px;background:#fee2e2;color:#991b1b;font-size:.78rem;font-weight:600;cursor:pointer;">
                <i class="fa-solid fa-rotate-right"></i> Coba Lagi
            </button>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ── STAT CARDS ── -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:1rem;margin-bottom:1.75rem;">
<?php
$sysFields = [
    ['label'=>'Identitas Router', 'icon'=>'fa-router',            'color'=>'#2563eb', 'value'=> htmlspecialchars($identity)],
    ['label'=>'Model',            'icon'=>'fa-microchip',          'color'=>'#7c3aed', 'value'=> htmlspecialchars($info['board-name'] ?? '-')],
    ['label'=>'RouterOS',         'icon'=>'fa-tag',                'color'=>'#0d9488', 'value'=> htmlspecialchars($info['version'] ?? '-')],
    ['label'=>'CPU Load',         'icon'=>'fa-gauge-high',         'color'=> $cpuClr,  'value'=> $cpuLoad . '%'],
    ['label'=>'Uptime',           'icon'=>'fa-clock-rotate-left',  'color'=>'#0891b2', 'value'=> htmlspecialchars($info['uptime'] ?? '-')],
    ['label'=>'Free Memory',      'icon'=>'fa-memory',             'color'=>'#16a34a', 'value'=> \Service\MikrotikService::formatBytes((int)($info['free-memory']  ?? 0))],
    ['label'=>'Total Memory',     'icon'=>'fa-server',             'color'=>'#64748b', 'value'=> \Service\MikrotikService::formatBytes((int)($info['total-memory'] ?? 0))],
    ['label'=>'Pelanggan',        'icon'=>'fa-users',              'color'=>'#2563eb', 'value'=> count($pelanggans)],
];
foreach ($sysFields as $f): ?>
<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:1.1rem 1.25rem;display:flex;align-items:center;gap:.875rem;box-shadow:0 1px 3px rgba(0,0,0,.04);transition:box-shadow .15s,transform .15s;"
     onmouseover="this.style.boxShadow='0 4px 12px rgba(0,0,0,.08)';this.style.transform='translateY(-1px)'"
     onmouseout="this.style.boxShadow='0 1px 3px rgba(0,0,0,.04)';this.style.transform=''">
    <div style="width:42px;height:42px;border-radius:10px;background:<?= $f['color'] ?>12;display:grid;place-items:center;flex-shrink:0;">
        <i class="fa-solid <?= $f['icon'] ?>" style="color:<?= $f['color'] ?>;font-size:.95rem;"></i>
    </div>
    <div style="min-width:0;">
        <div style="font-size:.68rem;color:#94a3b8;font-weight:600;text-transform:uppercase;letter-spacing:.04em;"><?= $f['label'] ?></div>
        <div style="font-size:1rem;font-weight:700;color:#0f172a;margin-top:.2rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= $f['value'] ?></div>
    </div>
</div>
<?php endforeach; ?>
</div>

<!-- ── QUICK ACTIONS ── -->
<div style="display:flex;flex-wrap:wrap;gap:.5rem;margin-bottom:1.75rem;">
    <a href="/mikrotik/queues" style="display:inline-flex;align-items:center;gap:.4rem;padding:.5rem 1rem;border-radius:8px;font-size:.82rem;font-weight:600;background:#f1f5f9;color:#475569;border:1px solid #e2e8f0;text-decoration:none;transition:all .15s;"
       onmouseover="this.style.background='#e2e8f0'" onmouseout="this.style.background='#f1f5f9'">
        <i class="fa-solid fa-gauge-high"></i> Simple Queue
    </a>
    <a href="/mikrotik/active" style="display:inline-flex;align-items:center;gap:.4rem;padding:.5rem 1rem;border-radius:8px;font-size:.82rem;font-weight:600;background:#f1f5f9;color:#475569;border:1px solid #e2e8f0;text-decoration:none;transition:all .15s;"
       onmouseover="this.style.background='#e2e8f0'" onmouseout="this.style.background='#f1f5f9'">
        <i class="fa-solid fa-wifi"></i> Sesi Aktif
    </a>
    <a href="/mikrotik/services" style="display:inline-flex;align-items:center;gap:.4rem;padding:.5rem 1rem;border-radius:8px;font-size:.82rem;font-weight:600;background:#f1f5f9;color:#475569;border:1px solid #e2e8f0;text-decoration:none;transition:all .15s;"
       onmouseover="this.style.background='#e2e8f0'" onmouseout="this.style.background='#f1f5f9'">
        <i class="fa-solid fa-list-check"></i> Layanan
    </a>
    <a href="/mikrotik/testpage" style="display:inline-flex;align-items:center;gap:.4rem;padding:.5rem 1rem;border-radius:8px;font-size:.82rem;font-weight:600;background:#eff6ff;color:#2563eb;border:1px solid #bfdbfe;text-decoration:none;transition:all .15s;"
       onmouseover="this.style.background='#dbeafe'" onmouseout="this.style.background='#eff6ff'">
        <i class="fa-solid fa-vial-circle-check"></i> Test Endpoint
    </a>
    <div style="flex:1;"></div>
    <button id="btnTestConn" style="display:inline-flex;align-items:center;gap:.4rem;padding:.5rem 1rem;border-radius:8px;font-size:.82rem;font-weight:600;background:#2563eb;color:#fff;border:none;cursor:pointer;transition:all .15s;"
       onmouseover="this.style.background='#1d4ed8'" onmouseout="this.style.background='#2563eb'">
        <i class="fa-solid fa-plug"></i> Test
    </button>
    <button onclick="location.reload()" style="display:inline-flex;align-items:center;gap:.4rem;padding:.5rem 1rem;border-radius:8px;font-size:.82rem;font-weight:600;background:#f1f5f9;color:#475569;border:1px solid #e2e8f0;cursor:pointer;transition:all .15s;"
       onmouseover="this.style.background='#e2e8f0'" onmouseout="this.style.background='#f1f5f9'">
        <i class="fa-solid fa-rotate-right"></i> Refresh
    </button>
</div>

<!-- ── STATUS PELANGGAN ── -->
<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.04);margin-bottom:1.75rem;">
    <div style="display:flex;justify-content:space-between;align-items:center;padding:1rem 1.25rem;border-bottom:1px solid #e2e8f0;">
        <div>
            <span style="font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#94a3b8;">Monitoring</span>
            <h3 style="margin:.15rem 0 0;font-size:1rem;font-weight:700;color:#0f172a;">
                <i class="fa-solid fa-circle-nodes" style="color:#2563eb;margin-right:.4rem;"></i>
                Status Pelanggan
            </h3>
        </div>
        <div style="display:flex;align-items:center;gap:.625rem;">
            <span id="pollCounter" style="font-size:.72rem;font-weight:600;padding:.2rem .6rem;border-radius:20px;background:#f1f5f9;color:#64748b;display:none;"></span>
            <span id="lastPoll" style="font-size:.72rem;color:#94a3b8;">—</span>
            <button id="btnPollAll" style="display:inline-flex;align-items:center;gap:.35rem;padding:.4rem .85rem;border-radius:7px;font-size:.78rem;font-weight:600;background:#f1f5f9;color:#475569;border:1px solid #e2e8f0;cursor:pointer;transition:all .15s;"
               onmouseover="this.style.background='#e2e8f0'" onmouseout="this.style.background='#f1f5f9'">
                <i class="fa-solid fa-arrow-rotate-right"></i> Poll
            </button>
        </div>
    </div>
    <div style="overflow-x:auto;">
        <table style="width:100%;border-collapse:collapse;font-size:.82rem;">
            <thead>
                <tr style="background:#f8fafc;border-bottom:1px solid #e2e8f0;">
                    <th style="padding:.7rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.03em;">#</th>
                    <th style="padding:.7rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.03em;">Pelanggan</th>
                    <th style="padding:.7rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.03em;">MAC Address</th>
                    <th style="padding:.7rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.03em;">Paket</th>
                    <th style="padding:.7rem 1rem;text-align:center;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.03em;">Status</th>
                    <th style="padding:.7rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.03em;">IP</th>
                    <th style="padding:.7rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.03em;">Uptime</th>
                    <th style="padding:.7rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.03em;">BW ↓/↑</th>
                    <th style="padding:.7rem 1rem;text-align:center;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.03em;">Aksi</th>
                </tr>
            </thead>
            <tbody id="pelangganTbody">
            <?php foreach ($pelanggans as $i => $p): ?>
            <tr data-mac="<?= htmlspecialchars($p['mac_address']) ?>"
                data-id="<?= $p['id'] ?>"
                style="border-bottom:1px solid #f1f5f9;transition:background .15s;"
                onmouseover="this.style.background='#f8fafc'"
                onmouseout="this.style.background=''">
                <td style="padding:.7rem 1rem;color:#94a3b8;font-size:.75rem;"><?= $i + 1 ?></td>
                <td style="padding:.7rem 1rem;">
                    <div style="font-weight:600;color:#0f172a;"><?= htmlspecialchars($p['nama_lengkap']) ?></div>
                    <div style="font-size:.72rem;color:#94a3b8;margin-top:.1rem;"><?= htmlspecialchars($p['no_telp'] ?? '') ?></div>
                </td>
                <td style="padding:.7rem 1rem;font-family:monospace;font-size:.75rem;color:#475569;">
                    <?= htmlspecialchars($p['mac_address']) ?>
                </td>
                <td style="padding:.7rem 1rem;">
                    <div style="color:#334155;font-weight:500;"><?= htmlspecialchars($p['nama_paket'] ?? '—') ?></div>
                    <div style="font-size:.72rem;color:#94a3b8;margin-top:.1rem;"><?= htmlspecialchars($p['kecepatan'] ?? '—') ?></div>
                </td>
                <td style="padding:.7rem 1rem;text-align:center;" class="pel-status-cell">
                    <span class="pel-status-badge" style="display:inline-flex;align-items:center;gap:.3rem;padding:.25rem .6rem;border-radius:20px;font-size:.72rem;font-weight:700;background:#f1f5f9;color:#94a3b8;">
                        <i class="fa-solid fa-circle-notch fa-spin" style="font-size:.55rem;"></i> Memuat…
                    </span>
                </td>
                <td style="padding:.7rem 1rem;font-family:monospace;font-size:.75rem;color:#475569;" class="pel-ip">—</td>
                <td style="padding:.7rem 1rem;color:#475569;" class="pel-uptime">—</td>
                <td style="padding:.7rem 1rem;font-family:monospace;font-size:.72rem;color:#475569;" class="pel-bw">—</td>
                <td style="padding:.7rem 1rem;text-align:center;">
                    <a href="/pelanggan/show/<?= $p['id'] ?>"
                       style="display:inline-flex;align-items:center;gap:.3rem;padding:.3rem .7rem;color:#2563eb;background:#eff6ff;border:1px solid #bfdbfe;border-radius:7px;text-decoration:none;font-size:.72rem;font-weight:600;transition:all .15s;"
                       onmouseover="this.style.background='#dbeafe'" onmouseout="this.style.background='#eff6ff'">
                        <i class="fa-solid fa-eye"></i> Detail
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($pelanggans)): ?>
            <tr><td colspan="9" style="text-align:center;padding:3.5rem;color:#94a3b8;">
                <i class="fa-solid fa-users-slash" style="font-size:1.8rem;display:block;margin-bottom:.75rem;opacity:.25;"></i>
                <span style="font-size:.85rem;">Belum ada pelanggan dengan MAC address terdaftar.</span>
            </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ── INTERFACE TABLE ── -->
<?php if (!empty($interfaces)): ?>
<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.04);">
    <div style="padding:1rem 1.25rem;border-bottom:1px solid #e2e8f0;">
        <h3 style="margin:0;font-size:1rem;font-weight:700;color:#0f172a;">
            <i class="fa-solid fa-ethernet" style="color:#0891b2;margin-right:.4rem;"></i>
            Daftar Interface
        </h3>
    </div>
    <div style="overflow-x:auto;">
        <table style="width:100%;border-collapse:collapse;font-size:.82rem;">
            <thead>
                <tr style="background:#f8fafc;border-bottom:1px solid #e2e8f0;">
                    <th style="padding:.6rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.03em;">Nama</th>
                    <th style="padding:.6rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.03em;">Tipe</th>
                    <th style="padding:.6rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.03em;">MAC</th>
                    <th style="padding:.6rem 1rem;text-align:center;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.03em;">Status</th>
                    <th style="padding:.6rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.03em;">TX / RX</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($interfaces as $iface):
                $running  = ($iface['running']  ?? 'false') === 'true';
                $disabled = ($iface['disabled'] ?? 'false') === 'true';
                $clr      = $disabled ? '#dc2626' : ($running ? '#16a34a' : '#94a3b8');
                $bgClr    = $disabled ? '#fef2f2' : ($running ? '#f0fdf4' : '#f8fafc');
                $lbl      = $disabled ? 'Disabled' : ($running ? 'Running' : 'Down');
                $tx       = \Service\MikrotikService::formatBytes((int)($iface['tx-byte'] ?? 0));
                $rx       = \Service\MikrotikService::formatBytes((int)($iface['rx-byte'] ?? 0));
            ?>
            <tr style="border-bottom:1px solid #f1f5f9;">
                <td style="padding:.6rem 1rem;font-weight:600;color:#0f172a;"><?= htmlspecialchars($iface['name'] ?? '-') ?></td>
                <td style="padding:.6rem 1rem;">
                    <span style="padding:.15rem .55rem;background:#f1f5f9;border-radius:5px;font-size:.72rem;color:#64748b;font-weight:500;">
                        <?= htmlspecialchars($iface['type'] ?? '-') ?>
                    </span>
                </td>
                <td style="padding:.6rem 1rem;font-family:monospace;font-size:.72rem;color:#64748b;"><?= htmlspecialchars($iface['mac-address'] ?? '-') ?></td>
                <td style="padding:.6rem 1rem;text-align:center;">
                    <span style="display:inline-flex;align-items:center;gap:.25rem;padding:.2rem .55rem;border-radius:20px;font-size:.7rem;font-weight:700;background:<?= $bgClr ?>;color:<?= $clr ?>;">
                        <i class="fa-solid fa-circle" style="font-size:.4rem;"></i> <?= $lbl ?>
                    </span>
                </td>
                <td style="padding:.6rem 1rem;font-family:monospace;font-size:.72rem;color:#64748b;"><?= $tx ?> / <?= $rx ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- ── MODAL TEST ── -->
<div id="modalTest" style="display:none;position:fixed;inset:0;z-index:9999;align-items:center;justify-content:center;background:rgba(0,0,0,.45);backdrop-filter:blur(2px);">
    <div style="background:#fff;border-radius:14px;padding:1.75rem;min-width:300px;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.15);">
        <div id="testResult">
            <i class="fa-solid fa-circle-notch fa-spin" style="font-size:1.8rem;color:#2563eb;"></i>
            <p style="margin:.875rem 0 0;font-size:.875rem;color:#64748b;">Menguji…</p>
        </div>
        <button onclick="document.getElementById('modalTest').style.display='none'"
                style="margin-top:1.25rem;padding:.45rem 1.5rem;border:1px solid #e2e8f0;border-radius:8px;background:#f8fafc;cursor:pointer;font-size:.82rem;font-weight:600;color:#475569;transition:all .15s;"
                onmouseover="this.style.background='#e2e8f0'" onmouseout="this.style.background='#f8fafc'">
            Tutup
        </button>
    </div>
</div>

<!-- ── SCRIPT ── -->
<script>
(function () {
    var onlineCount = 0;
    var offlineCount = 0;

    function pollAll() {
        fetch('/mikrotik/status')
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (!data.success) return;

                document.getElementById('lastPoll').textContent =
                    'Update: ' + new Date().toLocaleTimeString('id-ID');

                onlineCount = 0;
                offlineCount = 0;

                (data.data || []).forEach(function(row) {
                    var tr = document.querySelector('tr[data-mac="' + row.mac_address + '"]');
                    if (!tr) return;

                    var badge = tr.querySelector('.pel-status-badge');
                    var ipEl  = tr.querySelector('.pel-ip');
                    var uptEl = tr.querySelector('.pel-uptime');
                    var bwEl  = tr.querySelector('.pel-bw');

                    if (row.status === 'online') {
                        onlineCount++;
                        if (badge) {
                            badge.innerHTML = '<i class="fa-solid fa-circle" style="font-size:.45rem;"></i> Online';
                            badge.style.cssText = 'display:inline-flex;align-items:center;gap:.3rem;padding:.25rem .6rem;border-radius:20px;font-size:.72rem;font-weight:700;background:#f0fdf4;color:#16a34a;';
                        }
                        if (ipEl)  ipEl.textContent  = row.ip     || '—';
                        if (uptEl) uptEl.textContent = row.uptime || '—';
                        if (bwEl)  bwEl.textContent  = (row.rx_mbps || 0).toFixed(1) + '↓ / ' + (row.tx_mbps || 0).toFixed(1) + '↑';
                    } else {
                        offlineCount++;
                        if (badge) {
                            badge.innerHTML = '<i class="fa-solid fa-circle" style="font-size:.45rem;"></i> Offline';
                            badge.style.cssText = 'display:inline-flex;align-items:center;gap:.3rem;padding:.25rem .6rem;border-radius:20px;font-size:.72rem;font-weight:700;background:#fef2f2;color:#dc2626;';
                        }
                        if (ipEl)  ipEl.textContent  = '—';
                        if (uptEl) uptEl.textContent = '—';
                        if (bwEl)  bwEl.textContent  = '—';
                    }
                });

                // Update counter
                var counter = document.getElementById('pollCounter');
                if (counter && (onlineCount > 0 || offlineCount > 0)) {
                    counter.style.display = 'inline-flex';
                    counter.innerHTML = '<span style="color:#16a34a;">' + onlineCount + ' online</span> · <span style="color:#dc2626;">' + offlineCount + ' offline</span>';
                }
            })
            .catch(function() {
                document.getElementById('lastPoll').textContent = 'Update: Gagal';
            });
    }

    // Poll button
    var btnPoll = document.getElementById('btnPollAll');
    if (btnPoll) {
        btnPoll.addEventListener('click', function() {
            var icon = this.querySelector('i');
            if (icon) icon.className = 'fa-solid fa-circle-notch fa-spin';
            pollAll();
            setTimeout(function() {
                if (icon) icon.className = 'fa-solid fa-arrow-rotate-right';
            }, 1000);
        });
    }

    // Auto-poll
    pollAll();
    setInterval(pollAll, 30000);

    // ── Test Connection ──────────────────────────────────────
    var btnTest = document.getElementById('btnTestConn');
    if (btnTest) {
        btnTest.addEventListener('click', function() {
            var modal  = document.getElementById('modalTest');
            var result = document.getElementById('testResult');

            result.innerHTML =
                '<i class="fa-solid fa-circle-notch fa-spin" style="font-size:1.8rem;color:#2563eb;"></i>' +
                '<p style="margin:.875rem 0 0;font-size:.875rem;color:#64748b;">Menguji…</p>';
            modal.style.display = 'flex';

            fetch('/mikrotik/test')
                .then(function(r) { return r.json(); })
                .then(function(d) {
                    var ok = d.success;
                    result.innerHTML =
                        '<div style="width:56px;height:56px;border-radius:50%;background:' + (ok ? '#f0fdf4' : '#fef2f2') + ';display:grid;place-items:center;margin:0 auto .75rem;">' +
                            '<i class="fa-solid ' + (ok ? 'fa-check' : 'fa-xmark') + '" style="font-size:1.3rem;color:' + (ok ? '#16a34a' : '#dc2626') + ';"></i>' +
                        '</div>' +
                        '<p style="font-weight:700;margin:0 0 .25rem;font-size:1rem;color:' + (ok ? '#16a34a' : '#dc2626') + '">' +
                            (ok ? 'Berhasil' : 'Gagal') +
                        '</p>' +
                        '<p style="font-size:.82rem;color:#64748b;margin:0;line-height:1.5;">' + d.message + '</p>' +
                        (d.identity ? '<p style="font-size:.82rem;margin:.5rem 0 0;color:#475569;">Router: <strong style="color:#0f172a;">' + d.identity + '</strong></p>' : '');
                })
                .catch(function() {
                    result.innerHTML =
                        '<div style="width:56px;height:56px;border-radius:50%;background:#fef2f2;display:grid;place-items:center;margin:0 auto .75rem;">' +
                            '<i class="fa-solid fa-xmark" style="font-size:1.3rem;color:#dc2626;"></i>' +
                        '</div>' +
                        '<p style="font-weight:700;color:#dc2626;margin:0;">Error</p>' +
                        '<p style="font-size:.82rem;color:#64748b;margin:.25rem 0 0;">Gagal menghubungi server.</p>';
                });
        });
    }

    // Close modal on backdrop click
    var modal = document.getElementById('modalTest');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === this) this.style.display = 'none';
        });
    }
})();
</script>
