<?php
/**
 * views/Mikrotik/test.php
 * Halaman Test Koneksi MikroTik — visual endpoint tester
 */
?>

<div style="max-width:900px;margin:0 auto;">

    <!-- Back -->
    <a href="/mikrotik" style="display:inline-flex;align-items:center;gap:.4rem;color:#64748b;font-size:.875rem;text-decoration:none;margin-bottom:1.25rem;">
        <i class="fa-solid fa-arrow-left"></i> Kembali ke Dashboard
    </a>

    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06);margin-bottom:1.5rem;">
        <div style="padding:1.25rem;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;gap:.75rem;">
            <div style="width:42px;height:42px;border-radius:10px;background:#eff6ff;display:grid;place-items:center;">
                <i class="fa-solid fa-vial-circle-check" style="color:#2563eb;font-size:1.1rem;"></i>
            </div>
            <div>
                <h2 style="margin:0;font-size:1.1rem;font-weight:700;color:#0f172a;">Test Koneksi MikroTik</h2>
                <p style="margin:.15rem 0 0;font-size:.78rem;color:#64748b;">Uji semua endpoint API secara manual</p>
            </div>
        </div>
        <div style="padding:1.25rem;display:flex;gap:.5rem;flex-wrap:wrap;">
            <button class="btn-test btn-test--all" id="btnRunAll">
                <i class="fa-solid fa-play"></i> Jalankan Semua Test
            </button>
            <button class="btn-test btn-test--clear" id="btnClearAll">
                <i class="fa-solid fa-eraser"></i> Bersihkan Hasil
            </button>
        </div>
    </div>

    <!-- ── TEST ENDPOINTS ── -->
    <div id="testGrid" style="display:grid;grid-template-columns:1fr;gap:1rem;">
    </div>

    <!-- ── SUMMARY ── -->
    <div id="summaryCard" style="display:none;margin-top:1.5rem;background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:1.25rem;box-shadow:0 1px 3px rgba(0,0,0,.06);">
        <h3 style="margin:0 0 .75rem;font-size:.9rem;font-weight:700;color:#0f172a;">
            <i class="fa-solid fa-chart-bar" style="color:#2563eb;margin-right:.4rem;"></i> Ringkasan
        </h3>
        <div style="display:flex;gap:1rem;flex-wrap:wrap;">
            <div id="sumPass" style="flex:1;min-width:120px;padding:.75rem;background:#dcfce7;border:1px solid #86efac;border-radius:8px;text-align:center;">
                <div style="font-size:1.5rem;font-weight:700;color:#16a34a;" id="countPass">0</div>
                <div style="font-size:.72rem;font-weight:600;color:#15803d;text-transform:uppercase;">Berhasil</div>
            </div>
            <div id="sumFail" style="flex:1;min-width:120px;padding:.75rem;background:#fee2e2;border:1px solid #fca5a5;border-radius:8px;text-align:center;">
                <div style="font-size:1.5rem;font-weight:700;color:#dc2626;" id="countFail">0</div>
                <div style="font-size:.72rem;font-weight:600;color:#991b1b;text-transform:uppercase;">Gagal</div>
            </div>
            <div id="sumTime" style="flex:1;min-width:120px;padding:.75rem;background:#f0f9ff;border:1px solid #7dd3fc;border-radius:8px;text-align:center;">
                <div style="font-size:1.5rem;font-weight:700;color:#0284c7;" id="countTime">0ms</div>
                <div style="font-size:.72rem;font-weight:600;color:#0369a1;text-transform:uppercase;">Total Waktu</div>
            </div>
        </div>
    </div>

</div>

<style>
.btn-test {
    display:inline-flex;align-items:center;gap:.4rem;
    padding:.5rem 1rem;border-radius:8px;font-size:.82rem;font-weight:600;
    cursor:pointer;border:none;transition:all .15s;
}
.btn-test--all { background:#2563eb;color:#fff; }
.btn-test--all:hover { background:#1d4ed8; }
.btn-test--all:disabled { background:#93c5fd;cursor:not-allowed; }
.btn-test--clear { background:#f1f5f9;color:#475569;border:1px solid #e2e8f0; }
.btn-test--clear:hover { background:#e2e8f0; }

.test-card {
    background:#fff;border:1px solid #e2e8f0;border-radius:10px;overflow:hidden;
    box-shadow:0 1px 3px rgba(0,0,0,.04);transition:border-color .2s;
}
.test-card--pass { border-color:#86efac; }
.test-card--fail { border-color:#fca5a5; }
.test-card--loading { border-color:#7dd3fc; }

.test-card__header {
    display:flex;align-items:center;justify-content:space-between;
    padding:.875rem 1rem;border-bottom:1px solid #f1f5f9;
}
.test-card__title {
    display:flex;align-items:center;gap:.6rem;
}
.test-card__icon {
    width:32px;height:32px;border-radius:8px;display:grid;place-items:center;font-size:.85rem;
}
.test-card__name { font-size:.85rem;font-weight:700;color:#0f172a; }
.test-card__url  { font-size:.72rem;font-family:monospace;color:#64748b; }

.test-card__badge {
    padding:.2rem .6rem;border-radius:20px;font-size:.68rem;font-weight:700;
    display:inline-flex;align-items:center;gap:.3rem;
}
.badge--idle    { background:#f1f5f9;color:#94a3b8; }
.badge--loading { background:#e0f2fe;color:#0284c7; }
.badge--pass    { background:#dcfce7;color:#16a34a; }
.badge--fail    { background:#fee2e2;color:#dc2626; }

.test-card__body { padding:1rem;display:none; }
.test-card__body.is-open { display:block; }

.test-card__response {
    background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;
    padding:.75rem;font-family:monospace;font-size:.75rem;color:#334155;
    max-height:300px;overflow:auto;white-space:pre-wrap;word-break:break-all;
}

.test-card__meta {
    display:flex;gap:1rem;margin-bottom:.75rem;font-size:.75rem;color:#64748b;
}
.test-card__meta strong { color:#0f172a; }

.test-card__btn {
    padding:.35rem .75rem;border-radius:6px;font-size:.72rem;font-weight:600;
    cursor:pointer;border:1px solid #e2e8f0;background:#f8fafc;color:#475569;
    transition:all .15s;
}
.test-card__btn:hover { background:#e2e8f0; }

.test-card__toggle {
    background:none;border:none;cursor:pointer;color:#64748b;font-size:.75rem;
    padding:.25rem .5rem;border-radius:4px;
}
.test-card__toggle:hover { background:#f1f5f9;color:#0f172a; }
</style>

<script>
(function(){
    /**
     * Definisi endpoint yang akan di-test
     * Setiap endpoint: nama, URL, method, icon, deskripsi
     */
    var ENDPOINTS = [
        {
            name: 'System Info',
            url:  '/mikrotik/test',
            method: 'GET',
            icon: 'fa-server',
            color: '#2563eb',
            desc: 'Test koneksi dasar ke MikroTik'
        },
        {
            name: 'Status Pelanggan',
            url:  '/mikrotik/status',
            method: 'GET',
            icon: 'fa-circle-nodes',
            color: '#7c3aed',
            desc: 'Ambil status online/offline semua pelanggan'
        }
    ];

    var grid    = document.getElementById('testGrid');
    var results = {};

    // ── Build test cards ──────────────────────────────────────
    ENDPOINTS.forEach(function(ep, idx){
        var card = document.createElement('div');
        card.className = 'test-card';
        card.id = 'test-' + idx;
        card.innerHTML =
            '<div class="test-card__header">' +
                '<div class="test-card__title">' +
                    '<div class="test-card__icon" style="background:' + ep.color + '1a;">' +
                        '<i class="fa-solid ' + ep.icon + '" style="color:' + ep.color + ';"></i>' +
                    '</div>' +
                    '<div>' +
                        '<div class="test-card__name">' + ep.name + '</div>' +
                        '<div class="test-card__url">' + ep.method + ' ' + ep.url + '</div>' +
                    '</div>' +
                '</div>' +
                '<div style="display:flex;align-items:center;gap:.5rem;">' +
                    '<span class="test-card__badge badge--idle" id="badge-' + idx + '">' +
                        '<i class="fa-solid fa-minus" style="font-size:.5rem;"></i> Belum diuji' +
                    '</span>' +
                    '<button class="test-card__btn" onclick="window._runTest(' + idx + ')">' +
                        '<i class="fa-solid fa-play"></i> Test' +
                    '</button>' +
                    '<button class="test-card__toggle" onclick="window._toggleBody(' + idx + ')" title="Lihat detail">' +
                        '<i class="fa-solid fa-chevron-down"></i>' +
                    '</button>' +
                '</div>' +
            '</div>' +
            '<div class="test-card__body" id="body-' + idx + '">' +
                '<p style="font-size:.78rem;color:#64748b;margin:0 0 .75rem;">' + ep.desc + '</p>' +
                '<div class="test-card__meta" id="meta-' + idx + '" style="display:none;">' +
                    '<span>Status: <strong id="httpCode-' + idx + '">—</strong></span>' +
                    '<span>Waktu: <strong id="elapsed-' + idx + '">—</strong></span>' +
                '</div>' +
                '<div class="test-card__response" id="response-' + idx + '">Belum ada data.</div>' +
            '</div>';
        grid.appendChild(card);
    });

    // ── Run single test ──────────────────────────────────────
    window._runTest = function(idx){
        var ep   = ENDPOINTS[idx];
        var card = document.getElementById('test-' + idx);
        var badge = document.getElementById('badge-' + idx);
        var body  = document.getElementById('body-' + idx);
        var meta  = document.getElementById('meta-' + idx);
        var resp  = document.getElementById('response-' + idx);
        var code  = document.getElementById('httpCode-' + idx);
        var elapsed = document.getElementById('elapsed-' + idx);

        card.className = 'test-card test-card--loading';
        badge.className = 'test-card__badge badge--loading';
        badge.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin" style="font-size:.5rem;"></i> Menguji…';
        body.className = 'test-card__body is-open';
        meta.style.display = 'flex';
        resp.textContent = 'Loading…';

        var t0 = performance.now();

        fetch(ep.url, { method: ep.method })
            .then(function(r){
                var t1 = performance.now();
                var ms = Math.round(t1 - t0);

                code.textContent = r.status;
                elapsed.textContent = ms + 'ms';

                return r.text().then(function(text){
                    var json;
                    try { json = JSON.parse(text); } catch(e) { json = text; }

                    var ok = r.ok;
                    card.className = 'test-card ' + (ok ? 'test-card--pass' : 'test-card--fail');
                    badge.className = 'test-card__badge ' + (ok ? 'badge--pass' : 'badge--fail');
                    badge.innerHTML = ok
                        ? '<i class="fa-solid fa-check" style="font-size:.5rem;"></i> OK ' + r.status
                        : '<i class="fa-solid fa-xmark" style="font-size:.5rem;"></i> Error ' + r.status;

                    resp.textContent = typeof json === 'object'
                        ? JSON.stringify(json, null, 2)
                        : json;

                    results[idx] = { pass: ok, ms: ms };
                });
            })
            .catch(function(err){
                var t1 = performance.now();
                card.className = 'test-card test-card--fail';
                badge.className = 'test-card__badge badge--fail';
                badge.innerHTML = '<i class="fa-solid fa-xmark" style="font-size:.5rem;"></i> Gagal';
                code.textContent = 'ERR';
                elapsed.textContent = Math.round(t1 - t0) + 'ms';
                resp.textContent = 'Error: ' + err.message;
                results[idx] = { pass: false, ms: Math.round(t1 - t0) };
            });
    };

    // ── Toggle body ──────────────────────────────────────────
    window._toggleBody = function(idx){
        var body = document.getElementById('body-' + idx);
        body.classList.toggle('is-open');
    };

    // ── Run all tests ────────────────────────────────────────
    document.getElementById('btnRunAll').addEventListener('click', function(){
        var btn = this;
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Menguji semua…';
        results = {};

        var totalStart = performance.now();

        var chain = Promise.resolve();
        ENDPOINTS.forEach(function(ep, idx){
            chain = chain.then(function(){
                return new Promise(function(resolve){
                    window._runTest(idx);
                    setTimeout(resolve, 300); // slight delay for visual effect
                });
            });
        });

        chain.then(function(){
            setTimeout(function(){
                btn.disabled = false;
                btn.innerHTML = '<i class="fa-solid fa-play"></i> Jalankan Semua Test';

                // Show summary
                var pass = 0, fail = 0, totalMs = 0;
                Object.keys(results).forEach(function(k){
                    if(results[k].pass) pass++; else fail++;
                    totalMs += results[k].ms;
                });

                document.getElementById('countPass').textContent = pass;
                document.getElementById('countFail').textContent = fail;
                document.getElementById('countTime').textContent = Math.round(performance.now() - totalStart) + 'ms';
                document.getElementById('summaryCard').style.display = 'block';
            }, 500);
        });
    });

    // ── Clear results ────────────────────────────────────────
    document.getElementById('btnClearAll').addEventListener('click', function(){
        ENDPOINTS.forEach(function(ep, idx){
            var card  = document.getElementById('test-' + idx);
            var badge = document.getElementById('badge-' + idx);
            var body  = document.getElementById('body-' + idx);
            var resp  = document.getElementById('response-' + idx);
            var meta  = document.getElementById('meta-' + idx);

            card.className = 'test-card';
            badge.className = 'test-card__badge badge--idle';
            badge.innerHTML = '<i class="fa-solid fa-minus" style="font-size:.5rem;"></i> Belum diuji';
            body.className = 'test-card__body';
            meta.style.display = 'none';
            resp.textContent = 'Belum ada data.';
        });
        document.getElementById('summaryCard').style.display = 'none';
        results = {};
    });

})();
</script>
