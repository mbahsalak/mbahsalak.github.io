<?php
/**
 * views/pages/Mikrotik/services.php
 * Layanan teknis pelanggan — filter by MAC address only
 * Controller kirim: $pelanggans (array), $flash (?array), $user (array)
 */
$flash = $flash ?? null;
?>

<?php if (!empty($flash)): ?>
<div style="padding:.75rem 1rem;border-radius:8px;font-size:.875rem;font-weight:500;margin-bottom:1rem;
    <?= ($flash['type'] ?? '') === 'success'
        ? 'background:#f0fdf4;color:#166534;border:1px solid #bbf7d0;'
        : 'background:#fff1f2;color:#991b1b;border:1px solid #fecaca;' ?>">
    <i class="fa-solid fa-<?= ($flash['type'] ?? '') === 'success' ? 'check-circle' : 'circle-exclamation' ?>" style="margin-right:.4rem;"></i>
    <?= htmlspecialchars($flash['message'] ?? '') ?>
</div>
<?php endif; ?>

<!-- ── HEADER ── -->
<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.75rem;margin-bottom:1.25rem;">
    <div>
        <h4 style="margin:0 0 .2rem;font-weight:700;font-size:1.05rem;color:#0f172a;">
            <i class="fa-solid fa-list-check" style="color:#2563eb;margin-right:.4rem;"></i>
            Layanan Teknis Pelanggan
        </h4>
        <p style="margin:0;font-size:.75rem;color:#94a3b8;">Diidentifikasi via MAC address — tanpa PPPoE secret</p>
    </div>
    <div style="display:flex;gap:.5rem;">
        <input type="text" id="searchService" placeholder="Cari nama / MAC / paket..."
               oninput="filterService()"
               style="font-size:.8rem;border:1.5px solid #e2e8f0;border-radius:8px;padding:.375rem .75rem;width:14rem;outline:none;">
        <a href="/mikrotik" class="btn btn--ghost btn--sm">
            <i class="fa-solid fa-arrow-left"></i> Kembali
        </a>
    </div>
</div>

<!-- ── STATS ── -->
<?php
$total     = count($pelanggans ?? []);
$adaMac    = count(array_filter($pelanggans ?? [], fn($p) => !empty($p['mac_address'])));
$tanpaMac  = $total - $adaMac;
?>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:.75rem;margin-bottom:1.25rem;">
    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:.875rem 1rem;box-shadow:0 1px 3px rgba(0,0,0,.06);">
        <div style="font-size:.65rem;color:#94a3b8;font-weight:700;text-transform:uppercase;margin-bottom:.3rem;">Total Pelanggan</div>
        <div style="font-size:1.5rem;font-weight:700;color:#2563eb;"><?= $total ?></div>
    </div>
    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:.875rem 1rem;box-shadow:0 1px 3px rgba(0,0,0,.06);">
        <div style="font-size:.65rem;color:#94a3b8;font-weight:700;text-transform:uppercase;margin-bottom:.3rem;">Ada MAC</div>
        <div style="font-size:1.5rem;font-weight:700;color:#16a34a;"><?= $adaMac ?></div>
    </div>
    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:.875rem 1rem;box-shadow:0 1px 3px rgba(0,0,0,.06);">
        <div style="font-size:.65rem;color:#94a3b8;font-weight:700;text-transform:uppercase;margin-bottom:.3rem;">Tanpa MAC</div>
        <div style="font-size:1.5rem;font-weight:700;color:#dc2626;"><?= $tanpaMac ?></div>
    </div>
</div>

<!-- ── TABEL ── -->
<div class="card" style="overflow:hidden;">
    <div style="overflow-x:auto;">
        <table style="width:100%;border-collapse:collapse;font-size:.8rem;" id="tableService">
            <thead>
                <tr style="background:#f8fafc;border-bottom:1px solid #e2e8f0;">
                    <th style="padding:.625rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">#</th>
                    <th style="padding:.625rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">Pelanggan</th>
                    <th style="padding:.625rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">MAC Address</th>
                    <th style="padding:.625rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">Paket</th>
                    <th style="padding:.625rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">Kecepatan</th>
                    <th style="padding:.625rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">Alamat</th>
                    <th style="padding:.625rem 1rem;text-align:center;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">MAC Status</th>
                    <th style="padding:.625rem 1rem;text-align:center;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">Aksi</th>
                </tr>
            </thead>
            <tbody id="serviceTbody">
            <?php if (empty($pelanggans)): ?>
                <tr>
                    <td colspan="8" style="text-align:center;padding:3rem;color:#94a3b8;">
                        <i class="fa-solid fa-users-slash" style="font-size:1.5rem;display:block;margin-bottom:.5rem;opacity:.3;"></i>
                        Tidak ada pelanggan.
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($pelanggans as $i => $p):
                    $hasMac = !empty($p['mac_address']);
                ?>
                <tr class="svc-row" style="border-top:1px solid #f1f5f9;"
                    onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background=''">
                    <td style="padding:.625rem 1rem;color:#94a3b8;"><?= $i + 1 ?></td>
                    <td style="padding:.625rem 1rem;">
                        <div style="font-weight:600;color:#0f172a;">
                            <a href="/pelanggan/show/<?= $p['id'] ?>" style="color:inherit;text-decoration:none;">
                                <?= htmlspecialchars($p['nama_lengkap']) ?>
                            </a>
                        </div>
                        <div style="font-size:.7rem;color:#94a3b8;"><?= htmlspecialchars($p['no_telp'] ?? '') ?></div>
                    </td>
                    <td style="padding:.625rem 1rem;">
                        <?php if ($hasMac): ?>
                        <span style="font-family:monospace;font-size:.75rem;font-weight:600;color:#374151;">
                            <?= htmlspecialchars($p['mac_address']) ?>
                        </span>
                        <?php else: ?>
                        <span style="color:#94a3b8;font-style:italic;font-size:.78rem;">— Belum diisi</span>
                        <?php endif; ?>
                    </td>
                    <td style="padding:.625rem 1rem;color:#374151;"><?= htmlspecialchars($p['nama_paket'] ?? '—') ?></td>
                    <td style="padding:.625rem 1rem;font-family:monospace;font-size:.75rem;color:#374151;"><?= htmlspecialchars($p['kecepatan'] ?? '—') ?></td>
                    <td style="padding:.625rem 1rem;font-size:.78rem;color:#64748b;">
                        <?= htmlspecialchars(mb_strimwidth($p['alamat'] ?? '—', 0, 45, '…')) ?>
                    </td>
                    <td style="padding:.625rem 1rem;text-align:center;">
                        <?php if ($hasMac): ?>
                        <span style="padding:.2rem .6rem;border-radius:6px;font-size:.7rem;font-weight:700;background:#dcfce7;color:#16a34a;">
                            <i class="fa-solid fa-check" style="font-size:.6rem;margin-right:.2rem;"></i>Ada MAC
                        </span>
                        <?php else: ?>
                        <span style="padding:.2rem .6rem;border-radius:6px;font-size:.7rem;font-weight:700;background:#fee2e2;color:#dc2626;">
                            <i class="fa-solid fa-xmark" style="font-size:.6rem;margin-right:.2rem;"></i>No MAC
                        </span>
                        <?php endif; ?>
                    </td>
                    <td style="padding:.625rem 1rem;text-align:center;">
                        <div style="display:flex;justify-content:center;gap:.3rem;flex-wrap:wrap;">
                            <a href="/pelanggan/show/<?= $p['id'] ?>"
                               title="Detail" style="padding:.3rem .6rem;color:#2563eb;background:none;border:1.5px solid #bfdbfe;border-radius:7px;text-decoration:none;font-size:.72rem;">
                                <i class="fa-solid fa-eye"></i>
                            </a>
                            <a href="/pelanggan/edit/<?= $p['id'] ?>"
                               title="Edit" style="padding:.3rem .6rem;color:#d97706;background:none;border:1.5px solid #fde68a;border-radius:7px;text-decoration:none;font-size:.72rem;">
                                <i class="fa-solid fa-pen"></i>
                            </a>
                            <?php if ($hasMac): ?>
                            <button title="Poll Status"
                                    onclick="pollSingle('<?= htmlspecialchars($p['mac_address'], ENT_QUOTES) ?>', <?= $p['id'] ?>)"
                                    style="padding:.3rem .6rem;color:#0891b2;background:none;border:1.5px solid #a5f3fc;border-radius:7px;font-size:.72rem;cursor:pointer;">
                                <i class="fa-solid fa-rotate-right" id="spinBtn-<?= $p['id'] ?>"></i>
                            </button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function filterService() {
    const q = document.getElementById('searchService').value.toLowerCase();
    document.querySelectorAll('#serviceTbody .svc-row').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
}

function pollSingle(mac, pelId) {
    const spin = document.getElementById('spinBtn-' + pelId);
    if (spin) spin.classList.add('fa-spin');

    fetch('/pelanggan/' + pelId + '/uptime')
        .then(r => r.json())
        .then(d => {
            if (spin) spin.classList.remove('fa-spin');
            const row = document.querySelector(`tr td span[style*="monospace"]:not([id])`)?.closest('tr');
            // Tampilkan mini-result via alert sederhana
            alert(
                (d.status === 'online' ? '✅ Online' : '❌ Offline') + '\n' +
                'Uptime: ' + (d.uptime_human || '—') + '\n' +
                'IP: ' + (d.ip || '—')
            );
        })
        .catch(() => {
            if (spin) spin.classList.remove('fa-spin');
            alert('Gagal polling MAC: ' + mac);
        });
}
</script>
