<?php
/**
 * views/pages/Mikrotik/active.php
 * Klien aktif — deteksi by MAC address (bukan PPPoE)
 * Controller kirim: $active (array), $pelanggans (array), $error (?string)
 */
$flashSuccess = $_SESSION['flash_success'] ?? null;
$flashError   = $_SESSION['flash_error']   ?? null;
unset($_SESSION['flash_success'], $_SESSION['flash_error']);

// Bangun lookup pelanggan by MAC (lowercase, tanpa spasi)
$pelByMac = [];
foreach ($pelanggans ?? [] as $p) {
    $key = strtolower(trim($p['mac_address'] ?? ''));
    if ($key) $pelByMac[$key] = $p;
}

// Hitung total sesi yang cocok dengan MAC pelanggan terdaftar
$matched   = 0;
$unmatched = 0;
foreach ($active ?? [] as $a) {
    $mac = strtolower(trim($a['mac_address'] ?? ''));
    isset($pelByMac[$mac]) ? $matched++ : $unmatched++;
}
?>

<?php if ($flashSuccess): ?>
<div style="background:#dcfce7;border:1px solid #86efac;border-radius:8px;padding:.7rem 1rem;margin-bottom:1rem;font-size:.85rem;color:#166534;">
    <i class="fa-solid fa-check-circle" style="margin-right:.4rem;"></i><?= htmlspecialchars($flashSuccess) ?>
</div>
<?php endif; ?>
<?php if ($flashError): ?>
<div style="background:#fee2e2;border:1px solid #fca5a5;border-radius:8px;padding:.7rem 1rem;margin-bottom:1rem;font-size:.85rem;color:#991b1b;">
    <i class="fa-solid fa-circle-xmark" style="margin-right:.4rem;"></i><?= htmlspecialchars($flashError) ?>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div style="background:#fee2e2;border:1px solid #fca5a5;border-radius:10px;padding:.875rem 1rem;margin-bottom:1.25rem;display:flex;gap:.75rem;">
    <i class="fa-solid fa-triangle-exclamation" style="color:#dc2626;flex-shrink:0;margin-top:.1rem;"></i>
    <div>
        <strong style="font-size:.875rem;color:#991b1b;display:block;margin-bottom:.2rem;">Gagal Terhubung ke MikroTik</strong>
        <span style="font-size:.8rem;color:#b91c1c;"><?= htmlspecialchars($error) ?></span>
    </div>
</div>
<?php else: ?>

<!-- ── STATS ── -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:.75rem;margin-bottom:1.25rem;">
    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:.875rem 1rem;box-shadow:0 1px 3px rgba(0,0,0,.06);">
        <div style="font-size:.65rem;color:#94a3b8;font-weight:700;text-transform:uppercase;margin-bottom:.3rem;">Total Klien Aktif</div>
        <div style="font-size:1.5rem;font-weight:700;color:#2563eb;"><?= count($active ?? []) ?></div>
    </div>
    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:.875rem 1rem;box-shadow:0 1px 3px rgba(0,0,0,.06);">
        <div style="font-size:.65rem;color:#94a3b8;font-weight:700;text-transform:uppercase;margin-bottom:.3rem;">Cocok Pelanggan</div>
        <div style="font-size:1.5rem;font-weight:700;color:#16a34a;"><?= $matched ?></div>
    </div>
    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:.875rem 1rem;box-shadow:0 1px 3px rgba(0,0,0,.06);">
        <div style="font-size:.65rem;color:#94a3b8;font-weight:700;text-transform:uppercase;margin-bottom:.3rem;">Tidak Dikenal</div>
        <div style="font-size:1.5rem;font-weight:700;color:#d97706;"><?= $unmatched ?></div>
    </div>
    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:.875rem 1rem;box-shadow:0 1px 3px rgba(0,0,0,.06);">
        <div style="font-size:.65rem;color:#94a3b8;font-weight:700;text-transform:uppercase;margin-bottom:.3rem;">Terdaftar di DB</div>
        <div style="font-size:1.5rem;font-weight:700;color:#7c3aed;"><?= count($pelByMac) ?></div>
    </div>
</div>

<!-- ── TOOLBAR ── -->
<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.75rem;margin-bottom:1rem;">
    <div>
        <span style="font-size:.875rem;font-weight:700;color:#0f172a;">
            <i class="fa-solid fa-network-wired" style="color:#16a34a;margin-right:.4rem;"></i>
            Klien Aktif (Deteksi MAC Address)
        </span>
    </div>
    <div style="display:flex;align-items:center;gap:.5rem;">
        <input type="text" id="searchActive" placeholder="Cari MAC / nama pelanggan..."
               style="font-size:.8rem;border:1.5px solid #e2e8f0;border-radius:8px;padding:.375rem .75rem;width:14rem;outline:none;"
               oninput="filterActive()">
        <label style="display:flex;align-items:center;gap:.35rem;font-size:.8rem;color:#64748b;cursor:pointer;">
            <input type="checkbox" id="onlyMatched" onchange="filterActive()"> Hanya yg cocok
        </label>
        <button onclick="location.reload()"
                style="padding:.375rem .75rem;border:1.5px solid #e2e8f0;border-radius:8px;background:#fff;cursor:pointer;font-size:.8rem;color:#64748b;">
            <i class="fa-solid fa-rotate-right"></i>
        </button>
        <span id="refreshBadge" style="font-size:.72rem;color:#94a3b8;"></span>
    </div>
</div>

<!-- ── TABLE ── -->
<div class="card" style="overflow:hidden;">
    <div style="overflow-x:auto;">
        <table style="width:100%;border-collapse:collapse;font-size:.8rem;" id="tableActive">
            <thead>
                <tr style="background:#f8fafc;border-bottom:1px solid #e2e8f0;">
                    <th style="padding:.625rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">#</th>
                    <th style="padding:.625rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">MAC Address</th>
                    <th style="padding:.625rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">Pelanggan</th>
                    <th style="padding:.625rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">IP Address</th>
                    <th style="padding:.625rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">Hostname</th>
                    <th style="padding:.625rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">Uptime</th>
                    <th style="padding:.625rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">TX / RX</th>
                    <th style="padding:.625rem 1rem;text-align:left;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">Paket</th>
                    <th style="padding:.625rem 1rem;text-align:center;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;">Aksi</th>
                </tr>
            </thead>
            <tbody id="activeTbody">
            <?php if (empty($active)): ?>
                <tr>
                    <td colspan="9" style="text-align:center;padding:3rem;color:#94a3b8;">
                        <i class="fa-solid fa-wifi" style="font-size:1.5rem;display:block;margin-bottom:.5rem;opacity:.3;"></i>
                        Tidak ada klien aktif terdeteksi.
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($active as $i => $a):
                    // ── AMBIL MAC ADDRESS (sudah dinormalisasi oleh Service) ──
                    $mac     = strtolower(trim($a['mac_address'] ?? ''));
                    $pel     = $pelByMac[$mac] ?? null;
                    $macDisp = strtoupper($mac ?: '-');
                    $ip      = $a['ip_address'] ?? '-';
                    $host    = $a['hostname']   ?? '-';
                    $uptime  = $a['uptime']     ?? '-';
                    $iface   = $a['interface']  ?? '-';
                    $signal  = $a['signal']     ?? '';
                    $source  = $a['source']     ?? 'unknown';
                    $tx      = \Service\MikrotikService::formatBytes((int)($a['tx_bytes'] ?? 0));
                    $rx      = \Service\MikrotikService::formatBytes((int)($a['rx_bytes'] ?? 0));
                ?>
                <tr class="active-row <?= $pel ? 'row-matched' : 'row-unknown' ?>"
                    style="border-top:1px solid #f1f5f9;"
                    onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background=''">
                    <td style="padding:.625rem 1rem;color:#94a3b8;"><?= $i + 1 ?></td>

                    <!-- MAC ADDRESS -->
                    <td style="padding:.625rem 1rem;">
                        <div style="font-family:monospace;font-size:.75rem;font-weight:600;color:#374151;">
                            <?= htmlspecialchars($macDisp) ?>
                        </div>
                        <div style="font-size:.65rem;color:#94a3b8;margin-top:.15rem;">
                            <?php if ($signal): ?>
                                <span style="color:#16a34a;"><?= htmlspecialchars($signal) ?></span>
                                <span style="margin:0 .2rem;">·</span>
                            <?php endif; ?>
                            <span style="background:#f1f5f9;padding:.1rem .35rem;border-radius:3px;"><?= htmlspecialchars($source) ?></span>
                        </div>
                    </td>

                    <!-- PELANGGAN -->
                    <td style="padding:.625rem 1rem;">
                        <?php if ($pel): ?>
                        <div style="font-weight:600;color:#0f172a;">
                            <a href="/pelanggan/show/<?= $pel['id'] ?>" style="color:inherit;text-decoration:none;">
                                <?= htmlspecialchars($pel['nama_lengkap']) ?>
                            </a>
                        </div>
                        <div style="font-size:.7rem;color:#94a3b8;"><?= htmlspecialchars($pel['no_telp'] ?? '') ?></div>
                        <?php else: ?>
                        <span style="color:#94a3b8;font-style:italic;font-size:.78rem;">— Tidak terdaftar</span>
                        <?php endif; ?>
                    </td>

                    <!-- IP ADDRESS -->
                    <td style="padding:.625rem 1rem;font-family:monospace;font-size:.75rem;color:#374151;">
                        <?= htmlspecialchars($ip) ?>
                    </td>

                    <!-- HOSTNAME -->
                    <td style="padding:.625rem 1rem;font-size:.75rem;color:#374151;">
                        <div><?= htmlspecialchars($host) ?></div>
                        <div style="font-size:.65rem;color:#94a3b8;"><?= htmlspecialchars($iface) ?></div>
                    </td>

                    <!-- UPTIME -->
                    <td style="padding:.625rem 1rem;color:#374151;"><?= htmlspecialchars($uptime) ?></td>

                    <!-- TX / RX -->
                    <td style="padding:.625rem 1rem;font-family:monospace;font-size:.72rem;color:#64748b;">
                        <div title="TX (Upload)"><?= $tx ?></div>
                        <div title="RX (Download)" style="color:#94a3b8;"><?= $rx ?></div>
                    </td>

                    <!-- PAKET -->
                    <td style="padding:.625rem 1rem;">
                        <?php if ($pel): ?>
                        <div style="font-size:.78rem;color:#374151;"><?= htmlspecialchars($pel['nama_paket'] ?? '—') ?></div>
                        <div style="font-size:.68rem;color:#94a3b8;"><?= htmlspecialchars($pel['kecepatan'] ?? '') ?></div>
                        <?php else: ?>
                        <span style="color:#94a3b8;">—</span>
                        <?php endif; ?>
                    </td>

                    <!-- AKSI -->
                    <td style="padding:.625rem 1rem;text-align:center;">
                        <div style="display:flex;justify-content:center;gap:.25rem;">
                            <?php if ($pel): ?>
                            <a href="/pelanggan/show/<?= $pel['id'] ?>"
                               style="padding:.3rem .6rem;color:#2563eb;background:none;border:1.5px solid #bfdbfe;border-radius:7px;text-decoration:none;font-size:.72rem;"
                               title="Detail Pelanggan">
                                <i class="fa-solid fa-eye"></i>
                            </a>
                            <?php endif; ?>
                            <a href="/mikrotik/active/kick/<?= str_replace(':', '-', $macDisp) ?>"
                               style="padding:.3rem .6rem;color:#dc2626;background:none;border:1.5px solid #fecaca;border-radius:7px;text-decoration:none;font-size:.72rem;"
                               title="Putus Koneksi"
                               onclick="return confirm('Putus koneksi MAC <?= htmlspecialchars($macDisp, ENT_QUOTES) ?>?')">
                                <i class="fa-solid fa-ban"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php endif; ?>

<script>
// Auto-refresh countdown
let countdown = 30;
const badge   = document.getElementById('refreshBadge');
setInterval(() => {
    if (badge) badge.textContent = `Refresh dalam ${--countdown}s`;
    if (countdown <= 0) location.reload();
}, 1000);

// Filter
function filterActive() {
    const q          = document.getElementById('searchActive').value.toLowerCase();
    const onlyMatch  = document.getElementById('onlyMatched').checked;
    document.querySelectorAll('#activeTbody .active-row').forEach(row => {
        const text    = row.textContent.toLowerCase();
        const matched = row.classList.contains('row-matched');
        row.style.display = ((!q || text.includes(q)) && (!onlyMatch || matched)) ? '' : 'none';
    });
}
</script>
