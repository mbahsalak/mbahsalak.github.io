<?php
/**
 * views/pages/Mikrotik/queues.php
 * Simple Queue Management — filter by MAC Address pelanggan
 *
 * Variabel dari controller:
 *   $queues      array   — queue dari MikroTik yang cocok dengan MAC pelanggan
 *   $pelanggans  array   — semua pelanggan ber-MAC dari DB
 *   $error       ?string — error koneksi MikroTik
 *   $flash       ?array  — flash message
 *   $user        array
 */

$flash = $flash ?? null;
$error = $error ?? null;
$queues = $queues ?? [];
$pelanggans = $pelanggans ?? [];
?>

<div style="max-width:1200px; margin:0 auto; padding:1.5rem 1rem;">

    <!-- Header -->
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:.75rem; margin-bottom:1.25rem;">
        <div>
            <h4 style="margin:0 0 .2rem; font-weight:700; font-size:1.1rem; color:#111827;">
                <i class="fa-solid fa-gauge-high" style="color:#3b82f6; margin-right:.4rem;"></i>Manajemen Simple Queue
            </h4>
            <p style="margin:0; font-size:.75rem; color:#9ca3af;">Filter berdasarkan MAC address pelanggan terdaftar</p>
        </div>
        <div style="display:flex; gap:.5rem;">
            <a href="/mikrotik" style="display:inline-flex; align-items:center; gap:.35rem; padding:.4rem .9rem; border:1.5px solid #e5e7eb; color:#6b7280; border-radius:8px; font-size:.875rem; text-decoration:none; background:#fff;">
                <i class="fa-solid fa-arrow-left"></i> Kembali
            </a>
            <button onclick="bukaModalTambah()"
                    style="display:inline-flex; align-items:center; gap:.35rem; padding:.4rem .9rem; background:#3b82f6; color:#fff; border:none; border-radius:8px; font-size:.875rem; cursor:pointer;">
                <i class="fa-solid fa-plus"></i> Tambah Queue
            </button>
        </div>
    </div>

    <!-- Flash -->
    <?php if (!empty($flash)): ?>
    <div style="padding:.75rem 1rem; border-radius:8px; font-size:.875rem; font-weight:500; margin-bottom:1rem;
        <?= $flash['type'] === 'success'
            ? 'background:#f0fdf4; color:#166534; border:1px solid #bbf7d0;'
            : 'background:#fff1f2; color:#991b1b; border:1px solid #fecaca;' ?>">
        <i class="fa-solid fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'circle-exclamation' ?>" style="margin-right:.4rem;"></i>
        <?= htmlspecialchars($flash['message']) ?>
    </div>
    <?php endif; ?>

    <!-- Error koneksi MikroTik -->
    <?php if ($error): ?>
    <div style="padding:.875rem 1rem; background:#fff1f2; border:1px solid #fecaca; border-radius:8px; margin-bottom:1.25rem; display:flex; align-items:flex-start; gap:.75rem;">
        <i class="fa-solid fa-triangle-exclamation" style="color:#ef4444; margin-top:.1rem; flex-shrink:0;"></i>
        <div>
            <strong style="font-size:.875rem; color:#991b1b; display:block; margin-bottom:.2rem;">Gagal terhubung ke MikroTik</strong>
            <span style="font-size:.8rem; color:#b91c1c;"><?= htmlspecialchars($error) ?></span>
        </div>
    </div>
    <?php endif; ?>

    <!-- Stats -->
    <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:.75rem; margin-bottom:1.25rem;">
        <div style="background:#fff; border-radius:10px; box-shadow:0 1px 3px rgba(0,0,0,.08); padding:1rem;">
            <div style="font-size:.7rem; color:#9ca3af; font-weight:600; text-transform:uppercase; margin-bottom:.3rem;">Total Queue</div>
            <div style="font-size:1.5rem; font-weight:700; color:#2563eb;"><?= count($queues) ?></div>
            <div style="font-size:.7rem; color:#9ca3af; margin-top:.15rem;">dari MikroTik</div>
        </div>
        <div style="background:#fff; border-radius:10px; box-shadow:0 1px 3px rgba(0,0,0,.08); padding:1rem;">
            <?php $aktif = count(array_filter($queues, fn($q) => ($q['disabled'] ?? 'false') === 'false')); ?>
            <div style="font-size:.7rem; color:#9ca3af; font-weight:600; text-transform:uppercase; margin-bottom:.3rem;">Aktif</div>
            <div style="font-size:1.5rem; font-weight:700; color:#16a34a;"><?= $aktif ?></div>
            <div style="font-size:.7rem; color:#9ca3af; margin-top:.15rem;">queue enabled</div>
        </div>
        <div style="background:#fff; border-radius:10px; box-shadow:0 1px 3px rgba(0,0,0,.08); padding:1rem;">
            <div style="font-size:.7rem; color:#9ca3af; font-weight:600; text-transform:uppercase; margin-bottom:.3rem;">Disabled</div>
            <div style="font-size:1.5rem; font-weight:700; color:#dc2626;"><?= count($queues) - $aktif ?></div>
            <div style="font-size:.7rem; color:#9ca3af; margin-top:.15rem;">queue disabled</div>
        </div>
        <div style="background:#fff; border-radius:10px; box-shadow:0 1px 3px rgba(0,0,0,.08); padding:1rem;">
            <div style="font-size:.7rem; color:#9ca3af; font-weight:600; text-transform:uppercase; margin-bottom:.3rem;">Pelanggan Terdaftar</div>
            <div style="font-size:1.5rem; font-weight:700; color:#d97706;"><?= count($pelanggans) ?></div>
            <div style="font-size:.7rem; color:#9ca3af; margin-top:.15rem;">ber-MAC address</div>
        </div>
    </div>

    <!-- Tabel Queue -->
    <div style="background:#fff; border-radius:10px; box-shadow:0 1px 3px rgba(0,0,0,.08); overflow:hidden; margin-bottom:1.5rem;">
        <div style="padding:.75rem 1.25rem; border-bottom:1px solid #e5e7eb; display:flex; justify-content:space-between; align-items:center; gap:.75rem;">
            <h6 style="margin:0; font-weight:700; color:#374151; font-size:.875rem;">
                <i class="fa-solid fa-list" style="color:#3b82f6; margin-right:.4rem;"></i>Simple Queue (Filter MAC)
            </h6>
            <input type="text" id="searchQueue" oninput="filterQueue()"
                   placeholder="Cari nama / MAC / pelanggan..."
                   style="font-size:.8rem; border:1.5px solid #e5e7eb; border-radius:8px; padding:.35rem .75rem; width:13rem; outline:none;">
        </div>
        <div style="overflow-x:auto;">
            <table style="width:100%; border-collapse:collapse; font-size:.8rem;" id="tableQueue">
                <thead>
                    <tr style="background:#f9fafb; border-bottom:1px solid #e5e7eb;">
                        <th style="padding:.625rem 1rem; text-align:left; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase; white-space:nowrap;">#</th>
                        <th style="padding:.625rem 1rem; text-align:left; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase; white-space:nowrap;">Nama Queue</th>
                        <th style="padding:.625rem 1rem; text-align:left; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase; white-space:nowrap;">Target (MAC)</th>
                        <th style="padding:.625rem 1rem; text-align:left; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase; white-space:nowrap;">Pelanggan</th>
                        <th style="padding:.625rem 1rem; text-align:left; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase; white-space:nowrap;">Max Limit (↑/↓)</th>
                        <th style="padding:.625rem 1rem; text-align:left; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase; white-space:nowrap;">Burst</th>
                        <th style="padding:.625rem 1rem; text-align:center; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase; white-space:nowrap;">Status</th>
                        <th style="padding:.625rem 1rem; text-align:center; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase; white-space:nowrap;">Aksi</th>
                    </tr>
                </thead>
                <tbody id="queueTbody">
                <?php if (empty($queues)): ?>
                    <tr>
                        <td colspan="8" style="text-align:center; color:#9ca3af; padding:3rem 1rem;">
                            <i class="fa-solid fa-gauge-high" style="font-size:1.5rem; display:block; margin-bottom:.5rem; opacity:.3;"></i>
                            <?= $error ? 'Tidak dapat mengambil data queue.' : 'Tidak ada queue yang cocok dengan MAC address pelanggan.' ?>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($queues as $i => $q): ?>
                    <?php
                        $name      = $q['name']        ?? '-';
                        $target    = $q['target']      ?? '-';
                        $maxLim    = $q['max-limit']   ?? '-';
                        $burst     = $q['burst-limit'] ?? '-';
                        $disabled  = ($q['disabled']   ?? 'false') === 'true';
                        $comment   = $q['comment']     ?? '';
                        $pel       = $q['_pelanggan']  ?? null;
                    ?>
                    <tr class="queue-row" style="border-top:1px solid #f3f4f6;"
                        onmouseover="this.style.background='#f9fafb'" onmouseout="this.style.background=''">
                        <td style="padding:.625rem 1rem; color:#9ca3af;"><?= $i + 1 ?></td>
                        <td style="padding:.625rem 1rem;">
                            <span class="q-name" style="font-weight:600; color:#111827;"><?= htmlspecialchars($name) ?></span>
                            <?php if ($comment): ?>
                            <div style="font-size:.7rem; color:#9ca3af;"><?= htmlspecialchars($comment) ?></div>
                            <?php endif; ?>
                        </td>
                        <td style="padding:.625rem 1rem;">
                            <span class="q-target" style="font-family:monospace; font-size:.75rem; color:#374151;"><?= htmlspecialchars($target) ?></span>
                        </td>
                        <td style="padding:.625rem 1rem;">
                            <?php if ($pel): ?>
                            <span class="q-pel" style="font-weight:600; color:#374151;"><?= htmlspecialchars($pel['nama_lengkap']) ?></span>
                            <div style="font-size:.7rem; color:#9ca3af;"><?= htmlspecialchars($pel['nama_paket'] ?? '') ?> · <?= htmlspecialchars($pel['kecepatan'] ?? '') ?></div>
                            <?php else: ?>
                            <span style="color:#9ca3af;">—</span>
                            <?php endif; ?>
                        </td>
                        <td style="padding:.625rem 1rem; font-family:monospace; color:#374151;"><?= htmlspecialchars($maxLim) ?></td>
                        <td style="padding:.625rem 1rem; font-family:monospace; font-size:.75rem; color:#9ca3af;"><?= htmlspecialchars($burst) ?></td>
                        <td style="padding:.625rem 1rem; text-align:center;">
                            <span style="padding:.2rem .55rem; border-radius:6px; font-size:.72rem; font-weight:700;
                                <?= $disabled
                                    ? 'background:#fff1f2; color:#dc2626;'
                                    : 'background:#f0fdf4; color:#16a34a;' ?>">
                                <?= $disabled ? 'Disabled' : 'Active' ?>
                            </span>
                        </td>
                        <td style="padding:.625rem 1rem; text-align:center;">
                            <div style="display:flex; justify-content:center; gap:.25rem;">
                                <button title="Edit Limit"
                                        onclick="bukaModalEdit('<?= htmlspecialchars($name, ENT_QUOTES) ?>', '<?= htmlspecialchars($maxLim, ENT_QUOTES) ?>')"
                                        style="padding:.35rem .6rem; color:#2563eb; background:none; border:1.5px solid #bfdbfe; border-radius:7px; cursor:pointer; font-size:.75rem;"
                                        onmouseover="this.style.background='#eff6ff'" onmouseout="this.style.background=''">
                                    <i class="fa-solid fa-pencil"></i>
                                </button>
                                <a href="/mikrotik/queues/hapus/<?= urlencode($name) ?>"
                                   title="Hapus Queue"
                                   onclick="return confirm('Hapus queue <?= htmlspecialchars($name, ENT_QUOTES) ?>?')"
                                   style="padding:.35rem .6rem; color:#dc2626; background:none; border:1.5px solid #fecaca; border-radius:7px; text-decoration:none; font-size:.75rem; display:inline-flex; align-items:center;"
                                   onmouseover="this.style.background='#fff1f2'" onmouseout="this.style.background=''">
                                    <i class="fa-solid fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pelanggan tanpa queue -->
    <?php
    $macDenganQueue = array_map(
        fn($q) => strtolower(strtok($q['target'] ?? '', '/')),
        $queues
    );
    $pelTanpaQueue = array_filter(
        $pelanggans,
        fn($p) => !in_array(strtolower(trim($p['mac_address'])), $macDenganQueue, true)
    );
    ?>
    <?php if (!empty($pelTanpaQueue)): ?>
    <div style="background:#fff; border-radius:10px; box-shadow:0 1px 3px rgba(0,0,0,.08); overflow:hidden;">
        <div style="padding:.75rem 1.25rem; border-bottom:1px solid #e5e7eb;">
            <h6 style="margin:0; font-weight:700; color:#374151; font-size:.875rem;">
                <i class="fa-solid fa-triangle-exclamation" style="color:#f59e0b; margin-right:.4rem;"></i>
                Pelanggan Belum Punya Queue (<?= count($pelTanpaQueue) ?>)
            </h6>
        </div>
        <div style="overflow-x:auto;">
            <table style="width:100%; border-collapse:collapse; font-size:.8rem;">
                <thead>
                    <tr style="background:#fffbeb;">
                        <th style="padding:.5rem 1rem; text-align:left; font-size:.7rem; font-weight:600; color:#92400e; text-transform:uppercase;">Pelanggan</th>
                        <th style="padding:.5rem 1rem; text-align:left; font-size:.7rem; font-weight:600; color:#92400e; text-transform:uppercase;">MAC Address</th>
                        <th style="padding:.5rem 1rem; text-align:left; font-size:.7rem; font-weight:600; color:#92400e; text-transform:uppercase;">Paket</th>
                        <th style="padding:.5rem 1rem; text-align:center; font-size:.7rem; font-weight:600; color:#92400e; text-transform:uppercase;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($pelTanpaQueue as $p): ?>
                <tr style="border-top:1px solid #fef3c7;"
                    onmouseover="this.style.background='#fffbeb'" onmouseout="this.style.background=''">
                    <td style="padding:.5rem 1rem; font-weight:600; color:#374151;"><?= htmlspecialchars($p['nama_lengkap']) ?></td>
                    <td style="padding:.5rem 1rem; font-family:monospace; font-size:.75rem; color:#374151;"><?= htmlspecialchars($p['mac_address']) ?></td>
                    <td style="padding:.5rem 1rem; color:#6b7280;"><?= htmlspecialchars($p['nama_paket'] ?? '') ?> · <?= htmlspecialchars($p['kecepatan'] ?? '') ?></td>
                    <td style="padding:.5rem 1rem; text-align:center;">
                        <button onclick="bukaModalTambahDenganMac('<?= htmlspecialchars($p['nama_lengkap'], ENT_QUOTES) ?>', '<?= htmlspecialchars($p['mac_address'], ENT_QUOTES) ?>', '<?= htmlspecialchars($p['kecepatan'] ?? '10M/10M', ENT_QUOTES) ?>')"
                                style="padding:.3rem .75rem; background:#3b82f6; color:#fff; border:none; border-radius:7px; font-size:.75rem; cursor:pointer;">
                            <i class="fa-solid fa-plus" style="margin-right:.25rem;"></i>Buat Queue
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

</div>

<!-- ===================== MODAL TAMBAH ===================== -->
<div id="modalTambah" style="display:none; position:fixed; inset:0; z-index:50; align-items:center; justify-content:center; background:rgba(0,0,0,.4); padding:1rem;">
    <div style="background:#fff; border-radius:12px; box-shadow:0 10px 25px rgba(0,0,0,.15); width:100%; max-width:26rem;">
        <form method="POST" action="/mikrotik/queues/tambah">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token ?? '', ENT_QUOTES, 'UTF-8') ?>">
            <div style="display:flex; justify-content:space-between; align-items:center; padding:1rem 1.25rem; border-bottom:1px solid #e5e7eb;">
                <h6 style="margin:0; font-weight:700; color:#374151;">
                    <i class="fa-solid fa-plus" style="color:#3b82f6; margin-right:.4rem;"></i>Tambah Simple Queue
                </h6>
                <button type="button" onclick="tutupModal('modalTambah')" style="background:none; border:none; font-size:1.25rem; color:#9ca3af; cursor:pointer;">&times;</button>
            </div>
            <div style="padding:1.25rem; display:flex; flex-direction:column; gap:.875rem;">
                <div>
                    <label style="display:block; font-size:.75rem; font-weight:700; color:#6b7280; margin-bottom:.3rem; text-transform:uppercase;">Nama Queue <span style="color:#ef4444;">*</span></label>
                    <input type="text" name="name" id="addName" required placeholder="pelanggan-001"
                           style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; box-sizing:border-box;">
                </div>
                <div>
                    <label style="display:block; font-size:.75rem; font-weight:700; color:#6b7280; margin-bottom:.3rem; text-transform:uppercase;">Target MAC Address <span style="color:#ef4444;">*</span></label>
                    <input type="text" name="target" id="addTarget" required placeholder="AA:BB:CC:DD:EE:FF"
                           style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; font-family:monospace; box-sizing:border-box;">
                    <p style="font-size:.7rem; color:#9ca3af; margin:.3rem 0 0;">Format MAC address: <code>AA:BB:CC:DD:EE:FF</code></p>
                </div>
                <div>
                    <label style="display:block; font-size:.75rem; font-weight:700; color:#6b7280; margin-bottom:.3rem; text-transform:uppercase;">Max Limit (upload/download) <span style="color:#ef4444;">*</span></label>
                    <input type="text" name="max_limit" id="addLimit" required placeholder="10M/10M"
                           style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; font-family:monospace; box-sizing:border-box;">
                    <p style="font-size:.7rem; color:#9ca3af; margin:.3rem 0 0;">Format: <code>uploadSpeed/downloadSpeed</code> — contoh: <code>5M/10M</code></p>
                </div>
                <div>
                    <label style="display:block; font-size:.75rem; font-weight:700; color:#6b7280; margin-bottom:.3rem; text-transform:uppercase;">Komentar</label>
                    <input type="text" name="comment" placeholder="Opsional"
                           style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; box-sizing:border-box;">
                </div>
            </div>
            <div style="padding:.75rem 1.25rem; border-top:1px solid #e5e7eb; display:flex; justify-content:flex-end; gap:.5rem;">
                <button type="button" onclick="tutupModal('modalTambah')"
                        style="padding:.5rem 1rem; border:1.5px solid #e5e7eb; border-radius:8px; background:#fff; color:#6b7280; cursor:pointer; font-size:.875rem;">Batal</button>
                <button type="submit"
                        style="padding:.5rem 1rem; background:#3b82f6; color:#fff; border:none; border-radius:8px; cursor:pointer; font-size:.875rem;">
                    <i class="fa-solid fa-floppy-disk" style="margin-right:.25rem;"></i>Simpan
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ===================== MODAL EDIT LIMIT ===================== -->
<div id="modalEdit" style="display:none; position:fixed; inset:0; z-index:50; align-items:center; justify-content:center; background:rgba(0,0,0,.4); padding:1rem;">
    <div style="background:#fff; border-radius:12px; box-shadow:0 10px 25px rgba(0,0,0,.15); width:100%; max-width:22rem;">
        <form method="POST" action="/mikrotik/queues/update">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token ?? '', ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="name" id="editName">
            <div style="display:flex; justify-content:space-between; align-items:center; padding:1rem 1.25rem; border-bottom:1px solid #e5e7eb;">
                <h6 style="margin:0; font-weight:700; color:#374151;">
                    <i class="fa-solid fa-pencil" style="color:#f59e0b; margin-right:.4rem;"></i>Edit Max Limit
                </h6>
                <button type="button" onclick="tutupModal('modalEdit')" style="background:none; border:none; font-size:1.25rem; color:#9ca3af; cursor:pointer;">&times;</button>
            </div>
            <div style="padding:1.25rem; display:flex; flex-direction:column; gap:.875rem;">
                <p style="margin:0; font-size:.8rem; color:#6b7280;">Queue: <strong id="editLabel" style="color:#374151;"></strong></p>
                <div>
                    <label style="display:block; font-size:.75rem; font-weight:700; color:#6b7280; margin-bottom:.3rem; text-transform:uppercase;">Max Limit Baru <span style="color:#ef4444;">*</span></label>
                    <input type="text" name="max_limit" id="editLimit" required
                           style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; font-family:monospace; box-sizing:border-box;">
                    <p style="font-size:.7rem; color:#9ca3af; margin:.3rem 0 0;">Contoh: <code>10M/10M</code>, <code>5M/20M</code></p>
                </div>
            </div>
            <div style="padding:.75rem 1.25rem; border-top:1px solid #e5e7eb; display:flex; justify-content:flex-end; gap:.5rem;">
                <button type="button" onclick="tutupModal('modalEdit')"
                        style="padding:.5rem 1rem; border:1.5px solid #e5e7eb; border-radius:8px; background:#fff; color:#6b7280; cursor:pointer; font-size:.875rem;">Batal</button>
                <button type="submit"
                        style="padding:.5rem 1rem; background:#f59e0b; color:#fff; border:none; border-radius:8px; cursor:pointer; font-size:.875rem;">
                    <i class="fa-solid fa-floppy-disk" style="margin-right:.25rem;"></i>Simpan
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function bukaModal(id) { document.getElementById(id).style.display = 'flex'; }
function tutupModal(id) { document.getElementById(id).style.display = 'none'; }
function bukaModalTambah() { bukaModal('modalTambah'); }

function bukaModalTambahDenganMac(nama, mac, kecepatan) {
    document.getElementById('addName').value   = nama.toLowerCase().replace(/\s+/g, '-');
    document.getElementById('addTarget').value = mac;
    document.getElementById('addLimit').value  = kecepatan;
    bukaModal('modalTambah');
}

function bukaModalEdit(name, limit) {
    document.getElementById('editName').value  = name;
    document.getElementById('editLabel').textContent = name;
    document.getElementById('editLimit').value = limit;
    bukaModal('modalEdit');
}

// Tutup modal jika klik backdrop
['modalTambah','modalEdit'].forEach(id => {
    document.getElementById(id).addEventListener('click', function(e) {
        if (e.target === this) tutupModal(id);
    });
});

// Filter tabel
function filterQueue() {
    const q = document.getElementById('searchQueue').value.toLowerCase();
    document.querySelectorAll('#queueTbody .queue-row').forEach(row => {
        const text = [
            row.querySelector('.q-name')?.textContent,
            row.querySelector('.q-target')?.textContent,
            row.querySelector('.q-pel')?.textContent,
        ].join(' ').toLowerCase();
        row.style.display = text.includes(q) ? '' : 'none';
    });
}
</script>
