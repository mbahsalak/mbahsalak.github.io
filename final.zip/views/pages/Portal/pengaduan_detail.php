<?php
/**
 * views/pages/Portal/pengaduan_detail.php
 * FIX: Error 500 - Unclosed '(' does not match ']'
 */

// ── Ambil data pengaduan ──
$pengaduan = $data['data'] ?? $data ?? [];

// Fallback: ambil dari DB jika kosong
if (empty($pengaduan) || !isset($pengaduan['id'])) {
    $idFromUrl = $_GET['id'] ?? null;
    if (!$idFromUrl) {
        $uri = trim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?? '', '/');
        $segments = explode('/', $uri);
        $lastSegment = end($segments);
        if (ctype_digit((string)$lastSegment)) {
            $idFromUrl = $lastSegment;
        }
    }
    if ($idFromUrl && ctype_digit((string)$idFromUrl)) {
        try {
            $db = \Config\Database::getConnection();
            $stmt = $db->prepare("SELECT * FROM pengaduan WHERE id = ? LIMIT 1");
            $stmt->execute([(int)$idFromUrl]);
            $pengaduan = $stmt->fetch(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            $pengaduan = [];
        }
    }
}

// ── Jika tetap kosong ──
if (empty($pengaduan) || !isset($pengaduan['id'])) {
    echo '<div class="max-w-3xl mx-auto p-8 text-center">';
    echo '<div class="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl p-8">';
    echo '<i class="fa-solid fa-triangle-exclamation text-4xl text-red-400 mb-4"></i>';
    echo '<h2 class="text-lg font-bold text-red-700 dark:text-red-300 mb-2">Data Pengaduan Tidak Ditemukan</h2>';
    echo '<a href="/ticketing" class="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-red-600 text-white text-sm font-medium hover:bg-red-700 mt-4">';
    echo '<i class="fa-solid fa-arrow-left"></i> Kembali</a>';
    echo '</div></div>';
    return;
}

// ── Mapping kolom ──
$judul       = $pengaduan['judul'] ?? $pengaduan['title'] ?? 'Tanpa Judul';
$deskripsi   = $pengaduan['deskripsi'] ?? $pengaduan['description'] ?? $pengaduan['isi'] ?? 'Tidak ada deskripsi.';
$status      = $pengaduan['status'] ?? 'open';
$idPengaduan = $pengaduan['id'] ?? '-';
$createdAt   = $pengaduan['created_at'] ?? $pengaduan['tanggal'] ?? date('Y-m-d H:i:s');
$updatedAt   = $pengaduan['updated_at'] ?? null;
$latitude    = $pengaduan['latitude'] ?? null;
$longitude   = $pengaduan['longitude'] ?? null;

// ── Status badge (pakai if-else, BUKAN match + list assignment) ──
$bg    = 'bg-gray-100 dark:bg-gray-700';
$txt   = 'text-gray-700 dark:text-gray-300';
$lbl   = ucfirst($status);
$icon  = 'fa-circle-question';

if ($status === 'open') {
    $bg   = 'bg-red-100 dark:bg-red-900/30';
    $txt  = 'text-red-700 dark:text-red-400';
    $lbl  = 'Baru';
    $icon = 'fa-circle-exclamation';
} elseif ($status === 'proses') {
    $bg   = 'bg-amber-100 dark:bg-amber-900/30';
    $txt  = 'text-amber-700 dark:text-amber-400';
    $lbl  = 'Dalam Proses';
    $icon = 'fa-spinner';
} elseif ($status === 'selesai') {
    $bg   = 'bg-green-100 dark:bg-green-900/30';
    $txt  = 'text-green-700 dark:text-green-400';
    $lbl  = 'Selesai';
    $icon = 'fa-circle-check';
}
?>

<div class="max-w-3xl mx-auto space-y-6 p-4 md:p-0">

    <!-- HEADER -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div class="flex items-center gap-3 mb-4">
            <a href="/ticketing" class="w-9 h-9 rounded-lg bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
                <i class="fa-solid fa-arrow-left"></i>
            </a>
            <div class="flex-1 min-w-0">
                <h1 class="text-xl font-bold text-gray-900 dark:text-white truncate">
                    <?php echo htmlspecialchars($judul); ?>
                </h1>
                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Pengaduan #<?php echo htmlspecialchars((string)$idPengaduan); ?> &bull;
                    Dibuat: <?php echo date('d M Y, H:i', strtotime($createdAt)); ?>
                </p>
            </div>
            <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-wide <?php echo $bg; ?> <?php echo $txt; ?> flex-shrink-0">
                <i class="fa-solid <?php echo $icon; ?>"></i>
                <?php echo $lbl; ?>
            </span>
        </div>

        <!-- DESKRIPSI -->
        <div class="bg-gray-50 dark:bg-gray-700/30 rounded-lg p-5 border border-gray-200 dark:border-gray-700">
            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-2">Deskripsi Keluhan</p>
            <p class="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap leading-relaxed">
                <?php echo nl2br(htmlspecialchars($deskripsi)); ?>
            </p>
        </div>

        <!-- LOKASI -->
        <?php if (!empty($latitude) && !empty($longitude)): ?>
        <div class="mt-4">
            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-2">Lokasi Laporan</p>
            <div id="mapPengaduan" class="h-[280px] rounded-lg border border-gray-200 dark:border-gray-700 z-0"></div>
            <p class="text-[10px] text-gray-400 mt-1">
                Koordinat: <?php echo htmlspecialchars((string)$latitude); ?>, <?php echo htmlspecialchars((string)$longitude); ?>
            </p>
        </div>
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
        <script>
        (function() {
            var lat = <?php echo (float)$latitude; ?>;
            var lng = <?php echo (float)$longitude; ?>;
            var map = L.map('mapPengaduan').setView([lat, lng], 16);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap'
            }).addTo(map);
            L.marker([lat, lng]).addTo(map)
                .bindPopup('<strong>Lokasi Laporan</strong>')
                .openPopup();
        })();
        </script>
        <?php endif; ?>

        <!-- TIMELINE -->
        <div class="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-3">Timeline</p>
            <div class="space-y-2">
                <div class="flex items-center gap-2 text-xs">
                    <span class="w-2 h-2 rounded-full bg-blue-500"></span>
                    <span class="text-gray-500 dark:text-gray-400">Dibuat:</span>
                    <span class="font-medium text-gray-900 dark:text-white">
                        <?php echo date('d M Y, H:i', strtotime($createdAt)); ?>
                    </span>
                </div>
                <?php if (!empty($updatedAt) && $updatedAt !== $createdAt): ?>
                <div class="flex items-center gap-2 text-xs">
                    <span class="w-2 h-2 rounded-full bg-green-500"></span>
                    <span class="text-gray-500 dark:text-gray-400">Terakhir diperbarui:</span>
                    <span class="font-medium text-gray-900 dark:text-white">
                        <?php echo date('d M Y, H:i', strtotime($updatedAt)); ?>
                    </span>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- KEMBALI -->
    <div class="text-center pb-6">
        <a href="/ticketing" 
           class="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-sm font-medium hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors">
            <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar Pengaduan
        </a>
    </div>

</div>
