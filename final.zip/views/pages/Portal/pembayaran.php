<?php
/**
 * views/pages/Portal/pembayaran.php — Riwayat Pembayaran
 */
function formatRpP(float $n): string { return 'Rp ' . number_format($n, 0, ',', '.'); }
?>

<div class="max-w-[1320px] mx-auto space-y-6">

    <!-- HEADER -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 class="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                    <i class="fa-solid fa-receipt text-green-600"></i> Riwayat Pembayaran
                </h1>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Daftar semua tagihan yang telah Anda bayarkan.
                </p>
            </div>
            <div class="text-right">
                <p class="text-xs text-gray-500 dark:text-gray-400 uppercase font-semibold">Total Dibayar</p>
                <p class="text-2xl font-bold text-green-600 dark:text-green-400"><?= formatRpP($totalBayar) ?></p>
                <p class="text-xs text-gray-400 mt-1"><?= count($riwayat) ?> transaksi</p>
            </div>
        </div>
    </div>

    <!-- FILTER -->
    <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4">
        
<form method="GET" action="/pembayaran" class="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
            <div>
                <label class="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Bulan Pembayaran</label>
                <input type="month" name="bulan" value="<?= htmlspecialchars($filterBulan) ?>"
                    class="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm">
            </div>
            <div>
                <label class="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Metode Pembayaran</label>
                <select name="metode"
                    class="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm">
                    <option value="">Semua Metode</option>
                    <?php foreach ($metodeList as $m): ?>
                    <option value="<?= htmlspecialchars($m['metode_pembayaran']) ?>"
                        <?= $filterMetode === $m['metode_pembayaran'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($m['metode_pembayaran']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="flex gap-2">
                <button type="submit"
                    class="flex-1 px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-indigo-600 transition-colors">
                    <i class="fa-solid fa-filter mr-1"></i> Filter
                </button>
                <a href="/pembayaran" class="px-4 py-2.5 rounded-lg bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-sm font-medium hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors">
    Reset
</a>
            </div>
        </form>
    </div>

    <!-- TABEL -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
                    <tr>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase w-10">#</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Periode</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Tipe</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Tanggal Bayar</th>
                        <th class="px-5 py-3 text-center text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Metode</th>
                        <th class="px-5 py-3 text-center text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Penerima</th>
                        <th class="px-5 py-3 text-right text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Jumlah</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                    <?php if (!empty($riwayat)): ?>
                        <?php foreach ($riwayat as $i => $r): ?>
                        <tr class="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                            <td class="px-5 py-3 text-gray-400"><?= $i + 1 ?></td>
                            <td class="px-5 py-3">
                                <p class="font-medium text-gray-900 dark:text-white"><?= htmlspecialchars($r['periode'] ?? '-') ?></p>
                                <?php if (!empty($r['deskripsi'])): ?>
                                <p class="text-[10px] text-gray-400 mt-0.5"><?= htmlspecialchars($r['deskripsi']) ?></p>
                                <?php endif; ?>
                            </td>
                            <td class="px-5 py-3 text-xs text-gray-500 dark:text-gray-400">
                                <?= htmlspecialchars(ucfirst($r['tipe'] ?? '-')) ?>
                            </td>
                            <td class="px-5 py-3 text-xs text-gray-500 dark:text-gray-400">
                                <?= !empty($r['tgl_bayar']) ? date('d M Y, H:i', strtotime($r['tgl_bayar'])) : '-' ?>
                            </td>
                            <td class="px-5 py-3 text-center">
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                                    <?= htmlspecialchars($r['metode'] ?? 'Tunai') ?>
                                </span>
                            </td>
                            <td class="px-5 py-3 text-center text-xs text-gray-600 dark:text-gray-400">
                                <?= htmlspecialchars($r['penerima'] ?? '-') ?>
                            </td>
                            <td class="px-5 py-3 text-right font-bold text-gray-900 dark:text-white">
                                <?= formatRpP((float)($r['total'] ?? 0)) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="px-5 py-16 text-center">
                                <i class="fa-solid fa-inbox text-5xl text-gray-300 dark:text-gray-600 mb-4"></i>
                                <p class="text-sm font-medium text-gray-700 dark:text-gray-300">Belum ada riwayat pembayaran</p>
                                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                                    <?php if ($filterBulan || $filterMetode): ?>
                                        Tidak ada data dengan filter ini.
                                        <a href="/portal/pembayaran" class="text-primary hover:underline">Reset filter</a>
                                    <?php else: ?>
                                        Riwayat pembayaran Anda akan muncul di sini.
                                    <?php endif; ?>
                                </p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
