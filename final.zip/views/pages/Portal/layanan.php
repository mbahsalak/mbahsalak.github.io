<?php
/**
 * views/pages/Portal/layanan.php — Layanan Saya
 */

function formatBytes(int $bytes): string {
    if ($bytes <= 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $pow = min(floor(log($bytes, 1024)), count($units) - 1);
    return round($bytes / (1024 ** $pow), 2) . ' ' . $units[$pow];
}
function formatUptime(int $s): string {
    if ($s <= 0) return '0m';
    $d = intdiv($s, 86400); $h = intdiv($s % 86400, 3600); $m = intdiv($s % 3600, 60);
    $p = [];
    if ($d > 0) $p[] = "{$d}h";
    if ($h > 0) $p[] = "{$h}j";
    if ($m > 0) $p[] = "{$m}m";
    return implode(' ', $p) ?: '0m';
}
function formatRp(float $n): string { return 'Rp ' . number_format($n, 0, ',', '.'); }

$statusMap = [
    'aktif'    => ['green',  'Aktif'],
    'isolir'   => ['orange', 'Terisolir'],
    'pending'  => ['blue',   'Menunggu Aktivasi'],
    'nonaktif' => ['red',    'Tidak Aktif'],
];
$status = $statusMap[$pelanggan['status_internet'] ?? 'aktif'] ?? ['gray', ucfirst($pelanggan['status_internet'] ?? '-')];
?>

<div class="max-w-[1320px] mx-auto space-y-6">

    <!-- HEADER -->
    <div class="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-6 text-white shadow-lg">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 class="text-2xl font-bold flex items-center gap-2">
                    <i class="fa-solid fa-satellite-dish"></i> Layanan Saya
                </h1>
                <p class="text-indigo-100 text-sm mt-1">
                    Informasi detail layanan internet Anda saat ini.
                </p>
            </div>
            <?php if ($isOnline): ?>
            <span class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/20 border border-green-400/40 text-green-200 text-sm font-semibold">
                <span class="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span> Terhubung
            </span>
            <?php else: ?>
            <span class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-red-500/20 border border-red-400/40 text-red-200 text-sm font-semibold">
                <span class="w-2 h-2 rounded-full bg-red-400"></span> Tidak Terhubung
            </span>
            <?php endif; ?>
        </div>
    </div>

    <!-- INFO PELANGGAN & PAKET -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">

        <!-- Data Diri -->
        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5">
            <h3 class="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-4">
                <i class="fa-solid fa-id-card text-primary"></i> Data Pelanggan
            </h3>
            <dl class="space-y-3 text-sm">
                <div class="flex justify-between">
                    <dt class="text-gray-500 dark:text-gray-400">Nama</dt>
                    <dd class="font-semibold text-gray-900 dark:text-white"><?= htmlspecialchars($pelanggan['nama_lengkap'] ?? '-') ?></dd>
                </div>
                <div class="flex justify-between">
                    <dt class="text-gray-500 dark:text-gray-400">Username</dt>
                    <dd class="font-mono font-semibold text-gray-900 dark:text-white"><?= htmlspecialchars($user['username'] ?? '-') ?></dd>
                </div>
                <div class="flex justify-between">
                    <dt class="text-gray-500 dark:text-gray-400">No. HP</dt>
                    <dd class="font-semibold text-gray-900 dark:text-white"><?= htmlspecialchars($pelanggan['no_telp'] ?? '-') ?></dd>
                </div>
                <div class="flex justify-between">
                    <dt class="text-gray-500 dark:text-gray-400">Alamat</dt>
                    <dd class="font-semibold text-gray-900 dark:text-white text-right max-w-[60%]"><?= htmlspecialchars($pelanggan['alamat'] ?? '-') ?></dd>
                </div>
                <div class="flex justify-between pt-3 border-t border-gray-100 dark:border-gray-700">
                    <dt class="text-gray-500 dark:text-gray-400">Status</dt>
                    <dd>
                        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold uppercase
                            bg-<?= $status[0] ?>-100 text-<?= $status[0] ?>-700 dark:bg-<?= $status[0] ?>-900/30 dark:text-<?= $status[0] ?>-400">
                            <?= $status[1] ?>
                        </span>
                    </dd>
                </div>
            </dl>
                        <!-- TOMBOL CEPAT -->
            <div class="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700 space-y-2">
                <a href="/ticketing/buat?jenis=perbaikan"
                   class="flex items-center gap-2 px-3 py-2 rounded-lg border border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-400 text-xs font-medium hover:bg-amber-50 dark:hover:bg-amber-900/10 transition-colors">
                    <i class="fa-solid fa-wrench w-4 text-center"></i> Lapor Perbaikan
                </a>
                <a href="/ticketing/buat?jenis=upgrade_paket"
                   class="flex items-center gap-2 px-3 py-2 rounded-lg border border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-400 text-xs font-medium hover:bg-indigo-50 dark:hover:bg-indigo-900/10 transition-colors">
                    <i class="fa-solid fa-arrow-up-right-dots w-4 text-center"></i> Upgrade Paket
                </a>
            </div>

        </div>

                <!-- Paket Langganan -->
        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5">
            <h3 class="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-4">
                <i class="fa-solid fa-wifi text-primary"></i> Paket Langganan
            </h3>
            <div class="text-center py-4">
                <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-3">
                    <i class="fa-solid fa-bolt text-primary text-2xl"></i>
                </div>
                <p class="text-lg font-bold text-gray-900 dark:text-white"><?php echo htmlspecialchars($paket['nama_paket'] ?? '-'); ?></p>
                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Kecepatan</p>
                <p class="text-3xl font-bold text-primary mt-1"><?php echo htmlspecialchars($paket['kecepatan'] ?? '-'); ?></p>
                <div class="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                    <p class="text-xs text-gray-500 dark:text-gray-400">Biaya Bulanan</p>
                    <p class="text-xl font-bold text-gray-900 dark:text-white mt-1">
                        Rp <?php echo number_format((float)($paket['harga'] ?? 0), 0, ',', '.'); ?>
                    </p>
                </div>
                <div class="mt-3 text-xs text-gray-500 dark:text-gray-400">
                    Jatuh tempo tanggal <strong><?php echo (int)($pelanggan['tgl_jatuh_tempo'] ?? 5); ?></strong> setiap bulan
                </div>

                <!-- ✅ TOMBOL UPGRADE PAKET -->
                <div class="mt-5 pt-4 border-t border-gray-100 dark:border-gray-700">
                    <a href="/ticketing/buat?jenis=upgrade_paket"
                       class="inline-flex items-center justify-center gap-2 w-full px-4 py-2.5 rounded-lg bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-sm font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all shadow-sm hover:shadow-md">
                        <i class="fa-solid fa-arrow-up-right-dots"></i>
                        Upgrade Paket
                    </a>
                    <p class="text-[10px] text-gray-400 mt-2">Ajukan permintaan perubahan paket langganan Anda</p>
                </div>
            </div>
        </div>


        <!-- Status Koneksi -->
        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5">
            <h3 class="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-4">
                <i class="fa-solid fa-signal text-primary"></i> Status Koneksi
            </h3>
            <div class="space-y-3 text-sm">
                <div class="flex justify-between items-center py-2 border-b border-gray-100 dark:border-gray-700">
                    <span class="text-gray-500 dark:text-gray-400">Status</span>
                    <?php if ($isOnline): ?>
                        <span class="inline-flex items-center gap-1.5 text-green-600 dark:text-green-400 font-semibold">
                            <span class="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span> Online
                        </span>
                    <?php else: ?>
                        <span class="inline-flex items-center gap-1.5 text-red-600 dark:text-red-400 font-semibold">
                            <span class="w-2 h-2 rounded-full bg-red-500"></span> Offline
                        </span>
                    <?php endif; ?>
                </div>
                <div class="flex justify-between items-center py-2 border-b border-gray-100 dark:border-gray-700">
                    <span class="text-gray-500 dark:text-gray-400">Uptime</span>
                    <span class="font-mono font-bold text-gray-900 dark:text-white"><?= formatUptime($uptime) ?></span>
                </div>
                <div class="flex justify-between items-center py-2 border-b border-gray-100 dark:border-gray-700">
                    <span class="text-gray-500 dark:text-gray-400">IP Address</span>
                    <span class="font-mono font-semibold text-gray-900 dark:text-white"><?= htmlspecialchars($ipAddress) ?></span>
                </div>
                <?php if (!$isOnline && $lastSeen): ?>
                <div class="flex justify-between items-center py-2 border-b border-gray-100 dark:border-gray-700">
                    <span class="text-gray-500 dark:text-gray-400">Terakhir online</span>
                    <span class="text-xs text-gray-600 dark:text-gray-300"><?= date('d M Y, H:i', strtotime($lastSeen)) ?></span>
                </div>
                <?php endif; ?>
                <div class="flex justify-between items-center py-2">
                    <span class="text-gray-500 dark:text-gray-400">MAC Address</span>
                    <span class="font-mono text-xs text-gray-600 dark:text-gray-300"><?= htmlspecialchars(strtoupper($pelanggan['mac_address'] ?? '-')) ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- BANDWIDTH -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <!-- Hari Ini -->
        <div class="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/10 dark:to-indigo-900/10 rounded-xl border border-gray-200 dark:border-gray-700 p-5">
            <div class="flex items-center gap-3 mb-4">
                <div class="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                    <i class="fa-solid fa-calendar-day text-blue-600 dark:text-blue-400"></i>
                </div>
                <div>
                    <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Hari Ini</p>
                    <p class="text-[10px] text-gray-400"><?= date('d M Y') ?></p>
                </div>
            </div>
            <div class="space-y-3">
                <div>
                    <div class="flex justify-between text-sm mb-1">
                        <span class="text-gray-600 dark:text-gray-400 flex items-center gap-1">
                            <i class="fa-solid fa-arrow-down text-green-500 text-xs"></i> Download
                        </span>
                        <span class="font-bold text-gray-900 dark:text-white"><?= formatBytes((int)$usageToday['rx_bytes']) ?></span>
                    </div>
                    <div class="h-2 bg-white/60 dark:bg-gray-700 rounded-full overflow-hidden">
                        <?php
                        $total = max(1, (int)$usageToday['rx_bytes'] + (int)$usageToday['tx_bytes']);
                        $pctRx = min(100, ((int)$usageToday['rx_bytes'] / $total) * 100);
                        ?>
                        <div class="h-full bg-gradient-to-r from-green-400 to-green-600" style="width:<?= $pctRx ?>%"></div>
                    </div>
                </div>
                <div>
                    <div class="flex justify-between text-sm mb-1">
                        <span class="text-gray-600 dark:text-gray-400 flex items-center gap-1">
                            <i class="fa-solid fa-arrow-up text-blue-500 text-xs"></i> Upload
                        </span>
                        <span class="font-bold text-gray-900 dark:text-white"><?= formatBytes((int)$usageToday['tx_bytes']) ?></span>
                    </div>
                    <div class="h-2 bg-white/60 dark:bg-gray-700 rounded-full overflow-hidden">
                        <?php $pctTx = min(100, ((int)$usageToday['tx_bytes'] / $total) * 100); ?>
                        <div class="h-full bg-gradient-to-r from-blue-400 to-blue-600" style="width:<?= $pctTx ?>%"></div>
                    </div>
                </div>
                <div class="pt-3 border-t border-gray-200/60 dark:border-gray-600 flex justify-between">
                    <span class="text-xs font-semibold text-gray-500">Total</span>
                    <span class="text-lg font-bold text-blue-600 dark:text-blue-400"><?= formatBytes((int)$usageToday['rx_bytes'] + (int)$usageToday['tx_bytes']) ?></span>
                </div>
            </div>
        </div>

        <!-- Bulan Ini -->
        <div class="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/10 dark:to-pink-900/10 rounded-xl border border-gray-200 dark:border-gray-700 p-5">
            <div class="flex items-center gap-3 mb-4">
                <div class="w-10 h-10 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                    <i class="fa-solid fa-calendar-days text-purple-600 dark:text-purple-400"></i>
                </div>
                <div>
                    <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Bulan Ini</p>
                    <p class="text-[10px] text-gray-400"><?= date('F Y') ?></p>
                </div>
            </div>
            <div class="space-y-3">
                <div>
                    <div class="flex justify-between text-sm mb-1">
                        <span class="text-gray-600 dark:text-gray-400 flex items-center gap-1">
                            <i class="fa-solid fa-arrow-down text-green-500 text-xs"></i> Download
                        </span>
                        <span class="font-bold text-gray-900 dark:text-white"><?= formatBytes((int)$usageMonth['rx_bytes']) ?></span>
                    </div>
                    <div class="h-2 bg-white/60 dark:bg-gray-700 rounded-full overflow-hidden">
                        <?php
                        $totalM = max(1, (int)$usageMonth['rx_bytes'] + (int)$usageMonth['tx_bytes']);
                        $pctRxM = min(100, ((int)$usageMonth['rx_bytes'] / $totalM) * 100);
                        ?>
                        <div class="h-full bg-gradient-to-r from-green-400 to-emerald-600" style="width:<?= $pctRxM ?>%"></div>
                    </div>
                </div>
                <div>
                    <div class="flex justify-between text-sm mb-1">
                        <span class="text-gray-600 dark:text-gray-400 flex items-center gap-1">
                            <i class="fa-solid fa-arrow-up text-purple-500 text-xs"></i> Upload
                        </span>
                        <span class="font-bold text-gray-900 dark:text-white"><?= formatBytes((int)$usageMonth['tx_bytes']) ?></span>
                    </div>
                    <div class="h-2 bg-white/60 dark:bg-gray-700 rounded-full overflow-hidden">
                        <?php $pctTxM = min(100, ((int)$usageMonth['tx_bytes'] / $totalM) * 100); ?>
                        <div class="h-full bg-gradient-to-r from-purple-400 to-purple-600" style="width:<?= $pctTxM ?>%"></div>
                    </div>
                </div>
                <div class="pt-3 border-t border-gray-200/60 dark:border-gray-600 flex justify-between">
                    <span class="text-xs font-semibold text-gray-500">Total</span>
                    <span class="text-lg font-bold text-purple-600 dark:text-purple-400"><?= formatBytes((int)$usageMonth['rx_bytes'] + (int)$usageMonth['tx_bytes']) ?></span>
                </div>
            </div>
        </div>
    </div>

</div>
