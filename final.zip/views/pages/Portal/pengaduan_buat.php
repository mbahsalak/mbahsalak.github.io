<?php
/**
 * views/pages/Portal/pengaduan_buat.php
 * Form Buat Pengaduan — support pre-fill dari ?jenis=
 */

$csrf = $_SESSION['csrf_token'] ?? '';
$jenis = $jenis ?? '';

// Label & icon berdasarkan jenis
$jenisInfo = [
    'upgrade_paket' => ['fa-arrow-up-right-dots', 'indigo', 'Upgrade Paket', 'Ajukan permintaan perubahan paket langganan Anda.'],
    'perbaikan'     => ['fa-wrench',              'amber',  'Perbaikan',     'Laporkan masalah jaringan untuk diperbaiki tim teknis.'],
    'pemasangan'    => ['fa-plug',                'green',  'Pemasangan',    'Ajukan permintaan pemasangan koneksi internet baru.'],
];

$info    = $jenisInfo[$jenis] ?? ['fa-headset', 'primary', 'Bantuan Umum', 'Laporkan keluhan terkait layanan internet Anda.'];
$jIcon   = $info[0];
$jColor  = $info[1];
$jLabel  = $info[2];
$jDesc   = $info[3];
?>

<div class="max-w-3xl mx-auto space-y-6">

    <!-- HEADER -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div class="flex items-center gap-3 mb-2">
            <a href="/ticketing" class="w-9 h-9 rounded-lg bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
                <i class="fa-solid fa-arrow-left"></i>
            </a>
            <div class="flex items-center gap-3 flex-1">
                <div class="w-10 h-10 rounded-lg bg-<?php echo $jColor; ?>-100 dark:bg-<?php echo $jColor; ?>-900/30 flex items-center justify-center">
                    <i class="fa-solid <?php echo $jIcon; ?> text-<?php echo $jColor; ?>-600 dark:text-<?php echo $jColor; ?>-400"></i>
                </div>
                <div>
                    <h1 class="text-xl font-bold text-gray-900 dark:text-white"><?php echo htmlspecialchars($jLabel); ?></h1>
                    <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo htmlspecialchars($jDesc); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- INFO PAKET SAAT INI (khusus upgrade) -->
    <?php if ($jenis === 'upgrade_paket'): ?>
    <div class="bg-indigo-50 dark:bg-indigo-900/10 rounded-xl border border-indigo-200 dark:border-indigo-800 p-5">
        <p class="text-xs font-semibold text-indigo-600 dark:text-indigo-400 uppercase mb-3">Paket Anda Saat Ini</p>
        <div class="grid grid-cols-3 gap-4 text-sm">
            <div>
                <p class="text-gray-500 dark:text-gray-400 text-xs">Nama Paket</p>
                <p class="font-bold text-gray-900 dark:text-white"><?php echo htmlspecialchars($paket['nama_paket'] ?? '-'); ?></p>
            </div>
            <div>
                <p class="text-gray-500 dark:text-gray-400 text-xs">Kecepatan</p>
                <p class="font-bold text-gray-900 dark:text-white"><?php echo htmlspecialchars($paket['kecepatan'] ?? '-'); ?></p>
            </div>
            <div>
                <p class="text-gray-500 dark:text-gray-400 text-xs">Biaya/Bulan</p>
                <p class="font-bold text-gray-900 dark:text-white">Rp <?php echo number_format((float)($paket['harga'] ?? 0), 0, ',', '.'); ?></p>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- ERROR -->
    <?php if (!empty($errors)): ?>
    <div class="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl p-4">
        <div class="flex gap-3">
            <i class="fa-solid fa-triangle-exclamation text-red-500 mt-0.5"></i>
            <div>
                <p class="font-semibold text-red-800 dark:text-red-300 text-sm">Periksa kembali isian Anda:</p>
                <ul class="list-disc list-inside text-sm text-red-700 dark:text-red-400 mt-2 space-y-1">
                    <?php foreach ($errors as $e): ?>
                    <li><?php echo htmlspecialchars($e); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- FORM -->
    <form method="POST" action="/ticketing/store" class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6 space-y-5">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf); ?>">
        <input type="hidden" name="latitude" id="latitude" value="<?php echo htmlspecialchars($old['latitude'] ?? ''); ?>">
        <input type="hidden" name="longitude" id="longitude" value="<?php echo htmlspecialchars($old['longitude'] ?? ''); ?>">
        <?php if ($jenis): ?>
        <input type="hidden" name="jenis" value="<?php echo htmlspecialchars($jenis); ?>">
        <?php endif; ?>

        <!-- JUDUL -->
        <div>
            <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                Judul <span class="text-red-500">*</span>
            </label>
            <input type="text" name="judul" required minlength="5" maxlength="150"
                value="<?php echo htmlspecialchars($old['judul'] ?? ''); ?>"
                placeholder="Contoh: Internet lambat sejak pagi"
                class="w-full px-4 py-2.5 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm focus:ring-2 focus:ring-primary focus:border-transparent">
        </div>

        <!-- DESKRIPSI -->
        <div>
            <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                Deskripsi <span class="text-red-500">*</span>
            </label>
            <textarea name="deskripsi" required minlength="10" rows="8"
                placeholder="Jelaskan keluhan atau permintaan Anda secara detail..."
                class="w-full px-4 py-2.5 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm focus:ring-2 focus:ring-primary focus:border-transparent"><?php echo htmlspecialchars($old['deskripsi'] ?? ''); ?></textarea>
            
            <?php if ($jenis === 'upgrade_paket'): ?>
            <p class="text-xs text-indigo-500 dark:text-indigo-400 mt-1">
                <i class="fa-solid fa-info-circle mr-1"></i>
                Silakan lengkapi: <strong>nama paket yang diinginkan</strong> dan <strong>alasan upgrade</strong>.
            </p>
            <?php endif; ?>
        </div>

        <!-- LOKASI -->
        <div>
            <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                Lokasi (Opsional)
            </label>
            <div class="flex gap-2">
                <input type="text" id="locationText" readonly
                    placeholder="Klik tombol di samping untuk mengambil lokasi Anda"
                    value="<?php echo htmlspecialchars(($old['latitude'] ?? '') ? ($old['latitude'] . ', ' . $old['longitude']) : ''); ?>"
                    class="flex-1 px-4 py-2.5 rounded-lg border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white text-sm">
                <button type="button" onclick="getMyLocation()"
                    class="px-4 py-2.5 rounded-lg bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 text-sm font-medium hover:bg-blue-200 dark:hover:bg-blue-900/50 transition-colors">
                    <i class="fa-solid fa-location-crosshairs mr-1"></i> Ambil Lokasi
                </button>
            </div>
            <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Lokasi membantu teknisi menemukan titik masalah lebih cepat.
            </p>
        </div>

        <!-- TOMBOL AKSI -->
        <div class="flex gap-3 pt-4 border-t border-gray-100 dark:border-gray-700">
            <button type="submit"
                class="flex-1 px-4 py-2.5 rounded-lg bg-primary text-white text-sm font-medium hover:bg-indigo-600 transition-colors">
                <i class="fa-solid fa-paper-plane mr-1"></i> Kirim Pengaduan
            </button>
            <a href="/ticketing"
                class="px-4 py-2.5 rounded-lg bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-sm font-medium hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors">
                Batal
            </a>
        </div>
    </form>

</div>

<script>
function getMyLocation() {
    if (!navigator.geolocation) {
        alert('Browser Anda tidak mendukung geolocation.');
        return;
    }
    navigator.geolocation.getCurrentPosition(
        function(pos) {
            var lat = pos.coords.latitude.toFixed(7);
            var lng = pos.coords.longitude.toFixed(7);
            document.getElementById('latitude').value = lat;
            document.getElementById('longitude').value = lng;
            document.getElementById('locationText').value = lat + ', ' + lng;
        },
        function(err) { alert('Gagal mengambil lokasi: ' + err.message); },
        { enableHighAccuracy: true, timeout: 10000 }
    );
}
</script>
