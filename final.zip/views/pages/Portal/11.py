"""
 MikroTik REST API Server v4.0
Simulasi RouterOS 7.x REST API — lengkap layaknya router asli
"""

from flask import Flask, jsonify, request, Response
import random, time, json, hashlib
from functools import wraps
from datetime import datetime

app = Flask(__name__)

# ============================================================
# AUTH
# ============================================================
USERS_DB = {
    "admin":      "admin123",
    "monitoring": "monitor123",
    "teknisi":    "teknisi123",
}

def check_auth(u, p): return USERS_DB.get(u) == p
def authenticate():
    return Response(
        json.dumps({"error": "Autentikasi gagal"}), 401,
        {'WWW-Authenticate': 'Basic realm="MikroTik"', 'Content-Type': 'application/json'}
    )
def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.username, auth.password):
            return authenticate()
        return f(*args, **kwargs)
    return decorated

# ============================================================
# DATA STORE - ISP Tafi Net
# ============================================================

ROUTERS_DB = {
    "AA:BB:CC:DD:EE:01": {"identity": "Tafi-Router-Core", "base_uptime": 604800, "board": "RB4011iGS+RM", "version": "7.14.1", "arch": "arm64"},
    "AA:BB:CC:DD:EE:02": {"identity": "Tafi-Router-ODP-A", "base_uuptime": 259200, "board": "hEX S", "version": "7.13.5", "arch": "mipsbe"},
    "AA:BB:CC:DD:EE:03": {"identity": "Tafi-Router-ODP-B", "base_uptime": 86400, "board": "CCR1009-7G-1C-1S+", "version": "7.14.2", "arch": "tile"},
}

# NAMA PELANGGAN TAfi NET
NAMA_PELANGGAN = [
    "Ahmad Fauzi", "Siti Nurhaliza", "Budi Santoso", "Dewi Lestari", "Eko Prasetyo",
    "Fitri Rahayu", "Gunawan Hidayat", "Heni Marlina", "Irfan Maulana", "Jihan Salsabila",
    "Kurniawan Adi", "Lina Setiawan", "Muhammad Rizki", "Neng Mariana", "Oman Sulaeman",
    "Putri Wulandari", "Qori Ismail", "Ratna Setiawan", "Slamet Riyadi", "Tuti Alawiyah",
    "Udin Siregar", "Vina Panduwinata", "Wawan Hermawan", "Xena Putri", "Yudi Kurniawan",
    "Zaki Ahmad", "Andi Saputra", "Beti Wijaya", "Candra Kusuma", "Dina Anggraini",
    "Euis Permata", "Farah Ramadhani", "Gani Suherman", "Hesti Handayani", "Ira Audy",
    "Joni Sanjaya", "Kiki Kejora", "Lulu Marlina", "Mimi Sari", "Nani Wijaya",
    "Opi Hermawan", "Popo Fauzi", "Qiqi Lestari", "Rere Prasetyo", "Sasa Rahayu",
    "Tata Hidayat", "Uu Marlina", "Vava Maulana", "Wawa Salsabila", "Xixi Adi",
    "Yaya Setiawan", "Zaza Rizki", "Ayu Mariana", "Beni Sulaeman", "Cici Wulandari",
    "Dodo Ismail", "Eni Setiawan", "Feni Riyadi", "Geri Alawiyah", "Heni Siregar",
    "Indi Panduwinata", "Jeni Hermawan", "Koko Putri", "Lala Kurniawan", "Momo Ahmad",
    "Nana Saputra", "Ono Wijaya", "Pipi Kusuma", "Qori Anggraini", "Rian Permata",
    "Samsul Ramadhani", "Tita Suherman", "Ujang Handayani", "Vina Audy", "Wawan Sanjaya",
    "Xena Kejora", "Yudi Marlina", "Zaki Sari", "Abdi Wijaya", "Bobi Hermawan",
    "Caca Fauzi", "Dedi Lestari", "Eka Prasetyo", "Fifi Rahayu", "Gigi Hidayat",
    "Heri Marlina", "Iin Maulana", "Jaja Salsabila", "Koko Adi", "Lulu Setiawan",
    "Mimi Rizki", "Nana Mariana", "Ono Sulaeman", "Popo Wulandari", "Qiqi Ismail",
    "Rere Setiawan", "Sasa Riyadi", "Tata Alawiyah", "Umi Siregar", "Vivi Panduwinata",
    "Weni Hermawan", "Xavi Putri", "Yani Kurniawan", "Zaza Ahmad",
]

# GENERATE MAC ADDRESS untuk 100 pelanggan
def generate_mac_addresses(count):
    macs = []
    for i in range(1, count + 1):
        mac = f"00:1A:2B:3C:4D:{i:02X}"
        macs.append(mac)
    return macs

MAC_ADDRESSES = generate_mac_addresses(100)

# PPPoE Secrets - 100 Pelanggan Tafi Net
PPPOE_SECRETS = []
for i in range(100):
    nama = NAMA_PELANGGAN[i]
    username = f"tafi{i+1:03d}"
    password = f"pass{i+1:03d}!"
    
    # Random paket
    paket = random.choice([
        {"name": "Bronze-20Mbps", "price": 150000},
        {"name": "Silver-30Mbps", "price": 200000},
        {"name": "Gold-50Mbps", "price": 275000},
        {"name": "Platinum-100Mbps", "price": 350000},
    ])
    
    PPPOE_SECRETS.append({
        "name": username,
        "password": password,
        "profile": paket["name"],
        "service": "pppoe",
        "comment": nama,
        "disabled": "false" if i % 10 != 0 else "true",  # 10% disabled
        "local-address": "10.10.0.1",
        "remote-address": "pppoe-pool",
        "harga": paket["price"],
        "odp": f"ODP-{chr(65 + (i % 5))}",  # ODP-A sampai ODP-E
        "alamat": f"Jl. Melati No.{i+1}, RT {(i%10)+1:02d}/{(i%5)+1:02d}",
    })

# PPPoE Profiles
PPPOE_PROFILES = [
    {"name": "Bronze-20Mbps", "rate-limit": "20M/20M", "session-timeout": "", "idle-timeout": "00:30:00", "only-one": "yes"},
    {"name": "Silver-30Mbps", "rate-limit": "30M/30M", "session-timeout": "", "idle-timeout": "00:30:00", "only-one": "yes"},
    {"name": "Gold-50Mbps", "rate-limit": "50M/50M", "session-timeout": "", "idle-timeout": "00:30:00", "only-one": "yes"},
    {"name": "Platinum-100Mbps", "rate-limit": "100M/100M", "session-timeout": "", "idle-timeout": "01:00:00", "only-one": "yes"},
    {"name": "default", "rate-limit": "10M/10M", "session-timeout": "", "idle-timeout": "00:30:00", "only-one": "no"},
]

# PPPoE Active - 85 pelanggan online
PPPOE_ACTIVE = []
for i in range(85):
    pelanggan = PPPOE_SECRETS[i]
    if pelanggan["disabled"] == "false":
        uptime_days = random.randint(0, 7)
        uptime_hours = random.randint(0, 23)
        uptime_mins = random.randint(0, 59)
        uptime_secs = random.randint(0, 59)
        uptime_str = f"{uptime_days}d {uptime_hours:02d}:{uptime_mins:02d}:{uptime_secs:02d}"
        
        PPPOE_ACTIVE.append({
            "name": pelanggan["name"],
            "address": f"10.10.1.{i+2}",
            "uptime": uptime_str,
            "mac-address": MAC_ADDRESSES[i],
            "encoding": "",
            "caller-id": MAC_ADDRESSES[i],
            "service": "pppoe",
            "radius": "no",
        })

# Simple Queues - Bandwidth Management
SIMPLE_QUEUES = []
for i, pelanggan in enumerate(PPPOE_SECRETS[:85]):
    if pelanggan["disabled"] == "false":
        rate_map = {
            "Bronze-20Mbps": "20M/20M",
            "Silver-30Mbps": "30M/30M",
            "Gold-50Mbps": "50M/50M",
            "Platinum-100Mbps": "100M/100M",
        }
        max_limit = rate_map.get(pelanggan["profile"], "10M/10M")
        
        SIMPLE_QUEUES.append({
            "name": pelanggan["name"],
            "target": f"10.10.1.{i+2}/32",
            "max-limit": max_limit,
            "burst-limit": "",
            "burst-time": "",
            "burst-threshold": "",
            "priority": "8/8",
            "comment": pelanggan["comment"],
            "disabled": pelanggan["disabled"],
            "parent": "none",
        })

# IP Address List
IP_ADDRESSES = [
    {"address": "192.168.1.1/24", "interface": "bridge-lan", "network": "192.168.1.0", "disabled": "false", "dynamic": "false"},
    {"address": "10.10.0.1/24", "interface": "pppoe-out", "network": "10.10.0.0", "disabled": "false", "dynamic": "false"},
    {"address": "203.0.113.10/29", "interface": "ether1-wan", "network": "203.0.113.8", "disabled": "false", "dynamic": "true"},
]

# IP Routes
IP_ROUTES = [
    {"dst-address": "0.0.0.0/0", "gateway": "203.0.113.1", "distance": "1", "active": "true", "dynamic": "true", "comment": "Default Route"},
    {"dst-address": "192.168.1.0/24", "gateway": "bridge-lan", "distance": "0", "active": "true", "dynamic": "true", "comment": "LAN Route"},
    {"dst-address": "10.10.0.0/24", "gateway": "0.0.0.0", "distance": "0", "active": "true", "dynamic": "true", "comment": "PPPoE Pool"},
]

# Firewall Filter Rules
FIREWALL_FILTER = [
    {"chain": "input", "action": "accept", "protocol": "icmp", "comment": "Allow ICMP", "disabled": "false"},
    {"chain": "input", "action": "accept", "connection-state": "established,related", "comment": "Allow Established", "disabled": "false"},
    {"chain": "input", "action": "drop", "in-interface": "ether1-wan", "comment": "Drop WAN Input", "disabled": "false"},
    {"chain": "forward", "action": "accept", "connection-state": "established,related", "comment": "Allow Forward", "disabled": "false"},
    {"chain": "forward", "action": "drop", "connection-state": "invalid", "comment": "Drop Invalid", "disabled": "false"},
]

# Firewall NAT
FIREWALL_NAT = [
    {"chain": "srcnat", "action": "masquerade", "out-interface": "ether1-wan", "comment": "Masquerade WAN", "disabled": "false"},
]

# DHCP Leases
DHCP_LEASES = [
    {"address": "192.168.1.100", "mac-address": "BC:AE:C5:11:22:33", "client-id": "", "hostname": "PC-Admin", "status": "bound", "expires-after": "00:22:14", "dynamic": "true"},
    {"address": "192.168.1.101", "mac-address": "D4:E6:B7:44:55:66", "client-id": "", "hostname": "Laptop-Teknisi", "status": "bound", "expires-after": "00:45:02", "dynamic": "true"},
    {"address": "192.168.1.102", "mac-address": "F0:18:98:77:88:99", "client-id": "", "hostname": "CCTV-NVR", "status": "bound", "expires-after": "01:12:33", "dynamic": "true"},
]

# Interface List
INTERFACES = [
    {"name": "ether1-wan", "type": "ether", "mtu": "1500", "mac-address": "AA:BB:CC:DD:EE:01", "running": "true", "disabled": "false", "comment": "WAN ISP Upstream"},
    {"name": "ether2", "type": "ether", "mtu": "1500", "mac-address": "AA:BB:CC:DD:EE:02", "running": "true", "disabled": "false", "comment": "LAN Port 1"},
    {"name": "ether3", "type": "ether", "mtu": "1500", "mac-address": "AA:BB:CC:DD:EE:03", "running": "true", "disabled": "false", "comment": "LAN Port 2"},
    {"name": "ether4", "type": "ether", "mtu": "1500", "mac-address": "AA:BB:CC:DD:EE:04", "running": "true", "disabled": "false", "comment": "LAN Port 3"},
    {"name": "ether5", "type": "ether", "mtu": "1500", "mac-address": "AA:BB:CC:DD:EE:05", "running": "true", "disabled": "false", "comment": "LAN Port 4"},
    {"name": "bridge-lan", "type": "bridge", "mtu": "1500", "mac-address": "AA:BB:CC:DD:EE:06", "running": "true", "disabled": "false", "comment": "LAN Bridge"},
    {"name": "pppoe-out", "type": "pppoe", "mtu": "1480", "mac-address": "", "running": "true", "disabled": "false", "comment": "PPPoE Server"},
    {"name": "wlan1", "type": "wifi", "mtu": "1500", "mac-address": "AA:BB:CC:DD:EE:07", "running": "true", "disabled": "false", "comment": "WiFi 2.4GHz"},
    {"name": "wlan2", "type": "wifi", "mtu": "1500", "mac-address": "AA:BB:CC:DD:EE:08", "running": "true", "disabled": "false", "comment": "WiFi 5GHz"},
    {"name": "lo", "type": "loopback", "mtu": "65536", "mac-address": "", "running": "true", "disabled": "false", "comment": "Loopback"},
]

# DNS Static
DNS_STATIC = [
    {"name": "router.tafi.net", "address": "192.168.1.1", "ttl": "1d", "disabled": "false"},
    {"name": "billing.tafi.net", "address": "192.168.1.10", "ttl": "1d", "disabled": "false"},
    {"name": "radius.tafi.net", "address": "192.168.1.11", "ttl": "1d", "disabled": "false"},
]

# NTP Config
NTP_CONFIG = {
    "enabled": "yes",
    "mode": "unicast",
    "primary-ntp": "pool.ntp.org",
    "secondary-ntp": "time.google.com",
}

# SNMP Config
SNMP_CONFIG = {
    "enabled": "yes",
    "contact": "admin@tafi.net",
    "location": "Server Room Tafi Net",
    "engine-id": "tafi_net_001",
}

# ODP (Optical Distribution Point) Locations
ODP_LOCATIONS = [
    {"name": "ODP-A", "latitude": -6.2000, "longitude": 106.8400, "kapasitas": 32, "terpasang": 28},
    {"name": "ODP-B", "latitude": -6.2050, "longitude": 106.8450, "kapasitas": 32, "terpasang": 25},
    {"name": "ODP-C", "latitude": -6.2100, "longitude": 106.8500, "kapasitas": 32, "terpasang": 30},
    {"name": "ODP-D", "latitude": -6.2150, "longitude": 106.8550, "kapasitas": 32, "terpasang": 22},
    {"name": "ODP-E", "latitude": -6.2200, "longitude": 106.8600, "kapasitas": 32, "terpasang": 20},
]

# Log entries
LOG_ENTRIES = [
    {"time": "jun/10 06:21:58", "topics": "system,info", "message": "system started"},
    {"time": "jun/10 06:22:01", "topics": "pppoe,info", "message": "tafi001 logged in, 10.10.1.2"},
    {"time": "jun/10 06:22:03", "topics": "pppoe,info", "message": "tafi002 logged in, 10.10.1.3"},
    {"time": "jun/10 08:14:22", "topics": "firewall,info", "message": "Dropped invalid packet from 1.2.3.4"},
    {"time": "jun/10 12:00:00", "topics": "system,info", "message": "auto backup completed"},
    {"time": "jun/11 03:15:44", "topics": "dhcp,info", "message": "DHCP assigned 192.168.1.101 to D4:E6:B7:44:55:66"},
]

_mac_cache = {}
START_TIME = time.time()

# ============================================================
# HELPERS
# ============================================================
def format_uptime(seconds):
    w = seconds // 604800; r = seconds % 604800
    d = r // 86400;        r = r % 86400
    h = r // 3600;         r = r % 3600
    m = r // 60;           s = r % 60
    parts = []
    if w: parts.append(f"{w}w")
    if d: parts.append(f"{d}d")
    parts.append(f"{h:02}:{m:02}:{s:02}")
    return " ".join(parts)

def format_bytes(b):
    for unit in ['B','KiB','MiB','GiB','TiB']:
        if b < 1024: return f"{b:.1f} {unit}"
        b /= 1024
    return f"{b:.1f} TiB"

def seed_mac(mac):
    return int(hashlib.md5(mac.encode()).hexdigest(), 16) % (2**32)

def get_router_data(mac):
    if mac not in _mac_cache:
        random.seed(seed_mac(mac))
        boards = ["RB4011iGS+RM","hEX S","hAP ac2","RB750Gr3","CCR1009","RB3011UiAS","RB2011UiAS","RBD53G"]
        _mac_cache[mac] = {
            "identity":    f"CPE-{mac[-5:].replace(':','')}",
            "board":       random.choice(boards),
            "version":     random.choice(["7.14.1","7.14.2","7.13.5"]),
            "base_uptime": random.randint(3600, 2592000),
            "base_rx":     random.randint(500_000, 50_000_000),
            "base_tx":     random.randint(200_000, 20_000_000),
            "cpu_count":   random.choice([1, 2, 4]),
            "total_mem":   random.choice([64, 128, 256, 512, 1024]) * 1024 * 1024,
        }
        random.seed()
    return _mac_cache[mac]


# ============================================================
# ROOT
# ============================================================
@app.route('/')
def index():
    return jsonify({
        "status":  "ok",
        "server":  "Dummy MikroTik REST API",
        "version": "4.0",
        "auth":    "Basic (admin/admin123)",
        "endpoints": [
            "GET  /api/mikrotik/<mac>",
            "GET  /api/interface",
            "GET  /api/interface/monitor-traffic",
            "GET  /api/ip/address",
            "GET  /api/ip/route",
            "GET  /api/ip/dhcp-server/lease",
            "GET  /api/ip/dns/static",
            "GET  /api/pppoe/secrets",
            "POST /api/pppoe/secrets",
            "POST /api/pppoe/secrets/<user>/password",
            "POST /api/pppoe/secrets/<user>/toggle",
            "DEL  /api/pppoe/secrets/<user>",
            "GET  /api/pppoe/active",
            "POST /api/pppoe/active/<user>/kick",
            "GET  /api/pppoe/profile",
            "GET  /api/queues",
            "POST /api/queues",
            "POST /api/queues/<name>",
            "DEL  /api/queues/<name>",
            "GET  /api/firewall/filter",
            "GET  /api/firewall/nat",
            "GET  /api/system/resource",
            "GET  /api/system/routerboard",
            "GET  /api/system/clock",
            "GET  /api/system/ntp-client",
            "GET  /api/system/snmp",
            "GET  /api/log",
            "GET  /api/clients/active",
            "POST /api/clients/active/<mac>/kick",
            "GET  /api/clients/<mac>/uptime",
            "GET  /api/clients/<mac>/bandwidth",
            "GET  /api/clients/<mac>/usage/today",
            "GET  /api/clients/<mac>/usage/month",
        ]
    })

# ============================================================
# ROUTER STATS (per MAC)
# ============================================================
@app.route('/api/mikrotik/<path:mac_address>', methods=['GET'])
@requires_auth
def get_stats(mac_address):
    mac = mac_address.upper().strip()
    r   = ROUTERS_DB.get(mac) or get_router_data(mac)

    elapsed = int(time.time() - START_TIME)
    uptime  = r.get("base_uptime", 86400) + elapsed

    base_rx = r.get("base_rx", 500_000)
    base_tx = r.get("base_tx", 200_000)
    rx_bps  = max(100_000, base_rx + random.randint(-base_rx//4, base_rx//4))
    tx_bps  = max(50_000,  base_tx + random.randint(-base_tx//4, base_tx//4))

    total_mem = r.get("total_mem", 256 * 1024 * 1024)
    free_mem  = int(total_mem * random.uniform(0.4, 0.85))
    cpu_count = r.get("cpu_count", 1)
    cpu_loads = [random.randint(5, 60) for _ in range(cpu_count)]

    return jsonify({
        "mac_address":       mac,
        "identity":          r.get("identity", f"CPE-{mac[-5:]}"),
        "board_name":        r.get("board", "RouterBOARD"),
        "ros_version":       r.get("version", "7.14.1 (stable)"),
        "architecture_name": r.get("arch", "arm"),
        "uptime":            format_uptime(uptime),
        "uptime_seconds":    uptime,
        "cpu_count":         cpu_count,
        "cpu_load":          cpu_loads[0],
        "cpu_loads":         cpu_loads,
        "cpu_frequency":     "1400",
        "total_memory":      total_mem,
        "free_memory":       free_mem,
        "total_hdd_space":   128 * 1024 * 1024,
        "free_hdd_space":    random.randint(80, 120) * 1024 * 1024,
        "write_sect_since_reboot": random.randint(10000, 500000),
        "bad_blocks":        "0",
        "traffic": {
            "rx_byte":  50_000_000 + (elapsed * random.randint(10_000, 100_000)),
            "tx_byte":  20_000_000 + (elapsed * random.randint(5_000, 50_000)),
        },
        "bandwidth_usage": {
            "rx_bits_per_second": rx_bps,
            "tx_bits_per_second": tx_bps,
            "rx_mbps":  round(rx_bps / 100_000, 2),
            "tx_mbps":  round(tx_bps / 100_000, 2),
            "rx_human": format_bytes(rx_bps) + "/s",
            "tx_human": format_bytes(tx_bps) + "/s",
        },
        "interfaces": [
            {"name": i["name"], "mac_address": i["mac-address"],
             "status": "link-ok" if i["running"] == "true" else "no-link",
             "rx_byte": random.randint(1_000_000, 10_000_000_000),
             "tx_byte": random.randint(1_000_000, 5_000_000_000)}
            for i in INTERFACES if i["type"] == "ether"
        ],
        "active_pppoe": len(PPPOE_ACTIVE),
        "total_secrets": len(PPPOE_SECRETS),
    })

# ============================================================
# SYSTEM
# ============================================================
@app.route('/api/system/resource', methods=['GET'])
@requires_auth
def system_resource():
    elapsed = int(time.time() - START_TIME)
    return jsonify({
        "uptime":            format_uptime(604800 + elapsed),
        "version":           "7.14.1 (stable)",
        "build-time":        "2024-03-01 08:00:00",
        "free-memory":       "512.0MiB",
        "total-memory":      "1024.0MiB",
        "cpu":               "ARM",
        "cpu-count":         "4",
        "cpu-frequency":     "1400MHz",
        "cpu-load":          f"{random.randint(5,45)}%",
        "free-hdd-space":    "98.0MiB",
        "total-hdd-space":   "128.0MiB",
        "write-sect-since-reboot": str(random.randint(10000, 500000)),
        "write-sect-total":  str(random.randint(500000, 5000000)),
        "bad-blocks":        "0%",
        "architecture-name": "arm64",
        "board-name":        "RB4011iGS+RM",
        "platform":          "MikroTik",
    })

@app.route('/api/system/routerboard', methods=['GET'])
@requires_auth
def system_routerboard():
    return jsonify({
        "routerboard":       "yes",
        "model":             "RB4011iGS+RM",
        "revision":          "r2",
        "serial-number":     "HGL08Y4T1RN",
        "firmware-type":     "al2",
        "factory-firmware":  "7.6",
        "current-firmware":  "7.14.1",
        "upgrade-firmware":  "7.14.1",
    })

@app.route('/api/system/clock', methods=['GET'])
@requires_auth
def system_clock():
    now = datetime.now()
    return jsonify({
        "time": now.strftime("%H:%M:%S"),
        "date": now.strftime("%b/%d/%Y"),
        "time-zone-autodetect": "yes",
        "time-zone-name":       "Asia/Jakarta",
        "gmt-offset":           "+07:00",
        "dst-active":           "no",
    })

@app.route('/api/system/ntp-client', methods=['GET'])
@requires_auth
def system_ntp():
    return jsonify(NTP_CONFIG)

@app.route('/api/system/snmp', methods=['GET'])
@requires_auth
def system_snmp():
    return jsonify(SNMP_CONFIG)

# ============================================================
# SYSTEM INFO
# ============================================================

@app.route('/api/system/info', methods=['GET'])
@requires_auth
def system_info():
    return jsonify({
        "identity":     "MikroTik RB750",
        "board-name":   "RB750Gr3",
        "version":      "7.12.1",
        "cpu-load":     random.randint(5, 45),
        "uptime":       "12d 04:33:17",
        "free-memory":  str(random.randint(80_000_000, 200_000_000)),
        "total-memory": "268435456",
    })


@app.route('/api/system/identity', methods=['GET'])
@requires_auth
def system_identity():
    return jsonify({"name": "MikroTik RB750"})


# ============================================================
# INTERFACES
# ============================================================

@app.route('/api/interface', methods=['GET'])
@requires_auth
def get_interfaces():
    result = []
    for i in INTERFACES:
        rx = random.randint(1_000_000, 10_000_000_000)
        tx = random.randint(1_000_000, 5_000_000_000)
        result.append({**i, "rx-byte": str(rx), "tx-byte": str(tx),
                        "rx-packet": str(rx//1400), "tx-packet": str(tx//1400),
                        "rx-error": "0", "tx-error": "0", "rx-drop": "0", "tx-drop": "0"})
    return jsonify(result)

@app.route('/api/interface/monitor-traffic', methods=['GET', 'POST'])
@requires_auth
def monitor_traffic():
    iface = request.args.get('interface', 'ether1-wan')
    return jsonify([{
        "name":          iface,
        "rx-bits-per-second": str(random.randint(1_000_000, 100_000_000)),
        "tx-bits-per-second": str(random.randint(500_000,  50_000_000)),
        "rx-packets-per-second": str(random.randint(100, 10000)),
        "tx-packets-per-second": str(random.randint(50,  5000)),
        "fp-rx-bits-per-second": str(random.randint(1_000_000, 100_000_000)),
        "fp-tx-bits-per-second": str(random.randint(500_000,  50_000_000)),
    }])

# ============================================================
# IP
# ============================================================
@app.route('/api/ip/address', methods=['GET'])
@requires_auth
def ip_address():
    return jsonify(IP_ADDRESSES)

@app.route('/api/ip/route', methods=['GET'])
@requires_auth
def ip_route():
    return jsonify(IP_ROUTES)

@app.route('/api/ip/dns/static', methods=['GET'])
@requires_auth
def dns_static():
    return jsonify(DNS_STATIC)

@app.route('/api/ip/dhcp-server/lease', methods=['GET'])
@requires_auth
def dhcp_leases():
    leases = []
    for l in DHCP_LEASES:
        leases.append({**l, "expires-after": l["expires-after"] or "never"})
    return jsonify(leases)

# ============================================================
# PPPoE PROFILES
# ============================================================
@app.route('/api/pppoe/profile', methods=['GET'])
@requires_auth
def get_pppoe_profiles():
    return jsonify(PPPOE_PROFILES)

# ============================================================
# PPPoE SECRETS
# ============================================================
@app.route('/api/pppoe/secrets', methods=['GET'])
@requires_auth
def get_pppoe_secrets():
    return jsonify(PPPOE_SECRETS)

@app.route('/api/pppoe/secrets', methods=['POST'])
@requires_auth
def add_pppoe_secret():
    data = request.get_json() or {}
    username = data.get('username', '').strip()
    if not username:
        return jsonify({"ok": False, "error": "username wajib diisi"}), 400
    if any(s['name'] == username for s in PPPOE_SECRETS):
        return jsonify({"ok": False, "error": f"Username '{username}' sudah ada"}), 409
    PPPOE_SECRETS.append({
        "name":           username,
        "password":       data.get('password', ''),
        "profile":        data.get('profile', 'default'),
        "service":        data.get('service', 'pppoe'),
        "comment":        data.get('comment', ''),
        "disabled":       "false",
        "local-address":  "10.10.0.1",
        "remote-address": "pppoe-pool",
    })
    return jsonify({"ok": True, "name": username})

@app.route('/api/pppoe/secrets/<username>/password', methods=['POST'])
@requires_auth
def update_pppoe_password(username):
    data = request.get_json() or {}
    for s in PPPOE_SECRETS:
        if s['name'] == username:
            s['password'] = data.get('password', s['password'])
            return jsonify({"ok": True})
    return jsonify({"ok": False, "error": "Secret tidak ditemukan"}), 404

@app.route('/api/pppoe/secrets/<username>/toggle', methods=['POST'])
@requires_auth
def toggle_pppoe_secret(username):
    for s in PPPOE_SECRETS:
        if s['name'] == username:
            s['disabled'] = "true" if s['disabled'] == "false" else "false"
            return jsonify({"ok": True, "disabled": s['disabled']})
    return jsonify({"ok": False, "error": "Secret tidak ditemukan"}), 404

@app.route('/api/pppoe/secrets/<username>', methods=['DELETE'])
@requires_auth
def delete_pppoe_secret(username):
    global PPPOE_SECRETS
    before = len(PPPOE_SECRETS)
    PPPOE_SECRETS = [s for s in PPPOE_SECRETS if s['name'] != username]
    if len(PPPOE_SECRETS) < before:
        # Juga kick active session jika ada
        global PPPOE_ACTIVE
        PPPOE_ACTIVE = [a for a in PPPOE_ACTIVE if a['name'] != username]
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": "Secret tidak ditemukan"}), 404

# ============================================================
# PPPoE ACTIVE
# ============================================================
@app.route('/api/pppoe/active', methods=['GET'])
@requires_auth
def get_pppoe_active():
    result = []
    elapsed = int(time.time() - START_TIME)
    for a in PPPOE_ACTIVE:
        # Hitung bytes dinamis
        rx = random.randint(1_000_000, 500_000_000)
        tx = random.randint(500_000,   200_000_000)
        result.append({
            **a,
            "rx-bytes": str(rx),
            "tx-bytes": str(tx),
            "rx-bytes-human": format_bytes(rx),
            "tx-bytes-human": format_bytes(tx),
            "rx-bits-per-second": str(random.randint(100_000, 50_000_000)),
            "tx-bits-per-second": str(random.randint(50_000,  20_000_000)),
        })
    return jsonify(result)

@app.route('/api/pppoe/active/<username>/kick', methods=['POST'])
@requires_auth
def kick_pppoe_session(username):
    global PPPOE_ACTIVE
    before = len(PPPOE_ACTIVE)
    PPPOE_ACTIVE = [a for a in PPPOE_ACTIVE if a['name'] != username]
    if len(PPPOE_ACTIVE) < before:
        return jsonify({"ok": True, "message": f"Session {username} telah di-kick"})
    return jsonify({"ok": False, "error": "Session tidak ditemukan"}), 404

# ============================================================
# SIMPLE QUEUES
# ============================================================
@app.route('/api/queues', methods=['GET'])
@requires_auth
def get_queues():
    result = []
    for q in SIMPLE_QUEUES:
        result.append({
            **q,
            "queued-packets": f"{random.randint(0,50)}/{random.randint(0,50)}",
            "queued-bytes":   f"{random.randint(0,65535)}/{random.randint(0,65535)}",
            "bytes":          f"{random.randint(0,10_000_000)}/{random.randint(0,5_000_000)}",
            "packets":        f"{random.randint(0,10000)}/{random.randint(0,5000)}",
        })
    return jsonify(result)

@app.route('/api/queues', methods=['POST'])
@requires_auth
def add_queue():
    data = request.get_json() or {}
    name = data.get('name', '').strip()
    if not name:
        return jsonify({"ok": False, "error": "name wajib diisi"}), 400
    if any(q['name'] == name for q in SIMPLE_QUEUES):
        return jsonify({"ok": False, "error": f"Queue '{name}' sudah ada"}), 409
    SIMPLE_QUEUES.append({
        "name":             name,
        "target":           data.get('target', ''),
        "max-limit":        data.get('maxLimit', '10M/10M'),
        "burst-limit":      "",
        "burst-time":       "",
        "burst-threshold":  "",
        "priority":         "8/8",
        "comment":          data.get('comment', ''),
        "disabled":         "false",
        "parent":           "none",
    })
    return jsonify({"ok": True, "name": name})

@app.route('/api/queues/<name>', methods=['POST'])
@requires_auth
def update_queue(name):
    data = request.get_json() or {}
    for q in SIMPLE_QUEUES:
        if q['name'] == name:
            if 'maxLimit' in data: q['max-limit'] = data['maxLimit']
            if 'target'   in data: q['target']    = data['target']
            if 'comment'  in data: q['comment']   = data['comment']
            if 'disabled' in data: q['disabled']  = str(data['disabled']).lower()
            return jsonify({"ok": True})
    return jsonify({"ok": False, "error": "Queue tidak ditemukan"}), 404

@app.route('/api/queues/<name>', methods=['DELETE'])
@requires_auth
def delete_queue(name):
    global SIMPLE_QUEUES
    before = len(SIMPLE_QUEUES)
    SIMPLE_QUEUES = [q for q in SIMPLE_QUEUES if q['name'] != name]
    if len(SIMPLE_QUEUES) < before:
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": "Queue tidak ditemukan"}), 404

# ============================================================
# FIREWALL
# ============================================================
@app.route('/api/firewall/filter', methods=['GET'])
@requires_auth
def firewall_filter():
    return jsonify([{**r, "bytes": str(random.randint(0, 10_000_000_000)),
                     "packets": str(random.randint(0, 10_000_000))}
                    for r in FIREWALL_FILTER])

@app.route('/api/firewall/nat', methods=['GET'])
@requires_auth
def firewall_nat():
    return jsonify([{**r, "bytes": str(random.randint(0, 50_000_000_000)),
                     "packets": str(random.randint(0, 50_000_000))}
                    for r in FIREWALL_NAT])

# ============================================================
# LOG
# ============================================================
@app.route('/api/log', methods=['GET'])
@requires_auth
def get_log():
    # Tambahkan log entry realtime
    entries = list(LOG_ENTRIES)
    now = datetime.now().strftime("%b/%d %H:%M:%S").lower()
    entries.append({"time": now, "topics": "system,info", "message": f"uptime {format_uptime(int(time.time()-START_TIME)+86400)}"})
    return jsonify(entries[-50:])  # 50 entries terakhir

# ============================================================
# CONNECTED CLIENTS (MAC-based, NO PPPoE)
# Deteksi klien aktif via DHCP lease + ARP table + wireless
# ============================================================
CONNECTED_CLIENTS = [
    {
        "mac-address": "AA:BB:CC:DD:EE:01",
        "ip-address":  "192.168.1.100",
        "hostname":    "CPE-Budi-Santoso",
        "interface":   "bridge-lan",
        "uptime":      "6d 14:22:11",
        "rx-bytes":    0,
        "tx-bytes":    0,
        "signal":      "-45 dBm",
        "source":      "dhcp",
    },
    {
        "mac-address": "AA:BB:CC:DD:EE:02",
        "ip-address":  "192.168.1.101",
        "hostname":    "CPE-Siti-Rahayu",
        "interface":   "bridge-lan",
        "uptime":      "2d 08:44:55",
        "rx-bytes":    0,
        "tx-bytes":    0,
        "signal":      "-52 dBm",
        "source":      "dhcp",
    },
    {
        "mac-address": "AA:BB:CC:DD:EE:03",
        "ip-address":  "192.168.1.102",
        "hostname":    "CPE-Ahmad-Fauzi",
        "interface":   "bridge-lan",
        "uptime":      "1d 01:05:09",
        "rx-bytes":    0,
        "tx-bytes":    0,
        "signal":      "-60 dBm",
        "source":      "arp",
    },
    {
        "mac-address": "A1:B2:C3:D4:E5:F6",
        "ip-address":  "192.168.1.103",
        "hostname":    "Unknown-Device",
        "interface":   "ether2",
        "uptime":      "0d 03:15:22",
        "rx-bytes":    0,
        "tx-bytes":    0,
        "signal":      "",
        "source":      "arp",
    },
    {
        "mac-address": "BC:AE:C5:11:22:33",
        "ip-address":  "192.168.1.104",
        "hostname":    "PC-Admin",
        "interface":   "bridge-lan",
        "uptime":      "0d 00:22:14",
        "rx-bytes":    0,
        "tx-bytes":    0,
        "signal":      "",
        "source":      "dhcp",
    },
]

@app.route('/api/clients/active', methods=['GET'])
@requires_auth
def get_connected_clients():
    """
    Deteksi semua klien aktif berdasarkan MAC address.
    Sumber: DHCP lease + ARP table + wireless registration.
    BUKAN dari PPPoE.
    """
    result = []
    for c in CONNECTED_CLIENTS:
        rx = random.randint(1_000_000, 500_000_000)
        tx = random.randint(500_000,   200_000_000)
        result.append({
            **c,
            "rx-bytes":       str(rx),
            "tx-bytes":       str(tx),
            "rx-bytes-human": format_bytes(rx),
            "tx-bytes-human": format_bytes(tx),
        })
    return jsonify(result)


@app.route('/api/clients/active/<path:mac_address>/kick', methods=['POST'])
@requires_auth
def kick_client(mac_address):
    """Putus koneksi klien berdasarkan MAC address."""
    global CONNECTED_CLIENTS
    mac = mac_address.upper().strip()
    before = len(CONNECTED_CLIENTS)
    CONNECTED_CLIENTS = [c for c in CONNECTED_CLIENTS if c['mac-address'].upper() != mac]
    if len(CONNECTED_CLIENTS) < before:
        return jsonify({"ok": True, "message": f"Klien {mac} telah diputus"})
    return jsonify({"ok": False, "error": "Klien tidak ditemukan"}), 404

# ============================================================
# PER-CLIENT ENDPOINTS (by MAC Address)
# ============================================================

@app.route('/api/clients/<path:mac_address>/uptime', methods=['GET'])
@requires_auth
def client_uptime(mac_address):
    """Status uptime klien berdasarkan MAC address."""
    mac = mac_address.upper().strip()
    client = next((c for c in CONNECTED_CLIENTS if c['mac-address'].upper() == mac), None)

    if client:
        # Parse uptime string "6d 14:22:11" → seconds
        uptime_str = client.get('uptime', '0d 00:00:00')
        parts = uptime_str.replace('d ', ' ').split()
        if len(parts) == 2:
            days = int(parts[0])
            time_parts = parts[1].split(':')
            uptime_sec = days * 86400 + int(time_parts[0]) * 3600 + int(time_parts[1]) * 60 + int(time_parts[2])
        else:
            uptime_sec = 0

        return jsonify({
            "status":       "online",
            "uptime":       str(uptime_sec),
            "uptime_human": uptime_str,
            "ip":           client['ip-address'],
            "identity":     "MikroTik Router",
            "mode":         client.get('source', 'dhcp'),
            "signal":       client.get('signal', ''),
            "connected_at": "2025-06-06 08:00:00",
            "interface":    client.get('interface', 'bridge-lan'),
        })
    else:
        return jsonify({
            "status":    "offline",
            "uptime":    "0",
            "last_seen": "2025-06-12 08:30:00",
            "ip":        None,
            "identity":  None,
        })


@app.route('/api/clients/<path:mac_address>/bandwidth', methods=['GET'])
@requires_auth
def client_bandwidth(mac_address):
    """Bandwidth real-time klien berdasarkan MAC address."""
    mac = mac_address.upper().strip()
    client = next((c for c in CONNECTED_CLIENTS if c['mac-address'].upper() == mac), None)

    if client:
        rx_rate = random.randint(50_000, 12_500_000)   # bytes/s (up to ~100 Mbps)
        tx_rate = random.randint(10_000,  5_000_000)    # bytes/s
        return jsonify({
            "ok":         True,
            "rx_rate":    rx_rate,
            "tx_rate":    tx_rate,
            "rx_byte":    str(random.randint(1_000_000, 50_000_000)),
            "tx_byte":    str(random.randint(50_000_000,  200_000_000)),
            "ip":         client['ip-address'],
            "queue_name": f"queue-{mac.replace(':', '').lower()[:6]}",
            "mode":       client.get('source', 'dhcp'),
            "max_mbps":   100,
        })
    else:
        return jsonify({
            "ok":      False,
            "rx_rate": 0,
            "tx_rate": 0,
            "error":   "Client offline",
        })


@app.route('/api/clients/<path:mac_address>/usage/today', methods=['GET'])
@requires_auth
def client_usage_today(mac_address):
    """Penggunaan bandwidth hari ini (per jam)."""
    mac = mac_address.upper().strip()
    client = next((c for c in CONNECTED_CLIENTS if c['mac-address'].upper() == mac), None)

    if not client:
        return jsonify({"rx_bytes": 0, "tx_bytes": 0, "hourly": []})

    current_hour = datetime.now().hour
    hourly = []
    total_rx = 0
    total_tx = 0

    for h in range(current_hour + 1):
        rx = random.randint(50_000_000, 800_000_000)
        tx = random.randint(20_000_000, 300_000_000)
        total_rx += rx
        total_tx += tx
        hourly.append({
            "hour":     h,
            "rx_bytes": rx,
            "tx_bytes": tx,
        })

    return jsonify({
        "rx_bytes": total_rx,
        "tx_bytes": total_tx,
        "hourly":   hourly,
    })


@app.route('/api/clients/<path:mac_address>/usage/month', methods=['GET'])
@requires_auth
def client_usage_month(mac_address):
    """Penggunaan bandwidth bulan ini (per hari)."""
    mac = mac_address.upper().strip()
    client = next((c for c in CONNECTED_CLIENTS if c['mac-address'].upper() == mac), None)

    if not client:
        return jsonify({"rx_bytes": 0, "tx_bytes": 0, "daily": []})

    current_day = datetime.now().day
    daily = []
    total_rx = 0
    total_tx = 0

    for d in range(1, current_day + 1):
        date_str = f"2025-06-{d:02d}"
        rx = random.randint(500_000_000, 15_000_000_000)
        tx = random.randint(200_000_000,  5_000_000_000)
        total_rx += rx
        total_tx += tx
        daily.append({
            "date":     date_str,
            "rx_bytes": rx,
            "tx_bytes": tx,
        })

    return jsonify({
        "rx_bytes": total_rx,
        "tx_bytes": total_tx,
        "daily":    daily,
    })

# ============================================================
# HEALTH
# ============================================================
@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        "status":    "healthy",
        "timestamp": int(time.time()),
        "uptime":    format_uptime(int(time.time() - START_TIME)),
        "secrets":   len(PPPOE_SECRETS),
        "active":    len(PPPOE_ACTIVE),
        "queues":    len(SIMPLE_QUEUES),
    })

@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "error":         "Endpoint tidak ditemukan",
        "requested_url": request.url,
        "hint":          "Akses / untuk melihat semua endpoint",
    }), 404

@app.errorhandler(405)
def method_not_allowed(error):
    return jsonify({"error": "Method tidak diizinkan"}), 405

# ============================================================
if __name__ == '__main__':
    print("=" * 60)
    print("  Dummy MikroTik REST API Server v4.0")
    print("  URL  : http://localhost:5000")
    print("  Auth : admin / admin123")
    print("  Endpoints: lihat GET /")
    print("=" * 60)
    app.run(host='0.0.0.0', port=5000, debug=True)
