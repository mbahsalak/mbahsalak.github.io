<?php
/**
 * views/pages/Portal/tagihan.php — Tagihan Belum Bayar
 */
function formatRpT(float $n): string { return 'Rp ' . number_format($n, 0, ',', '.'); }
?>

<div class="max-w-[1320px] mx-auto space-y-6">

    <!-- HEADER -->
    <div class="bg-gradient-to-r from-red-500 to-orange-500 rounded-2xl p-6 text-white shadow-lg">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 class="text-2xl font-bold flex items-center gap-2">
                    <i class="fa-solid fa-file-invoice-dollar"></i> Tagihan Saya
                </h1>
                <p class="text-red-100 text-sm mt-1">Daftar tagihan yang belum Anda bayarkan.</p>
            </div>
            <div class="text-right">
                <p class="text-xs text-red-100 uppercase font-semibold">Total Tunggakan</p>
                <p class="text-2xl font-bold"><?= formatRpT($totalTunggakan) ?></p>
                <p class="text-xs text-red-100 mt-1"><?= count($tagihan) ?> tagihan belum dibayar</p>
            </div>
        </div>
    </div>

    <!-- TABEL TAGIHAN -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div class="px-5 py-4 border-b border-gray-200 dark:border-gray-700">
            <h2 class="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <i class="fa-solid fa-list-check text-red-500"></i>
                Tagihan Belum Dibayar
                <?php if (count($tagihan) > 0): ?>
                <span class="ml-1 px-2 py-0.5 rounded-full bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 text-[10px] font-bold">
                    <?= count($tagihan) ?>
                </span>
                <?php endif; ?>
            </h2>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
                    <tr>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase w-10">#</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Periode</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Tipe</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Jatuh Tempo</th>
                        <th class="px-5 py-3 text-right text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Jumlah</th>
                        <th class="px-5 py-3 text-center text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                    <?php if (!empty($tagihan)): ?>
                        <?php foreach ($tagihan as $i => $t): ?>
                        <?php
                        $isOverdue = !empty($t['jatuh_tempo']) && strtotime($t['jatuh_tempo']) < time();
                        $tipeLabel = match($t['tipe'] ?? 'paket') {
                            'paket'      => 'Abonemen',
                            'pemasangan' => 'Pasang Baru',
                            'perbaikan'  => 'Perbaikan',
                            'lainnya'    => 'Lainnya',
                            default      => ucfirst($t['tipe'] ?? '-'),
                        };
                        ?>
                        <tr class="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                            <td class="px-5 py-3 text-gray-400"><?= $i + 1 ?></td>
                            <td class="px-5 py-3">
                                <p class="font-medium text-gray-900 dark:text-white"><?= htmlspecialchars($t['periode'] ?? '-') ?></p>
                                <?php if (!empty($t['deskripsi'])): ?>
                                <p class="text-[10px] text-gray-400 mt-0.5"><?= htmlspecialchars($t['deskripsi']) ?></p>
                                <?php endif; ?>
                            </td>
                            <td class="px-5 py-3 text-xs text-gray-500 dark:text-gray-400"><?= $tipeLabel ?></td>
                            <td class="px-5 py-3 text-gray-500 dark:text-gray-400">
                                <?php if (!empty($t['jatuh_tempo'])): ?>
                                    <span class="<?= $isOverdue ? 'text-red-600 dark:text-red-400 font-semibold' : '' ?>">
                                        <?= date('d M Y', strtotime($t['jatuh_tempo'])) ?>
                                        <?php if ($isOverdue): ?>
                                        <span class="ml-1 text-[10px] font-bold text-red-500">TERLAMBAT</span>
                                        <?php endif; ?>
                                    </span>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td class="px-5 py-3 text-right font-bold text-gray-900 dark:text-white">
                                <?= formatRpT((float)($t['total'] ?? 0)) ?>
                            </td>
                            <td class="px-5 py-3 text-center">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide
                                    <?= $isOverdue ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' : 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' ?>">
                                    <?= $isOverdue ? 'Terlambat' : 'Belum Bayar' ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="px-5 py-16 text-center">
                                <i class="fa-solid fa-circle-check text-5xl text-green-400 mb-4"></i>
                                <p class="text-sm font-medium text-gray-700 dark:text-gray-300">Tidak ada tagihan tertunggak 🎉</p>
                                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Semua tagihan Anda sudah lunas.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- RIWAYAT BARU (5 terakhir) -->
    <?php if (!empty($riwayatBaru)): ?>
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div class="px-5 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
            <h2 class="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <i class="fa-solid fa-clock-rotate-left text-blue-500"></i>
                Pembayaran Terbaru
            </h2>
            <a href="/pembayaran" class="text-xs font-medium text-primary hover:text-indigo-600">Lihat semua &rarr;</a>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
                    <tr>
                        <th class="px-5 py-2.5 text-left text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase">Periode</th>
                        <th class="px-5 py-2.5 text-left text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase">Tanggal Bayar</th>
                        <th class="px-5 py-2.5 text-center text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase">Metode</th>
                        <th class="px-5 py-2.5 text-right text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase">Jumlah</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                    <?php foreach ($riwayatBaru as $r): ?>
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                        <td class="px-5 py-3 font-medium text-gray-900 dark:text-white text-xs"><?= htmlspecialchars($r['periode'] ?? '-') ?></td>
                        <td class="px-5 py-3 text-xs text-gray-500 dark:text-gray-400"><?= !empty($r['tgl_bayar']) ? date('d M Y', strtotime($r['tgl_bayar'])) : '-' ?></td>
                        <td class="px-5 py-3 text-center">
                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                                <i class="fa-solid fa-circle-check mr-1"></i><?= htmlspecialchars($r['metode'] ?? 'Tunai') ?>
                            </span>
                        </td>
                        <td class="px-5 py-3 text-right font-bold text-gray-900 dark:text-white text-xs"><?= formatRpT((float)($r['total'] ?? 0)) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

</div>
