<?php
/**
 * views/pages/Portal/pengaduan.php — Pengaduan Saya
 */
?>

<div class="max-w-[1320px] mx-auto space-y-6">

    <!-- HEADER -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 class="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                    <i class="fa-solid fa-headset text-amber-600"></i> Pengaduan Saya
                </h1>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">Daftar laporan keluhan yang pernah Anda kirim.</p>
            </div>
            <a href="/ticketing/buat"
                class="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-indigo-600 transition-colors shadow-sm">
                <i class="fa-solid fa-plus"></i> Buat Pengaduan Baru
            </a>
        </div>
    </div>

    <!-- FILTER STATUS -->
    <div class="flex flex-wrap gap-2">
        <?php
        $filters = [
            'all'     => ['Semua', 'gray'],
            'open'    => ['Baru', 'red'],
            'proses'  => ['Proses', 'amber'],
            'selesai' => ['Selesai', 'green'],
        ];
        foreach ($filters as $key => [$label, $color]):
            $isActive = $filterStatus === $key;
        ?>
        <a href="/ticketing<?= $key !== 'all' ? '?status=' . $key : '' ?>"
            class="px-4 py-1.5 rounded-full text-xs font-semibold transition-colors
                <?= $isActive
                    ? 'bg-gray-900 text-white dark:bg-white dark:text-gray-900'
                    : 'bg-' . $color . '-100 text-' . $color . '-700 hover:bg-' . $color . '-200 dark:bg-' . $color . '-900/30 dark:text-' . $color . '-400' ?>">
            <?= $label ?>
        </a>
        <?php endforeach; ?>
    </div>

    <!-- LIST -->
    <div class="space-y-3">
        <?php if (!empty($pengaduan)): ?>
            <?php foreach ($pengaduan as $pg): ?>
            <?php
            [$bg, $txt, $lbl] = match($pg['status'] ?? 'open') {
                'open'    => ['bg-red-100 dark:bg-red-900/30',    'text-red-700 dark:text-red-400',      'Baru'],
                'proses'  => ['bg-amber-100 dark:bg-amber-900/30','text-amber-700 dark:text-amber-400',  'Dalam Proses'],
                'selesai' => ['bg-green-100 dark:bg-green-900/30','text-green-700 dark:text-green-400',  'Selesai'],
                default   => ['bg-gray-100 dark:bg-gray-700',     'text-gray-700 dark:text-gray-300',    ucfirst($pg['status'] ?? '-')],
            };
            $iconColor = match($pg['status'] ?? 'open') {
                'open'    => 'red', 'proses' => 'amber', 'selesai' => 'green', default => 'gray',
            };
            ?>
            <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 hover:shadow-md transition-shadow">
                <div class="flex items-start gap-4">
                    <div class="w-10 h-10 rounded-lg bg-<?= $iconColor ?>-100 dark:bg-<?= $iconColor ?>-900/30 flex items-center justify-center flex-shrink-0">
                        <i class="fa-solid fa-<?= $pg['status'] === 'selesai' ? 'circle-check' : ($pg['status'] === 'proses' ? 'spinner' : 'circle-exclamation') ?> text-<?= $iconColor ?>-600 dark:text-<?= $iconColor ?>-400"></i>
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-2">
                            <h3 class="font-bold text-gray-900 dark:text-white truncate">
                                <?= htmlspecialchars($pg['judul'] ?? '-') ?>
                            </h3>
                            <span class="inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide <?= $bg ?> <?= $txt ?> w-fit">
                                <?= $lbl ?>
                            </span>
                        </div>
                        <p class="text-sm text-gray-600 dark:text-gray-400 line-clamp-2 mb-3">
                            <?= htmlspecialchars($pg['deskripsi'] ?? '-') ?>
                        </p>
                        <div class="flex flex-wrap items-center gap-3 text-xs text-gray-500 dark:text-gray-400">
                            <span class="flex items-center gap-1">
                                <i class="fa-solid fa-calendar"></i>
                                <?= date('d M Y, H:i', strtotime($pg['created_at'] ?? 'now')) ?>
                            </span>
                            <?php if (!empty($pg['updated_at']) && $pg['updated_at'] !== $pg['created_at']): ?>
                            <span class="flex items-center gap-1">
                                <i class="fa-solid fa-pen"></i>
                                Diperbarui <?= date('d M Y', strtotime($pg['updated_at'])) ?>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <a href="/ticketing/<?= $pg['id'] ?>"
                        class="inline-flex items-center gap-1 px-3 py-1.5 rounded-md border border-primary text-primary hover:bg-primary hover:text-white text-xs font-medium transition-colors flex-shrink-0">
                        <i class="fa-solid fa-eye"></i> Detail
                    </a>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-16 text-center">
                <i class="fa-solid fa-inbox text-5xl text-gray-300 dark:text-gray-600 mb-4"></i>
                <p class="text-sm font-medium text-gray-700 dark:text-gray-300">Belum ada pengaduan</p>
                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1 mb-4">
                    <?php if ($filterStatus !== 'all'): ?>
                        Tidak ada pengaduan dengan status ini.
                        <a href="/ticketing" class="text-primary hover:underline">Lihat semua</a>
                    <?php else: ?>
                        Klik tombol di bawah untuk membuat pengaduan baru.
                    <?php endif; ?>
                </p>
                <?php if ($filterStatus === 'all'): ?>
                <a href="/ticketing/buat"
                    class="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-indigo-600 transition-colors">
                    <i class="fa-solid fa-plus"></i> Buat Pengaduan Baru
                </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

</div>
