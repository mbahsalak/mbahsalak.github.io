<?php
/** views/pages/Paket/create.php */
$appUrl = $_ENV['APP_URL'] ?? '';
?>

<div style="max-width:500px; margin:0 auto;">

    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.25rem;">
        <h4 style="margin:0; font-size:1.15rem; font-weight:700; color:#1f2937;">Tambah Paket</h4>
        <a href="<?= $appUrl ?>/paket"
           style="display:inline-flex;align-items:center;gap:.4rem;padding:.4rem .9rem;border:1.5px solid #e5e7eb;border-radius:8px;text-decoration:none;color:#6b7280;font-size:.8rem;font-weight:600;">
            <i class="fa-solid fa-arrow-left"></i> Kembali
        </a>
    </div>

    <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
        <div style="height:5px; background:#6366f1; border-radius:12px 12px 0 0;"></div>
        <div style="padding:1.25rem 1.5rem; border-bottom:1px solid #e5e7eb;">
            <h2 style="margin:0; font-size:1rem; color:#374151; display:flex; align-items:center; gap:.5rem;">
                <i class="fa-solid fa-box-open" style="color:#6366f1;"></i> Form Tambah Paket
            </h2>
        </div>

        <form action="<?= $appUrl ?>/paket/store" method="POST" style="padding:1.5rem;">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">

            <div style="margin-bottom:1rem;">
                <label style="display:block; font-size:.75rem; font-weight:700; color:#6b7280; text-transform:uppercase; margin-bottom:.4rem;">Nama Paket</label>
                <input type="text" name="nama_paket" required
                       style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem;">
            </div>

            <div style="margin-bottom:1rem;">
                <label style="display:block; font-size:.75rem; font-weight:700; color:#6b7280; text-transform:uppercase; margin-bottom:.4rem;">Kecepatan</label>
                <input type="text" name="kecepatan" required placeholder="cth. 10 Mbps"
                       style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem;">
            </div>

            <div style="margin-bottom:1rem;">
                <label style="display:block; font-size:.75rem; font-weight:700; color:#6b7280; text-transform:uppercase; margin-bottom:.4rem;">Harga (Rp)</label>
                <input type="text" name="harga" required placeholder="cth. 150000"
                       style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem;">
            </div>

            <div style="margin-bottom:1.5rem;">
                <label style="display:block; font-size:.75rem; font-weight:700; color:#6b7280; text-transform:uppercase; margin-bottom:.4rem;">Deskripsi</label>
                <textarea name="deskripsi" rows="3"
                          style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; resize:none;"></textarea>
            </div>

            <div style="display:flex; justify-content:flex-end; gap:.75rem; padding-top:1.25rem; border-top:1px solid #e5e7eb;">
                <a href="<?= $appUrl ?>/paket"
                   style="padding:.6rem 1.25rem; border:1.5px solid #e5e7eb; border-radius:8px; text-decoration:none; color:#6b7280; font-weight:600; font-size:.875rem;">Batal</a>
                <button type="submit"
                        style="padding:.6rem 1.5rem; background:#6366f1; color:#fff; border:none; border-radius:8px; font-weight:600; font-size:.875rem; cursor:pointer;">
                    <i class="fa-solid fa-floppy-disk" style="margin-right:.25rem;"></i> Simpan
                </button>
            </div>
        </form>
    </div>
</div>
