<?php
/**
 * views/pages/Paket/index.php — Tailwind CSS version
 */
$appUrl = $_ENV['APP_URL'] ?? '';
?>

<!-- PAGE HEADER -->
<div class="flex items-center justify-between flex-wrap gap-3 mb-5">
    <div>
        <h1 class="flex items-center gap-2 text-xl font-bold text-gray-800 m-0">
            <i class="fa-solid fa-wifi text-indigo-500"></i>
            Paket Internet
        </h1>
        <p class="text-sm text-gray-500 mt-0.5 mb-0">Kelola paket layanan internet</p>
    </div>
    <a href="<?= $appUrl ?>/paket/tambah"
       class="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors no-underline">
        <i class="fa-solid fa-plus"></i> Tambah Paket
    </a>
</div>

<!-- FLASH MESSAGE -->
<?php if (!empty($flash)): ?>
    <?php
    $flashType = $flash['type'] ?? 'info';
    $flashClasses = [
        'success' => 'bg-green-50 border-green-300 text-green-700',
        'error'   => 'bg-red-50 border-red-300 text-red-700',
        'warning' => 'bg-yellow-50 border-yellow-300 text-yellow-700',
        'info'    => 'bg-cyan-50 border-cyan-300 text-cyan-700',
    ];
    $fc = $flashClasses[$flashType] ?? $flashClasses['info'];
    ?>
    <div class="flex items-center gap-2 px-4 py-3 mb-4 rounded-lg border text-sm <?= $fc ?>" role="alert">
        <i class="fa-solid fa-<?= $flashType === 'success' ? 'circle-check' : 'circle-exclamation' ?>"></i>
        <span><?= htmlspecialchars($flash['message'] ?? '') ?></span>
        <button onclick="this.parentElement.remove()"
                class="ml-auto bg-transparent border-0 cursor-pointer opacity-60 hover:opacity-100 text-inherit p-0 leading-none">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>
<?php endif; ?>

<!-- TABLE CARD -->
<div class="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">

    <!-- Card Header -->
    <div class="flex items-center justify-between px-5 py-3 bg-gray-50 border-b border-gray-200">
        <h2 class="flex items-center gap-2 text-xs font-bold text-gray-500 uppercase tracking-wide m-0">
            <i class="fa-solid fa-list text-indigo-500"></i>
            Daftar Paket
        </h2>
        <?php if (!empty($list)): ?>
            <span class="text-xs text-gray-400"><?= count($list) ?> paket</span>
        <?php endif; ?>
    </div>

    <!-- Table -->
    <div class="overflow-x-auto">
        <table class="w-full text-sm border-collapse">
            <thead>
                <tr class="bg-gray-50">
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 whitespace-nowrap w-10">#</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 whitespace-nowrap">Nama Paket</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 whitespace-nowrap">Kecepatan</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 whitespace-nowrap w-32">Harga</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500">Deskripsi</th>
                    <th class="px-4 py-3 text-center text-xs font-semibold text-gray-500 whitespace-nowrap w-24">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($list)): ?>
                    <?php foreach ($list as $i => $row): ?>
                        <tr class="border-t border-gray-100 hover:bg-gray-50 transition-colors">

                            <!-- No -->
                            <td class="px-4 py-3 text-gray-400 text-sm"><?= $i + 1 ?></td>

                            <!-- Nama Paket -->
                            <td class="px-4 py-3 font-semibold text-gray-800">
                                <?= htmlspecialchars($row['nama_paket'] ?? '-') ?>
                            </td>

                            <!-- Kecepatan -->
                            <td class="px-4 py-3">
                                <span class="inline-flex items-center gap-1 bg-indigo-50 text-indigo-600 text-xs font-semibold px-3 py-1 rounded-full whitespace-nowrap">
                                    <i class="fa-solid fa-gauge-high text-xs"></i>
                                    <?= htmlspecialchars($row['kecepatan'] ?? '-') ?>
                                </span>
                            </td>

                            <!-- Harga -->
                            <td class="px-4 py-3 font-semibold text-gray-800 whitespace-nowrap">
                                Rp&nbsp;<?= number_format((float)($row['harga'] ?? 0), 0, ',', '.') ?>
                            </td>

                            <!-- Deskripsi -->
                            <td class="px-4 py-3 text-gray-500 max-w-[200px] truncate">
                                <?= htmlspecialchars($row['deskripsi'] ?? '-') ?>
                            </td>

                            <!-- Aksi -->
                            <td class="px-4 py-3">
                                <div class="flex items-center justify-center gap-1.5">
                                    <!-- Edit -->
                                    <a href="<?= $appUrl ?>/paket/edit/<?= $row['id'] ?>"
                                       title="Edit"
                                       class="inline-flex items-center justify-center w-7 h-7 rounded-md border border-amber-400 text-amber-500 hover:bg-amber-400 hover:text-white transition-colors text-xs no-underline">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </a>
                                    <!-- Hapus -->
                                    <form method="POST"
                                          action="<?= $appUrl ?>/paket/hapus/<?= $row['id'] ?>"
                                          class="m-0"
                                          onsubmit="return confirm('Hapus paket <?= htmlspecialchars(addslashes($row['nama_paket'] ?? '')) ?>?')">
                                        <input type="hidden" name="csrf_token"
                                               value="<?= htmlspecialchars(\Core\Middleware::generateCsrfToken()) ?>">
                                        <button type="submit"
                                                title="Hapus"
                                                class="inline-flex items-center justify-center w-7 h-7 rounded-md border border-red-400 text-red-500 hover:bg-red-400 hover:text-white transition-colors text-xs cursor-pointer bg-transparent p-0 font-[inherit]">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>

                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="px-4 py-12 text-center text-gray-400">
                            <i class="fa-solid fa-inbox text-3xl block mb-3 opacity-40"></i>
                            Belum ada paket tersedia.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>
