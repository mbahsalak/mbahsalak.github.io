<?php
/**
 * views/pages/Ticketing/index.php - Tailwind CSS + Leaflet Maps
 */
$appUrl  = $_ENV['APP_URL'] ?? '';
$tickets = $tickets ?? [];

$total    = count($tickets);
$open     = count(array_filter($tickets, fn($t) => ($t['status'] ?? '') === 'open'));
$proses   = count(array_filter($tickets, fn($t) => ($t['status'] ?? '') === 'proses'));
$selesai  = count(array_filter($tickets, fn($t) => ($t['status'] ?? '') === 'selesai'));

// Filter tickets with location
$ticketsWithLocation = array_filter($tickets, fn($t) => !empty($t['latitude']) && !empty($t['longitude']));
$hasAnyLocation = count($ticketsWithLocation) > 0;
?>

<div class="flex justify-between items-center mb-6 flex-wrap gap-4">
    <div>
        <h1 class="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <i class="fa-solid fa-headset text-indigo-600"></i>
            Tiket Pengaduan
        </h1>
        <p class="text-slate-600 mt-1">Kelola tiket layanan pelanggan</p>
    </div>
    <a href="<?= $appUrl ?>/ticketing/buat"
       class="px-5 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-medium transition-colors flex items-center gap-2 text-sm shadow-sm">
        <i class="fa-solid fa-plus"></i> Buat Tiket
    </a>
</div>

<?php if (!empty($flash)): ?>
    <div class="flex items-center gap-3 p-4 mb-4 rounded-lg border <?= 
        match($flash['type'] ?? 'info') {
            'success' => 'bg-green-50 border-green-200 text-green-800',
            'error'   => 'bg-red-50 border-red-200 text-red-800',
            default   => 'bg-blue-50 border-blue-200 text-blue-800'
        } ?> shadow-sm">
        <i class="fa-solid fa-<?= ($flash['type'] ?? '') === 'success' ? 'circle-check' : 'circle-xmark' ?>"></i>
        <span><?= htmlspecialchars($flash['message'] ?? '') ?></span>
        <button class="ml-auto text-inherit hover:text-inherit" onclick="this.parentElement.remove()">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>
<?php endif; ?>

<!-- Summary -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <?php foreach ([
        ['fa-list',         'Total',   $total,   'indigo'],
        ['fa-circle-exclamation', 'Open', $open,  'red'],
        ['fa-spinner',      'Proses',  $proses,  'amber'],
        ['fa-circle-check', 'Selesai', $selesai, 'emerald'],
    ] as [$icon, $label, $val, $color]): ?>
    <div class="bg-white rounded-xl p-4 border-l-4 border-<?= $color ?>-500 shadow-sm">
        <div class="text-xs text-slate-500 mb-1 flex items-center gap-2">
            <i class="fa-solid <?= $icon ?> text-<?= $color ?>-500"></i><?= $label ?>
        </div>
        <div class="text-2xl font-bold text-<?= $color ?>-600"><?= $val ?></div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Maps Section -->
<?php if ($hasAnyLocation): ?>
<div class="bg-white rounded-xl overflow-hidden shadow-sm border border-slate-200 mb-6">
    <div class="px-6 py-4 border-b border-slate-200 bg-gradient-to-r from-indigo-50 to-white">
        <h2 class="text-sm font-bold text-slate-900 flex items-center gap-2">
            <i class="fa-solid fa-map-location-dot text-indigo-600"></i>
            Peta Lokasi Pengaduan
            <span class="ml-2 px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 text-xs font-semibold">
                <?= count($ticketsWithLocation) ?> titik
            </span>
        </h2>
    </div>
    <div class="p-4">
        <div id="map-index" class="h-96 rounded-lg border border-slate-300 z-10"></div>
        <p class="text-xs text-slate-500 mt-2 flex items-center gap-1">
            <i class="fa-solid fa-circle-info"></i>
            Klik marker untuk melihat detail tiket
        </p>
    </div>
</div>
<?php endif; ?>

<!-- Table -->
<div class="bg-white rounded-xl overflow-hidden shadow-sm border border-slate-200">
    <div class="overflow-x-auto">
        <table class="w-full border-collapse text-sm">
            <thead>
                <tr class="bg-slate-50">
                    <th class="px-4 py-3 text-left font-semibold text-slate-600 w-12">#</th>
                    <th class="px-4 py-3 text-left font-semibold text-slate-600">Pelanggan</th>
                    <th class="px-4 py-3 text-left font-semibold text-slate-600">No. WA</th>
                    <th class="px-4 py-3 text-left font-semibold text-slate-600">Paket</th>
                    <th class="px-4 py-3 text-left font-semibold text-slate-600">Judul</th>
                    <th class="px-4 py-3 text-left font-semibold text-slate-600">Status</th>
                    <th class="px-4 py-3 text-left font-semibold text-slate-600">Tanggal</th>
                    <th class="px-4 py-3 text-center font-semibold text-slate-600 w-20">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($tickets)): ?>
                    <?php foreach ($tickets as $i => $t):
                        $status = $t['status'] ?? 'open';
                        [$bg, $txt, $icon] = match($status) {
                            'open'    => ['bg-red-100', 'text-red-700', 'fa-circle-exclamation'],
                            'proses'  => ['bg-amber-100', 'text-amber-700', 'fa-spinner'],
                            'selesai' => ['bg-emerald-100', 'text-emerald-700', 'fa-circle-check'],
                            default   => ['bg-slate-100', 'text-slate-700', 'fa-circle'],
                        };
                    ?>
                        <tr class="border-t border-slate-200 hover:bg-slate-50">
                            <td class="px-4 py-3 text-slate-500"><?= $i + 1 ?></td>
                            <td class="px-4 py-3 font-semibold">
                                <?= htmlspecialchars($t['nama_lengkap'] ?? '-') ?>
                            </td>
                            <td class="px-4 py-3">
                                <?php $noTelp = preg_replace('/^0/', '62', $t['no_telp'] ?? ''); ?>
                                <?php if (!empty($t['no_telp'])): ?>
                                    <div class="inline-flex items-center gap-2">
                                        <span class="text-sm"><?= htmlspecialchars($t['no_telp']) ?></span>
                                        <a href="https://wa.me/<?= $noTelp ?>" target="_blank" title="Chat WA"
                                           class="px-2 py-1.5 rounded bg-emerald-100 border border-emerald-200 text-emerald-700 text-xs font-medium flex items-center">
                                            <i class="fa-brands fa-whatsapp"></i>
                                        </a>
                                    </div>
                                <?php else: ?>
                                    <span class="text-slate-400">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3">
                                <?php if (!empty($t['nama_paket'])): ?>
                                    <span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-violet-100 text-violet-700">
                                        <?= htmlspecialchars($t['nama_paket']) ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-slate-400">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3 max-w-56 truncate">
                                <?= htmlspecialchars($t['judul'] ?? '-') ?>
                            </td>
                            <td class="px-4 py-3">
                                <span class="px-3 py-1.5 rounded-full text-xs font-semibold <?= $bg ?> <?= $txt ?>">
                                    <i class="fa-solid <?= $icon ?> mr-1"></i>
                                    <?= ucfirst($status) ?>
                                </span>
                            </td>
                            <td class="px-4 py-3 text-slate-500">
                                <?= !empty($t['created_at']) ? date('d M Y', strtotime($t['created_at'])) : '-' ?>
                            </td>
                            <td class="px-4 py-3 text-center">
                                <a href="<?= $appUrl ?>/ticketing/<?= $t['id'] ?>" title="Detail"
                                   class="px-2.5 py-2 rounded border border-indigo-500 text-indigo-600 text-xs font-medium flex items-center justify-center hover:bg-indigo-50 transition-colors">
                                    <i class="fa-solid fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="px-4 py-12 text-center text-slate-500">
                            <i class="fa-solid fa-inbox text-4xl opacity-40 block mb-3"></i>
                            Belum ada tiket pengaduan.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($hasAnyLocation): ?>
<!-- Leaflet CSS & JS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<script>
// Initialize map
const map = L.map('map-index').setView([-6.200000, 106.816666], 12);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors',
    maxZoom: 19
}).addTo(map);

// Add markers for all tickets with location
const markers = [];
const ticketsData = <?= json_encode($ticketsWithLocation) ?>;

ticketsData.forEach(ticket => {
    const lat = parseFloat(ticket.latitude);
    const lng = parseFloat(ticket.longitude);
    
    if (!isNaN(lat) && !isNaN(lng)) {
        const statusColor = {
            'open': '#ef4444',
            'proses': '#f59e0b',
            'selesai': '#10b981'
        }[ticket.status] || '#64748b';
        
        const marker = L.circleMarker([lat, lng], {
            radius: 8,
            fillColor: statusColor,
            color: '#fff',
            weight: 2,
            opacity: 1,
            fillOpacity: 0.8
        }).addTo(map);
        
        marker.bindPopup(`
            <div style="font-family: system-ui, sans-serif; font-size: 13px; min-width: 200px;">
                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
                    <strong style="color: #4f46e5; font-size: 14px;">Tiket #${ticket.id}</strong>
                    <span style="padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: 600; 
                                 background: ${statusColor}20; color: ${statusColor};">
                        ${ticket.status.charAt(0).toUpperCase() + ticket.status.slice(1)}
                    </span>
                </div>
                <div style="color: #1e293b; font-weight: 600; margin-bottom: 4px;">
                    ${ticket.nama_lengkap || '-'}
                </div>
                <div style="color: #475569; font-size: 12px; margin-bottom: 8px;">
                    ${ticket.judul || '-'}
                </div>
                <a href="<?= $appUrl ?>/ticketing/${ticket.id}" 
                   style="display: inline-flex; align-items: center; gap: 4px; 
                          padding: 4px 12px; border-radius: 6px; 
                          background: #4f46e5; color: white; 
                          text-decoration: none; font-size: 12px; font-weight: 500;">
                    <i class="fa-solid fa-eye"></i> Lihat Detail
                </a>
            </div>
        `);
        
        markers.push(marker);
    }
});

// Fit map to show all markers
if (markers.length > 0) {
    const group = L.featureGroup(markers);
    map.fitBounds(group.getBounds().pad(0.1));
}
</script>
<?php endif; ?>
