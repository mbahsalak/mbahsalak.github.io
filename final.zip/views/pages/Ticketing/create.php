<?php
/**
 * views/pages/Ticketing/create.php
 * Buat Tiket Pengaduan dengan Maps Picker - Tailwind CSS + Leaflet
 */

$appUrl = $_ENV['APP_URL'] ?? '';
?>

<div class="max-w-3xl mx-auto">

    <!-- Back -->
    <a href="<?= $appUrl ?>/ticketing"
       class="inline-flex items-center gap-1 text-slate-500 hover:text-slate-700 text-sm font-medium mb-5 transition-colors">
        <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar Tiket
    </a>

    <!-- Flash -->
    <?php if (!empty($flash)): ?>
        <div class="flex items-center gap-3 p-4 mb-4 rounded-lg border <?= 
            match($flash['type'] ?? 'info') {
                'success' => 'bg-green-50 border-green-200 text-green-800',
                'error'   => 'bg-red-50 border-red-200 text-red-800',
                default   => 'bg-blue-50 border-blue-200 text-blue-800'
            } ?> shadow-sm">
            <i class="fa-solid fa-<?= ($flash['type'] ?? '') === 'success' ? 'circle-check' : 'circle-xmark' ?>"></i>
            <span><?= htmlspecialchars($flash['message'] ?? '') ?></span>
            <button class="ml-auto text-inherit hover:text-inherit" onclick="this.parentElement.remove()">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    <?php endif; ?>

    <div class="bg-white rounded-xl overflow-hidden shadow-sm border border-slate-200">
        <div class="h-1 bg-indigo-600"></div>
        <div class="p-6">

            <h2 class="flex items-center gap-2 text-lg font-bold text-slate-900 mb-5">
                <i class="fa-solid fa-headset text-indigo-600"></i>
                Buat Tiket Pengaduan
            </h2>

            <form method="POST" action="<?= $appUrl ?>/ticketing/buat">
                <input type="hidden" name="csrf_token"
                       value="<?= htmlspecialchars(\Core\Middleware::generateCsrfToken()) ?>">

                <div class="space-y-4">

                    <!-- Pilih Pelanggan -->
                    <div>
                        <label for="pelanggan_id"
                               class="block font-semibold text-sm text-slate-700 mb-1">
                            Pelanggan <span class="text-red-500">*</span>
                        </label>
                        <select id="pelanggan_id" name="pelanggan_id" required
                                class="w-full px-3 py-2.5 rounded-lg border border-slate-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 text-sm bg-white cursor-pointer">
                            <option value="">-- Pilih Pelanggan --</option>
                            <?php foreach ($pelanggan ?? [] as $p): ?>
                                <option value="<?= $p['id'] ?>">
                                    <?= htmlspecialchars($p['nama_lengkap']) ?>
                                    <?php if (!empty($p['no_telp'])): ?>
                                        — <?= htmlspecialchars($p['no_telp']) ?>
                                    <?php endif; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Judul -->
                    <div>
                        <label for="judul"
                               class="block font-semibold text-sm text-slate-700 mb-1">
                            Judul Pengaduan <span class="text-red-500">*</span>
                        </label>
                        <input type="text" id="judul" name="judul" required
                               placeholder="Contoh: Internet tidak bisa connect"
                               maxlength="100"
                               class="w-full px-3 py-2.5 rounded-lg border border-slate-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 text-sm bg-white">
                        <small class="text-xs text-slate-500 mt-1">Maks. 100 karakter</small>
                    </div>

                    <!-- Deskripsi -->
                    <div>
                        <label for="deskripsi"
                               class="block font-semibold text-sm text-slate-700 mb-1">
                            Deskripsi <span class="text-red-500">*</span>
                        </label>
                        <textarea id="deskripsi" name="deskripsi" required rows="5"
                                  placeholder="Jelaskan masalah secara detail..."
                                  class="w-full px-3 py-2.5 rounded-lg border border-slate-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 text-sm bg-white resize-vertical"></textarea>
                    </div>

                    <!-- Lokasi Maps Picker -->
                    <div>
                        <label class="block font-semibold text-sm text-slate-700 mb-1">
                            Lokasi Pengaduan <span class="text-red-500">*</span>
                        </label>
                        <p class="text-xs text-slate-500 mb-2">
                            <i class="fa-solid fa-circle-info mr-1"></i>
                            Klik pada peta atau cari alamat untuk menentukan lokasi
                        </p>
                        
                        <!-- Search Box -->
                        <div class="flex gap-2 mb-3">
                            <input type="text" id="searchAddress" 
                                   class="flex-1 px-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 text-sm"
                                   placeholder="Cari alamat atau nama tempat...">
                            <button type="button" onclick="searchLocation()" 
                                    class="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium transition-colors">
                                <i class="fa-solid fa-magnifying-glass"></i>
                            </button>
                        </div>

                        <!-- Map Container -->
                        <div id="map-create" class="h-80 rounded-lg border border-slate-300 z-10 mb-3"></div>

                        <!-- Coordinates Display -->
                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <label class="block text-xs font-medium text-slate-600 mb-1">Latitude</label>
                                <input type="text" name="latitude" id="latitude" readonly required
                                       class="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50 text-sm font-mono">
                            </div>
                            <div>
                                <label class="block text-xs font-medium text-slate-600 mb-1">Longitude</label>
                                <input type="text" name="longitude" id="longitude" readonly required
                                       class="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50 text-sm font-mono">
                            </div>
                        </div>
                    </div>

                </div>

                <div class="flex justify-end gap-3 mt-6 pt-5 border-t border-slate-200">
                    <a href="<?= $appUrl ?>/ticketing"
                       class="px-5 py-2.5 rounded-lg border border-slate-300 text-slate-600 font-medium hover:bg-slate-50 transition-colors flex items-center gap-1 text-sm">
                        <i class="fa-solid fa-xmark"></i> Batal
                    </a>
                    <button type="submit"
                            class="px-6 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-medium transition-colors flex items-center gap-1 text-sm shadow-sm">
                        <i class="fa-solid fa-paper-plane"></i> Kirim Tiket
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Leaflet CSS & JS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<script>
// Initialize map
const map = L.map('map-create').setView([-6.200000, 106.816666], 13);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors',
    maxZoom: 19
}).addTo(map);

let marker = null;

// Click on map to set location
map.on('click', function(e) {
    setLocation(e.latlng.lat, e.latlng.lng);
});

function setLocation(lat, lng) {
    if (marker) {
        map.removeLayer(marker);
    }
    
    marker = L.marker([lat, lng]).addTo(map);
    map.setView([lat, lng], 16);
    
    document.getElementById('latitude').value = lat.toFixed(6);
    document.getElementById('longitude').value = lng.toFixed(6);
}

// Search location
function searchLocation() {
    const query = document.getElementById('searchAddress').value.trim();
    if (!query) {
        alert('Masukkan alamat atau nama tempat');
        return;
    }
    
    fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`)
        .then(r => r.json())
        .then(data => {
            if (data && data.length > 0) {
                const lat = parseFloat(data[0].lat);
                const lng = parseFloat(data[0].lon);
                setLocation(lat, lng);
            } else {
                alert('Lokasi tidak ditemukan');
            }
        })
        .catch(err => {
            console.error('Search error:', err);
            alert('Gagal mencari lokasi');
        });
}

// Enter key on search
document.getElementById('searchAddress').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        searchLocation();
    }
});
</script>
