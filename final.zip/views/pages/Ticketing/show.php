<?php
/**
 * views/pages/Ticketing/show.php - Tailwind CSS + Leaflet Maps
 */
$appUrl = $_ENV['APP_URL'] ?? '';
$t      = $ticket ?? [];
$status = $t['status'] ?? 'open';

$statusColor = match($status) {
    'open'    => ['bg' => 'bg-red-100', 'txt' => 'text-red-700', 'icon' => 'fa-circle-exclamation'],
    'proses'  => ['bg' => 'bg-amber-100', 'txt' => 'text-amber-700', 'icon' => 'fa-spinner'],
    'selesai' => ['bg' => 'bg-emerald-100', 'txt' => 'text-emerald-700', 'icon' => 'fa-circle-check'],
    default   => ['bg' => 'bg-slate-100', 'txt' => 'text-slate-700', 'icon' => 'fa-circle'],
};

$canUpdate = in_array($user['role'] ?? '', ['admin', 'teknisi']);
$hasLocation = !empty($t['latitude']) && !empty($t['longitude']);
?>

<div class="max-w-3xl mx-auto">

    <a href="<?= $appUrl ?>/ticketing"
       class="inline-flex items-center gap-1 text-slate-500 hover:text-slate-700 text-sm font-medium mb-5 transition-colors">
        <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar Tiket
    </a>

    <?php if (!empty($flash)): ?>
        <div class="flex items-center gap-3 p-4 mb-4 rounded-lg border <?= 
            match($flash['type'] ?? 'info') {
                'success' => 'bg-green-50 border-green-200 text-green-800',
                'error'   => 'bg-red-50 border-red-200 text-red-800',
                default   => 'bg-blue-50 border-blue-200 text-blue-800'
            } ?> shadow-sm">
            <i class="fa-solid fa-<?= ($flash['type'] ?? '') === 'success' ? 'circle-check' : 'circle-xmark' ?>"></i>
            <span><?= htmlspecialchars($flash['message'] ?? '') ?></span>
            <button class="ml-auto text-inherit hover:text-inherit" onclick="this.parentElement.remove()">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    <?php endif; ?>

    <!-- Header -->
    <div class="bg-white rounded-xl overflow-hidden shadow-sm border border-slate-200 mb-5">
        <div class="h-1 bg-indigo-600"></div>
        <div class="px-6 py-5 flex justify-between items-start flex-wrap gap-4">
            <div>
                <div class="flex items-center gap-3 flex-wrap mb-1">
                    <h2 class="text-lg font-bold text-slate-900">
                        <?= htmlspecialchars($t['judul'] ?? '') ?>
                    </h2>
                    <span class="px-3 py-1.5 rounded-full text-xs font-semibold <?= $statusColor['bg'] ?> <?= $statusColor['txt'] ?>">
                        <i class="fa-solid <?= $statusColor['icon'] ?> mr-1"></i>
                        <?= ucfirst($status) ?>
                    </span>
                </div>
                <p class="text-sm text-slate-500">
                    Tiket #<?= $t['id'] ?> •
                    <?= !empty($t['created_at']) ? date('d M Y H:i', strtotime($t['created_at'])) : '-' ?>
                </p>
            </div>
            <?php if ($canUpdate && $status !== 'selesai'): ?>
            <form method="POST" action="<?= $appUrl ?>/ticketing/update/<?= $t['id'] ?>"
                  class="flex gap-2 items-center">
                <input type="hidden" name="csrf_token"
                       value="<?= htmlspecialchars(\Core\Middleware::generateCsrfToken()) ?>">
                <select name="status"
                        class="px-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 text-sm bg-white cursor-pointer">
                    <option value="open"    <?= $status === 'open'    ? 'selected' : '' ?>>Open</option>
                    <option value="proses"  <?= $status === 'proses'  ? 'selected' : '' ?>>Proses</option>
                    <option value="selesai" <?= $status === 'selesai' ? 'selected' : '' ?>>Selesai</option>
                </select>
                <button type="submit"
                        class="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm transition-colors flex items-center gap-1">
                    <i class="fa-solid fa-check mr-1"></i>Update
                </button>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- Info Pelanggan + Info Tiket -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">

        <!-- Pelanggan -->
        <div class="bg-white rounded-xl p-5 shadow-sm border border-slate-200">
            <h3 class="flex items-center gap-2 text-sm font-bold text-indigo-600 mb-4">
                <i class="fa-solid fa-user"></i> Data Pelanggan
            </h3>
            <table class="w-full text-sm">
                <!-- Nama -->
                <tr class="border-b border-slate-200">
                    <td class="py-2.5 px-1 text-slate-500 whitespace-nowrap">
                        <i class="fa-solid fa-id-card mr-2 w-3.5"></i>Nama
                    </td>
                    <td class="py-2.5 px-1 font-medium">
                        <?= htmlspecialchars($t['nama_lengkap'] ?? '-') ?>
                    </td>
                </tr>
                <!-- No. Telp + WA -->
                <tr class="border-b border-slate-200">
                    <td class="py-2.5 px-1 text-slate-500 whitespace-nowrap">
                        <i class="fa-solid fa-phone mr-2 w-3.5"></i>No. Telp
                    </td>
                    <td class="py-2.5 px-1 font-medium">
                        <?php if (!empty($t['no_telp'])): ?>
                            <div class="inline-flex items-center gap-2">
                                <span><?= htmlspecialchars($t['no_telp']) ?></span>
                                <?php $wa = preg_replace('/^0/', '62', $t['no_telp']); ?>
                                <a href="https://wa.me/<?= $wa ?>" target="_blank"
                                   title="Chat via WhatsApp"
                                   class="px-2.5 py-1.5 rounded bg-emerald-100 border border-emerald-200 text-emerald-700 text-xs font-medium flex items-center gap-1">
                                    <i class="fa-brands fa-whatsapp"></i>
                                    <span class="font-semibold">WA</span>
                                </a>
                            </div>
                        <?php else: ?>
                            <span class="text-slate-400">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <!-- Paket -->
                <tr class="border-b border-slate-200">
                    <td class="py-2.5 px-1 text-slate-500 whitespace-nowrap">
                        <i class="fa-solid fa-wifi mr-2 w-3.5"></i>Paket
                    </td>
                    <td class="py-2.5 px-1 font-medium">
                        <?php if (!empty($t['nama_paket'])): ?>
                            <span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-violet-100 text-violet-700 flex items-center gap-1">
                                <i class="fa-solid fa-wifi mr-1"></i>
                                <?= htmlspecialchars($t['nama_paket']) ?>
                            </span>
                        <?php else: ?>
                            <span class="text-slate-400">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        </div>

        <!-- Info Tiket -->
        <div class="bg-white rounded-xl p-5 shadow-sm border border-slate-200">
            <h3 class="flex items-center gap-2 text-sm font-bold text-indigo-600 mb-4">
                <i class="fa-solid fa-circle-info"></i> Info Tiket
            </h3>
            <table class="w-full text-sm">
                <?php foreach ([
                    ['fa-hashtag',       'ID Tiket',    '#' . $t['id']],
                    ['fa-calendar',      'Dibuat',      !empty($t['created_at'])  ? date('d M Y', strtotime($t['created_at']))  : '-'],
                    ['fa-calendar-check','Diperbarui',  !empty($t['updated_at'])  ? date('d M Y', strtotime($t['updated_at']))  : '-'],
                ] as [$icon, $label, $val]): ?>
                <tr class="border-b border-slate-200">
                    <td class="py-2.5 px-1 text-slate-500 whitespace-nowrap">
                        <i class="fa-solid <?= $icon ?> mr-2 w-3.5"></i><?= $label ?>
                    </td>
                    <td class="py-2.5 px-1 font-medium"><?= htmlspecialchars((string)$val) ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>

    </div>

    <!-- Deskripsi -->
    <div class="bg-white rounded-xl p-5 shadow-sm border border-slate-200 mt-5">
        <h3 class="flex items-center gap-2 text-sm font-bold text-indigo-600 mb-3">
            <i class="fa-solid fa-align-left"></i> Deskripsi Pengaduan
        </h3>
        <p class="text-sm leading-relaxed text-slate-700 whitespace-pre-wrap">
            <?= htmlspecialchars($t['deskripsi'] ?? '') ?>
        </p>
    </div>

    <!-- Lokasi Maps -->
    <?php if ($hasLocation): ?>
    <div class="bg-white rounded-xl p-5 shadow-sm border border-slate-200 mt-5">
        <h3 class="flex items-center gap-2 text-sm font-bold text-indigo-600 mb-3">
            <i class="fa-solid fa-location-dot"></i> Lokasi Pengaduan
        </h3>
        <div id="map-show" class="h-80 rounded-lg border border-slate-300 z-10 mb-3"></div>
        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="block text-xs font-medium text-slate-600 mb-1">Latitude</label>
                <input type="text" value="<?= htmlspecialchars($t['latitude']) ?>" readonly
                       class="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50 text-sm font-mono">
            </div>
            <div>
                <label class="block text-xs font-medium text-slate-600 mb-1">Longitude</label>
                <input type="text" value="<?= htmlspecialchars($t['longitude']) ?>" readonly
                       class="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50 text-sm font-mono">
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="bg-amber-50 border border-amber-200 rounded-xl p-4 mt-5">
        <div class="flex items-start gap-3">
            <i class="fa-solid fa-triangle-exclamation text-amber-600 mt-0.5"></i>
            <div>
                <p class="text-sm font-semibold text-amber-900">Lokasi tidak tersedia</p>
                <p class="text-xs text-amber-700 mt-1">Tiket ini tidak memiliki data koordinat lokasi.</p>
            </div>
        </div>
    </div>
    <?php endif; ?>

</div>

<?php if ($hasLocation): ?>
<!-- Leaflet CSS & JS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<script>
// Initialize map
const lat = <?= (float)$t['latitude'] ?>;
const lng = <?= (float)$t['longitude'] ?>;

const map = L.map('map-show').setView([lat, lng], 16);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors',
    maxZoom: 19
}).addTo(map);

// Add marker
const marker = L.marker([lat, lng]).addTo(map);

// Add popup with ticket info
marker.bindPopup(`
    <div style="font-family: system-ui, sans-serif; font-size: 13px;">
        <strong style="color: #4f46e5;">Tiket #<?= $t['id'] ?></strong><br>
        <span style="color: #475569;"><?= htmlspecialchars($t['nama_lengkap'] ?? '-') ?></span><br>
        <small style="color: #94a3b8;"><?= htmlspecialchars($t['judul'] ?? '') ?></small>
    </div>
`).openPopup();
</script>
<?php endif; ?>
