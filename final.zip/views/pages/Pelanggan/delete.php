
<?php
/**
 * views/Pelanggan/delete.php
 * Modal/halaman konfirmasi hapus pelanggan
 */
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <h5 class="mb-0"><i class="fas fa-trash-alt"></i> Konfirmasi Hapus Pelanggan</h5>
                </div>
                <div class="card-body">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i>
                        <strong>Peringatan!</strong> Tindakan ini tidak dapat dibatalkan.
                    </div>

                    <p>Anda yakin ingin menghapus pelanggan berikut?</p>

                    <table class="table table-bordered">
                        <tr>
                            <th width="200">Nama Lengkap</th>
                            <td><?= htmlspecialchars($pelanggan['nama_lengkap'] ?? '') ?></td>
                        </tr>
                        <tr>
                            <th>Username</th>
                            <td><?= htmlspecialchars($pelanggan['username'] ?? '') ?></td>
                        </tr>
                        <tr>
                            <th>No. Telepon</th>
                            <td><?= htmlspecialchars($pelanggan['no_telp'] ?? '') ?></td>
                        </tr>
                        <tr>
                            <th>Paket</th>
                            <td><?= htmlspecialchars($pelanggan['nama_paket'] ?? '') ?></td>
                        </tr>
                        <tr>
                            <th>Alamat</th>
                            <td><?= htmlspecialchars($pelanggan['alamat'] ?? '') ?></td>
                        </tr>
                    </table>

                    <form method="POST" action="/pelanggan/delete/<?= $pelanggan['id'] ?>" class="d-inline">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash"></i> Ya, Hapus Pelanggan
                        </button>
                        <a href="/pelanggan" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Batal
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>