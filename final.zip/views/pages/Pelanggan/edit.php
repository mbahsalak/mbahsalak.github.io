<?php
/**
 * views/Pelanggan/edit.php
 * ✅ ENUM sinkron: pending, aktif, isolir, nonaktif
 */

declare(strict_types=1);

$appUrl = rtrim($_ENV['APP_URL'] ?? '', '/');
$p = $pelanggan ?? [];
$pakets = $pakets ?? [];
$odps = $odps ?? [];

$esc = fn($s) => htmlspecialchars((string)($s ?? ''), ENT_QUOTES, 'UTF-8');
$val = fn($key, $default = '') => $esc($p[$key] ?? $default);
?>

<div class="min-h-screen bg-slate-50">
    <!-- Header -->
    <div class="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <a href="<?= $appUrl ?>/pelanggan" 
                       class="w-9 h-9 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 transition-colors">
                        <i class="fa-solid fa-arrow-left text-sm"></i>
                    </a>
                    <div>
                        <h1 class="text-lg font-bold text-slate-900">Ubah Data Pelanggan</h1>
                        <p class="text-xs text-slate-500">Edit informasi pelanggan #<?= $esc($p['id'] ?? '') ?></p>
                    </div>
                </div>
                <div class="flex items-center gap-2">
                    <span class="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-50 text-amber-700 text-xs font-medium">
                        <i class="fa-solid fa-user-pen text-[10px]"></i>
                        Form Edit
                    </span>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-5xl mx-auto px-4 sm:px-6 py-6">
        <form action="<?= $appUrl ?>/pelanggan/update/<?= $esc($p['id'] ?? '') ?>" method="POST" class="space-y-6">
            <input type="hidden" name="csrf_token" value="<?= $esc($_SESSION['csrf_token'] ?? '') ?>">

            <!-- Info Akun -->
            <div class="bg-white rounded-xl border border-slate-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-100 bg-gradient-to-r from-slate-50 to-white">
                    <h2 class="text-sm font-bold text-slate-900 flex items-center gap-2">
                        <i class="fa-solid fa-user-shield text-slate-500"></i>
                        Informasi Akun
                    </h2>
                </div>
                <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1.5">
                            Username
                        </label>
                        <input type="text" value="<?= $val('username') ?>" disabled
                               class="w-full px-4 py-2.5 rounded-lg border border-slate-300 bg-slate-100 text-sm text-slate-600 cursor-not-allowed">
                        <p class="mt-1 text-xs text-slate-500">Username tidak dapat diubah</p>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1.5">
                            Password Baru
                        </label>
                        <input type="password" name="password" 
                               class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-sm"
                               placeholder="Kosongkan jika tidak diubah">
                        <p class="mt-1 text-xs text-slate-500">Minimal 6 karakter</p>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1.5">
                            Status Akun
                        </label>
                        <select name="status_akun" 
                                class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-sm">
                            <option value="active" <?= ($p['user_status'] ?? 'active') === 'active' ? 'selected' : '' ?>>
                                Aktif — Bisa login
                            </option>
                            <option value="inactive" <?= ($p['user_status'] ?? '') === 'inactive' ? 'selected' : '' ?>>
                                Nonaktif — Tidak bisa login
                            </option>
                        </select>
                        <p class="mt-1 text-xs text-slate-500">Status akun login (tabel users)</p>
                    </div>
                </div>
            </div>

            <!-- Data Pribadi -->
            <div class="bg-white rounded-xl border border-slate-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-100 bg-gradient-to-r from-emerald-50 to-white">
                    <h2 class="text-sm font-bold text-slate-900 flex items-center gap-2">
                        <i class="fa-solid fa-id-card text-emerald-500"></i>
                        Data Pribadi
                    </h2>
                </div>
                <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-slate-700 mb-1.5">
                            Nama Lengkap <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="nama_lengkap" value="<?= $val('nama_lengkap') ?>" required
                               class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-sm"
                               placeholder="Nama lengkap pelanggan">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1.5">
                            No. Telepon <span class="text-red-500">*</span>
                        </label>
                        <input type="tel" name="no_telp" value="<?= $val('no_telp') ?>" required
                               class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-sm"
                               placeholder="08xxxxxxxxxx">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1.5">
                            Tanggal Jatuh Tempo
                        </label>
                        <select name="tgl_jatuh_tempo" 
                                class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-sm">
                            <?php for ($i = 1; $i <= 28; $i++): ?>
                            <option value="<?= $i ?>" <?= ($p['tgl_jatuh_tempo'] ?? 5) == $i ? 'selected' : '' ?>>
                                Tanggal <?= $i ?>
                            </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-slate-700 mb-1.5">
                            Alamat <span class="text-red-500">*</span>
                        </label>
                        <textarea name="alamat" rows="3" required
                                  class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-sm"
                                  placeholder="Alamat lengkap pelanggan"><?= $val('alamat') ?></textarea>
                    </div>
                </div>
            </div>

            <!-- Layanan -->
            <div class="bg-white rounded-xl border border-slate-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-100 bg-gradient-to-r from-purple-50 to-white">
                    <h2 class="text-sm font-bold text-slate-900 flex items-center gap-2">
                        <i class="fa-solid fa-wifi text-purple-500"></i>
                        Data Layanan
                    </h2>
                </div>
                <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1.5">
                            Paket Internet <span class="text-red-500">*</span>
                        </label>
                        <select name="paket_id" required
                                class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-sm">
                            <option value="">-- Pilih Paket --</option>
                            <?php foreach ($pakets as $pkt): ?>
                            <option value="<?= $pkt['id'] ?>" <?= ($p['paket_id'] ?? '') == $pkt['id'] ? 'selected' : '' ?>>
                                <?= $esc($pkt['nama_paket']) ?> — <?= $esc($pkt['kecepatan']) ?> — Rp <?= number_format((float)$pkt['harga'], 0, ',', '.') ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1.5">
                            ODP (Optical Distribution Point)
                        </label>
                        <select name="odp_id" 
                                class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-sm">
                            <option value="">-- Pilih ODP --</option>
                            <?php foreach ($odps as $odp): ?>
                            <option value="<?= $odp['id'] ?>" <?= ($p['odp_id'] ?? '') == $odp['id'] ? 'selected' : '' ?>>
                                <?= $esc($odp['nama_odp']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1.5">
                            MAC Address
                        </label>
                        <input type="text" name="mac_address" value="<?= $val('mac_address') ?>"
                               class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-sm font-mono"
                               placeholder="AA:BB:CC:DD:EE:FF">
                        <p class="mt-1 text-xs text-slate-500">Format: XX:XX:XX:XX:XX:XX</p>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1.5">
                            Status Internet
                        </label>
                        <select name="status_internet" 
                                class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-sm">
                            <!-- ✅ ENUM sinkron: pending, aktif, isolir, nonaktif -->
                            <option value="pending" <?= ($p['status_internet'] ?? '') === 'pending' ? 'selected' : '' ?>>
                                Pending — Menunggu aktivasi
                            </option>
                            <option value="aktif" <?= ($p['status_internet'] ?? 'aktif') === 'aktif' ? 'selected' : '' ?>>
                                Aktif — Layanan aktif
                            </option>
                            <option value="isolir" <?= ($p['status_internet'] ?? '') === 'isolir' ? 'selected' : '' ?>>
                                Isolir — Blokir akses internet via MAC
                            </option>
                            <option value="nonaktif" <?= ($p['status_internet'] ?? '') === 'nonaktif' ? 'selected' : '' ?>>
                                Nonaktif — Layanan dinonaktifkan
                            </option>
                        </select>
                        <p class="mt-1 text-xs text-slate-500">Status layanan internet (tabel pelanggan)</p>
                    </div>
                </div>
            </div>

            <!-- Lokasi -->
            <div class="bg-white rounded-xl border border-slate-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-100 bg-gradient-to-r from-sky-50 to-white">
                    <h2 class="text-sm font-bold text-slate-900 flex items-center gap-2">
                        <i class="fa-solid fa-location-dot text-sky-500"></i>
                        Lokasi Pelanggan
                    </h2>
                </div>
                <div class="p-6 space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1.5">
                            Cari Lokasi
                        </label>
                        <div class="flex gap-2">
                            <input type="text" id="searchAddress" 
                                   class="flex-1 px-4 py-2.5 rounded-lg border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-sm"
                                   placeholder="Ketik alamat atau nama tempat...">
                            <button type="button" onclick="searchLocation()" 
                                    class="px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-sm font-medium transition-colors">
                                <i class="fa-solid fa-magnifying-glass"></i>
                            </button>
                        </div>
                    </div>
                    <div id="map-edit" class="h-80 rounded-lg border border-slate-300 z-10"></div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-1.5">Latitude</label>
                            <input type="text" name="latitude" id="latitude" value="<?= $val('latitude') ?>" readonly
                                   class="w-full px-4 py-2.5 rounded-lg border border-slate-300 bg-slate-50 text-sm font-mono">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-1.5">Longitude</label>
                            <input type="text" name="longitude" id="longitude" value="<?= $val('longitude') ?>" readonly
                                   class="w-full px-4 py-2.5 rounded-lg border border-slate-300 bg-slate-50 text-sm font-mono">
                        </div>
                    </div>
                    <input type="hidden" name="koordinat" id="koordinat" value="<?= $val('latitude') ?><?= $p['latitude'] ? ',' : '' ?><?= $val('longitude') ?>">
                </div>
            </div>

            <!-- Actions -->
            <div class="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
                <a href="<?= $appUrl ?>/pelanggan" 
                   class="px-6 py-2.5 rounded-lg border border-slate-300 text-slate-700 text-sm font-medium hover:bg-slate-50 transition-colors">
                    Batal
                </a>
                <button type="submit" 
                        class="px-6 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-sm font-medium transition-colors shadow-sm">
                    <i class="fa-solid fa-floppy-disk mr-1.5"></i>
                    Simpan Perubahan
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Leaflet CSS & JS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<script>
// Initialize map
const map = L.map('map-edit').setView([-6.200000, 106.816666], 13);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

let marker = null;

// Check if we have saved coordinates
const savedLat = document.getElementById('latitude').value;
const savedLng = document.getElementById('longitude').value;

if (savedLat && savedLng) {
    const lat = parseFloat(savedLat);
    const lng = parseFloat(savedLng);
    marker = L.marker([lat, lng]).addTo(map);
    map.setView([lat, lng], 16);
}

// Click on map to set location
map.on('click', function(e) {
    setLocation(e.latlng.lat, e.latlng.lng);
});

function setLocation(lat, lng) {
    if (marker) {
        map.removeLayer(marker);
    }
    
    marker = L.marker([lat, lng]).addTo(map);
    map.setView([lat, lng], 16);
    
    document.getElementById('latitude').value = lat.toFixed(6);
    document.getElementById('longitude').value = lng.toFixed(6);
    document.getElementById('koordinat').value = lat.toFixed(6) + ',' + lng.toFixed(6);
}

// Search location
function searchLocation() {
    const query = document.getElementById('searchAddress').value.trim();
    if (!query) return;
    
    fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`)
        .then(r => r.json())
        .then(data => {
            if (data && data.length > 0) {
                const lat = parseFloat(data[0].lat);
                const lng = parseFloat(data[0].lon);
                setLocation(lat, lng);
            } else {
                alert('Lokasi tidak ditemukan');
            }
        })
        .catch(err => {
            console.error('Search error:', err);
            alert('Gagal mencari lokasi');
        });
}

// Enter key on search
document.getElementById('searchAddress').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        searchLocation();
    }
});
</script>
