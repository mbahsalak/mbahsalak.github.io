<?php
/**
 * views/pages/Pelanggan/status.php
 * Dashboard kelola status pelanggan — terutama untuk
 * MENGAKTIFKAN pendaftar baru yang berstatus 'pending'.
 *
 * Dipanggil oleh: PelangganController::status()
 * Update status:  POST /pelanggan/status/update/{id}  (field: status_internet)
 *
 * Variabel yang dikirim controller:
 *   $pelangganList   array
 *   $filterStatus    string  (all|pending|active|isolir|suspend|nonaktif)
 *   $search          string
 *   $totalAll        int
 *   $countPending    int
 *   $countActive     int
 *   $countIsolir     int
 *   $countSuspend    int
 *   $countNonaktif   int
 *   $flash           array|null  ['type'=>.., 'message'=>..]
 */
$appUrl  = $_ENV['APP_URL'] ?? '';
$list    = $pelangganList ?? [];
$filter  = $filterStatus  ?? 'all';
$search  = $search        ?? '';
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-5">

    <!-- ── HEADER ── -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
            <h1 class="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <i class="fa-solid fa-user-clock text-indigo-500"></i> Status Pelanggan
            </h1>
            <p class="text-sm text-gray-400 dark:text-gray-500 mt-0.5">
                Tinjau dan aktifkan pendaftar baru, atau kelola status koneksi pelanggan.
            </p>
        </div>
        <a href="<?= $appUrl ?>/pelanggan"
           class="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium
                  border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-300
                  hover:bg-gray-50 dark:hover:bg-gray-700 no-underline transition-colors w-fit">
            <i class="fa-solid fa-arrow-left text-xs"></i> Kembali ke Daftar Pelanggan
        </a>
    </div>

    <!-- ── FLASH MESSAGE ── -->
    <?php if (!empty($flash) && !empty($flash['message'])):
        $flashType  = $flash['type'] ?? 'info';
        $flashStyle = match($flashType) {
            'success' => 'bg-emerald-50 border-emerald-200 text-emerald-700 dark:bg-emerald-900/20 dark:border-emerald-800 dark:text-emerald-300',
            'danger'  => 'bg-red-50 border-red-200 text-red-700 dark:bg-red-900/20 dark:border-red-800 dark:text-red-300',
            'warning' => 'bg-amber-50 border-amber-200 text-amber-700 dark:bg-amber-900/20 dark:border-amber-800 dark:text-amber-300',
            default   => 'bg-blue-50 border-blue-200 text-blue-700 dark:bg-blue-900/20 dark:border-blue-800 dark:text-blue-300',
        };
        $flashIcon = match($flashType) {
            'success' => 'fa-circle-check',
            'danger'  => 'fa-circle-exclamation',
            'warning' => 'fa-triangle-exclamation',
            default   => 'fa-circle-info',
        };
    ?>
    <div class="border rounded-xl px-4 py-3 text-sm flex items-start gap-2.5 <?= $flashStyle ?>">
        <i class="fa-solid <?= $flashIcon ?> mt-0.5 shrink-0"></i>
        <span><?= $flash['message'] ?></span>
    </div>
    <?php endif; ?>

    <!-- ── STAT CARDS (klik untuk filter) ── -->
    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <?php
        $cards = [
            ['all',      'Semua',       $totalAll      ?? 0, 'blue',   'fa-users'],
            ['pending',  'Pending',     $countPending  ?? 0, 'amber',  'fa-clock'],
            ['active',   'Aktif',       $countActive   ?? 0, 'green',  'fa-circle-check'],
            ['isolir',   'Isolir',      $countIsolir   ?? 0, 'red',    'fa-ban'],
            ['suspend',  'Suspend',     $countSuspend  ?? 0, 'orange', 'fa-pause-circle'],
            ['nonaktif', 'Nonaktif',    $countNonaktif ?? 0, 'gray',   'fa-circle-xmark'],
        ];
        $colorMap = [
            'blue'   => ['bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400',     'ring-blue-400'],
            'amber'  => ['bg-amber-50 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400',  'ring-amber-400'],
            'green'  => ['bg-green-50 text-green-600 dark:bg-green-900/20 dark:text-green-400',  'ring-green-400'],
            'red'    => ['bg-red-50 text-red-600 dark:bg-red-900/20 dark:text-red-400',          'ring-red-400'],
            'orange' => ['bg-orange-50 text-orange-600 dark:bg-orange-900/20 dark:text-orange-400','ring-orange-400'],
            'gray'   => ['bg-gray-100 text-gray-500 dark:bg-gray-700 dark:text-gray-400',         'ring-gray-400'],
        ];
        foreach ($cards as [$key, $label, $count, $color, $icon]):
            [$badgeCls, $ringCls] = $colorMap[$color];
            $isActive = $filter === $key;
        ?>
        <a href="<?= $appUrl ?>/pelanggan/status?status=<?= $key ?><?= $search ? '&q=' . urlencode($search) : '' ?>"
           class="rounded-xl border p-3.5 no-underline transition-all
                  bg-white dark:bg-gray-800
                  <?= $isActive ? 'border-indigo-400 ring-2 ' . $ringCls . ' shadow-sm' : 'border-gray-100 dark:border-gray-700 hover:border-gray-300' ?>">
            <div class="flex items-center justify-between mb-2">
                <div class="w-8 h-8 rounded-lg flex items-center justify-center <?= $badgeCls ?>">
                    <i class="fa-solid <?= $icon ?> text-sm"></i>
                </div>
                <?php if ($key === 'pending' && $count > 0): ?>
                <span class="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                <?php endif; ?>
            </div>
            <p class="text-2xl font-bold text-gray-900 dark:text-white leading-none"><?= $count ?></p>
            <p class="text-xs text-gray-400 dark:text-gray-500 mt-1"><?= $label ?></p>
        </a>
        <?php endforeach; ?>
    </div>

    <!-- ── BANNER PENDING (tampil jika ada pendaftar baru & filter bukan pending) ── -->
    <?php if (($countPending ?? 0) > 0 && $filter !== 'pending'): ?>
    <div class="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800
                rounded-xl px-5 py-3.5 flex items-center justify-between gap-4 flex-wrap">
        <div class="flex items-center gap-3">
            <div class="w-9 h-9 bg-amber-100 dark:bg-amber-800/40 rounded-full flex items-center justify-center shrink-0">
                <i class="fa-solid fa-clock text-amber-500 dark:text-amber-400"></i>
            </div>
            <div>
                <p class="text-sm font-semibold text-amber-800 dark:text-amber-300">
                    <?= $countPending ?> Pendaftaran Menunggu Aktivasi
                </p>
                <p class="text-xs text-amber-600 dark:text-amber-400 mt-0.5">
                    Tinjau data, lalu aktifkan atau tolak pendaftar baru.
                </p>
            </div>
        </div>
        <a href="<?= $appUrl ?>/pelanggan/status?status=pending"
           class="shrink-0 px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-600
                  text-white text-sm font-semibold transition-colors no-underline">
            Lihat Pending
        </a>
    </div>
    <?php endif; ?>

    <!-- ── SEARCH BAR ── -->
    <form method="GET" action="<?= $appUrl ?>/pelanggan/status" class="flex flex-wrap gap-2">
        <input type="hidden" name="status" value="<?= htmlspecialchars($filter) ?>">
        <div class="relative flex-1 min-w-[200px]">
            <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xs"></i>
            <input type="text" name="q" value="<?= htmlspecialchars($search) ?>"
                   placeholder="Cari nama, username, atau no. WA…"
                   class="w-full pl-9 pr-3 py-2 rounded-lg text-sm
                          bg-white dark:bg-gray-800
                          border border-gray-200 dark:border-gray-600
                          text-gray-700 dark:text-gray-200
                          focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/20
                          outline-none transition-all">
        </div>
        <button type="submit"
                class="px-4 py-2 rounded-lg text-sm font-medium bg-indigo-600 hover:bg-indigo-700
                       text-white border-0 cursor-pointer transition-colors">
            Cari
        </button>
        <?php if ($search || $filter !== 'all'): ?>
        <a href="<?= $appUrl ?>/pelanggan/status"
           class="px-4 py-2 rounded-lg text-sm font-medium border border-gray-200 dark:border-gray-600
                  text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700
                  no-underline transition-colors">
            Reset
        </a>
        <?php endif; ?>
    </form>

    <!-- ── TABLE CARD ── -->
    <div class="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 overflow-hidden shadow-sm">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 dark:bg-gray-700/50 text-left">
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide w-10">#</th>
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Nama / Username</th>
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">WhatsApp</th>
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide max-w-[180px]">Alamat</th>
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Paket</th>
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Daftar</th>
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide text-center">Status</th>
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide text-center w-44">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                <?php if (!empty($list)): ?>
                    <?php foreach ($list as $i => $p):
                        $status  = $p['status_internet'] ?? 'pending';
                        $badge   = match($status) {
                            'pending'  => 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
                            'active'   => 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
                            'isolir'   => 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
                            'suspend'  => 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400',
                            'nonaktif' => 'bg-gray-200 text-gray-600 dark:bg-gray-700 dark:text-gray-400',
                            default    => 'bg-gray-100 text-gray-500',
                        };
                        $icon    = match($status) {
                            'pending'  => 'fa-clock',
                            'active'   => 'fa-circle-check',
                            'isolir'   => 'fa-ban',
                            'suspend'  => 'fa-pause-circle',
                            'nonaktif' => 'fa-circle-xmark',
                            default    => 'fa-circle',
                        };
                        $labelMap = [
                            'pending' => 'Pending', 'active' => 'Aktif', 'isolir' => 'Isolir',
                            'suspend' => 'Suspend', 'nonaktif' => 'Nonaktif',
                        ];
                        $label     = $labelMap[$status] ?? ucfirst($status);
                        $isPending = ($status === 'pending');
                        $wa        = preg_replace('/^0/', '62', $p['no_telp'] ?? '');
                        $tglDaftar = !empty($p['created_at']) ? date('d/m/Y', strtotime($p['created_at'])) : '—';
                    ?>
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors
                               <?= $isPending ? 'bg-amber-50/50 dark:bg-amber-900/5' : '' ?>">

                        <td class="px-4 py-3 text-gray-400 dark:text-gray-500 text-xs"><?= $i + 1 ?></td>

                        <!-- Nama / Username -->
                        <td class="px-4 py-3">
                            <div class="flex items-center gap-1.5 flex-wrap">
                                <a href="<?= $appUrl ?>/pelanggan/<?= $p['id'] ?>"
                                   class="font-semibold text-indigo-600 hover:text-indigo-700
                                          dark:text-indigo-400 dark:hover:text-indigo-300
                                          no-underline transition-colors">
                                    <?= htmlspecialchars($p['nama_lengkap'] ?? '-') ?>
                                </a>
                                <?php if ($isPending): ?>
                                <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold
                                             bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400">
                                    BARU
                                </span>
                                <?php endif; ?>
                            </div>
                            <div class="text-xs text-gray-400 dark:text-gray-500 font-mono mt-0.5">
                                <?= htmlspecialchars($p['username'] ?? '—') ?>
                            </div>
                        </td>

                        <!-- WhatsApp -->
                        <td class="px-4 py-3">
                            <?php if (!empty($p['no_telp'])): ?>
                                <div class="flex items-center gap-1.5">
                                    <span class="text-sm text-gray-700 dark:text-gray-300"><?= htmlspecialchars($p['no_telp']) ?></span>
                                    <a href="https://wa.me/<?= $wa ?>" target="_blank"
                                       class="inline-flex items-center justify-center w-5 h-5 rounded
                                              bg-green-100 text-green-600 hover:bg-green-200
                                              dark:bg-green-900/30 dark:text-green-400
                                              no-underline transition-colors text-xs">
                                        <i class="fa-brands fa-whatsapp"></i>
                                    </a>
                                </div>
                            <?php else: ?>
                                <span class="text-gray-300 dark:text-gray-600">—</span>
                            <?php endif; ?>
                        </td>

                        <!-- Alamat -->
                        <td class="px-4 py-3 text-xs text-gray-500 dark:text-gray-400 max-w-[180px] truncate"
                            title="<?= htmlspecialchars($p['alamat'] ?? '') ?>">
                            <?= htmlspecialchars($p['alamat'] ?? '—') ?>
                        </td>

                        <!-- Paket -->
                        <td class="px-4 py-3">
                            <?php if (!empty($p['nama_paket'])): ?>
                                <span class="inline-block px-2 py-0.5 rounded-full text-[11px] font-semibold
                                             bg-indigo-50 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400">
                                    <?= htmlspecialchars($p['nama_paket']) ?>
                                </span>
                                <?php if (!empty($p['kecepatan'])): ?>
                                <div class="text-[10px] text-gray-400 dark:text-gray-500 mt-0.5"><?= htmlspecialchars($p['kecepatan']) ?></div>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="text-gray-300 dark:text-gray-600">—</span>
                            <?php endif; ?>
                        </td>

                        <!-- Tgl daftar -->
                        <td class="px-4 py-3 text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">
                            <?= $tglDaftar ?>
                        </td>

                        <!-- Status -->
                        <td class="px-4 py-3 text-center">
                            <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full
                                         text-[11px] font-bold uppercase tracking-wide <?= $badge ?>">
                                <i class="fa-solid <?= $icon ?> text-[9px]"></i>
                                <?= $label ?>
                            </span>
                        </td>

                        <!-- Aksi -->
                        <td class="px-4 py-3">
                            <?php if ($isPending): ?>
                            <!-- ── Tombol khusus pending: Aktifkan / Tolak ── -->
                            <div class="flex items-center justify-center gap-1.5">
                                <form method="POST" action="<?= $appUrl ?>/pelanggan/status/update/<?= $p['id'] ?>" class="m-0"
                                      onsubmit="return confirm('Aktifkan akun <?= htmlspecialchars(addslashes($p['nama_lengkap'] ?? ''), ENT_QUOTES) ?>?')">
                                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
                                    <input type="hidden" name="status_internet" value="active">
                                    <button type="submit" title="Aktifkan Akun"
                                            class="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-semibold
                                                   bg-emerald-500 hover:bg-emerald-600 text-white
                                                   border-0 cursor-pointer transition-colors">
                                        <i class="fa-solid fa-check"></i> Aktifkan
                                    </button>
                                </form>
                                <form method="POST" action="<?= $appUrl ?>/pelanggan/status/update/<?= $p['id'] ?>" class="m-0"
                                      onsubmit="return confirm('Tolak pendaftaran <?= htmlspecialchars(addslashes($p['nama_lengkap'] ?? ''), ENT_QUOTES) ?>?')">
                                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
                                    <input type="hidden" name="status_internet" value="nonaktif">
                                    <button type="submit" title="Tolak"
                                            class="inline-flex items-center justify-center w-7 h-7 rounded-md
                                                   border border-red-400 text-red-500
                                                   hover:bg-red-400 hover:text-white
                                                   bg-transparent cursor-pointer transition-colors text-xs">
                                        <i class="fa-solid fa-xmark"></i>
                                    </button>
                                </form>
                            </div>
                            <?php else: ?>
                            <!-- ── Dropdown ubah status untuk yang sudah aktif ── -->
                            <form method="POST" action="<?= $appUrl ?>/pelanggan/status/update/<?= $p['id'] ?>"
                                  class="flex items-center justify-center gap-1.5 m-0"
                                  onsubmit="return confirm('Ubah status pelanggan ini?')">
                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
                                <select name="status_internet"
                                        onchange="this.form.querySelector('button').disabled=false"
                                        class="px-2 py-1 rounded-md text-xs border border-gray-200 dark:border-gray-600
                                               bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200
                                               focus:border-indigo-400 outline-none cursor-pointer">
                                    <option value="active"   <?= $status === 'active'   ? 'selected' : '' ?>>Aktif</option>
                                    <option value="isolir"   <?= $status === 'isolir'   ? 'selected' : '' ?>>Isolir</option>
                                    <option value="suspend"  <?= $status === 'suspend'  ? 'selected' : '' ?>>Suspend</option>
                                    <option value="nonaktif" <?= $status === 'nonaktif' ? 'selected' : '' ?>>Nonaktif</option>
                                </select>
                                <button type="submit" disabled title="Simpan"
                                        class="inline-flex items-center justify-center w-7 h-7 rounded-md
                                               border border-indigo-400 text-indigo-500
                                               hover:bg-indigo-500 hover:text-white
                                               bg-transparent cursor-pointer transition-colors text-xs
                                               disabled:opacity-30 disabled:cursor-not-allowed">
                                    <i class="fa-solid fa-floppy-disk"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </td>

                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="px-4 py-14 text-center text-gray-400 dark:text-gray-500">
                            <i class="fa-solid fa-inbox text-3xl block mb-3 opacity-30"></i>
                            <?= $filter === 'pending'
                                ? 'Tidak ada pendaftar yang menunggu aktivasi.'
                                : 'Tidak ada data pelanggan untuk filter ini.' ?>
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Footer -->
        <?php if (!empty($list)): ?>
        <div class="px-5 py-2.5 border-t border-gray-100 dark:border-gray-700
                    bg-gray-50 dark:bg-gray-700/30
                    text-xs text-gray-400 dark:text-gray-500">
            Menampilkan <strong class="text-gray-600 dark:text-gray-300"><?= count($list) ?></strong> data
            <?= $filter !== 'all' ? 'dengan status <strong>' . htmlspecialchars($filter) . '</strong>' : '' ?>
        </div>
        <?php endif; ?>
    </div>

</div>

<script>
/* Enable tombol simpan saat dropdown berubah (sudah inline di onchange),
   ini hanya fallback jika browser tidak fire onchange saat value sama. */
document.querySelectorAll('select[name="status_internet"]').forEach(sel => {
    sel.addEventListener('change', function() {
        const btn = this.closest('form')?.querySelector('button[type="submit"]');
        if (btn) btn.disabled = false;
    });
});
</script>
