<?php
/**
 * views/pages/Pelanggan/index.php — Tailwind version
 * Mengikuti pola visual index_admin.php (dashboard)
 */
$appUrl  = $_ENV['APP_URL'] ?? '';
$rows    = $list ?? $pelanggan ?? [];
$cTotal  = count($rows);
$cAktif  = count(array_filter($rows, fn($p) => ($p['status_internet'] ?? 'active') === 'active'));
$cIsolir = count(array_filter($rows, fn($p) => ($p['status_internet'] ?? '') === 'isolir'));
$cSuspend= count(array_filter($rows, fn($p) => ($p['status_internet'] ?? '') === 'suspend'));
?>

<?php /* ── FLASH ── */
$flashCfg = [
    'success' => ['bg-green-50 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-300 dark:border-green-800', 'circle-check'],
    'error'   => ['bg-red-50 text-red-800 border-red-200 dark:bg-red-900/20 dark:text-red-300 dark:border-red-800',   'circle-xmark'],
    'warning' => ['bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-900/20 dark:text-amber-300 dark:border-amber-800', 'triangle-exclamation'],
    'info'    => ['bg-blue-50 text-blue-800 border-blue-200 dark:bg-blue-900/20 dark:text-blue-300 dark:border-blue-800', 'circle-info'],
];
foreach (['success','error','warning','info'] as $ft):
    if (empty($flash[$ft])) continue;
    [$fc, $fi] = $flashCfg[$ft];
?>
<div class="mb-5 flex items-center gap-3 px-4 py-3 rounded-lg border <?= $fc ?> animate-fade-in-down" role="alert">
    <i class="fa-solid fa-<?= $fi ?> shrink-0"></i>
    <span class="text-sm font-medium flex-1"><?= htmlspecialchars($flash[$ft]) ?></span>
    <button onclick="this.closest('[role=alert]').remove()" class="opacity-50 hover:opacity-100 transition-opacity">
        <i class="fa-solid fa-xmark"></i>
    </button>
</div>
<?php endforeach; ?>

<div class="max-w-[1320px] mx-auto space-y-5">

    <!-- ══ HEADER CARD ══════════════════════════════════════════ -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5">

        <!-- Title row -->
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-gray-200 dark:border-gray-700 mb-5">
            <div>
                <h1 class="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                    <i class="fa-solid fa-users text-indigo-500"></i> Data Pelanggan
                </h1>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Kelola data pelanggan aktif</p>
            </div>
            <div class="flex items-center gap-2 flex-wrap">
                <!-- Export -->
                <a href="<?= $appUrl ?>/pelanggan/export"
                   class="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium
                          border border-emerald-400 text-emerald-600 hover:bg-emerald-50
                          dark:text-emerald-400 dark:hover:bg-emerald-900/20 transition-colors no-underline">
                    <i class="fa-solid fa-file-excel"></i> Export
                </a>
                <!-- Import -->
                <button onclick="document.getElementById('modalImport').classList.remove('hidden')"
                        class="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium
                               border border-sky-400 text-sky-600 hover:bg-sky-50
                               dark:text-sky-400 dark:hover:bg-sky-900/20 transition-colors bg-transparent cursor-pointer">
                    <i class="fa-solid fa-file-import"></i> Import
                </button>
                <!-- Tambah -->
                <a href="<?= $appUrl ?>/pelanggan/tambah"
                   class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium
                          bg-indigo-600 text-white hover:bg-indigo-700 transition-colors shadow-sm shadow-indigo-500/30 no-underline">
                    <i class="fa-solid fa-user-plus"></i> Tambah Pelanggan
                </a>
                <a href="<?= $appUrl ?>/pelanggan/status"
                   class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium
                          bg-indigo-600 text-white hover:bg-indigo-700 transition-colors shadow-sm shadow-indigo-500/30 no-underline">
                    <i class="fa-solid fa-user-plus"></i> Status Pelanggan
                </a>
            </div>
        </div>

        <!-- ── STAT CARDS ── -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <?php
            $stats = [
                ['/pelanggan',          'blue',   'fa-users',        'Total Pelanggan', $cTotal,   ''],
                ['/pelanggan?s=active', 'green',  'fa-circle-check', 'Aktif',           $cAktif,   'pelanggan aktif'],
                ['/pelanggan?s=isolir', 'red',    'fa-ban',          'Isolir',          $cIsolir,  'perlu perhatian'],
                ['/pelanggan?s=suspend','orange', 'fa-pause-circle', 'Suspend',         $cSuspend, ''],
            ];
            $cmap = [
                'blue'   => ['bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400',   'text-blue-600 dark:text-blue-400'],
                'green'  => ['bg-green-50 text-green-600 dark:bg-green-900/20 dark:text-green-400','text-green-600 dark:text-green-400'],
                'red'    => ['bg-red-50 text-red-600 dark:bg-red-900/20 dark:text-red-400',        'text-red-600 dark:text-red-400'],
                'orange' => ['bg-orange-50 text-orange-600 dark:bg-orange-900/20 dark:text-orange-400','text-orange-600 dark:text-orange-400'],
            ];
            foreach ($stats as [$href,$color,$icon,$label,$val,$sub]):
                [$iconCls,$valCls] = $cmap[$color];
            ?>
            <a href="<?= $appUrl . $href ?>"
               class="group block bg-gray-50 dark:bg-gray-700/50 rounded-xl border border-gray-100 dark:border-gray-700
                      p-4 hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 no-underline">
                <div class="flex justify-between items-start mb-2">
                    <span class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide leading-tight">
                        <?= $label ?>
                    </span>
                    <div class="w-8 h-8 rounded-lg flex items-center justify-center text-sm shrink-0 <?= $iconCls ?>">
                        <i class="fa-solid <?= $icon ?>"></i>
                    </div>
                </div>
                <div class="text-2xl font-bold <?= $valCls ?> group-hover:opacity-80 transition-opacity">
                    <?= $val ?>
                </div>
                <?php if ($sub): ?>
                    <div class="text-[11px] text-gray-400 dark:text-gray-500 mt-0.5 font-medium"><?= $sub ?></div>
                <?php endif; ?>
            </a>
            <?php endforeach; ?>
        </div>

    </div><!-- /header card -->


    <!-- ══ TABLE CARD ═══════════════════════════════════════════ -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">

        <!-- Filter bar -->
        <div class="flex items-center gap-3 flex-wrap px-5 py-3.5
                    border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/30">
            <!-- Search -->
            <div class="relative flex-1 min-w-[180px] max-w-xs group">
                <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2
                          text-gray-400 text-xs group-focus-within:text-indigo-500 transition-colors pointer-events-none"></i>
                <input type="text" placeholder="Cari pelanggan…"
                       oninput="filterTable(this.value)"
                       class="w-full pl-8 pr-3 py-1.5 rounded-lg text-sm
                              bg-white dark:bg-gray-700
                              border border-gray-200 dark:border-gray-600
                              focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/20
                              dark:text-gray-100 outline-none transition-all">
            </div>
            <!-- Status filter -->
            <select onchange="filterStatus(this.value)"
                    class="px-3 py-1.5 rounded-lg text-sm
                           bg-white dark:bg-gray-700
                           border border-gray-200 dark:border-gray-600
                           text-gray-700 dark:text-gray-300
                           focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/20
                           outline-none cursor-pointer transition-all">
                <option value="">Semua Status</option>
                <option value="active">Aktif</option>
                <option value="isolir">Isolir</option>
                <option value="suspend">Suspend</option>
            </select>
            <!-- Row count -->
            <?php if ($cTotal > 0): ?>
            <span class="ml-auto text-xs text-gray-400 dark:text-gray-500 font-medium shrink-0">
                <?= $cTotal ?> pelanggan
            </span>
            <?php endif; ?>
        </div>

        <!-- Table -->
        <div class="overflow-x-auto">
            <table class="w-full text-sm border-collapse" id="tabelPelanggan">
                <thead>
                    <tr class="bg-gray-50 dark:bg-gray-700/50 text-left">
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide w-10">#</th>
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Nama</th>
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Username</th>
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">WhatsApp</th>
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide max-w-[160px]">Alamat</th>
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Paket</th>
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Harga</th>
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">ODP</th>
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide text-center">Status</th>
                        <th class="px-4 py-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide text-center w-28">Aksi</th>
                    </tr>
                </thead>
                <tbody id="tbodyPelanggan" class="divide-y divide-gray-100 dark:divide-gray-700">

                <?php if (!empty($rows)): ?>
                    <?php foreach ($rows as $i => $p):
                        $status = $p['status_internet'] ?? 'active';
                        $badge  = match($status) {
                            'active'  => 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
                            'isolir'  => 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
                            'suspend' => 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
                            default   => 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400',
                        };
                        $label = match($status) {
                            'active'  => 'Aktif',
                            'isolir'  => 'Isolir',
                            'suspend' => 'Suspend',
                            default   => ucfirst($status),
                        };
                        $wa = preg_replace('/^0/', '62', $p['no_telp'] ?? '');
                    ?>
                    <tr class="row-pel hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors"
                        data-status="<?= $status ?>">

                        <!-- No -->
                        <td class="px-4 py-3 text-gray-400 dark:text-gray-500 text-xs"><?= $i + 1 ?></td>

                        <!-- Nama -->
                        <td class="px-4 py-3">
                            <a href="<?= $appUrl ?>/pelanggan/<?= $p['id'] ?>"
                               class="font-semibold text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 dark:hover:text-indigo-300 no-underline transition-colors">
                                <?= htmlspecialchars($p['nama_lengkap'] ?? '-') ?>
                            </a>
                        </td>

                        <!-- Username -->
                        <td class="px-4 py-3 text-xs text-gray-500 dark:text-gray-400 font-mono">
                            <?= htmlspecialchars($p['username'] ?? '—') ?>
                        </td>

                        <!-- WhatsApp -->
                        <td class="px-4 py-3">
                            <?php if (!empty($p['no_telp'])): ?>
                                <div class="flex items-center gap-1.5">
                                    <span class="text-sm text-gray-700 dark:text-gray-300">
                                        <?= htmlspecialchars($p['no_telp']) ?>
                                    </span>
                                    <a href="https://wa.me/<?= $wa ?>" target="_blank"
                                       class="inline-flex items-center justify-center w-5 h-5 rounded
                                              bg-green-100 text-green-600 hover:bg-green-200
                                              dark:bg-green-900/30 dark:text-green-400
                                              no-underline transition-colors text-xs">
                                        <i class="fa-brands fa-whatsapp"></i>
                                    </a>
                                </div>
                            <?php else: ?>
                                <span class="text-gray-300 dark:text-gray-600">—</span>
                            <?php endif; ?>
                        </td>

                        <!-- Alamat -->
                        <td class="px-4 py-3 text-xs text-gray-500 dark:text-gray-400 max-w-[160px] truncate"
                            title="<?= htmlspecialchars($p['alamat'] ?? '') ?>">
                            <?= htmlspecialchars($p['alamat'] ?? '—') ?>
                        </td>

                        <!-- Paket -->
                        <td class="px-4 py-3">
                            <?php if (!empty($p['nama_paket'])): ?>
                                <span class="inline-block px-2 py-0.5 rounded-full text-[11px] font-semibold
                                             bg-indigo-50 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400">
                                    <?= htmlspecialchars($p['nama_paket']) ?>
                                </span>
                                <?php if (!empty($p['kecepatan'])): ?>
                                    <div class="text-[10px] text-gray-400 dark:text-gray-500 mt-0.5">
                                        <?= htmlspecialchars($p['kecepatan']) ?>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="text-gray-300 dark:text-gray-600">—</span>
                            <?php endif; ?>
                        </td>

                        <!-- Harga -->
                        <td class="px-4 py-3 whitespace-nowrap">
                            <?php if (!empty($p['harga'])): ?>
                                <span class="text-sm font-semibold text-teal-700 dark:text-teal-400">
                                    Rp&nbsp;<?= number_format((float)$p['harga'], 0, ',', '.') ?>
                                </span>
                            <?php else: ?>
                                <span class="text-gray-300 dark:text-gray-600">—</span>
                            <?php endif; ?>
                        </td>

                        <!-- ODP -->
                        <td class="px-4 py-3 text-xs text-gray-500 dark:text-gray-400">
                            <?= htmlspecialchars($p['nama_odp'] ?? $p['odp_name'] ?? '—') ?>
                        </td>

                        <!-- Status -->
                        <td class="px-4 py-3 text-center">
                            <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wide <?= $badge ?>">
                                <?= $label ?>
                            </span>
                        </td>

                        <!-- Aksi -->
                        <td class="px-4 py-3">
                            <div class="flex items-center justify-center gap-1.5">
                                <!-- Detail -->
                                <a href="<?= $appUrl ?>/pelanggan/<?= $p['id'] ?>" title="Detail"
                                   class="inline-flex items-center justify-center w-7 h-7 rounded-md
                                          border border-indigo-400 text-indigo-500
                                          hover:bg-indigo-500 hover:text-white
                                          dark:border-indigo-500 dark:text-indigo-400
                                          transition-colors no-underline text-xs">
                                    <i class="fa-solid fa-eye"></i>
                                </a>
                                <!-- Edit -->
                                <a href="<?= $appUrl ?>/pelanggan/edit/<?= $p['id'] ?>" title="Edit"
                                   class="inline-flex items-center justify-center w-7 h-7 rounded-md
                                          border border-amber-400 text-amber-500
                                          hover:bg-amber-400 hover:text-white
                                          dark:border-amber-500 dark:text-amber-400
                                          transition-colors no-underline text-xs">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </a>
                                <!-- Hapus -->
                                <form method="POST" action="<?= $appUrl ?>/pelanggan/hapus/<?= $p['id'] ?>" class="m-0"
                                      onsubmit="return confirm('Hapus <?= htmlspecialchars(addslashes($p['nama_lengkap'] ?? ''), ENT_QUOTES) ?>?')">
                                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
                                    <button type="submit" title="Hapus"
                                            class="inline-flex items-center justify-center w-7 h-7 rounded-md
                                                   border border-red-400 text-red-500
                                                   hover:bg-red-400 hover:text-white
                                                   dark:border-red-500 dark:text-red-400
                                                   transition-colors bg-transparent cursor-pointer text-xs p-0">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>

                    </tr>
                    <?php endforeach; ?>

                <?php else: ?>
                    <tr>
                        <td colspan="10" class="px-4 py-14 text-center text-gray-400 dark:text-gray-500">
                            <i class="fa-solid fa-users-slash text-3xl block mb-3 opacity-30"></i>
                            Belum ada data pelanggan.
                        </td>
                    </tr>
                <?php endif; ?>

                </tbody>
            </table>
        </div>

        <!-- Table footer -->
        <?php if ($cTotal > 0): ?>
        <div class="px-5 py-2.5 border-t border-gray-100 dark:border-gray-700
                    bg-gray-50 dark:bg-gray-700/30
                    text-xs text-gray-400 dark:text-gray-500 flex items-center gap-3">
            <span>Total <strong class="text-gray-600 dark:text-gray-300"><?= $cTotal ?></strong> pelanggan</span>
            <span class="text-gray-300 dark:text-gray-600">&bull;</span>
            <span><strong class="text-green-600 dark:text-green-400"><?= $cAktif ?></strong> aktif</span>
            <span class="text-gray-300 dark:text-gray-600">&bull;</span>
            <span><strong class="text-red-500 dark:text-red-400"><?= $cIsolir ?></strong> isolir</span>
            <?php if ($cSuspend > 0): ?>
            <span class="text-gray-300 dark:text-gray-600">&bull;</span>
            <span><strong class="text-amber-500 dark:text-amber-400"><?= $cSuspend ?></strong> suspend</span>
            <?php endif; ?>
        </div>
        <?php endif; ?>

    </div><!-- /table card -->

</div><!-- /max-w -->


<!-- ══ MODAL IMPORT ══════════════════════════════════════════ -->
<div id="modalImport"
     class="hidden fixed inset-0 bg-black/50 dark:bg-black/70 backdrop-blur-sm z-50
            flex items-center justify-center p-4">
    <div class="bg-white dark:bg-gray-800 rounded-2xl w-full max-w-md shadow-2xl
                border border-gray-200 dark:border-gray-700 overflow-hidden animate-fade-in-down">

        <!-- Modal header -->
        <div class="flex items-center justify-between px-5 py-4 border-b border-gray-100 dark:border-gray-700">
            <h3 class="flex items-center gap-2 text-base font-bold text-gray-900 dark:text-white">
                <i class="fa-solid fa-file-import text-sky-500"></i> Import Pelanggan
            </h3>
            <button onclick="document.getElementById('modalImport').classList.add('hidden')"
                    class="w-7 h-7 rounded-lg flex items-center justify-center
                           text-gray-400 hover:text-gray-600 hover:bg-gray-100
                           dark:hover:text-gray-200 dark:hover:bg-gray-700
                           transition-colors border-0 bg-transparent cursor-pointer">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <!-- Modal body -->
        <div class="p-5">
            <p class="text-sm text-gray-500 dark:text-gray-400 mb-4 leading-relaxed">
                Upload file CSV hasil <strong class="text-gray-700 dark:text-gray-300">export</strong> atau template.
                Kolom wajib: <code class="bg-gray-100 dark:bg-gray-700 px-1 rounded text-xs">username</code>
                dan <code class="bg-gray-100 dark:bg-gray-700 px-1 rounded text-xs">password</code>.
                Kolom lain seperti nama, telepon, paket, ODP akan dikenali otomatis.
            </p>

            <a href="<?= $appUrl ?>/pelanggan/import/template"
               class="inline-flex items-center gap-1.5 text-sm text-sky-600 hover:text-sky-700
                      dark:text-sky-400 no-underline font-medium mb-4 transition-colors">
                <i class="fa-solid fa-download"></i> Download Template CSV
            </a>

            <form method="POST" action="<?= $appUrl ?>/pelanggan/import" enctype="multipart/form-data" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">

                <!-- Drop zone -->
                <div onclick="document.getElementById('csvFile').click()"
                     ondragover="event.preventDefault();this.classList.add('border-sky-400','bg-sky-50','dark:bg-sky-900/10')"
                     ondragleave="this.classList.remove('border-sky-400','bg-sky-50','dark:bg-sky-900/10')"
                     ondrop="event.preventDefault();this.classList.remove('border-sky-400','bg-sky-50','dark:bg-sky-900/10');handleDrop(event)"
                     class="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl
                            p-8 text-center cursor-pointer transition-all duration-150
                            hover:border-sky-400 hover:bg-sky-50 dark:hover:bg-sky-900/10">
                    <i class="fa-solid fa-cloud-arrow-up text-3xl text-sky-400 mb-2 block"></i>
                    <p id="fileLabel" class="text-sm text-gray-500 dark:text-gray-400">
                        Klik atau drag &amp; drop file CSV di sini
                    </p>
                </div>
                <input type="file" id="csvFile" name="csv_file" accept=".csv" class="hidden"
                       onchange="document.getElementById('fileLabel').textContent = this.files[0]?.name ?? 'Pilih file CSV'">

                <!-- Actions -->
                <div class="flex justify-end gap-2 pt-1">
                    <button type="button"
                            onclick="document.getElementById('modalImport').classList.add('hidden')"
                            class="px-4 py-2 rounded-lg text-sm font-medium border border-gray-300 dark:border-gray-600
                                   text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700
                                   bg-white dark:bg-transparent transition-colors cursor-pointer">
                        Batal
                    </button>
                    <button type="submit"
                            class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium
                                   bg-sky-500 hover:bg-sky-600 text-white border-0 cursor-pointer transition-colors">
                        <i class="fa-solid fa-upload"></i> Upload & Import
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
/* ── Filter tabel ── */
function filterTable(q) {
    q = q.toLowerCase();
    document.querySelectorAll('#tbodyPelanggan .row-pel').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
}
function filterStatus(s) {
    document.querySelectorAll('#tbodyPelanggan .row-pel').forEach(row => {
        row.style.display = (!s || row.dataset.status === s) ? '' : 'none';
    });
}

/* ── Tutup modal klik backdrop ── */
document.getElementById('modalImport').addEventListener('click', function(e) {
    if (e.target === this) this.classList.add('hidden');
});

/* ── Drag & drop handler ── */
function handleDrop(e) {
    const file = e.dataTransfer.files[0];
    if (file) {
        const dt = new DataTransfer();
        dt.items.add(file);
        document.getElementById('csvFile').files = dt.files;
        document.getElementById('fileLabel').textContent = file.name;
    }
}
</script>
