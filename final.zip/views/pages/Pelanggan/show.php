<?php declare(strict_types=1);
/**
 * views/pages/Pelanggan/show.php — Tailwind version
 * ✅ FIXED: loadMonthUsage() ditambahkan, fallback DB saat offline
 */
$appUrl = $_ENV['APP_URL'] ?? '';
$mac    = $pelanggan['mac_address'] ?? null;
$hasMac = !empty($mac) && $mac !== '-';
$pid    = (int)($pelanggan['id'] ?? 0);
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<div class="max-w-5xl mx-auto space-y-5">

    <!-- Back -->
    <a href="<?= $appUrl ?>/pelanggan"
       class="inline-flex items-center gap-1.5 text-sm text-gray-400 hover:text-indigo-500 dark:hover:text-indigo-400 no-underline transition-colors w-fit">
        <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar Pelanggan
    </a>

    <!-- ══ PROFIL CARD ══════════════════════════════════════════ -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div class="h-1 bg-indigo-600"></div>

        <!-- Header -->
        <div class="flex items-center justify-between gap-4 px-5 py-4 border-b border-gray-100 dark:border-gray-700 flex-wrap">
            <div>
                <span class="text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Profil Pelanggan</span>
                <h2 class="text-lg font-bold text-gray-900 dark:text-white mt-0.5 mb-0">
                    <?= htmlspecialchars($pelanggan['nama_lengkap']) ?>
                </h2>
            </div>
            <div class="flex items-center gap-2">
                <!-- Status badge -->
                <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold
                             border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700" id="statusBadge">
                    <span class="w-2 h-2 rounded-full bg-gray-300 shrink-0 transition-colors" id="statusDot"></span>
                    <span id="statusText" class="text-gray-500 dark:text-gray-400">Memuat…</span>
                </span>
                <!-- Edit -->
                <a href="<?= $appUrl ?>/pelanggan/edit/<?= $pid ?>"
                   class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold
                          border border-amber-300 text-amber-600 hover:bg-amber-50
                          dark:border-amber-600 dark:text-amber-400 dark:hover:bg-amber-900/20
                          no-underline transition-colors">
                    <i class="fa-solid fa-pen"></i> Edit
                </a>
            </div>
        </div>

        <!-- Info Grid 2 col -->
        <div class="grid grid-cols-1 sm:grid-cols-2 divide-y sm:divide-y-0 sm:divide-x divide-gray-100 dark:divide-gray-700">
            <?php
            $infoItems = [
                ['fa-phone',         'No. WhatsApp',  htmlspecialchars($pelanggan['no_telp'] ?? '—')],
                ['fa-box',           'Paket',
                    htmlspecialchars($pelanggan['nama_paket'] ?? '—') .
                    (!empty($pelanggan['harga']) ? ' <span class="text-xs text-gray-400 font-normal ml-1">Rp ' . number_format((float)$pelanggan['harga'], 0, ',', '.') . '/Bln</span>' : '')],
                ['fa-calendar-day',  'Jatuh Tempo',   '<span class="text-red-500 dark:text-red-400">Tgl ' . ($pelanggan['tgl_jatuh_tempo'] ?? '—') . '</span>'],
                ['fa-location-dot',  'Alamat',        htmlspecialchars($pelanggan['alamat'] ?? '—')],
                ['fa-ethernet',      'MAC Address',   '<span class="font-mono">' . htmlspecialchars($pelanggan['mac_address'] ?? '—') . '</span>'],
                ['fa-network-wired', 'IP Address',    '<span class="font-mono" id="pelIp">—</span>'],
            ];
            foreach ($infoItems as $idx => $item):
                $isOdd = $idx % 2 === 0;
            ?>
            <div class="px-5 py-3.5 <?= $idx >= 4 ? 'border-t border-gray-100 dark:border-gray-700' : '' ?>">
                <span class="block text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-1">
                    <i class="fa-solid <?= $item[0] ?> text-indigo-400 mr-1"></i><?= $item[1] ?>
                </span>
                <span class="text-sm font-semibold text-gray-800 dark:text-gray-200"><?= $item[2] ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- ══ BANDWIDTH CARDS ══════════════════════════════════════ -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">

        <!-- Hari Ini -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
            <div class="h-1 bg-sky-500"></div>
            <div class="flex items-center justify-between px-5 py-3.5 border-b border-gray-100 dark:border-gray-700">
                <div>
                    <span class="text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Hari Ini</span>
                    <h3 class="text-sm font-bold text-gray-800 dark:text-gray-200 mt-0.5 mb-0 flex items-center gap-1.5">
                        <i class="fa-solid fa-calendar-day text-sky-500 text-xs"></i> Penggunaan Bandwidth
                    </h3>
                </div>
                <span id="dayUpdBadge"
                      class="text-[10px] font-bold px-2 py-0.5 rounded-full
                             bg-gray-100 dark:bg-gray-700 border border-gray-200 dark:border-gray-600
                             text-gray-400 dark:text-gray-500 transition-colors">—</span>
            </div>
            <div class="p-5">
                <?php if ($hasMac): ?>
                    <!-- Uptime box -->
                    <div id="uptimeInfo"
                         class="mb-4 p-3 bg-gray-50 dark:bg-gray-700/50 border border-gray-200 dark:border-gray-600 rounded-lg">
                        <div class="flex justify-between items-center mb-1.5">
                            <span class="text-[10px] font-bold uppercase tracking-wider text-gray-400 dark:text-gray-500">
                                <i class="fa-solid fa-clock mr-1"></i>Uptime
                            </span>
                            <span class="text-sm font-bold text-gray-800 dark:text-gray-200 tabular-nums" id="uptimeValue">—</span>
                        </div>
                        <div class="flex gap-4 text-[10px] text-gray-400 dark:text-gray-500">
                            <span>Sejak: <strong class="text-gray-600 dark:text-gray-300" id="uptimeSince">—</strong></span>
                            <span>Sumber: <strong class="text-gray-600 dark:text-gray-300" id="uptimeSource">—</strong></span>
                        </div>
                    </div>
                    <!-- Source badge -->
                    <div class="flex items-center gap-2 mb-3">
                        <span id="daySourceBadge"
                              class="text-[9px] font-bold px-2 py-0.5 rounded-full
                                     bg-gray-100 dark:bg-gray-700 text-gray-400 dark:text-gray-500
                                     border border-gray-200 dark:border-gray-600">—</span>
                    </div>
                    <!-- Total stat -->
                    <div class="flex gap-2 mb-3">
                        <div class="flex-1 flex flex-col items-center gap-1 p-2.5
                                    bg-gray-50 dark:bg-gray-700/50 border border-gray-200 dark:border-gray-600
                                    rounded-lg text-center">
                            <i class="fa-solid fa-wave-square text-violet-500 text-xs"></i>
                            <span class="text-[10px] font-bold uppercase tracking-wider text-gray-400 dark:text-gray-500">Total</span>
                            <span class="text-sm font-bold text-gray-800 dark:text-gray-200 tabular-nums" id="dayTotal">—</span>
                        </div>
                    </div>
                    <div class="relative h-28">
                        <canvas id="chartDayUsage"></canvas>
                    </div>
                <?php else: ?>
                    <p class="text-xs text-gray-400 dark:text-gray-500 py-2">
                        <i class="fa-solid fa-circle-info mr-1"></i>
                        Data tidak tersedia — MAC address belum diisi.
                    </p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Bulan Ini -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
            <div class="h-1 bg-violet-600"></div>
            <div class="flex items-center justify-between px-5 py-3.5 border-b border-gray-100 dark:border-gray-700">
                <div>
                    <span class="text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">Bulan Ini</span>
                    <h3 class="text-sm font-bold text-gray-800 dark:text-gray-200 mt-0.5 mb-0 flex items-center gap-1.5">
                        <i class="fa-solid fa-calendar text-violet-500 text-xs"></i> Penggunaan Bandwidth
                    </h3>
                </div>
                <span id="monUpdBadge"
                      class="text-[10px] font-bold px-2 py-0.5 rounded-full
                             bg-gray-100 dark:bg-gray-700 border border-gray-200 dark:border-gray-600
                             text-gray-400 dark:text-gray-500 transition-colors">—</span>
            </div>
            <div class="p-5">
                <?php if ($hasMac): ?>
                    <!-- Source badge -->
                    <div class="flex items-center gap-2 mb-3">
                        <span id="monSourceBadge"
                              class="text-[9px] font-bold px-2 py-0.5 rounded-full
                                     bg-gray-100 dark:bg-gray-700 text-gray-400 dark:text-gray-500
                                     border border-gray-200 dark:border-gray-600">—</span>
                    </div>
                    <div class="flex gap-2 mb-3">
                        <div class="flex-1 flex flex-col items-center gap-1 p-2.5
                                    bg-gray-50 dark:bg-gray-700/50 border border-gray-200 dark:border-gray-600
                                    rounded-lg text-center">
                            <i class="fa-solid fa-wave-square text-violet-500 text-xs"></i>
                            <span class="text-[10px] font-bold uppercase tracking-wider text-gray-400 dark:text-gray-500">Total</span>
                            <span class="text-sm font-bold text-gray-800 dark:text-gray-200 tabular-nums" id="monTotal">—</span>
                        </div>
                    </div>
                    <div class="relative h-28">
                        <canvas id="chartMonUsage"></canvas>
                    </div>
                <?php else: ?>
                    <p class="text-xs text-gray-400 dark:text-gray-500 py-2">
                        <i class="fa-solid fa-circle-info mr-1"></i>
                        Data tidak tersedia — MAC address belum diisi.
                    </p>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <!-- ══ PETA ══════════════════════════════════════════════════ -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div class="h-1 bg-emerald-500"></div>
        <div class="flex items-center justify-between px-5 py-3.5 border-b border-gray-100 dark:border-gray-700">
            <span class="text-sm font-bold text-gray-800 dark:text-gray-200 flex items-center gap-2">
                <i class="fa-solid fa-map-location-dot text-emerald-500"></i> Titik Koordinat
            </span>
            <?php if (!empty($pelanggan['latitude']) && !empty($pelanggan['longitude'])): ?>
                <a href="https://www.google.com/maps?q=<?= urlencode((string)$pelanggan['latitude']) ?>,<?= urlencode((string)$pelanggan['longitude']) ?>"
                   target="_blank"
                   class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg no-underline transition-colors shadow-sm shadow-indigo-500/30">
                    <i class="fa-solid fa-location-arrow"></i> Google Maps
                </a>
            <?php endif; ?>
        </div>
        <div id="customerMap" style="height:300px;width:100%;"></div>
    </div>

</div>

<!-- Leaflet -->
<script>if (!window.L) { document.write('<scr'+'ipt src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"><\/scr'+'ipt>'); }</script>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>

<style>
#statusDot.online  { background:#10b981 !important; animation: pulseDot 1.4s ease-in-out infinite; }
#statusDot.offline { background:#ef4444 !important; }
#statusText.online  { color:#10b981; }
#statusText.offline { color:#ef4444; }
#dayUpdBadge.live,#monUpdBadge.live {
    background:#dcfce7; border-color:#86efac; color:#16a34a;
}
.dark #dayUpdBadge.live,.dark #monUpdBadge.live {
    background:rgba(16,185,129,.15); border-color:#064e3b; color:#34d399;
}
#daySourceBadge.from-db { background:#fef3c7; color:#d97706; border-color:#fbbf24; }
#daySourceBadge.live    { background:#dcfce7; color:#16a34a; border-color:#86efac; }
#monSourceBadge.from-db { background:#fef3c7; color:#d97706; border-color:#fbbf24; }
#monSourceBadge.live    { background:#dcfce7; color:#16a34a; border-color:#86efac; }
.dark #daySourceBadge.from-db,.dark #monSourceBadge.from-db { background:rgba(217,119,6,.15); color:#fbbf24; border-color:#92400e; }
.dark #daySourceBadge.live,.dark #monSourceBadge.live       { background:rgba(16,185,129,.15); color:#34d399; border-color:#064e3b; }
@keyframes pulseDot { 0%,100%{opacity:1} 50%{opacity:.35} }
</style>

<script>
(function () {
    const PID    = <?= json_encode($pid) ?>;
    const HASMAC = <?= json_encode($hasMac) ?>;
    const APPURL = <?= json_encode($appUrl) ?>;
    const isDark = document.documentElement.classList.contains('dark');

    let dayChart = null, monChart = null;

    function fmtGB(b) {
        if ((b||0) >= 1e9) return (b/1e9).toFixed(2) + ' GB';
        if ((b||0) >= 1e6) return (b/1e6).toFixed(1) + ' MB';
        return ((b||0)/1e3).toFixed(0) + ' KB';
    }
    function setEl(id, txt) { const e=document.getElementById(id); if(e) e.textContent=txt; }

    const gridColor = isDark ? '#374151' : '#f1f5f9';
    const textColor = isDark ? '#9ca3af' : '#64748b';

    // Helper: set source badge
    function setSourceBadge(badgeId, source) {
        const badge = document.getElementById(badgeId);
        if (!badge) return;
        badge.classList.remove('from-db', 'live');
        if (source === 'live' || source === 'mikrotik') {
            badge.classList.add('live');
            badge.textContent = 'LIVE (MikroTik)';
        } else if (source && source.startsWith('db')) {
            badge.classList.add('from-db');
            badge.textContent = 'DATABASE (Offline)';
        } else {
            badge.textContent = source || '—';
        }
    }

    /* ──────────────────────────────────────────────────────────
     *  UPTIME + STATUS
     * ────────────────────────────────────────────────────────── */
    function loadUptime() {
        if (!HASMAC) {
            const dot = document.getElementById('statusDot');
            const txt = document.getElementById('statusText');
            dot.classList.add('offline');
            dot.classList.remove('online');
            txt.classList.add('offline');
            txt.classList.remove('online');
            txt.textContent = 'No MAC';
            return;
        }
        fetch(`${APPURL}/pelanggan/${PID}/uptime`)
            .then(r => { if (!r.ok) throw 0; return r.json(); })
            .then(d => {
                const dot = document.getElementById('statusDot');
                const txt = document.getElementById('statusText');
                const online = d.status === 'online';

                dot.classList.toggle('online', online);
                dot.classList.toggle('offline', !online);
                txt.classList.toggle('online', online);
                txt.classList.toggle('offline', !online);
                txt.textContent = online ? 'Online' : 'Offline';

                if (online) {
                    setEl('pelIp', d.ip || '—');
                    setEl('uptimeValue', d.uptime_human || '—');
                    setEl('uptimeSince', d.connected_at || '—');
                    setEl('uptimeSource', (d.mode||'unknown').toUpperCase());
                } else {
                    setEl('uptimeValue', 'Offline');
                    setEl('uptimeSince', d.last_seen || 'Terakhir terlihat: —');
                    setEl('uptimeSource', '—');
                    // IP dari database
                    if (d.ip) setEl('pelIp', d.ip);
                }
            })
            .catch(() => {
                setEl('statusText', 'Error');
                const dot = document.getElementById('statusDot');
                dot.classList.add('offline');
                dot.classList.remove('online');
            });
    }

    /* ──────────────────────────────────────────────────────────
     *  USAGE HARI INI
     *  ✅ Fallback ke database saat offline
     * ────────────────────────────────────────────────────────── */
    function loadDayUsage() {
        if (!HASMAC) return;
        fetch(`${APPURL}/pelanggan/${PID}/usageToday`)
            .then(r => {
                if (!r.ok) throw new Error('HTTP ' + r.status);
                return r.json();
            })
            .then(d => {
                const rx = d.rx_bytes || 0;
                const tx = d.tx_bytes || 0;
                const totalBytes = rx + tx;

                setEl('dayTotal', fmtGB(totalBytes));

                // Source badge
                const source = d.source || (totalBytes > 0 ? 'db' : 'no_data');
                setSourceBadge('daySourceBadge', source);

                // Update time badge
                const badge = document.getElementById('dayUpdBadge');
                const now = new Date().toLocaleTimeString('id-ID', {hour:'2-digit', minute:'2-digit'});
                if (badge) {
                    badge.classList.add('live');
                    badge.textContent = now;
                }

                // Chart
                const ctx = document.getElementById('chartDayUsage');
                if (!ctx) return;

                const h = d.hourly || [];
                if (dayChart) dayChart.destroy();

                // Jika tidak ada hourly data, buat 24 jam kosong
                const hourlyData = h.length > 0
                    ? h
                    : Array.from({length: 24}, (_, i) => ({hour: i, rx_bytes: 0, tx_bytes: 0}));

                dayChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: hourlyData.map(x => x.hour + 'h'),
                        datasets: [
                            {
                                label: 'Download',
                                data: hourlyData.map(x => (x.rx_bytes || 0) / 1e6),
                                backgroundColor: 'rgba(16,185,129,.7)',
                                borderRadius: 3
                            },
                            {
                                label: 'Upload',
                                data: hourlyData.map(x => (x.tx_bytes || 0) / 1e6),
                                backgroundColor: 'rgba(59,130,246,.65)',
                                borderRadius: 3
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        animation: {duration: 400},
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: {color: gridColor},
                                ticks: {color: textColor, font: {size: 10}, callback: v => v + 'MB'}
                            },
                            x: {
                                grid: {display: false},
                                ticks: {color: textColor, font: {size: 9}}
                            }
                        },
                        plugins: {legend: {display: false}}
                    }
                });
            })
            .catch(err => {
                console.error('Error loading day usage:', err);
                setEl('dayTotal', 'Error');
                setSourceBadge('daySourceBadge', 'error');
            });
    }

    /* ──────────────────────────────────────────────────────────
     *  ✅ USAGE BULAN INI — FIX: Fungsi ini sebelumnya HILANG
     *  Fallback ke database saat offline
     * ────────────────────────────────────────────────────────── */
    function loadMonthUsage() {
        if (!HASMAC) return;
        fetch(`${APPURL}/pelanggan/${PID}/usageMonth`)
            .then(r => {
                if (!r.ok) throw new Error('HTTP ' + r.status);
                return r.json();
            })
            .then(d => {
                const rx = d.rx_bytes || 0;
                const tx = d.tx_bytes || 0;
                const totalBytes = rx + tx;

                setEl('monTotal', fmtGB(totalBytes));

                // Source badge
                const source = d.source || (totalBytes > 0 ? 'db' : 'no_data');
                setSourceBadge('monSourceBadge', source);

                // Update time badge
                const badge = document.getElementById('monUpdBadge');
                const now = new Date().toLocaleTimeString('id-ID', {hour:'2-digit', minute:'2-digit'});
                if (badge) {
                    badge.classList.add('live');
                    badge.textContent = now;
                }

                // Chart
                const ctx = document.getElementById('chartMonUsage');
                if (!ctx) return;

                const daily = d.daily || [];
                if (monChart) monChart.destroy();

                if (daily.length === 0) {
                    // Tidak ada data — tampilkan chart kosong
                    monChart = new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: ['—'],
                            datasets: [
                                {label:'Download', data:[0], backgroundColor:'rgba(139,92,246,.7)', borderRadius:3},
                                {label:'Upload',   data:[0], backgroundColor:'rgba(236,72,153,.6)', borderRadius:3}
                            ]
                        },
                        options: {
                            responsive: true, maintainAspectRatio: false,
                            plugins: {legend:{display:false}, tooltip:{enabled:false}},
                            scales: {
                                y: {beginAtZero:true, grid:{color:gridColor}, ticks:{color:textColor,font:{size:10}}},
                                x: {grid:{display:false}, ticks:{color:textColor,font:{size:9}}}
                            }
                        }
                    });
                    return;
                }

                // Ada data — tampilkan chart harian
                monChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: daily.map(x => {
                            const parts = x.date.split('-');
                            return parts[2] + '/' + parts[1]; // "17/06"
                        }),
                        datasets: [
                            {
                                label: 'Download',
                                data: daily.map(x => (x.rx_bytes || 0) / 1e9),
                                backgroundColor: 'rgba(139,92,246,.7)',
                                borderRadius: 3
                            },
                            {
                                label: 'Upload',
                                data: daily.map(x => (x.tx_bytes || 0) / 1e9),
                                backgroundColor: 'rgba(236,72,153,.6)',
                                borderRadius: 3
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        animation: {duration: 400},
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: {color: gridColor},
                                ticks: {color: textColor, font: {size: 10}, callback: v => v.toFixed(1) + 'GB'}
                            },
                            x: {
                                grid: {display: false},
                                ticks: {color: textColor, font: {size: 8}, maxRotation: 45}
                            }
                        },
                        plugins: {legend: {display: false}}
                    }
                });
            })
            .catch(err => {
                console.error('Error loading month usage:', err);
                setEl('monTotal', 'Error');
                setSourceBadge('monSourceBadge', 'error');
            });
    }

    /* ──────────────────────────────────────────────────────────
     *  PETA LEAFLET
     * ────────────────────────────────────────────────────────── */
    const lat = <?= json_encode(!empty($pelanggan['latitude'])  ? (float)$pelanggan['latitude']  : null) ?>;
    const lng = <?= json_encode(!empty($pelanggan['longitude']) ? (float)$pelanggan['longitude'] : null) ?>;

    function initMap() {
        if (!document.getElementById('customerMap') || !window.L) return;
        const center = (lat && lng) ? [lat, lng] : [-6.2, 106.81];
        const map = L.map('customerMap').setView(center, lat && lng ? 16 : 11);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap'
        }).addTo(map);
        if (lat && lng) {
            L.marker([lat, lng]).addTo(map)
                .bindPopup('<b><?= htmlspecialchars($pelanggan['nama_lengkap'], ENT_QUOTES) ?></b>')
                .openPopup();
        }
    }
    if (window.L) initMap(); else window.addEventListener('load', initMap);

    /* ──────────────────────────────────────────────────────────
     *  INIT — Jalankan semua + auto-refresh
     * ────────────────────────────────────────────────────────── */
    loadUptime();
    loadDayUsage();
    loadMonthUsage();

    if (HASMAC) {
        setInterval(loadUptime,      30000);  // 30 detik
        setInterval(loadDayUsage,    60000);  // 60 detik
        setInterval(loadMonthUsage,  60000);  // 60 detik
    }
})();
</script>
