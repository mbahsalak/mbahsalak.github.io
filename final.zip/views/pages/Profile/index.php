<?php
/**
 * views/pages/Profile/index.php
 * Profil Saya — semua role
 */

$appUrl  = $_ENV['APP_URL'] ?? '';
$role    = $user['role'] ?? '';
$isActive = true;

$roleColor = match($role) {
    'admin'     => '#6366f1',
    'kasir'     => '#10b981',
    'teknisi'   => '#f59e0b',
    'pelanggan' => '#3b82f6',
    default     => '#6b7280',
};
$roleIcon = match($role) {
    'admin'     => 'fa-user-shield',
    'kasir'     => 'fa-cash-register',
    'teknisi'   => 'fa-screwdriver-wrench',
    'pelanggan' => 'fa-user',
    default     => 'fa-user',
};
?>

<div style="max-width:700px;">

    <!-- Flash -->
    <?php if (!empty($flash)): ?>
        <div class="flash flash--<?= $flash['type'] ?? 'info' ?>" role="alert" style="margin-bottom:1rem;">
            <i class="fa-solid fa-<?= ($flash['type'] ?? '') === 'success' ? 'circle-check' : 'circle-xmark' ?>"></i>
            <span><?= htmlspecialchars($flash['message'] ?? '') ?></span>
            <button class="flash-close" onclick="this.parentElement.remove()">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    <?php endif; ?>

    <!-- Header Card -->
    <div class="card" style="border-radius:12px;overflow:hidden;margin-bottom:1.25rem;">
        <div style="height:5px;background:<?= $roleColor ?>;"></div>
        <div style="padding:1.5rem;display:flex;align-items:center;gap:1.25rem;flex-wrap:wrap;">
            <!-- Avatar -->
            <div style="width:72px;height:72px;border-radius:50%;
                        background:<?= $roleColor ?>22;
                        display:flex;align-items:center;justify-content:center;flex-shrink:0;
                        font-size:1.75rem;font-weight:700;color:<?= $roleColor ?>;">
                <?= strtoupper(substr($user['username'] ?? 'U', 0, 1)) ?>
            </div>
            <div style="flex:1;">
                <div style="display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;">
                    <h2 style="margin:0;font-size:1.2rem;font-weight:700;">
                        <?= htmlspecialchars($user['username'] ?? '') ?>
                    </h2>
                    <span style="padding:.25rem .75rem;border-radius:99px;font-size:.75rem;
                                 font-weight:600;background:<?= $roleColor ?>22;color:<?= $roleColor ?>;">
                        <i class="fa-solid <?= $roleIcon ?>" style="margin-right:.3rem;"></i>
                        <?= ucfirst($role) ?>
                    </span>
                </div>
                <p style="margin:.3rem 0 0;font-size:.85rem;color:var(--text-muted,#6b7280);">
                    ID #<?= $user['id'] ?? '-' ?>
                </p>
            </div>
            <a href="<?= $appUrl ?>/profile/ganti-password"
               style="padding:.5rem 1rem;border-radius:8px;border:1.5px solid #f59e0b;
                      color:#f59e0b;text-decoration:none;font-weight:600;font-size:.875rem;
                      display:inline-flex;align-items:center;gap:.4rem;white-space:nowrap;">
                <i class="fa-solid fa-key"></i> Ganti Password
            </a>
        </div>
    </div>

    <!-- Form Edit Profil -->
    <div class="card" style="border-radius:12px;padding:1.5rem;">
        <h3 style="margin:0 0 1.25rem;font-size:.95rem;font-weight:700;
                   display:flex;align-items:center;gap:.5rem;color:<?= $roleColor ?>;">
            <i class="fa-solid fa-pen-to-square"></i> Edit Profil
        </h3>

        <form method="POST" action="<?= $appUrl ?>/profile/update">
            <input type="hidden" name="csrf_token"
                   value="<?= htmlspecialchars(\Core\Middleware::generateCsrfToken()) ?>">

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">

                <!-- Username (readonly) -->
                <div>
                    <label style="font-weight:600;font-size:.875rem;display:block;margin-bottom:.4rem;">
                        Username
                    </label>
                    <input type="text" value="<?= htmlspecialchars($user['username'] ?? '') ?>"
                           disabled
                           style="width:100%;padding:.6rem .85rem;border-radius:8px;
                                  border:1.5px solid var(--border,#e5e7eb);font-size:.875rem;
                                  background:var(--surface-alt,#f9fafb);color:var(--text-muted,#6b7280);
                                  box-sizing:border-box;">
                    <small style="color:var(--text-muted,#6b7280);font-size:.75rem;">Tidak dapat diubah</small>
                </div>

                <!-- Role (readonly) -->
                <div>
                    <label style="font-weight:600;font-size:.875rem;display:block;margin-bottom:.4rem;">
                        Role
                    </label>
                    <input type="text" value="<?= ucfirst($role) ?>"
                           disabled
                           style="width:100%;padding:.6rem .85rem;border-radius:8px;
                                  border:1.5px solid var(--border,#e5e7eb);font-size:.875rem;
                                  background:var(--surface-alt,#f9fafb);color:var(--text-muted,#6b7280);
                                  box-sizing:border-box;">
                </div>

                <!-- Nama Lengkap -->
                <div style="grid-column:1/-1;">
                    <label for="nama_lengkap"
                           style="font-weight:600;font-size:.875rem;display:block;margin-bottom:.4rem;">
                        Nama Lengkap
                    </label>
                    <input type="text" id="nama_lengkap" name="nama_lengkap"
                           value="<?= htmlspecialchars($user['nama_lengkap'] ?? '') ?>"
                           placeholder="Masukkan nama lengkap"
                           style="width:100%;padding:.6rem .85rem;border-radius:8px;
                                  border:1.5px solid var(--border,#e5e7eb);font-size:.875rem;
                                  background:var(--surface,#fff);box-sizing:border-box;">
                </div>

                <!-- Email -->
                <div>
                    <label for="email"
                           style="font-weight:600;font-size:.875rem;display:block;margin-bottom:.4rem;">
                        Email
                    </label>
                    <input type="email" id="email" name="email"
                           value="<?= htmlspecialchars($user['email'] ?? '') ?>"
                           placeholder="email@contoh.com"
                           style="width:100%;padding:.6rem .85rem;border-radius:8px;
                                  border:1.5px solid var(--border,#e5e7eb);font-size:.875rem;
                                  background:var(--surface,#fff);box-sizing:border-box;">
                </div>

                <!-- No HP -->
                <div>
                    <label for="no_hp"
                           style="font-weight:600;font-size:.875rem;display:block;margin-bottom:.4rem;">
                        No. HP
                    </label>
                    <input type="text" id="no_hp" name="no_hp"
                           value="<?= htmlspecialchars($user['no_hp'] ?? '') ?>"
                           placeholder="08xxxxxxxxxx"
                           style="width:100%;padding:.6rem .85rem;border-radius:8px;
                                  border:1.5px solid var(--border,#e5e7eb);font-size:.875rem;
                                  background:var(--surface,#fff);box-sizing:border-box;">
                </div>

            </div>

            <div style="display:flex;justify-content:flex-end;gap:.75rem;margin-top:1.5rem;
                        padding-top:1.25rem;border-top:1px solid var(--border,#e5e7eb);">
                <button type="reset"
                        style="padding:.6rem 1.25rem;border-radius:8px;cursor:pointer;font-weight:600;
                               border:1.5px solid var(--border,#e5e7eb);background:transparent;
                               color:var(--text-muted,#6b7280);">
                    <i class="fa-solid fa-rotate-left" style="margin-right:.4rem;"></i>Reset
                </button>
                <button type="submit"
                        style="padding:.6rem 1.5rem;border-radius:8px;border:none;cursor:pointer;
                               font-weight:600;background:<?= $roleColor ?>;color:#fff;">
                    <i class="fa-solid fa-floppy-disk" style="margin-right:.4rem;"></i>Simpan Perubahan
                </button>
            </div>
        </form>
    </div>

</div>
