<?php
/**
 * views/pages/Profile/change_password.php
 * Ganti Password — semua role
 */

$appUrl    = $_ENV['APP_URL'] ?? '';
$role      = $user['role'] ?? '';
$roleColor = match($role) {
    'admin'     => '#6366f1',
    'kasir'     => '#10b981',
    'teknisi'   => '#f59e0b',
    'pelanggan' => '#3b82f6',
    default     => '#6b7280',
};
?>

<div style="max-width:480px;">

    <!-- Back -->
    <a href="<?= $appUrl ?>/profile"
       style="display:inline-flex;align-items:center;gap:.4rem;color:var(--text-muted,#6b7280);
              font-size:.875rem;text-decoration:none;margin-bottom:1.25rem;">
        <i class="fa-solid fa-arrow-left"></i> Kembali ke Profil
    </a>

    <!-- Flash -->
    <?php if (!empty($flash)): ?>
        <div class="flash flash--<?= $flash['type'] ?? 'info' ?>" role="alert" style="margin-bottom:1rem;">
            <i class="fa-solid fa-<?= ($flash['type'] ?? '') === 'success' ? 'circle-check' : 'circle-xmark' ?>"></i>
            <span><?= htmlspecialchars($flash['message'] ?? '') ?></span>
            <button class="flash-close" onclick="this.parentElement.remove()">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    <?php endif; ?>

    <div class="card" style="border-radius:12px;overflow:hidden;">
        <div style="height:5px;background:<?= $roleColor ?>;"></div>
        <div style="padding:1.5rem;">

            <h2 style="margin:0 0 1.25rem;font-size:1rem;font-weight:700;
                       display:flex;align-items:center;gap:.5rem;">
                <i class="fa-solid fa-key" style="color:<?= $roleColor ?>;"></i>
                Ganti Password
            </h2>

            <form method="POST" action="<?= $appUrl ?>/profile/ganti-password" id="formPassword">
                <input type="hidden" name="csrf_token"
                       value="<?= htmlspecialchars(\Core\Middleware::generateCsrfToken()) ?>">

                <div style="display:flex;flex-direction:column;gap:1rem;">

                    <!-- Password Lama -->
                    <div>
                        <label for="password_lama"
                               style="font-weight:600;font-size:.875rem;display:block;margin-bottom:.4rem;">
                            Password Lama
                        </label>
                        <div style="position:relative;">
                            <input type="password" id="password_lama" name="password_lama"
                                   placeholder="Masukkan password saat ini" required
                                   style="width:100%;padding:.6rem 2.5rem .6rem .85rem;border-radius:8px;
                                          border:1.5px solid var(--border,#e5e7eb);font-size:.875rem;
                                          background:var(--surface,#fff);box-sizing:border-box;">
                            <button type="button" onclick="togglePw('password_lama',this)"
                                    style="position:absolute;right:.75rem;top:50%;transform:translateY(-50%);
                                           border:none;background:none;cursor:pointer;
                                           color:var(--text-muted,#6b7280);padding:0;">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Password Baru -->
                    <div>
                        <label for="password_baru"
                               style="font-weight:600;font-size:.875rem;display:block;margin-bottom:.4rem;">
                            Password Baru
                        </label>
                        <div style="position:relative;">
                            <input type="password" id="password_baru" name="password_baru"
                                   placeholder="Minimal 6 karakter" required
                                   oninput="checkStrength(this.value)"
                                   style="width:100%;padding:.6rem 2.5rem .6rem .85rem;border-radius:8px;
                                          border:1.5px solid var(--border,#e5e7eb);font-size:.875rem;
                                          background:var(--surface,#fff);box-sizing:border-box;">
                            <button type="button" onclick="togglePw('password_baru',this)"
                                    style="position:absolute;right:.75rem;top:50%;transform:translateY(-50%);
                                           border:none;background:none;cursor:pointer;
                                           color:var(--text-muted,#6b7280);padding:0;">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                        </div>
                        <!-- Strength bar -->
                        <div id="strengthBar"
                             style="height:4px;border-radius:99px;margin-top:.4rem;
                                    background:var(--border,#e5e7eb);overflow:hidden;">
                            <div id="strengthFill"
                                 style="height:100%;width:0;border-radius:99px;transition:all .3s;"></div>
                        </div>
                        <small id="strengthText" style="font-size:.75rem;color:var(--text-muted,#6b7280);"></small>
                    </div>

                    <!-- Konfirmasi -->
                    <div>
                        <label for="konfirmasi_password"
                               style="font-weight:600;font-size:.875rem;display:block;margin-bottom:.4rem;">
                            Konfirmasi Password Baru
                        </label>
                        <div style="position:relative;">
                            <input type="password" id="konfirmasi_password" name="konfirmasi_password"
                                   placeholder="Ulangi password baru" required
                                   oninput="checkMatch()"
                                   style="width:100%;padding:.6rem 2.5rem .6rem .85rem;border-radius:8px;
                                          border:1.5px solid var(--border,#e5e7eb);font-size:.875rem;
                                          background:var(--surface,#fff);box-sizing:border-box;">
                            <button type="button" onclick="togglePw('konfirmasi_password',this)"
                                    style="position:absolute;right:.75rem;top:50%;transform:translateY(-50%);
                                           border:none;background:none;cursor:pointer;
                                           color:var(--text-muted,#6b7280);padding:0;">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                        </div>
                        <small id="matchText" style="font-size:.75rem;"></small>
                    </div>

                </div>

                <div style="display:flex;justify-content:flex-end;gap:.75rem;margin-top:1.5rem;
                            padding-top:1.25rem;border-top:1px solid var(--border,#e5e7eb);">
                    <a href="<?= $appUrl ?>/profile"
                       style="padding:.6rem 1.25rem;border-radius:8px;text-decoration:none;
                              border:1.5px solid var(--border,#e5e7eb);font-weight:600;
                              color:var(--text-muted,#6b7280);display:inline-flex;align-items:center;gap:.4rem;">
                        <i class="fa-solid fa-xmark"></i> Batal
                    </a>
                    <button type="submit"
                            style="padding:.6rem 1.5rem;border-radius:8px;border:none;cursor:pointer;
                                   font-weight:600;background:<?= $roleColor ?>;color:#fff;
                                   display:inline-flex;align-items:center;gap:.4rem;">
                        <i class="fa-solid fa-floppy-disk"></i> Simpan Password
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function togglePw(id, btn) {
    const input = document.getElementById(id);
    const isHidden = input.type === 'password';
    input.type = isHidden ? 'text' : 'password';
    btn.querySelector('i').className = isHidden ? 'fa-solid fa-eye-slash' : 'fa-solid fa-eye';
}

function checkStrength(val) {
    const fill = document.getElementById('strengthFill');
    const text = document.getElementById('strengthText');
    let score = 0;
    if (val.length >= 6)  score++;
    if (val.length >= 10) score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^A-Za-z0-9]/.test(val)) score++;

    const levels = [
        { w: '20%', c: '#ef4444', t: 'Sangat lemah' },
        { w: '40%', c: '#f97316', t: 'Lemah' },
        { w: '60%', c: '#f59e0b', t: 'Cukup' },
        { w: '80%', c: '#3b82f6', t: 'Kuat' },
        { w: '100%', c: '#10b981', t: 'Sangat kuat' },
    ];
    const lvl = levels[Math.min(score - 1, 4)] ?? levels[0];
    fill.style.width      = val.length ? lvl.w : '0';
    fill.style.background = lvl.c;
    text.textContent      = val.length ? lvl.t : '';
    text.style.color      = lvl.c;
}

function checkMatch() {
    const pw  = document.getElementById('password_baru').value;
    const cfm = document.getElementById('konfirmasi_password').value;
    const el  = document.getElementById('matchText');
    if (!cfm) { el.textContent = ''; return; }
    if (pw === cfm) {
        el.textContent = '✓ Password cocok';
        el.style.color = '#10b981';
    } else {
        el.textContent = '✗ Password tidak cocok';
        el.style.color = '#ef4444';
    }
}
</script>
