<?php
/**
 * views/pages/Dashboard/index_admin.php
 * Dual Mode Dashboard: Classic + Trade
 * Dengan pengaturan tata letak fleksibel
 */

function formatRp(float $n): string {
    if ($n >= 1000000) return 'Rp ' . number_format($n / 1000000, 1, ',', '.') . 'M';
    if ($n >= 1000) return 'Rp ' . number_format($n / 1000, 0, ',', '.') . 'K';
    return 'Rp ' . number_format($n, 0, ',', '.');
}
function formatBytes(int $bytes): string {
    if ($bytes <= 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $pow = min(floor(log(max(1, $bytes), 1024)), count($units) - 1);
    return round($bytes / (1024 ** $pow), 2) . ' ' . $units[$pow];
}

$S = $stats ?? [];
$prefs = $prefs ?? ['mode' => 'classic', 'settings' => ['layout' => 'comfortable']];
$mode = $prefs['mode'] ?? 'classic';
$layout = $prefs['settings']['layout'] ?? 'comfortable';
$widgets = explode(',', $prefs['settings']['widgets'] ?? 'revenue,bandwidth,growth,paket,status,pengaduan,pembayaran,pengaduan_table');
$isTrade = ($mode === 'trade');
$isCompact = ($layout === 'compact');

// Class wrapper
$bodyClass = $isTrade ? 'dash-trade' : 'dash-classic';
if ($isCompact) $bodyClass .= ' dash-compact';
?>

<div class="<?php echo $bodyClass; ?>" id="dashboardRoot">

    <!-- ═══════════════════ TOP CONTROL BAR ═══════════════════ -->
    <div class="dash-control-bar">
        <div class="flex items-center gap-3 flex-1 min-w-0">
            <h1 class="text-lg font-bold truncate">
                <?php if ($isTrade): ?>
                <i class="fa-solid fa-chart-line text-emerald-400 mr-1"></i>
                <span class="text-white">Trade Dashboard</span>
                <?php else: ?>
                <i class="fa-solid fa-gauge-high text-blue-600 mr-1"></i>
                <span class="text-gray-900 dark:text-white">Classic Dashboard</span>
                <?php endif; ?>
            </h1>
            <span class="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold <?php echo $isTrade ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400' : 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400'; ?>">
                <span class="w-1.5 h-1.5 rounded-full bg-current animate-pulse"></span> LIVE
            </span>
        </div>

        <div class="flex items-center gap-2">
            <!-- Mode Toggle -->
            <div class="mode-toggle">
                <button type="button" onclick="switchMode('classic')" class="mode-btn <?php echo !$isTrade ? 'active' : ''; ?>" title="Classic Mode">
                    <i class="fa-solid fa-table-cells"></i>
                    <span class="hidden sm:inline">Classic</span>
                </button>
                <button type="button" onclick="switchMode('trade')" class="mode-btn <?php echo $isTrade ? 'active' : ''; ?>" title="Trade Mode">
                    <i class="fa-solid fa-chart-line"></i>
                    <span class="hidden sm:inline">Trade</span>
                </button>
            </div>

            <!-- Settings Button -->
            <button type="button" onclick="openSettings()" class="ctrl-btn" title="Pengaturan">
                <i class="fa-solid fa-gear"></i>
            </button>

            <!-- Fullscreen -->
            <button type="button" onclick="toggleFullscreen()" class="ctrl-btn hidden sm:flex" title="Fullscreen">
                <i class="fa-solid fa-expand"></i>
            </button>

            <!-- Refresh -->
            <button type="button" onclick="location.reload()" class="ctrl-btn" title="Refresh">
                <i class="fa-solid fa-rotate-right"></i>
            </button>
        </div>
    </div>

    <!-- ═══════════════════ STAT CARDS ═══════════════════ -->
    <div class="stat-grid <?php echo $isCompact ? 'stat-compact' : ''; ?>">
        
        <!-- Revenue -->
        <div class="stat-card" data-stat="revenue">
            <div class="stat-icon-wrap" style="--accent: <?php echo $isTrade ? '#10b981' : '#3b82f6'; ?>">
                <i class="fa-solid fa-sack-dollar"></i>
            </div>
            <div class="stat-content">
                <p class="stat-label">Revenue Bulan Ini</p>
                <p class="stat-value"><?php echo formatRp((float)($S['revenueBulanIni'] ?? 0)); ?></p>
                <div class="stat-trend">
                    <?php $trend = $S['revTrend'] ?? 0; ?>
                    <?php if ($trend >= 0): ?>
                    <span class="trend-up"><i class="fa-solid fa-arrow-trend-up"></i> +<?php echo $trend; ?>%</span>
                    <?php else: ?>
                    <span class="trend-down"><i class="fa-solid fa-arrow-trend-down"></i> <?php echo $trend; ?>%</span>
                    <?php endif; ?>
                    <span class="trend-label">vs bulan lalu</span>
                </div>
            </div>
        </div>

        <!-- Pelanggan -->
        <div class="stat-card" data-stat="pelanggan">
            <div class="stat-icon-wrap" style="--accent: <?php echo $isTrade ? '#3b82f6' : '#8b5cf6'; ?>">
                <i class="fa-solid fa-users"></i>
            </div>
            <div class="stat-content">
                <p class="stat-label">Total Pelanggan</p>
                <p class="stat-value"><?php echo number_format((int)($S['totalPelanggan'] ?? 0)); ?></p>
                <div class="stat-trend">
                    <span class="text-emerald-500 font-semibold"><span class="dot bg-emerald-500"></span><?php echo (int)($S['pelangganAktif'] ?? 0); ?> Aktif</span>
                    <span class="text-red-500 font-semibold"><span class="dot bg-red-500"></span><?php echo (int)($S['pelangganIsolir'] ?? 0); ?> Isolir</span>
                </div>
            </div>
        </div>

        <!-- Tunggakan -->
        <div class="stat-card" data-stat="tunggakan">
            <div class="stat-icon-wrap" style="--accent: <?php echo $isTrade ? '#f59e0b' : '#f59e0b'; ?>">
                <i class="fa-solid fa-clock"></i>
            </div>
            <div class="stat-content">
                <p class="stat-label">Tunggakan</p>
                <p class="stat-value"><?php echo formatRp((float)($S['tunggakanTotal'] ?? 0)); ?></p>
                <div class="stat-trend">
                    <span class="text-amber-500 font-semibold"><?php echo (int)($S['tagihanPending'] ?? 0); ?> belum bayar</span>
                </div>
            </div>
        </div>

        <!-- Pengaduan -->
        <div class="stat-card" data-stat="pengaduan">
            <div class="stat-icon-wrap" style="--accent: <?php echo $isTrade ? '#ef4444' : '#ec4899'; ?>">
                <i class="fa-solid fa-headset"></i>
            </div>
            <div class="stat-content">
                <p class="stat-label">Pengaduan Aktif</p>
                <p class="stat-value"><?php echo (int)($S['pengaduanOpen'] ?? 0) + (int)($S['pengaduanProses'] ?? 0); ?></p>
                <div class="stat-trend">
                    <span class="text-red-500 font-semibold"><?php echo (int)($S['pengaduanOpen'] ?? 0); ?> Baru</span>
                    <span class="text-amber-500 font-semibold"><?php echo (int)($S['pengaduanProses'] ?? 0); ?> Proses</span>
                </div>
            </div>
        </div>
    </div>

    <!-- ═══════════════════ WIDGET GRID (DYNAMIC ORDER) ═══════════════════ -->
    <div class="widget-grid" id="widgetGrid">

        <?php foreach ($widgets as $widgetId): $widgetId = trim($widgetId); ?>

        <?php if ($widgetId === 'revenue'): ?>
        <!-- CANDLESTICK REVENUE -->
        <div class="widget <?php echo $isTrade ? 'widget-dark' : ''; ?> widget-full" data-widget="revenue">
            <div class="widget-header">
                <div class="widget-title">
                    <div class="widget-icon" style="--c: <?php echo $isTrade ? '#10b981' : '#3b82f6'; ?>">
                        <i class="fa-solid fa-dollar-sign"></i>
                    </div>
                    <div>
                        <h3 class="widget-title-text">Revenue Candlestick</h3>
                        <p class="widget-subtitle">OHLC Daily • 30 Hari</p>
                    </div>
                </div>
                <div class="widget-actions">
                    <?php if ($isTrade): ?>
                    <span class="legend"><span class="legend-line bg-emerald-400"></span>Bullish</span>
                    <span class="legend"><span class="legend-line bg-red-400"></span>Bearish</span>
                    <?php endif; ?>
                    <button class="widget-ctrl" onclick="toggleWidget(this)"><i class="fa-solid fa-minus"></i></button>
                </div>
            </div>
            <div class="widget-body">
                <?php if (!empty($candleRevenue)): ?>
                <div id="candleRevenue" style="height:<?php echo $isCompact ? '280' : '360'; ?>px;"></div>
                <?php else: ?>
                <div class="empty-state"><i class="fa-solid fa-chart-column text-3xl"></i><span>Belum ada data</span></div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($widgetId === 'bandwidth'): ?>
        <!-- BANDWIDTH -->
        <div class="widget <?php echo $isTrade ? 'widget-dark' : ''; ?>" data-widget="bandwidth">
            <div class="widget-header">
                <div class="widget-title">
                    <div class="widget-icon" style="--c: <?php echo $isTrade ? '#3b82f6' : '#06b6d4'; ?>">
                        <i class="fa-solid fa-network-wired"></i>
                    </div>
                    <div>
                        <h3 class="widget-title-text">Bandwidth Usage</h3>
                        <p class="widget-subtitle">OHLC Daily • 30 Hari</p>
                    </div>
                </div>
                <button class="widget-ctrl" onclick="toggleWidget(this)"><i class="fa-solid fa-minus"></i></button>
            </div>
            <div class="widget-body">
                <?php if (!empty($candleBandwidth)): ?>
                <div id="candleBandwidth" style="height:<?php echo $isCompact ? '240' : '300'; ?>px;"></div>
                <?php else: ?>
                <div class="empty-state"><i class="fa-solid fa-chart-column text-2xl"></i><span>Tidak ada data</span></div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($widgetId === 'growth'): ?>
        <!-- GROWTH -->
        <div class="widget <?php echo $isTrade ? 'widget-dark' : ''; ?>" data-widget="growth">
            <div class="widget-header">
                <div class="widget-title">
                    <div class="widget-icon" style="--c: #3b82f6"><i class="fa-solid fa-user-plus"></i></div>
                    <div>
                        <h3 class="widget-title-text">Pertumbuhan</h3>
                        <p class="widget-subtitle">12 Bulan</p>
                    </div>
                </div>
                <button class="widget-ctrl" onclick="toggleWidget(this)"><i class="fa-solid fa-minus"></i></button>
            </div>
            <div class="widget-body">
                <?php if (!empty($pelangganGrowth)): ?>
                <div id="chartGrowth" style="height:<?php echo $isCompact ? '220' : '260'; ?>px;"></div>
                <?php else: ?>
                <div class="empty-state"><i class="fa-solid fa-chart-area text-2xl"></i><span>Tidak ada data</span></div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($widgetId === 'paket'): ?>
        <div class="widget <?php echo $isTrade ? 'widget-dark' : ''; ?>" data-widget="paket">
            <div class="widget-header">
                <div class="widget-title">
                    <div class="widget-icon" style="--c: #8b5cf6"><i class="fa-solid fa-wifi"></i></div>
                    <div>
                        <h3 class="widget-title-text">Distribusi Paket</h3>
                        <p class="widget-subtitle">Per paket</p>
                    </div>
                </div>
                <button class="widget-ctrl" onclick="toggleWidget(this)"><i class="fa-solid fa-minus"></i></button>
            </div>
            <div class="widget-body">
                <?php if (!empty($paketDist)): ?>
                <div id="chartPaket" style="height:<?php echo $isCompact ? '220' : '260'; ?>px;"></div>
                <?php else: ?>
                <div class="empty-state"><i class="fa-solid fa-chart-pie text-2xl"></i><span>Tidak ada data</span></div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($widgetId === 'status'): ?>
        <div class="widget <?php echo $isTrade ? 'widget-dark' : ''; ?>" data-widget="status">
            <div class="widget-header">
                <div class="widget-title">
                    <div class="widget-icon" style="--c: #10b981"><i class="fa-solid fa-signal"></i></div>
                    <div>
                        <h3 class="widget-title-text">Status Internet</h3>
                        <p class="widget-subtitle">Per status</p>
                    </div>
                </div>
                <button class="widget-ctrl" onclick="toggleWidget(this)"><i class="fa-solid fa-minus"></i></button>
            </div>
            <div class="widget-body">
                <?php if (!empty($statusDist)): ?>
                <div id="chartStatus" style="height:<?php echo $isCompact ? '220' : '260'; ?>px;"></div>
                <?php else: ?>
                <div class="empty-state"><i class="fa-solid fa-chart-pie text-2xl"></i><span>Tidak ada data</span></div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($widgetId === 'pengaduan'): ?>
        <div class="widget <?php echo $isTrade ? 'widget-dark' : ''; ?> widget-full" data-widget="pengaduan">
            <div class="widget-header">
                <div class="widget-title">
                    <div class="widget-icon" style="--c: #f59e0b"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h3 class="widget-title-text">Pengaduan Harian</h3>
                        <p class="widget-subtitle">14 Hari</p>
                    </div>
                </div>
                <button class="widget-ctrl" onclick="toggleWidget(this)"><i class="fa-solid fa-minus"></i></button>
            </div>
            <div class="widget-body">
                <?php if (!empty($pengaduanDaily)): ?>
                <div id="chartPengaduan" style="height:<?php echo $isCompact ? '180' : '220'; ?>px;"></div>
                <?php else: ?>
                <div class="empty-state"><i class="fa-solid fa-chart-area text-2xl"></i><span>Belum ada data</span></div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($widgetId === 'pembayaran'): ?>
        <!-- TABEL PEMBAYARAN -->
        <div class="widget <?php echo $isTrade ? 'widget-dark' : ''; ?>" data-widget="pembayaran">
            <div class="widget-header">
                <div class="widget-title">
                    <div class="widget-icon" style="--c: #10b981"><i class="fa-solid fa-receipt"></i></div>
                    <h3 class="widget-title-text">Pembayaran Terbaru</h3>
                </div>
                <a href="/tagihan" class="text-[10px] text-primary hover:underline font-semibold">Lihat semua &rarr;</a>
            </div>
            <div class="widget-body widget-flush">
                <div class="table-scroll">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Pelanggan</th>
                                <th>Periode</th>
                                <th class="text-right">Jumlah</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($pembayaranTerbaru)): foreach ($pembayaranTerbaru as $pb): ?>
                            <tr>
                                <td>
                                    <p class="font-medium"><?php echo htmlspecialchars($pb['pelanggan'] ?? '-'); ?></p>
                                    <p class="text-[10px] opacity-60"><?php echo date('d M, H:i', strtotime($pb['tgl_bayar'])); ?></p>
                                </td>
                                <td><?php echo htmlspecialchars($pb['periode_bulan'] ?? '-'); ?></td>
                                <td class="text-right font-bold text-emerald-500"><?php echo formatRp((float)($pb['total'] ?? 0)); ?></td>
                            </tr>
                            <?php endforeach; else: ?>
                            <tr><td colspan="3" class="text-center py-8 opacity-50">Belum ada pembayaran</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($widgetId === 'pengaduan_table'): ?>
        <!-- TABEL PENGADUAN -->
        <div class="widget <?php echo $isTrade ? 'widget-dark' : ''; ?>" data-widget="pengaduan_table">
            <div class="widget-header">
                <div class="widget-title">
                    <div class="widget-icon" style="--c: #f59e0b"><i class="fa-solid fa-headset"></i></div>
                    <h3 class="widget-title-text">Pengaduan Terbaru</h3>
                </div>
                <a href="/pengaduan" class="text-[10px] text-primary hover:underline font-semibold">Lihat semua &rarr;</a>
            </div>
            <div class="widget-body widget-flush">
                <div class="table-scroll">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Pelanggan</th>
                                <th>Judul</th>
                                <th class="text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($pengaduanTerbaru)): foreach ($pengaduanTerbaru as $pg): 
                                $sBg = match($pg['status'] ?? 'open') {
                                    'open' => 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
                                    'proses' => 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
                                    'selesai' => 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
                                    default => 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300',
                                };
                            ?>
                            <tr>
                                <td>
                                    <p class="font-medium"><?php echo htmlspecialchars($pg['pelanggan'] ?? '-'); ?></p>
                                    <p class="text-[10px] opacity-60"><?php echo date('d M, H:i', strtotime($pg['created_at'])); ?></p>
                                </td>
                                <td class="max-w-[120px] truncate"><?php echo htmlspecialchars($pg['judul'] ?? '-'); ?></td>
                                <td class="text-center">
                                    <span class="inline-block px-2 py-0.5 rounded-full text-[9px] font-bold uppercase <?php echo $sBg; ?>">
                                        <?php echo htmlspecialchars($pg['status'] ?? '-'); ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; else: ?>
                            <tr><td colspan="3" class="text-center py-8 opacity-50">Belum ada pengaduan</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php endforeach; ?>
    </div>

</div>

<!-- ═══════════════════ SETTINGS PANEL (MODAL) ═══════════════════ -->
<div id="settingsPanel" class="settings-panel">
    <div class="settings-backdrop" onclick="closeSettings()"></div>
    <div class="settings-drawer">
        <div class="settings-header">
            <h2 class="text-lg font-bold"><i class="fa-solid fa-gear mr-2"></i>Pengaturan Dashboard</h2>
            <button onclick="closeSettings()" class="ctrl-btn"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="settings-body">
            
            <!-- MODE -->
            <div class="settings-section">
                <label class="settings-label">Mode Dashboard</label>
                <div class="mode-selector">
                    <label class="mode-option <?php echo !$isTrade ? 'active' : ''; ?>">
                        <input type="radio" name="mode" value="classic" <?php echo !$isTrade ? 'checked' : ''; ?>>
                        <div class="mode-option-content">
                            <i class="fa-solid fa-table-cells text-2xl text-blue-500"></i>
                            <strong>Classic</strong>
                            <span>Tampilan bersih & sederhana</span>
                        </div>
                    </label>
                    <label class="mode-option <?php echo $isTrade ? 'active' : ''; ?>">
                        <input type="radio" name="mode" value="trade" <?php echo $isTrade ? 'checked' : ''; ?>>
                        <div class="mode-option-content">
                            <i class="fa-solid fa-chart-line text-2xl text-emerald-500"></i>
                            <strong>Trade</strong>
                            <span>Dark theme, candlestick chart</span>
                        </div>
                    </label>
                </div>
            </div>

            <!-- LAYOUT -->
            <div class="settings-section">
                <label class="settings-label">Kepadatan</label>
                <div class="layout-selector">
                    <label class="layout-option <?php echo !$isCompact ? 'active' : ''; ?>">
                        <input type="radio" name="layout" value="comfortable" <?php echo !$isCompact ? 'checked' : ''; ?>>
                        <i class="fa-solid fa-expand"></i> Nyaman
                    </label>
                    <label class="layout-option <?php echo $isCompact ? 'active' : ''; ?>">
                        <input type="radio" name="layout" value="compact" <?php echo $isCompact ? 'checked' : ''; ?>>
                        <i class="fa-solid fa-compress"></i> Padat
                    </label>
                </div>
            </div>

            <!-- AUTO REFRESH -->
            <div class="settings-section">
                <label class="settings-label">Auto Refresh</label>
                <select id="autoRefresh" class="settings-select">
                    <option value="0">Nonaktif</option>
                    <option value="30">Setiap 30 detik</option>
                    <option value="60">Setiap 1 menit</option>
                    <option value="300">Setiap 5 menit</option>
                </select>
            </div>

            <!-- WIDGET ORDER -->
            <div class="settings-section">
                <label class="settings-label">
                    Urutan Widget
                    <span class="text-xs text-gray-400 ml-1">(drag untuk urutkan)</span>
                </label>
                <div class="widget-order-list" id="widgetOrderList">
                    <!-- diisi JS -->
                </div>
            </div>

        </div>
        <div class="settings-footer">
            <button onclick="resetSettings()" class="btn btn-secondary">Reset</button>
            <button onclick="saveSettings()" class="btn btn-primary">Simpan</button>
        </div>
    </div>
</div>

<!-- ═══════════════════ STYLES ═══════════════════ -->
<style>
/* ── Root Variables ── */
.dash-classic {
    --bg-primary: #ffffff;
    --bg-secondary: #f9fafb;
    --bg-card: #ffffff;
    --border: #e5e7eb;
    --text-primary: #111827;
    --text-secondary: #6b7280;
    --text-muted: #9ca3af;
    --chart-bg: #ffffff;
    --grid-color: #e5e7eb;
}
.dash-trade {
    --bg-primary: #0f172a;
    --bg-secondary: #020617;
    --bg-card: #1e293b;
    --border: #334155;
    --text-primary: #f1f5f9;
    --text-secondary: #cbd5e1;
    --text-muted: #64748b;
    --chart-bg: #0f172a;
    --grid-color: #1e293b;
}
.dark .dash-classic {
    --bg-primary: #0f172a;
    --bg-secondary: #020617;
    --bg-card: #1e293b;
    --border: #334155;
    --text-primary: #f1f5f9;
    --text-secondary: #cbd5e1;
    --text-muted: #64748b;
    --chart-bg: #0f172a;
    --grid-color: #1e293b;
}

#dashboardRoot {
    min-height: 100vh;
    background: var(--bg-secondary);
    color: var(--text-primary);
    padding: 1rem;
    transition: background 0.3s, color 0.3s;
}
.dash-trade #dashboardRoot,
.dash-trade {
    background: var(--bg-secondary);
    color: var(--text-primary);
}

/* ── Control Bar ── */
.dash-control-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 1rem;
    padding: 0.75rem 1rem;
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: 0.75rem;
    margin-bottom: 1rem;
    flex-wrap: wrap;
}

.mode-toggle {
    display: flex;
    background: var(--bg-secondary);
    border: 1px solid var(--border);
    border-radius: 0.5rem;
    padding: 0.25rem;
    gap: 0.125rem;
}
.mode-btn {
    display: flex;
    align-items: center;
    gap: 0.375rem;
    padding: 0.375rem 0.75rem;
    border-radius: 0.375rem;
    border: none;
    background: transparent;
    color: var(--text-secondary);
    font-size: 0.75rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
}
.mode-btn:hover { background: var(--border); }
.mode-btn.active {
    background: var(--text-primary);
    color: var(--bg-card);
}
.dash-trade .mode-btn.active {
    background: #10b981;
    color: #fff;
}

.ctrl-btn {
    width: 2.25rem;
    height: 2.25rem;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 0.5rem;
    border: 1px solid var(--border);
    background: var(--bg-card);
    color: var(--text-secondary);
    cursor: pointer;
    transition: all 0.2s;
    font-size: 0.875rem;
}
.ctrl-btn:hover {
    background: var(--border);
    color: var(--text-primary);
}

/* ── Stat Cards ── */
.stat-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 1rem;
    margin-bottom: 1rem;
}
.stat-grid.stat-compact {
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 0.5rem;
}
.stat-card {
    position: relative;
    display: flex;
    align-items: flex-start;
    gap: 1rem;
    padding: 1.25rem;
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: 0.75rem;
    overflow: hidden;
    transition: all 0.2s;
}
.stat-compact .stat-card { padding: 0.875rem; }
.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
}
.dash-trade .stat-card:hover {
    box-shadow: 0 8px 20px rgba(0,0,0,0.4);
}
.stat-icon-wrap {
    width: 3rem;
    height: 3rem;
    border-radius: 0.75rem;
    background: color-mix(in srgb, var(--accent) 15%, transparent);
    color: var(--accent);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.125rem;
    flex-shrink: 0;
}
.stat-compact .stat-icon-wrap {
    width: 2.5rem;
    height: 2.5rem;
    font-size: 1rem;
}
.stat-content { flex: 1; min-width: 0; }
.stat-label {
    font-size: 0.65rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--text-muted);
    margin-bottom: 0.25rem;
}
.stat-value {
    font-size: 1.5rem;
    font-weight: 800;
    color: var(--text-primary);
    line-height: 1.1;
    letter-spacing: -0.02em;
}
.stat-compact .stat-value { font-size: 1.25rem; }
.stat-trend {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-top: 0.5rem;
    font-size: 0.7rem;
    flex-wrap: wrap;
}
.trend-up { color: #10b981; font-weight: 700; }
.trend-down { color: #ef4444; font-weight: 700; }
.trend-label { color: var(--text-muted); }
.dot {
    display: inline-block;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    margin-right: 0.25rem;
}

/* ── Widget Grid ── */
.widget-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1rem;
}
.widget-full { grid-column: 1 / -1; }
.dash-compact .widget-grid { gap: 0.5rem; }

@media (max-width: 1024px) {
    .widget-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 640px) {
    .widget-grid { grid-template-columns: 1fr; }
}

.widget {
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: 0.75rem;
    overflow: hidden;
    transition: all 0.2s;
}
.widget:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.06);
}
.dash-trade .widget:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
}
.widget-dark {
    background: #0f172a;
    border-color: #1e293b;
}
.widget.collapsed .widget-body { display: none; }

.widget-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.75rem;
    padding: 1rem 1.25rem;
    border-bottom: 1px solid var(--border);
    flex-wrap: wrap;
}
.widget-dark .widget-header { border-bottom-color: #1e293b; }

.widget-title {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    flex: 1;
    min-width: 0;
}
.widget-icon {
    width: 2.25rem;
    height: 2.25rem;
    border-radius: 0.5rem;
    background: color-mix(in srgb, var(--c) 15%, transparent);
    color: var(--c);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.875rem;
    flex-shrink: 0;
}
.widget-title-text {
    font-size: 0.875rem;
    font-weight: 700;
    color: var(--text-primary);
}
.widget-dark .widget-title-text { color: #f1f5f9; }
.widget-subtitle {
    font-size: 0.65rem;
    color: var(--text-muted);
}

.widget-actions {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}
.widget-ctrl {
    width: 1.75rem;
    height: 1.75rem;
    border-radius: 0.375rem;
    background: transparent;
    border: 1px solid var(--border);
    color: var(--text-muted);
    cursor: pointer;
    font-size: 0.65rem;
    transition: all 0.2s;
}
.widget-ctrl:hover { background: var(--border); color: var(--text-primary); }
.widget-dark .widget-ctrl { border-color: #334155; }
.widget-dark .widget-ctrl:hover { background: #1e293b; color: #fff; }

.widget-body {
    padding: 0.5rem 1rem 1rem;
}
.widget-flush { padding: 0; }

.legend {
    display: flex;
    align-items: center;
    gap: 0.25rem;
    font-size: 0.65rem;
    color: var(--text-muted);
}
.legend-line {
    width: 12px;
    height: 2px;
    border-radius: 1px;
}

.empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 200px;
    color: var(--text-muted);
    font-size: 0.875rem;
    gap: 0.5rem;
    opacity: 0.6;
}

/* ── Tables ── */
.table-scroll {
    overflow: auto;
    max-height: 380px;
    -webkit-overflow-scrolling: touch;
}
.data-table {
    width: 100%;
    font-size: 0.75rem;
    border-collapse: collapse;
}
.data-table th {
    padding: 0.625rem 1rem;
    text-align: left;
    font-size: 0.65rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--text-muted);
    background: var(--bg-secondary);
    border-bottom: 1px solid var(--border);
    position: sticky;
    top: 0;
    z-index: 1;
}
.data-table td {
    padding: 0.625rem 1rem;
    color: var(--text-secondary);
    border-bottom: 1px solid var(--border);
}
.data-table tbody tr:hover { background: var(--bg-secondary); }
.data-table .font-medium { color: var(--text-primary); }
.text-right { text-align: right; }
.text-center { text-align: center; }

/* ── Settings Panel ── */
.settings-panel {
    position: fixed;
    inset: 0;
    z-index: 100;
    display: none;
    pointer-events: none;
}
.settings-panel.open {
    display: block;
    pointer-events: auto;
}
.settings-backdrop {
    position: absolute;
    inset: 0;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(2px);
}
.settings-drawer {
    position: absolute;
    top: 0;
    right: 0;
    width: 100%;
    max-width: 420px;
    height: 100%;
    background: var(--bg-card);
    border-left: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    animation: slideIn 0.3s ease-out;
}
@keyframes slideIn {
    from { transform: translateX(100%); }
    to { transform: translateX(0); }
}
.settings-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 1rem 1.25rem;
    border-bottom: 1px solid var(--border);
    color: var(--text-primary);
}
.settings-body {
    flex: 1;
    overflow-y: auto;
    padding: 1rem 1.25rem;
}
.settings-footer {
    display: flex;
    justify-content: flex-end;
    gap: 0.5rem;
    padding: 1rem 1.25rem;
    border-top: 1px solid var(--border);
}
.settings-section { margin-bottom: 1.5rem; }
.settings-label {
    display: block;
    font-size: 0.75rem;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 0.5rem;
    text-transform: uppercase;
    letter-spacing: 0.03em;
}
.settings-select {
    width: 100%;
    padding: 0.5rem 0.75rem;
    background: var(--bg-secondary);
    border: 1px solid var(--border);
    border-radius: 0.5rem;
    color: var(--text-primary);
    font-size: 0.875rem;
}

.mode-selector {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 0.5rem;
}
.mode-option {
    cursor: pointer;
}
.mode-option input { display: none; }
.mode-option-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.25rem;
    padding: 1rem;
    border: 2px solid var(--border);
    border-radius: 0.75rem;
    background: var(--bg-secondary);
    text-align: center;
    transition: all 0.2s;
    color: var(--text-primary);
}
.mode-option-content strong { font-size: 0.875rem; }
.mode-option-content span { font-size: 0.7rem; color: var(--text-muted); }
.mode-option.active .mode-option-content {
    border-color: #3b82f6;
    background: rgba(59,130,246,0.08);
}
.dash-trade .mode-option.active .mode-option-content {
    border-color: #10b981;
    background: rgba(16,185,129,0.08);
}

.layout-selector {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 0.5rem;
}
.layout-option {
    cursor: pointer;
    padding: 0.625rem 0.75rem;
    border: 2px solid var(--border);
    border-radius: 0.5rem;
    background: var(--bg-secondary);
    color: var(--text-primary);
    font-size: 0.875rem;
    font-weight: 600;
    text-align: center;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}
.layout-option input { display: none; }
.layout-option.active {
    border-color: #3b82f6;
    background: rgba(59,130,246,0.08);
}

.widget-order-list {
    display: flex;
    flex-direction: column;
    gap: 0.375rem;
}
.widget-order-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.5rem 0.75rem;
    background: var(--bg-secondary);
    border: 1px solid var(--border);
    border-radius: 0.5rem;
    cursor: move;
    font-size: 0.8rem;
    color: var(--text-primary);
    user-select: none;
}
.widget-order-item:hover { background: var(--border); }
.widget-order-item.dragging { opacity: 0.5; }
.widget-order-item .handle { color: var(--text-muted); cursor: grab; }
.widget-order-item .remove {
    margin-left: auto;
    color: var(--text-muted);
    cursor: pointer;
    font-size: 0.75rem;
}
.widget-order-item .remove:hover { color: #ef4444; }

.btn {
    padding: 0.5rem 1rem;
    border-radius: 0.5rem;
    font-size: 0.875rem;
    font-weight: 600;
    border: none;
    cursor: pointer;
    transition: all 0.2s;
}
.btn-primary {
    background: #3b82f6;
    color: #fff;
}
.btn-primary:hover { background: #2563eb; }
.dash-trade .btn-primary { background: #10b981; }
.dash-trade .btn-primary:hover { background: #059669; }
.btn-secondary {
    background: var(--bg-secondary);
    color: var(--text-primary);
    border: 1px solid var(--border);
}
.btn-secondary:hover { background: var(--border); }

/* ── Scrollbar ── */
.table-scroll::-webkit-scrollbar,
.settings-body::-webkit-scrollbar { width: 6px; height: 6px; }
.table-scroll::-webkit-scrollbar-thumb,
.settings-body::-webkit-scrollbar-thumb {
    background: var(--border);
    border-radius: 3px;
}
.table-scroll::-webkit-scrollbar-track,
.settings-body::-webkit-scrollbar-track { background: transparent; }
</style>

<!-- ═══════════════════ SCRIPTS ═══════════════════ -->
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
<script>
(function() {
    'use strict';

    var isTrade = <?php echo $isTrade ? 'true' : 'false'; ?>;
    var textColor = isTrade ? '#94a3b8' : (document.documentElement.classList.contains('dark') ? '#9ca3af' : '#6b7280');
    var gridColor = isTrade ? '#1e293b' : (document.documentElement.classList.contains('dark') ? '#1f2937' : '#e5e7eb');

    // ── CANDLESTICK REVENUE ──
    var revenueData = <?php echo json_encode($candleRevenue ?? []); ?>;
    var el = document.querySelector("#candleRevenue");
    if (el && revenueData.length > 0) {
        new ApexCharts(el, {
            series: [{ data: revenueData }],
            chart: {
                type: 'candlestick', height: el.style.height.replace('px','') * 1,
                background: 'transparent', foreColor: textColor,
                toolbar: { show: true }
            },
            plotOptions: { candlestick: { colors: { upward: '#10b981', downward: '#ef4444' }, wick: { useFillColor: true } } },
            xaxis: { type: 'datetime', axisBorder: { color: gridColor }, labels: { style: { colors: textColor, fontSize: '10px' } } },
            yaxis: { labels: { style: { colors: textColor, fontSize: '10px' },
                formatter: function(v) { return v >= 1e6 ? 'Rp '+(v/1e6).toFixed(1)+'M' : v >= 1e3 ? 'Rp '+(v/1e3).toFixed(0)+'K' : 'Rp '+v; }
            }},
            grid: { borderColor: gridColor, strokeDashArray: 3 },
            tooltip: { theme: 'dark' }
        }).render();
    }

    // ── CANDLESTICK BANDWIDTH ──
    var bwData = <?php echo json_encode($candleBandwidth ?? []); ?>;
    el = document.querySelector("#candleBandwidth");
    if (el && bwData.length > 0) {
        new ApexCharts(el, {
            series: [{ data: bwData }],
            chart: { type: 'candlestick', height: el.style.height.replace('px','') * 1, background: 'transparent', foreColor: textColor, toolbar: { show: true } },
            plotOptions: { candlestick: { colors: { upward: '#3b82f6', downward: '#f97316' }, wick: { useFillColor: true } } },
            xaxis: { type: 'datetime', axisBorder: { color: gridColor }, labels: { style: { colors: textColor, fontSize: '10px' } } },
            yaxis: { labels: { style: { colors: textColor, fontSize: '10px' },
                formatter: function(v) { return v >= 1073741824 ? (v/1073741824).toFixed(1)+' GB' : v >= 1048576 ? (v/1048576).toFixed(0)+' MB' : (v/1024).toFixed(0)+' KB'; }
            }},
            grid: { borderColor: gridColor, strokeDashArray: 3 },
            tooltip: { theme: 'dark' }
        }).render();
    }

    // ── GROWTH ──
    var growthData = <?php echo json_encode($pelangganGrowth ?? []); ?>;
    el = document.querySelector("#chartGrowth");
    if (el && growthData.length > 0) {
        new ApexCharts(el, {
            series: [{ name: 'Pelanggan', data: growthData.map(function(r){ return parseInt(r.new_pelanggan); }) }],
            chart: { type: 'area', height: el.style.height.replace('px','') * 1, toolbar: { show: false } },
            xaxis: { categories: growthData.map(function(r){ return r.bulan; }), labels: { style: { fontSize: '9px', colors: textColor } } },
            yaxis: { labels: { style: { fontSize: '10px', colors: textColor } } },
            colors: ['#3b82f6'],
            fill: { type: 'gradient', gradient: { opacityFrom: 0.4, opacityTo: 0.05 } },
            stroke: { curve: 'smooth', width: 2 },
            dataLabels: { enabled: false },
            grid: { borderColor: gridColor, strokeDashArray: 3 },
            tooltip: { theme: isTrade ? 'dark' : 'light' }
        }).render();
    }

    // ── PAKET DONUT ──
    var paketData = <?php echo json_encode($paketDist ?? []); ?>;
    el = document.querySelector("#chartPaket");
    if (el && paketData.length > 0) {
        new ApexCharts(el, {
            series: paketData.map(function(r){ return parseInt(r.cnt); }),
            chart: { type: 'donut', height: el.style.height.replace('px','') * 1 },
            labels: paketData.map(function(r){ return r.nama_paket; }),
            colors: ['#8b5cf6','#06b6d4','#f59e0b','#ef4444','#10b981'],
            legend: { position: 'bottom', fontSize: '10px', labels: { colors: textColor } },
            plotOptions: { pie: { donut: { size: '65%' } } },
            tooltip: { theme: 'dark' }
        }).render();
    }

    // ── STATUS DONUT ──
    var statusData = <?php echo json_encode($statusDist ?? []); ?>;
    el = document.querySelector("#chartStatus");
    if (el && statusData.length > 0) {
        var sc = { 'aktif':'#10b981', 'isolir':'#ef4444', 'pending':'#f59e0b', 'nonaktif':'#6b7280' };
        new ApexCharts(el, {
            series: statusData.map(function(r){ return parseInt(r.cnt); }),
            chart: { type: 'donut', height: el.style.height.replace('px','') * 1 },
            labels: statusData.map(function(r){ return r.status_internet; }),
            colors: statusData.map(function(r){ return sc[r.status_internet] || '#6b7280'; }),
            legend: { position: 'bottom', fontSize: '10px', labels: { colors: textColor } },
            plotOptions: { pie: { donut: { size: '65%' } } },
            tooltip: { theme: 'dark' }
        }).render();
    }

    // ── PENGADUAN AREA ──
    var pengData = <?php echo json_encode($pengaduanDaily ?? []); ?>;
    el = document.querySelector("#chartPengaduan");
    if (el && pengData.length > 0) {
        new ApexCharts(el, {
            series: [{ name: 'Pengaduan', data: pengData.map(function(r){ return parseInt(r.cnt); }) }],
            chart: { type: 'area', height: el.style.height.replace('px','') * 1, toolbar: { show: false } },
            xaxis: { categories: pengData.map(function(r){ return r.tanggal; }), labels: { style: { fontSize: '9px', colors: textColor } } },
            yaxis: { labels: { style: { fontSize: '10px', colors: textColor } } },
            colors: ['#f59e0b'],
            fill: { type: 'gradient', gradient: { opacityFrom: 0.4, opacityTo: 0.05 } },
            stroke: { curve: 'smooth', width: 2 },
            dataLabels: { enabled: false },
            grid: { borderColor: gridColor, strokeDashArray: 3 },
            tooltip: { theme: isTrade ? 'dark' : 'light' }
        }).render();
    }

})();

// ── Widget Toggle ──
function toggleWidget(btn) {
    var widget = btn.closest('.widget');
    widget.classList.toggle('collapsed');
    var icon = btn.querySelector('i');
    icon.className = widget.classList.contains('collapsed') ? 'fa-solid fa-plus' : 'fa-solid fa-minus';
}

// ── Fullscreen ──
function toggleFullscreen() {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen();
    else document.exitFullscreen();
}

// ── Switch Mode ──
function switchMode(mode) {
    fetch('/dashboard/switch-mode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'mode=' + encodeURIComponent(mode)
    }).then(function(r) { return r.json(); })
      .then(function() { location.reload(); })
      .catch(function(e) { console.error(e); });
}

// ── Settings Panel ──
var widgetLabels = {
    revenue: 'Revenue Candlestick',
    bandwidth: 'Bandwidth Usage',
    growth: 'Pertumbuhan Pelanggan',
    paket: 'Distribusi Paket',
    status: 'Status Internet',
    pengaduan: 'Pengaduan Harian',
    pembayaran: 'Pembayaran Terbaru',
    pengaduan_table: 'Pengaduan Terbaru'
};
var currentWidgets = <?php echo json_encode($widgets); ?>;

function openSettings() {
    renderWidgetOrder();
    document.getElementById('settingsPanel').classList.add('open');
    
    // Set mode radio
    document.querySelectorAll('input[name="mode"]').forEach(function(r) {
        r.closest('.mode-option').classList.toggle('active', r.checked);
    });
    document.querySelectorAll('input[name="layout"]').forEach(function(r) {
        r.closest('.layout-option').classList.toggle('active', r.checked);
    });
}

function closeSettings() {
    document.getElementById('settingsPanel').classList.remove('open');
}

function renderWidgetOrder() {
    var list = document.getElementById('widgetOrderList');
    list.innerHTML = '';
    currentWidgets.forEach(function(w, idx) {
        var item = document.createElement('div');
        item.className = 'widget-order-item';
        item.dataset.widget = w;
        item.innerHTML = '<span class="handle"><i class="fa-solid fa-grip-vertical"></i></span>' +
                        '<span>' + (widgetLabels[w] || w) + '</span>' +
                        '<span class="remove" onclick="removeWidget(\'' + w + '\')"><i class="fa-solid fa-xmark"></i></span>';
        list.appendChild(item);
    });
    
    if (typeof Sortable !== 'undefined') {
        new Sortable(list, {
            animation: 150,
            handle: '.handle',
            onEnd: function() {
                currentWidgets = Array.from(list.children).map(function(el) { return el.dataset.widget; });
            }
        });
    }
}

function removeWidget(w) {
    currentWidgets = currentWidgets.filter(function(x) { return x !== w; });
    renderWidgetOrder();
}

function resetSettings() {
    currentWidgets = ['revenue','bandwidth','growth','paket','status','pengaduan','pembayaran','pengaduan_table'];
    document.querySelector('input[name="mode"][value="classic"]').checked = true;
    document.querySelector('input[name="layout"][value="comfortable"]').checked = true;
    document.getElementById('autoRefresh').value = '0';
    document.querySelectorAll('.mode-option, .layout-option').forEach(function(el) {
        var radio = el.querySelector('input');
        el.classList.toggle('active', radio.checked);
    });
    renderWidgetOrder();
}

function saveSettings() {
    var mode = document.querySelector('input[name="mode"]:checked').value;
    var layout = document.querySelector('input[name="layout"]:checked').value;
    var refresh = document.getElementById('autoRefresh').value;
    var widgets = currentWidgets.join(',');
    
    // Simpan mode dulu jika berubah
    var currentMode = <?php echo json_encode($mode); ?>;
    var promise = Promise.resolve();
    
    if (mode !== currentMode) {
        promise = fetch('/dashboard/switch-mode', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'mode=' + encodeURIComponent(mode)
        });
    }
    
    promise.then(function() {
        return fetch('/dashboard/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'layout=' + encodeURIComponent(layout) +
                  '&auto_refresh=' + encodeURIComponent(refresh) +
                  '&widgets=' + encodeURIComponent(widgets)
        });
    }).then(function(r) { return r.json(); })
      .then(function() { location.reload(); })
      .catch(function(e) { console.error(e); alert('Gagal menyimpan: ' + e); });
}

// ── Mode/Layout Radio Handler ──
document.addEventListener('change', function(e) {
    if (e.target.matches('input[name="mode"]')) {
        document.querySelectorAll('.mode-option').forEach(function(el) {
            el.classList.toggle('active', el.querySelector('input').checked);
        });
    }
    if (e.target.matches('input[name="layout"]')) {
        document.querySelectorAll('.layout-option').forEach(function(el) {
            el.classList.toggle('active', el.querySelector('input').checked);
        });
    }
});
</script>
