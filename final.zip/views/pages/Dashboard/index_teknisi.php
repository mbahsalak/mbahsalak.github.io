<?php
/**
 * views/pages/Dashboard/index_teknisi.php
 * Dashboard TEKNISI
 * ✅ Ditambahkan: Peta Lokasi Pelanggan (Leaflet Maps)
 * ✅ Tata ulang: layout lebih rapi & konsisten
 */

$pelanggan = $pelanggan ?? [];
$pelangganWithLocation = array_filter($pelanggan, fn($p) => !empty($p['latitude']) && !empty($p['longitude']));
$totalPelangganMap = count($pelangganWithLocation);

// Hitung jumlah per status untuk legend
$statusCounts = ['aktif' => 0, 'isolir' => 0, 'nonaktif' => 0, 'pending' => 0];
foreach ($pelangganWithLocation as $p) {
    $s = $p['status_internet'] ?? 'aktif';
    if (isset($statusCounts[$s])) $statusCounts[$s]++;
}
?>

<div class="max-w-[1320px] mx-auto space-y-6">

    <!-- ===================== PAGE HEADER ===================== -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 class="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                    <i class="fa-solid fa-wrench text-teal-600"></i>
                    Dashboard Teknisi
                </h1>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Halo, <strong class="text-primary"><?= htmlspecialchars($user['username'] ?? 'Teknisi') ?></strong>
                    — pantau jaringan & tiket pelanggan hari ini.
                </p>
            </div>
            <div class="flex items-center gap-3">
                <span class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-teal-100 dark:bg-teal-900/30 text-teal-700 dark:text-teal-400 text-xs font-semibold">
                    <i class="fa-solid fa-circle-check text-[8px]"></i> Online
                </span>
                <span class="text-xs text-gray-500 dark:text-gray-400 font-mono hidden sm:inline" id="liveClock"></span>
                <a href="/ticketing/buat"
                   class="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-indigo-600 transition-colors shadow-sm">
                    <i class="fa-solid fa-plus"></i>
                    <span class="hidden sm:inline">Buat Tiket</span>
                </a>
            </div>
        </div>
    </div>

    <!-- ===================== STAT CARDS ===================== -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">

        <!-- Tiket Open -->
        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 hover:shadow-md transition-shadow">
            <div class="flex items-start justify-between">
                <div>
                    <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Tiket Terbuka</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?= number_format($stats['tiket_open'] ?? 0) ?></p>
                    <p class="text-xs text-red-600 dark:text-red-400 font-medium mt-1">
                        <i class="fa-solid fa-circle-exclamation mr-1"></i>Perlu ditangani
                    </p>
                </div>
                <div class="w-10 h-10 rounded-lg bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                    <i class="fa-solid fa-headset text-red-600 dark:text-red-400"></i>
                </div>
            </div>
        </div>

        <!-- Tiket Proses -->
        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 hover:shadow-md transition-shadow">
            <div class="flex items-start justify-between">
                <div>
                    <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Dalam Proses</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?= number_format($stats['tiket_proses'] ?? 0) ?></p>
                    <p class="text-xs text-orange-600 dark:text-orange-400 font-medium mt-1">
                        <i class="fa-solid fa-spinner fa-spin mr-1"></i>Sedang ditangani
                    </p>
                </div>
                <div class="w-10 h-10 rounded-lg bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center">
                    <i class="fa-solid fa-clock text-orange-600 dark:text-orange-400"></i>
                </div>
            </div>
        </div>

        <!-- Total Pelanggan -->
        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 hover:shadow-md transition-shadow">
            <div class="flex items-start justify-between">
                <div>
                    <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Total Pelanggan</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?= number_format($stats['total_pelanggan'] ?? 0) ?></p>
                    <p class="text-xs text-blue-600 dark:text-blue-400 font-medium mt-1">
                        <i class="fa-solid fa-users mr-1"></i>Terdaftar di sistem
                    </p>
                </div>
                <div class="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                    <i class="fa-solid fa-users text-blue-600 dark:text-blue-400"></i>
                </div>
            </div>
        </div>

        <!-- Pelanggan Aktif -->
        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 hover:shadow-md transition-shadow">
            <div class="flex items-start justify-between">
                <div>
                    <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Pelanggan Aktif</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?= number_format($stats['pelanggan_aktif'] ?? 0) ?></p>
                    <p class="text-xs text-green-600 dark:text-green-400 font-medium mt-1">
                        <i class="fa-solid fa-signal mr-1"></i>Layanan berjalan
                    </p>
                </div>
                <div class="w-10 h-10 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                    <i class="fa-solid fa-wifi text-green-600 dark:text-green-400"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- ===================== PETA LOKASI PELANGGAN ===================== -->
    <?php if ($totalPelangganMap > 0): ?>
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <!-- Header Peta -->
        <div class="p-5 pb-3 border-b border-gray-200 dark:border-gray-700">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                    <h2 class="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
                        <i class="fa-solid fa-map-location-dot text-teal-600"></i>
                        Peta Sebaran Pelanggan
                    </h2>
                    <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        Menampilkan <strong><?= $totalPelangganMap ?></strong> pelanggan dengan koordinat lokasi.
                        Klik marker untuk detail.
                    </p>
                </div>

                <!-- Filter Status -->
                <div class="flex items-center gap-1.5 flex-wrap" id="mapFilter">
                    <button type="button" data-filter="all"
                            class="map-filter-btn active px-3 py-1.5 rounded-full text-xs font-semibold bg-gray-900 text-white transition-colors">
                        Semua (<?= $totalPelangganMap ?>)
                    </button>
                    <button type="button" data-filter="aktif"
                            class="map-filter-btn px-3 py-1.5 rounded-full text-xs font-semibold bg-green-100 text-green-700 hover:bg-green-200 dark:bg-green-900/30 dark:text-green-400 transition-colors">
                        <i class="fa-solid fa-circle text-[6px] mr-1"></i>Aktif (<?= $statusCounts['aktif'] ?>)
                    </button>
                    <button type="button" data-filter="isolir"
                            class="map-filter-btn px-3 py-1.5 rounded-full text-xs font-semibold bg-orange-100 text-orange-700 hover:bg-orange-200 dark:bg-orange-900/30 dark:text-orange-400 transition-colors">
                        <i class="fa-solid fa-circle text-[6px] mr-1"></i>Isolir (<?= $statusCounts['isolir'] ?>)
                    </button>
                    <button type="button" data-filter="pending"
                            class="map-filter-btn px-3 py-1.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-700 hover:bg-blue-200 dark:bg-blue-900/30 dark:text-blue-400 transition-colors">
                        <i class="fa-solid fa-circle text-[6px] mr-1"></i>Pending (<?= $statusCounts['pending'] ?>)
                    </button>
                    <button type="button" data-filter="nonaktif"
                            class="map-filter-btn px-3 py-1.5 rounded-full text-xs font-semibold bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 transition-colors">
                        <i class="fa-solid fa-circle text-[6px] mr-1"></i>Nonaktif (<?= $statusCounts['nonaktif'] ?>)
                    </button>
                </div>
            </div>
        </div>

        <!-- Peta -->
        <div id="mapDashboard" class="h-[450px] w-full z-0"></div>

        <!-- Footer Peta -->
        <div class="p-4 bg-gray-50 dark:bg-gray-700/30 border-t border-gray-200 dark:border-gray-700">
            <div class="flex flex-wrap items-center justify-between gap-3 text-xs">
                <div class="flex items-center gap-4">
                    <span class="flex items-center gap-1.5">
                        <span class="w-3 h-3 rounded-full bg-green-500"></span>
                        <span class="text-gray-600 dark:text-gray-400">Aktif</span>
                    </span>
                    <span class="flex items-center gap-1.5">
                        <span class="w-3 h-3 rounded-full bg-orange-500"></span>
                        <span class="text-gray-600 dark:text-gray-400">Isolir</span>
                    </span>
                    <span class="flex items-center gap-1.5">
                        <span class="w-3 h-3 rounded-full bg-blue-500"></span>
                        <span class="text-gray-600 dark:text-gray-400">Pending</span>
                    </span>
                    <span class="flex items-center gap-1.5">
                        <span class="w-3 h-3 rounded-full bg-gray-500"></span>
                        <span class="text-gray-600 dark:text-gray-400">Nonaktif</span>
                    </span>
                </div>
                <a href="/pelanggan" class="text-primary hover:text-indigo-600 dark:hover:text-indigo-400 font-medium">
                    Lihat semua pelanggan &rarr;
                </a>
            </div>
        </div>
    </div>
    <?php else: ?>
    <!-- Placeholder jika tidak ada data peta -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-8 text-center">
        <i class="fa-solid fa-map-location-dot text-4xl text-gray-300 dark:text-gray-600 mb-3"></i>
        <p class="text-sm font-medium text-gray-700 dark:text-gray-300">Belum ada data lokasi pelanggan</p>
        <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Tambahkan koordinat pada data pelanggan untuk menampilkan peta.</p>
    </div>
    <?php endif; ?>

    <!-- ===================== ANTRIAN TIKET ===================== -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div class="p-5 pb-3 flex justify-between items-start">
            <div>
                <h2 class="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
                    <i class="fa-solid fa-headset text-red-500"></i>
                    Antrian Tiket
                </h2>
                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Tiket <em>open</em> & <em>dalam proses</em> — perlu tindakan segera.
                </p>
            </div>
            <a href="/ticketing"
               class="text-xs font-medium text-primary hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors flex items-center gap-1">
                Semua Tiket <i class="fa-solid fa-arrow-right text-[10px]"></i>
            </a>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 dark:bg-gray-700/50 border-y border-gray-200 dark:border-gray-700">
                    <tr>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider w-10">#</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Pelanggan</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Keluhan</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Waktu</th>
                        <th class="px-5 py-3 text-right text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider w-24">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                    <?php if (!empty($ticketOpen)): ?>
                        <?php foreach ($ticketOpen as $i => $tk): ?>
                        <tr class="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                            <td class="px-5 py-3 text-gray-400"><?= $i + 1 ?></td>
                            <td class="px-5 py-3">
                                <div class="flex items-center gap-3">
                                    <div class="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                                        <?= strtoupper(substr($tk['nama_lengkap'] ?? '?', 0, 1)) ?>
                                    </div>
                                    <span class="font-medium text-gray-900 dark:text-white truncate max-w-[160px]">
                                        <?= htmlspecialchars($tk['nama_lengkap'] ?? '-') ?>
                                    </span>
                                </div>
                            </td>
                            <td class="px-5 py-3 max-w-[280px]">
                                <p class="text-sm font-medium text-gray-900 dark:text-white truncate"><?= htmlspecialchars($tk['judul']) ?></p>
                                <?php if (!empty($tk['deskripsi'])): ?>
                                <p class="text-xs text-gray-500 dark:text-gray-400 mt-0.5 truncate max-w-[260px]">
                                    <?= htmlspecialchars($tk['deskripsi']) ?>
                                </p>
                                <?php endif; ?>
                            </td>
                            <td class="px-5 py-3">
                                <?php
                                [$badgeBg, $badgeText, $badgeLabel] = match($tk['status'] ?? 'open') {
                                    'open'   => ['bg-red-100 dark:bg-red-900/30', 'text-red-700 dark:text-red-400', 'Baru'],
                                    'proses' => ['bg-orange-100 dark:bg-orange-900/30', 'text-orange-700 dark:text-orange-400', 'Proses'],
                                    default  => ['bg-gray-100 dark:bg-gray-700', 'text-gray-700 dark:text-gray-300', ucfirst($tk['status'] ?? '-')],
                                };
                                ?>
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wide <?= $badgeBg ?> <?= $badgeText ?>">
                                    <?= $badgeLabel ?>
                                </span>
                            </td>
                            <td class="px-5 py-3 text-gray-500 dark:text-gray-400 text-xs whitespace-nowrap">
                                <?= date('d M, H:i', strtotime($tk['created_at'] ?? 'now')) ?>
                            </td>
                            <td class="px-5 py-3 text-right">
                                <a href="/ticketing/<?= $tk['id'] ?>"
                                   class="inline-flex items-center gap-1 px-3 py-1.5 rounded-md bg-primary hover:bg-indigo-600 text-white text-xs font-medium transition-colors">
                                    <i class="fa-solid fa-arrow-right"></i> Tangani
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="px-5 py-12 text-center">
                                <i class="fa-solid fa-circle-check text-4xl text-green-400 mb-3"></i>
                                <p class="text-sm font-medium text-gray-700 dark:text-gray-300">Semua tiket tertangani</p>
                                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Tidak ada antrian tiket saat ini.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- ===================== LEAFLET CSS & JS ===================== -->
<?php if ($totalPelangganMap > 0): ?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<script>
(function() {
    // Data pelanggan dari PHP
    const pelangganData = <?= json_encode(array_values($pelangganWithLocation), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    const appUrl = '<?= rtrim($_ENV['APP_URL'] ?? '', '/') ?>';

    // Konfigurasi warna berdasarkan status
    const statusConfig = {
        'aktif':    { color: '#10b981', label: 'Aktif' },
        'isolir':   { color: '#f97316', label: 'Isolir' },
        'pending':  { color: '#3b82f6', label: 'Pending' },
        'nonaktif': { color: '#64748b', label: 'Nonaktif' },
    };

    // Default center (Jakarta)
    const defaultCenter = [-6.200000, 106.816666];

    // Init map
    const map = L.map('mapDashboard', {
        zoomControl: true,
        scrollWheelZoom: true
    }).setView(defaultCenter, 12);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
    }).addTo(map);

    // Simpan semua marker dengan referensi status
    const markers = {};
    const allMarkers = [];

    // Buat marker untuk setiap pelanggan
    pelangganData.forEach(p => {
        const lat = parseFloat(p.latitude);
        const lng = parseFloat(p.longitude);
        if (isNaN(lat) || isNaN(lng)) return;

        const status = p.status_internet || 'aktif';
        const cfg = statusConfig[status] || statusConfig['aktif'];

        // Custom div icon dengan warna status
        const icon = L.divIcon({
            className: 'custom-marker',
            html: `
                <div style="
                    width: 28px; height: 28px;
                    background: ${cfg.color};
                    border: 3px solid white;
                    border-radius: 50%;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                    position: relative;
                ">
                    <div style="
                        position: absolute;
                        top: 50%; left: 50%;
                        transform: translate(-50%, -50%);
                        color: white;
                        font-size: 11px;
                        font-weight: bold;
                    ">
                        <i class="fa-solid fa-user" style="font-size: 10px;"></i>
                    </div>
                </div>
            `,
            iconSize: [28, 28],
            iconAnchor: [14, 14],
            popupAnchor: [0, -14]
        });

        const marker = L.marker([lat, lng], { icon: icon }).addTo(map);

        // Popup info
        const noTelp = p.no_telp ? p.no_telp.replace(/^0/, '62') : '';
        const waLink = noTelp ? `<a href="https://wa.me/${noTelp}" target="_blank" class="wa-link">
            <i class="fa-brands fa-whatsapp"></i> Chat WA
        </a>` : '';

        marker.bindPopup(`
            <div style="font-family: system-ui, sans-serif; min-width: 220px; font-size: 13px;">
                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px; padding-bottom: 8px; border-bottom: 1px solid #e5e7eb;">
                    <div style="
                        width: 32px; height: 32px;
                        background: ${cfg.color};
                        border-radius: 50%;
                        display: flex; align-items: center; justify-content: center;
                        color: white; font-weight: bold;
                    ">${(p.nama_lengkap || '?').charAt(0).toUpperCase()}</div>
                    <div style="flex: 1; min-width: 0;">
                        <div style="font-weight: 600; color: #1e293b;">${p.nama_lengkap || '-'}</div>
                        <div style="font-size: 11px; color: #64748b;">${p.username || '-'}</div>
                    </div>
                </div>

                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                    <span style="
                        display: inline-block;
                        padding: 2px 10px;
                        border-radius: 12px;
                        background: ${cfg.color}20;
                        color: ${cfg.color};
                        font-size: 11px;
                        font-weight: 600;
                    ">${cfg.label}</span>
                    <span style="font-size: 11px; color: #64748b;">
                        ${p.nama_paket ? '📦 ' + p.nama_paket : ''}
                    </span>
                </div>

                ${p.no_telp ? `<div style="font-size: 12px; color: #475569; margin-bottom: 8px;">
                    <i class="fa-solid fa-phone" style="color: #94a3b8;"></i> ${p.no_telp}
                </div>` : ''}

                <div style="display: flex; gap: 6px; margin-top: 10px;">
                    <a href="${appUrl}/pelanggan/${p.id}" style="
                        flex: 1;
                        padding: 6px 10px;
                        background: #4f46e5;
                        color: white;
                        text-decoration: none;
                        border-radius: 6px;
                        font-size: 12px;
                        font-weight: 500;
                        text-align: center;
                    ">
                        <i class="fa-solid fa-eye"></i> Detail
                    </a>
                    ${waLink}
                </div>
            </div>
        `, { maxWidth: 300 });

        // Simpan marker berdasarkan status
        if (!markers[status]) markers[status] = [];
        markers[status].push(marker);
        allMarkers.push(marker);
    });

    // Fit bounds ke semua marker
    if (allMarkers.length > 0) {
        const group = L.featureGroup(allMarkers);
        map.fitBounds(group.getBounds().pad(0.15));
    }

    // Style untuk WA link di popup
    const style = document.createElement('style');
    style.textContent = `
        .wa-link {
            flex: 1;
            padding: 6px 10px;
            background: #22c55e;
            color: white !important;
            text-decoration: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 500;
            text-align: center;
            display: inline-block;
        }
        .wa-link:hover { background: #16a34a; }
        .custom-marker { background: transparent !important; border: none !important; }
    `;
    document.head.appendChild(style);

    // Filter functionality
    let activeFilter = 'all';
    document.querySelectorAll('.map-filter-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const filter = this.dataset.filter;
            if (filter === activeFilter) return;

            activeFilter = filter;

            // Update button styles
            document.querySelectorAll('.map-filter-btn').forEach(b => {
                b.classList.remove('active');
                if (b.dataset.filter === 'all') {
                    b.classList.remove('bg-gray-900', 'text-white');
                    b.classList.add('bg-gray-100', 'text-gray-700', 'hover:bg-gray-200', 'dark:bg-gray-700', 'dark:text-gray-300');
                }
            });
            this.classList.add('active');
            if (this.dataset.filter === 'all') {
                this.classList.remove('bg-gray-100', 'text-gray-700', 'hover:bg-gray-200', 'dark:bg-gray-700', 'dark:text-gray-300');
                this.classList.add('bg-gray-900', 'text-white');
            }

            // Show/hide markers
            if (filter === 'all') {
                allMarkers.forEach(m => m.addTo(map));
            } else {
                allMarkers.forEach(m => map.removeLayer(m));
                (markers[filter] || []).forEach(m => m.addTo(map));
            }

            // Fit bounds ke marker yang visible
            const visibleMarkers = filter === 'all' ? allMarkers : (markers[filter] || []);
            if (visibleMarkers.length > 0) {
                const group = L.featureGroup(visibleMarkers);
                map.fitBounds(group.getBounds().pad(0.15));
            }
        });
    });
})();
</script>
<?php endif; ?>

<!-- ===================== LIVE CLOCK ===================== -->
<script>
(function() {
    const clock = document.getElementById('liveClock');
    if (!clock) return;

    function updateClock() {
        const now = new Date();
        const opts = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false };
        clock.textContent = now.toLocaleTimeString('id-ID', opts) + ' • ' +
            now.toLocaleDateString('id-ID', { weekday: 'short', day: 'numeric', month: 'short' });
    }
    updateClock();
    setInterval(updateClock, 1000);
})();
</script>
