<?php
/**
 * views/pages/Dashboard/index_pelanggan_nonaktif.php
 * Dashboard yang dilihat PELANGGAN saat akunnya berstatus 'nonaktif'
 * (pendaftaran ditolak admin, atau dinonaktifkan).
 *
 * Dipanggil oleh: DashboardController::renderPelanggan()
 * saat $statusInternet === 'nonaktif'
 */
$appUrl    = rtrim($_ENV['APP_URL'] ?? '', '/');
$pelanggan = $pelanggan ?? [];
$nama      = $pelanggan['nama_lengkap'] ?? ($user['nama_lengkap'] ?? $user['username'] ?? 'Pelanggan');
?>

<div class="max-w-2xl mx-auto px-4 py-12">

    <?php if (!empty($flash) && !empty($flash['message'])):
        $flashType  = $flash['type'] ?? 'info';
        $flashStyle = match($flashType) {
            'success' => 'bg-emerald-50 border-emerald-200 text-emerald-700',
            'danger'  => 'bg-red-50 border-red-200 text-red-700',
            default   => 'bg-blue-50 border-blue-200 text-blue-700',
        };
    ?>
    <div class="border rounded-xl px-4 py-3 text-sm mb-5 <?= $flashStyle ?>"><?= $flash['message'] ?></div>
    <?php endif; ?>

    <div class="bg-white dark:bg-gray-800 rounded-3xl shadow-lg border border-gray-100 dark:border-gray-700 overflow-hidden">
        <div class="bg-gradient-to-br from-red-400 to-rose-500 px-8 py-10 text-center">
            <div class="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i class="fa-solid fa-circle-exclamation text-white text-4xl"></i>
            </div>
            <h1 class="text-2xl font-extrabold text-white mb-1.5">
                Halo, <?= htmlspecialchars($nama) ?>
            </h1>
            <p class="text-red-50 text-sm font-medium">Akun Anda saat ini tidak aktif</p>
        </div>

        <div class="p-8 space-y-5 text-center">
            <p class="text-gray-600 dark:text-gray-300 text-sm leading-relaxed max-w-md mx-auto">
                Akun Anda telah dinonaktifkan oleh sistem. Hal ini bisa terjadi karena pendaftaran
                belum dapat diproses, atau ada masalah administrasi. Silakan hubungi tim kami untuk
                informasi lebih lanjut.
            </p>

            <a href="https://wa.me/" target="_blank"
               class="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl
                      bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-sm
                      no-underline transition-colors shadow-sm shadow-emerald-500/30">
                <i class="fa-brands fa-whatsapp text-base"></i> Hubungi Customer Service
            </a>
        </div>
    </div>
</div>
