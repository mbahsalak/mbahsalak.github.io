<?php
/**
 * views/pages/Dashboard/index_kasir.php
 * Dashboard KASIR — fokus: tagihan, kas, piutang, grafik pendapatan
 */
?>

<div class="max-w-[1320px] mx-auto space-y-6">
    <!-- PAGE HEADER -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Dashboard Kasir</h1>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Halo, <strong class="text-primary"><?= htmlspecialchars($user['username'] ?? 'Kasir') ?></strong> — rekapitulasi keuangan hari ini.
                </p>
            </div>
            <div class="flex items-center gap-3">
                <span class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400 text-xs font-semibold">
                    <i class="fa-solid fa-cash-register"></i> Kasir
                </span>
                <span class="text-xs text-gray-500 dark:text-gray-400 font-mono" id="liveClock"></span>
                <a href="/tagihan/generate" class="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-indigo-600 transition-colors shadow-sm">
                    <i class="fa-solid fa-bolt"></i> Generate Tagihan
                </a>
            </div>
        </div>
    </div>

    <!-- STAT CARDS -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 hover:shadow-md transition-shadow">
            <div class="flex items-start justify-between mb-3">
                <div class="w-10 h-10 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                    <i class="fa-solid fa-circle-check text-green-600 dark:text-green-400"></i>
                </div>
            </div>
            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Tagihan Lunas</p>
            <p class="text-2xl font-bold text-gray-900 dark:text-white mb-1"><?= number_format($stats['tagihan_paid'] ?? 0) ?></p>
            <p class="text-xs text-green-600 dark:text-green-400 font-medium">
                Rp <?= number_format($stats['pendapatan_bulan'] ?? 0, 0, ',', '.') ?> bulan ini
            </p>
        </div>

        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 hover:shadow-md transition-shadow">
            <div class="flex items-start justify-between mb-3">
                <div class="w-10 h-10 rounded-lg bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center">
                    <i class="fa-solid fa-clock-rotate-left text-orange-600 dark:text-orange-400"></i>
                </div>
            </div>
            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Belum Lunas</p>
            <p class="text-2xl font-bold text-gray-900 dark:text-white mb-1"><?= number_format($stats['tagihan_unpaid'] ?? 0) ?></p>
            <p class="text-xs text-orange-600 dark:text-orange-400 font-medium">
                Rp <?= number_format($stats['piutang'] ?? 0, 0, ',', '.') ?> piutang
            </p>
        </div>

        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 hover:shadow-md transition-shadow">
            <div class="flex items-start justify-between mb-3">
                <div class="w-10 h-10 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                    <i class="fa-solid fa-money-bill-wave text-purple-600 dark:text-purple-400"></i>
                </div>
            </div>
            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Kas Masuk Bulan Ini</p>
            <p class="text-2xl font-bold text-gray-900 dark:text-white mb-1">
                Rp <?= number_format($stats['kas_masuk'] ?? 0, 0, ',', '.') ?>
            </p>
            <p class="text-xs text-gray-500 dark:text-gray-400 font-medium">
                Keluar: Rp <?= number_format($stats['kas_keluar'] ?? 0, 0, ',', '.') ?>
            </p>
        </div>
    </div>

    <!-- MAIN ROW: Chart Pendapatan + Ringkasan Kas -->
    <div class="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-6">
        <!-- Bar chart pendapatan -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5">
            <div class="flex justify-between items-start mb-4">
                <div>
                    <h2 class="text-base font-bold text-gray-900 dark:text-white">Pendapatan Bulanan</h2>
                    <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">12 bulan terakhir</p>
                </div>
                <div class="flex items-center gap-4 text-xs">
                    <span class="flex items-center gap-1.5">
                        <span class="w-3 h-3 rounded-sm bg-blue-600"></span> Lunas
                    </span>
                    <span class="flex items-center gap-1.5">
                        <span class="w-3 h-3 rounded-sm bg-red-500"></span> Belum Lunas
                    </span>
                </div>
            </div>
            <div class="relative h-[300px] w-full">
                <canvas id="chartPendapatan"></canvas>
            </div>
        </div>

        <!-- Ringkasan kas -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5">
            <h2 class="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-5">
                <i class="fa-solid fa-wallet text-purple-600"></i> Ringkasan Kas
            </h2>
            <div class="space-y-4">
                <div class="flex items-center gap-4 p-4 rounded-lg bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
                    <div class="w-10 h-10 rounded-lg bg-green-600 flex items-center justify-center text-white">
                        <i class="fa-solid fa-arrow-down"></i>
                    </div>
                    <div>
                        <p class="text-xs text-green-600 dark:text-green-400 font-medium">Total Masuk</p>
                        <p class="text-lg font-bold text-green-700 dark:text-green-300">Rp <?= number_format($stats['kas_masuk'] ?? 0, 0, ',', '.') ?></p>
                    </div>
                </div>

                <div class="flex items-center gap-4 p-4 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800">
                    <div class="w-10 h-10 rounded-lg bg-red-600 flex items-center justify-center text-white">
                        <i class="fa-solid fa-arrow-up"></i>
                    </div>
                    <div>
                        <p class="text-xs text-red-600 dark:text-red-400 font-medium">Total Keluar</p>
                        <p class="text-lg font-bold text-red-700 dark:text-red-300">Rp <?= number_format($stats['kas_keluar'] ?? 0, 0, ',', '.') ?></p>
                    </div>
                </div>

                <div class="border-t border-gray-200 dark:border-gray-700 pt-4">
                    <?php $saldo = ($stats['kas_masuk'] ?? 0) - ($stats['kas_keluar'] ?? 0); ?>
                    <div class="flex items-center gap-4 p-4 rounded-lg bg-gray-50 dark:bg-gray-700/50 border border-gray-200 dark:border-gray-600">
                        <div class="w-10 h-10 rounded-lg bg-primary flex items-center justify-center text-white">
                            <i class="fa-solid fa-scale-balanced"></i>
                        </div>
                        <div>
                            <p class="text-xs text-gray-500 dark:text-gray-400 font-medium">Saldo Bersih</p>
                            <p class="text-lg font-bold <?= $saldo >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400' ?>">
                                Rp <?= number_format(abs($saldo), 0, ',', '.') ?>
                            </p>
                        </div>
                    </div>
                </div>

                <a href="/kas" class="block w-full text-center px-4 py-2.5 rounded-lg border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 text-sm font-medium hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                    <i class="fa-solid fa-book-open mr-2"></i> Lihat Buku Kas
                </a>
            </div>
        </div>
    </div>

    <!-- TABEL TAGIHAN -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
        <div class="p-5 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
                <h2 class="text-base font-bold text-gray-900 dark:text-white">Tagihan Terbaru</h2>
                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">15 tagihan terakhir masuk</p>
            </div>
            <div class="flex gap-2">
                <a href="/tagihan?filter=unpaid" class="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-medium transition-colors">
                    <i class="fa-solid fa-clock"></i> Belum Lunas
                </a>
                <a href="/tagihan" class="text-xs font-medium text-primary hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">Lihat Semua &rarr;</a>
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 dark:bg-gray-700/50 border-y border-gray-200 dark:border-gray-700">
                    <tr>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">#</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Pelanggan</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Paket</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Total</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Jatuh Tempo</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                        <th class="px-5 py-3 text-right text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                    <?php if (!empty($recentTagihan)): ?>
                        <?php foreach ($recentTagihan as $i => $t): ?>
                        <tr class="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                            <td class="px-5 py-3 text-gray-400"><?= $i + 1 ?></td>
                            <td class="px-5 py-3">
                                <div class="flex items-center gap-3">
                                    <div class="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center text-white text-xs font-bold">
                                        <?= strtoupper(substr($t['nama_lengkap'], 0, 1)) ?>
                                    </div>
                                    <span class="font-medium text-gray-900 dark:text-white"><?= htmlspecialchars($t['nama_lengkap']) ?></span>
                                </div>
                            </td>
                            <td class="px-5 py-3">
                                <span class="inline-flex px-2 py-1 rounded-md bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-xs font-medium">
                                    <?= htmlspecialchars($t['nama_paket']) ?>
                                </span>
                            </td>
                            <td class="px-5 py-3 font-mono text-gray-900 dark:text-white font-medium">
                                Rp <?= number_format($t['total'], 0, ',', '.') ?>
                            </td>
                            <td class="px-5 py-3 <?= strtotime($t['jatuh_tempo']) < time() && $t['status'] === 'unpaid' ? 'text-red-600 dark:text-red-400 font-semibold' : 'text-gray-600 dark:text-gray-400' ?>">
                                <?= date('d M Y', strtotime($t['jatuh_tempo'])) ?>
                            </td>
                            <td class="px-5 py-3">
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wide <?= $t['status'] === 'paid' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' ?>">
                                    <?= $t['status'] === 'paid' ? 'Lunas' : 'Belum Lunas' ?>
                                </span>
                            </td>
                            <td class="px-5 py-3 text-right">
                                <?php if ($t['status'] !== 'paid'): ?>
                                <a href="/tagihan/bayar/<?= $t['id'] ?>" class="inline-flex items-center gap-1 px-3 py-1 rounded-md bg-green-600 hover:bg-green-700 text-white text-xs font-medium transition-colors">
                                    <i class="fa-solid fa-money-bill"></i> Bayar
                                </a>
                                <?php else: ?>
                                <a href="/tagihan/<?= $t['id'] ?>" class="inline-flex items-center gap-1 px-3 py-1 rounded-md bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 text-xs font-medium transition-colors">
                                    <i class="fa-solid fa-eye"></i>
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="px-5 py-12 text-center">
                                <i class="fa-regular fa-folder-open text-3xl text-gray-300 dark:text-gray-600 mb-3"></i>
                                <p class="text-sm text-gray-500 dark:text-gray-400">Belum ada tagihan</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
const isDark = document.documentElement.classList.contains('dark');
const gridColor = isDark ? '#374151' : '#f1f5f9';
const textColor = isDark ? '#9ca3af' : '#64748b';

Chart.defaults.color = textColor;
Chart.defaults.borderColor = gridColor;

window.DASHBOARD_DATA = <?= json_encode([
    'pendapatan' => $chartData['pendapatan'] ?? [],
    'labels'     => $chartData['labels']     ?? [],
    'unpaid'     => $chartData['unpaid']     ?? [],
    'paket'      => [],
], JSON_HEX_TAG) ?>;

const cd = window.DASHBOARD_DATA;
const ctx = document.getElementById('chartPendapatan')?.getContext('2d');
if (ctx && cd.labels.length) {
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: cd.labels,
            datasets: [
                { label: 'Lunas', data: cd.pendapatan, backgroundColor: '#2563eb', borderRadius: 6 },
                { label: 'Belum Lunas', data: cd.unpaid, backgroundColor: '#dc2626', borderRadius: 6 },
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: { callbacks: { label: c => 'Rp ' + c.raw.toLocaleString('id-ID') } }
            },
            scales: {
                x: { grid: { display: false }, ticks: { font: { size: 10 } } },
                y: { grid: { color: gridColor }, ticks: { font: { size: 10 }, callback: v => 'Rp ' + (v/1e6).toFixed(0) + 'jt' } }
            }
        }
    });
}
</script>
