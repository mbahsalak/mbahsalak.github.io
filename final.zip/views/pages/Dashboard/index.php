<?php
/**
 * views/pages/Dashboard/index.php
 * Dashboard dengan fitur kustomisasi: toggle widget, drag-reorder
 */
?>

<!-- ===== PAGE HEADER ===== -->
<div class="page-header">
    <div class="page-header__left">
        <h1 class="page-title">Dashboard</h1>
        <p class="page-subtitle">Selamat datang, <strong><?= htmlspecialchars($_SESSION['user']['username'] ?? 'Admin') ?></strong> — ringkasan sistem hari ini.</p>
    </div>
    <div class="page-header__right">
        <span class="live-clock" id="liveClock"></span>
        <button class="btn btn--ghost btn--sm" id="btnCustomize">
            <i class="fa-solid fa-sliders"></i> Kustomisasi
        </button>
        <a href="/tagihan/generate" class="btn btn--primary">
            <i class="fa-solid fa-bolt"></i> Generate Tagihan
        </a>
    </div>
</div>

<!-- ===== CUSTOMIZE PANEL ===== -->
<div class="customize-panel" id="customizePanel" style="display:none">
    <div class="customize-panel__header">
        <span><i class="fa-solid fa-sliders"></i> Kustomisasi Dashboard</span>
        <div style="display:flex;gap:8px;align-items:center">
            <button class="btn btn--ghost btn--sm" id="btnResetLayout">
                <i class="fa-solid fa-rotate-left"></i> Reset
            </button>
            <button class="btn btn--primary btn--sm" id="btnSaveLayout">
                <i class="fa-solid fa-check"></i> Simpan
            </button>
            <button class="icon-btn" id="btnCloseCustomize" style="margin-left:4px">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    </div>
    <p class="customize-panel__hint">Centang widget yang ingin ditampilkan. Drag kartu untuk mengubah urutan.</p>
    <div class="customize-toggles" id="customizeToggles"></div>
</div>

<!-- ===== STAT CARDS ===== -->
<div class="stats-grid dash-section" id="section-stats" data-label="Kartu Statistik">
    <div class="stat-card stat-card--blue dash-widget" data-id="stat-pelanggan">
        <div class="stat-card__icon"><i class="fa-solid fa-users"></i></div>
        <div class="stat-card__body">
            <span class="stat-card__label">Total Pelanggan</span>
            <span class="stat-card__value"><?= number_format($stats['total_pelanggan'] ?? 0) ?></span>
            <span class="stat-card__trend trend--up">
                <i class="fa-solid fa-arrow-trend-up"></i>
                <?= $stats['pelanggan_baru_bulan'] ?? 0 ?> baru bulan ini
            </span>
        </div>
    </div>

    <div class="stat-card stat-card--green dash-widget" data-id="stat-lunas">
        <div class="stat-card__icon"><i class="fa-solid fa-circle-check"></i></div>
        <div class="stat-card__body">
            <span class="stat-card__label">Tagihan Lunas</span>
            <span class="stat-card__value"><?= number_format($stats['tagihan_paid'] ?? 0) ?></span>
            <span class="stat-card__trend">
                Rp <?= number_format($stats['pendapatan_bulan'] ?? 0, 0, ',', '.') ?> bulan ini
            </span>
        </div>
    </div>

    <div class="stat-card stat-card--orange dash-widget" data-id="stat-unpaid">
        <div class="stat-card__icon"><i class="fa-solid fa-clock-rotate-left"></i></div>
        <div class="stat-card__body">
            <span class="stat-card__label">Tagihan Belum Lunas</span>
            <span class="stat-card__value"><?= number_format($stats['tagihan_unpaid'] ?? 0) ?></span>
            <span class="stat-card__trend trend--warn">
                Rp <?= number_format($stats['piutang'] ?? 0, 0, ',', '.') ?> piutang
            </span>
        </div>
    </div>

    <div class="stat-card stat-card--red dash-widget" data-id="stat-tiket">
        <div class="stat-card__icon"><i class="fa-solid fa-headset"></i></div>
        <div class="stat-card__body">
            <span class="stat-card__label">Tiket Terbuka</span>
            <span class="stat-card__value"><?= number_format($stats['tiket_open'] ?? 0) ?></span>
            <span class="stat-card__trend trend--danger">
                <?= $stats['tiket_proses'] ?? 0 ?> sedang ditangani
            </span>
        </div>
    </div>

    <div class="stat-card stat-card--purple dash-widget" data-id="stat-kas">
        <div class="stat-card__icon"><i class="fa-solid fa-money-bill-wave"></i></div>
        <div class="stat-card__body">
            <span class="stat-card__label">Kas Masuk (Bulan Ini)</span>
            <span class="stat-card__value">Rp <?= number_format($stats['kas_masuk'] ?? 0, 0, ',', '.') ?></span>
            <span class="stat-card__trend">
                Keluar: Rp <?= number_format($stats['kas_keluar'] ?? 0, 0, ',', '.') ?>
            </span>
        </div>
    </div>

    <div class="stat-card stat-card--teal dash-widget" data-id="stat-odp">
        <div class="stat-card__icon"><i class="fa-solid fa-tower-broadcast"></i></div>
        <div class="stat-card__body">
            <span class="stat-card__label">Total ODP Aktif</span>
            <span class="stat-card__value"><?= number_format($stats['odp_aktif'] ?? 0) ?></span>
            <span class="stat-card__trend">
                <?= $stats['odp_total'] ?? 0 ?> ODP terdaftar
            </span>
        </div>
    </div>
</div><!-- /.stats-grid -->


<!-- ===== CHARTS ROW ===== -->
<div class="dashboard-row dash-section" id="section-charts" data-label="Grafik">
    <div class="card chart-card chart-card--wide dash-widget" data-id="chart-pendapatan">
        <div class="card-header">
            <div>
                <h2 class="card-title">Pendapatan Bulanan</h2>
                <p class="card-subtitle">12 bulan terakhir</p>
            </div>
            <div class="chart-legend">
                <span class="legend-dot legend-dot--paid"></span> Lunas
                <span class="legend-dot legend-dot--unpaid"></span> Belum Lunas
            </div>
        </div>
        <div class="card-body">
            <canvas id="chartPendapatan" height="90"></canvas>
        </div>
    </div>

    <div class="card chart-card dash-widget" data-id="chart-paket">
        <div class="card-header">
            <div>
                <h2 class="card-title">Distribusi Paket</h2>
                <p class="card-subtitle">Berdasarkan pelanggan aktif</p>
            </div>
        </div>
        <div class="card-body chart-donut-wrap">
            <canvas id="chartPaket" height="180"></canvas>
            <div class="donut-legend" id="donutLegend"></div>
        </div>
    </div>
</div>


<!-- ===== TABLES ROW ===== -->
<div class="dashboard-row dash-section" id="section-tables" data-label="Tabel">
    <div class="card table-card table-card--wide dash-widget" data-id="tabel-tagihan">
        <div class="card-header">
            <div>
                <h2 class="card-title">Tagihan Terbaru</h2>
                <p class="card-subtitle">10 tagihan terakhir masuk</p>
            </div>
            <a href="/tagihan" class="btn btn--ghost btn--sm">Lihat Semua</a>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Pelanggan</th>
                            <th>Paket</th>
                            <th>Total</th>
                            <th>Jatuh Tempo</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($recentTagihan)): ?>
                            <?php foreach ($recentTagihan as $i => $t): ?>
                            <tr>
                                <td class="text-muted"><?= $i + 1 ?></td>
                                <td>
                                    <div class="cell-user">
                                        <span class="avatar-xs"><?= strtoupper(substr($t['nama_lengkap'], 0, 1)) ?></span>
                                        <?= htmlspecialchars($t['nama_lengkap']) ?>
                                    </div>
                                </td>
                                <td><span class="tag"><?= htmlspecialchars($t['nama_paket']) ?></span></td>
                                <td class="font-mono">Rp <?= number_format($t['total'], 0, ',', '.') ?></td>
                                <td class="<?= strtotime($t['jatuh_tempo']) < time() && $t['status'] === 'unpaid' ? 'text-danger' : '' ?>">
                                    <?= date('d M Y', strtotime($t['jatuh_tempo'])) ?>
                                </td>
                                <td>
                                    <span class="badge badge--<?= $t['status'] === 'paid' ? 'success' : 'warning' ?>">
                                        <?= $t['status'] === 'paid' ? 'Lunas' : 'Belum Lunas' ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="/tagihan/<?= $t['id'] ?>" class="btn btn--ghost btn--xs">
                                        <i class="fa-solid fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="empty-row">
                                    <i class="fa-regular fa-folder-open"></i>
                                    <p>Belum ada tagihan</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="card table-card dash-widget" data-id="tabel-tiket">
        <div class="card-header">
            <div>
                <h2 class="card-title">Tiket Terbuka</h2>
                <p class="card-subtitle">Perlu tindak lanjut</p>
            </div>
            <a href="/ticketing" class="btn btn--ghost btn--sm">Semua Tiket</a>
        </div>
        <div class="card-body p-0">
            <div class="ticket-list">
                <?php if (!empty($ticketOpen)): ?>
                    <?php foreach (array_slice($ticketOpen, 0, 6) as $tk): ?>
                    <a href="/ticketing/<?= $tk['id'] ?>" class="ticket-item">
                        <span class="ticket-status ticket-status--<?= $tk['status'] ?>"></span>
                        <div class="ticket-body">
                            <p class="ticket-title"><?= htmlspecialchars($tk['judul']) ?></p>
                            <p class="ticket-meta"><?= htmlspecialchars($tk['nama_lengkap']) ?></p>
                        </div>
                        <span class="badge badge--<?= $tk['status'] === 'open' ? 'danger' : 'info' ?> badge--sm">
                            <?= $tk['status'] === 'open' ? 'Baru' : 'Proses' ?>
                        </span>
                    </a>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state-sm">
                        <i class="fa-solid fa-circle-check"></i>
                        <p>Semua tiket tertangani</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div><!-- /.dashboard-row -->



<!-- ===== BANDWIDTH ROW ===== -->
<div class="dashboard-row dash-section" id="section-bandwidth" data-label="Bandwidth">
    <div class="card chart-card dash-widget" style="grid-column:1/-1" data-id="chart-bandwidth">
        <div class="card-header">
            <div>
                <h2 class="card-title"><i class="fa-solid fa-wave-square" style="color:var(--clr-teal);margin-right:.4rem"></i>Bandwidth Real-Time</h2>
                <p class="card-subtitle">TX / RX per interface — diperbarui tiap 3 detik</p>
            </div>
            <div style="display:flex;align-items:center;gap:10px">
                <!-- Filter interface -->
                <select id="bwIfaceSelect" class="bw-select">
                    <option value="">Semua Interface</option>
                </select>
                <!-- Indikator live -->
                <span class="bw-live-dot" id="bwLiveDot"></span>
                <span style="font-size:.75rem;color:var(--txt-muted)" id="bwLastUpdate">—</span>
                <!-- Pause/Resume -->
                <button class="btn btn--ghost btn--sm" id="bwPauseBtn">
                    <i class="fa-solid fa-pause"></i>
                </button>
            </div>
        </div>
        <div class="card-body">
            <!-- Summary chips -->
            <div class="bw-summary" id="bwSummary"></div>
            <!-- Canvas -->
            <canvas id="chartBandwidth" height="80"></canvas>
            <!-- Error state -->
            <div class="bw-error" id="bwError" style="display:none">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <span id="bwErrorMsg">Tidak dapat terhubung ke MikroTik</span>
            </div>
        </div>
    </div>
</div><!-- /.bandwidth-row -->

<!-- ===== CHART DATA ===== -->
<script>
    window.DASHBOARD_DATA = <?= json_encode([
        'pendapatan' => $chartData['pendapatan'] ?? [],
        'labels'     => $chartData['labels'] ?? [],
        'unpaid'     => $chartData['unpaid'] ?? [],
        'paket'      => $topPaket ?? [],
    ], JSON_HEX_TAG) ?>;
</script>
