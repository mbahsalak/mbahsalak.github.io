<?php
/**
 * views/pages/Dashboard/index_pelanggan_pending.php
 * Dashboard yang dilihat PELANGGAN saat akunnya masih berstatus 'pending'
 * (baru mendaftar, belum disurvei/diaktifkan admin).
 *
 * Dipanggil oleh: DashboardController::renderPelanggan()
 * saat $statusInternet === 'pending'
 *
 * Variabel yang dikirim controller:
 *   $user       array   — data session user (username, role, pelanggan_id, dst)
 *   $pelanggan  array|null — data lengkap dari tabel pelanggan + join paket
 *   $flash      array|null
 */
$appUrl    = rtrim($_ENV['APP_URL'] ?? '', '/');
$pelanggan = $pelanggan ?? [];
$nama      = $pelanggan['nama_lengkap'] ?? ($user['nama_lengkap'] ?? $user['username'] ?? 'Pelanggan');
$username  = $user['username'] ?? '—';
$noTelp    = $pelanggan['no_telp'] ?? '—';
$alamat    = $pelanggan['alamat'] ?? '—';
$paketNama = $pelanggan['nama_paket'] ?? null;
$kecepatan = $pelanggan['kecepatan'] ?? null;
$harga     = $pelanggan['harga'] ?? null;
$tglDaftar = !empty($pelanggan['created_at']) ? date('d M Y', strtotime($pelanggan['created_at'])) : null;

// Estimasi: hari ke berapa sejak daftar (untuk progress bar visual)
$hariBerlalu = $tglDaftar ? (int) floor((time() - strtotime($pelanggan['created_at'])) / 86400) : 0;
$progressPct = min(100, max(8, $hariBerlalu === 0 ? 15 : ($hariBerlalu >= 2 ? 90 : 50)));
?>

<div class="max-w-3xl mx-auto px-4 py-8 sm:py-12">

    <!-- ── FLASH ── -->
    <?php if (!empty($flash) && !empty($flash['message'])):
        $flashType  = $flash['type'] ?? 'info';
        $flashStyle = match($flashType) {
            'success' => 'bg-emerald-50 border-emerald-200 text-emerald-700 dark:bg-emerald-900/20 dark:border-emerald-800 dark:text-emerald-300',
            'danger'  => 'bg-red-50 border-red-200 text-red-700 dark:bg-red-900/20 dark:border-red-800 dark:text-red-300',
            default   => 'bg-blue-50 border-blue-200 text-blue-700 dark:bg-blue-900/20 dark:border-blue-800 dark:text-blue-300',
        };
    ?>
    <div class="border rounded-xl px-4 py-3 text-sm mb-5 <?= $flashStyle ?>">
        <?= $flash['message'] ?>
    </div>
    <?php endif; ?>

    <!-- ── HERO CARD ── -->
    <div class="bg-white dark:bg-gray-800 rounded-3xl shadow-lg border border-gray-100 dark:border-gray-700 overflow-hidden">

        <!-- Header amber -->
        <div class="bg-gradient-to-br from-amber-400 via-amber-500 to-orange-500 px-6 sm:px-10 py-10 text-center relative overflow-hidden">
            <!-- Decorative pulse rings -->
            <div class="absolute inset-0 flex items-center justify-center opacity-20">
                <div class="w-40 h-40 rounded-full border-4 border-white animate-ping"></div>
            </div>
            <div class="relative">
                <div class="w-20 h-20 bg-white/20 backdrop-blur rounded-full flex items-center justify-center mx-auto mb-4 ring-4 ring-white/30">
                    <i class="fa-solid fa-clock text-white text-4xl"></i>
                </div>
                <h1 class="text-2xl sm:text-3xl font-extrabold text-white mb-1.5">
                    Halo, <?= htmlspecialchars($nama) ?> 👋
                </h1>
                <p class="text-amber-50 text-sm sm:text-base font-medium">
                    Akun Anda sedang menunggu aktivasi
                </p>
            </div>
        </div>

        <div class="p-6 sm:p-10 space-y-6">

            <!-- Status badge besar -->
            <div class="flex items-center justify-center">
                <span class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-bold
                             bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400">
                    <span class="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
                    STATUS: PENDING
                </span>
            </div>

            <!-- Penjelasan -->
            <div class="text-center max-w-md mx-auto">
                <p class="text-gray-600 dark:text-gray-300 text-sm leading-relaxed">
                    Terima kasih telah mendaftar! Tim kami akan melakukan <strong>survei lokasi</strong>
                    dan memasang layanan internet Anda. Proses ini biasanya memakan waktu
                    <strong class="text-amber-600 dark:text-amber-400">1–2 hari kerja</strong>.
                </p>
            </div>

            <!-- Progress bar visual -->
            <div class="max-w-md mx-auto">
                <div class="flex justify-between text-xs font-medium text-gray-400 dark:text-gray-500 mb-1.5">
                    <span>Pendaftaran</span>
                    <span>Survei</span>
                    <span>Aktif</span>
                </div>
                <div class="h-2.5 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div class="h-full bg-gradient-to-r from-amber-400 to-orange-500 rounded-full transition-all duration-700"
                         style="width: <?= $progressPct ?>%"></div>
                </div>
                <?php if ($tglDaftar): ?>
                <p class="text-center text-xs text-gray-400 dark:text-gray-500 mt-2">
                    Mendaftar pada <?= $tglDaftar ?>
                    <?= $hariBerlalu > 0 ? "({$hariBerlalu} hari yang lalu)" : '(hari ini)' ?>
                </p>
                <?php endif; ?>
            </div>

            <!-- Ringkasan data pendaftaran -->
            <div class="bg-gray-50 dark:bg-gray-700/30 rounded-2xl divide-y divide-gray-200 dark:divide-gray-700 text-sm">
                <div class="px-4 sm:px-5 py-3 flex justify-between items-center">
                    <span class="text-gray-500 dark:text-gray-400 flex items-center gap-2">
                        <i class="fa-solid fa-user text-gray-300 dark:text-gray-600 w-4 text-center"></i> Nama Lengkap
                    </span>
                    <span class="font-semibold text-gray-900 dark:text-white"><?= htmlspecialchars($nama) ?></span>
                </div>
                <div class="px-4 sm:px-5 py-3 flex justify-between items-center">
                    <span class="text-gray-500 dark:text-gray-400 flex items-center gap-2">
                        <i class="fa-solid fa-at text-gray-300 dark:text-gray-600 w-4 text-center"></i> Username
                    </span>
                    <span class="font-mono font-semibold text-indigo-600 dark:text-indigo-400"><?= htmlspecialchars($username) ?></span>
                </div>
                <div class="px-4 sm:px-5 py-3 flex justify-between items-center">
                    <span class="text-gray-500 dark:text-gray-400 flex items-center gap-2">
                        <i class="fa-brands fa-whatsapp text-gray-300 dark:text-gray-600 w-4 text-center"></i> WhatsApp
                    </span>
                    <span class="font-semibold text-gray-900 dark:text-white"><?= htmlspecialchars($noTelp) ?></span>
                </div>
                <div class="px-4 sm:px-5 py-3 flex justify-between items-start gap-3">
                    <span class="text-gray-500 dark:text-gray-400 flex items-center gap-2 shrink-0">
                        <i class="fa-solid fa-location-dot text-gray-300 dark:text-gray-600 w-4 text-center"></i> Alamat
                    </span>
                    <span class="font-semibold text-gray-900 dark:text-white text-right"><?= htmlspecialchars($alamat) ?></span>
                </div>
                <?php if ($paketNama): ?>
                <div class="px-4 sm:px-5 py-3 flex justify-between items-center">
                    <span class="text-gray-500 dark:text-gray-400 flex items-center gap-2">
                        <i class="fa-solid fa-wifi text-gray-300 dark:text-gray-600 w-4 text-center"></i> Paket Dipilih
                    </span>
                    <span class="text-right">
                        <span class="font-semibold text-indigo-700 dark:text-indigo-400"><?= htmlspecialchars($paketNama) ?></span>
                        <?php if ($kecepatan): ?>
                        <span class="text-xs text-gray-400 dark:text-gray-500 block"><?= htmlspecialchars($kecepatan) ?></span>
                        <?php endif; ?>
                        <?php if ($harga): ?>
                        <span class="text-xs text-teal-600 dark:text-teal-400 block font-semibold">
                            Rp <?= number_format((float)$harga, 0, ',', '.') ?>/bln
                        </span>
                        <?php endif; ?>
                    </span>
                </div>
                <?php endif; ?>
            </div>

            <!-- Apa yang akan terjadi -->
            <div class="bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-800 rounded-2xl p-5">
                <p class="font-semibold text-indigo-800 dark:text-indigo-300 text-sm mb-3 flex items-center gap-2">
                    <i class="fa-solid fa-list-check"></i> Apa selanjutnya?
                </p>
                <ol class="space-y-2.5 text-sm text-indigo-700 dark:text-indigo-300/90">
                    <li class="flex items-start gap-2.5">
                        <span class="shrink-0 w-5 h-5 rounded-full bg-indigo-200 dark:bg-indigo-800 text-indigo-700 dark:text-indigo-300 text-[11px] font-bold flex items-center justify-center mt-0.5">1</span>
                        <span>Tim teknisi kami akan menghubungi Anda via WhatsApp untuk konfirmasi jadwal survei.</span>
                    </li>
                    <li class="flex items-start gap-2.5">
                        <span class="shrink-0 w-5 h-5 rounded-full bg-indigo-200 dark:bg-indigo-800 text-indigo-700 dark:text-indigo-300 text-[11px] font-bold flex items-center justify-center mt-0.5">2</span>
                        <span>Survei lokasi dan pemasangan perangkat dilakukan oleh teknisi kami.</span>
                    </li>
                    <li class="flex items-start gap-2.5">
                        <span class="shrink-0 w-5 h-5 rounded-full bg-indigo-200 dark:bg-indigo-800 text-indigo-700 dark:text-indigo-300 text-[11px] font-bold flex items-center justify-center mt-0.5">3</span>
                        <span>Setelah aktif, Anda bisa login kembali untuk melihat tagihan dan status koneksi.</span>
                    </li>
                </ol>
            </div>

            <!-- Tombol aksi -->
            <div class="flex flex-col sm:flex-row gap-3 pt-2">
                <a href="https://wa.me/" target="_blank"
                   class="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl
                          bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-sm
                          no-underline transition-colors shadow-sm shadow-emerald-500/30">
                    <i class="fa-brands fa-whatsapp text-base"></i> Hubungi Kami
                </a>
                <button onclick="location.reload()"
                        class="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl
                               border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-300
                               hover:bg-gray-50 dark:hover:bg-gray-700 font-semibold text-sm
                               bg-white dark:bg-transparent cursor-pointer transition-colors">
                    <i class="fa-solid fa-rotate-right text-sm"></i> Cek Status Terbaru
                </button>
            </div>

        </div>
    </div>

    <p class="text-center text-xs text-gray-400 dark:text-gray-500 mt-6">
        Halaman ini akan otomatis berubah menjadi dashboard penuh setelah akun Anda diaktifkan.
    </p>

</div>

<script>
/* Auto-refresh halaman setiap 2 menit untuk cek status terbaru
   (tanpa mengganggu — silent reload) */
setTimeout(() => {
    window.location.reload();
}, 120000);
</script>
