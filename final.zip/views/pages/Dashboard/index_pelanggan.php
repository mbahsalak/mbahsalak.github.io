<?php
/**
 * views/pages/Dashboard/index_pelanggan.php
 * Dashboard PELANGGAN
 * ✅ Card: Usage Hari Ini + Bulan Ini + Uptime + Online/Offline
 * ✅ Tabel: Tagihan, Riwayat Pembayaran, Pengaduan Saya
 */

$appUrl    = rtrim($_ENV['APP_URL'] ?? '', '/');
$user      = $user ?? [];
$pelanggan = $pelanggan ?? [];
$paket     = $paket ?? [];

// Usage data
$usageToday = $usageToday ?? ['rx_bytes' => 0, 'tx_bytes' => 0];
$usageMonth = $usageMonth ?? ['rx_bytes' => 0, 'tx_bytes' => 0];

// Uptime & status
$uptime     = $uptime ?? 0;
$isOnline   = $isOnline ?? false;
$lastSeen   = $lastSeen ?? null;
$ipAddress  = $ipAddress ?? '-';

// Data tables
$tagihan     = $tagihan ?? [];
$riwayat     = $riwayat ?? [];
$pengaduan   = $pengaduan ?? [];

// Helpers
function formatBytes(int $bytes, int $precision = 2): string {
    if ($bytes <= 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $pow = floor(log($bytes, 1024));
    $pow = min($pow, count($units) - 1);
    return round($bytes / (1024 ** $pow), $precision) . ' ' . $units[$pow];
}

function formatUptimeHuman(int $seconds): string {
    if ($seconds <= 0) return '0m';
    $d = intdiv($seconds, 86400);
    $h = intdiv($seconds % 86400, 3600);
    $m = intdiv($seconds % 3600, 60);
    $parts = [];
    if ($d > 0) $parts[] = "{$d}h";
    if ($h > 0) $parts[] = "{$h}j";
    if ($m > 0) $parts[] = "{$m}m";
    return implode(' ', $parts) ?: '0m';
}

function formatRupiah(float $amount): string {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

// Usage percentages (for visual bar)
$paketSpeed = $paket['kecepatan'] ?? '10 Mbps';
$speedNum   = (int)filter_var($paketSpeed, FILTER_SANITIZE_NUMBER_INT) ?: 10;
?>

<div class="max-w-[1320px] mx-auto space-y-6">

    <!-- ===================== PAGE HEADER ===================== -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 class="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                    <i class="fa-solid fa-house-user text-primary"></i>
                    Dashboard Saya
                </h1>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Selamat datang, <strong class="text-primary"><?= htmlspecialchars($pelanggan['nama_lengkap'] ?? $user['username'] ?? 'Pelanggan') ?></strong>
                    — pantau layanan internet Anda.
                </p>
            </div>
            <div class="flex items-center gap-3">
                <!-- Status Badge -->
                <?php if ($isOnline): ?>
                <span class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 text-xs font-semibold">
                    <span class="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                    Online
                </span>
                <?php else: ?>
                <span class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 text-xs font-semibold">
                    <span class="w-2 h-2 rounded-full bg-red-500"></span>
                    Offline
                </span>
                <?php endif; ?>
                <span class="text-xs text-gray-500 dark:text-gray-400 font-mono hidden sm:inline" id="liveClock"></span>
                <a href="<?= $appUrl ?>/ticketing/buat"
                   class="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-indigo-600 transition-colors shadow-sm">
                    <i class="fa-solid fa-headset"></i>
                    <span class="hidden sm:inline">Buat Pengaduan</span>
                </a>
            </div>
        </div>
    </div>

    <!-- ===================== MAIN CARD: Usage + Uptime + Status ===================== -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">

        <!-- ===== KIRI: Status Koneksi (1 col) ===== -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
            <div class="p-5">
                <h2 class="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-4">
                    <i class="fa-solid fa-signal text-primary"></i>
                    Status Koneksi
                </h2>

                <!-- Online/Offline Big Indicator -->
                <div class="text-center mb-5">
                    <div class="inline-flex items-center justify-center w-20 h-20 rounded-full <?= $isOnline ? 'bg-green-100 dark:bg-green-900/30' : 'bg-red-100 dark:bg-red-900/30' ?> mb-3">
                        <i class="fa-solid fa-<?= $isOnline ? 'wifi' : 'wifi' ?> text-3xl <?= $isOnline ? 'text-green-600 dark:text-green-400' : 'text-red-400 dark:text-red-500' ?>"></i>
                    </div>
                    <p class="text-lg font-bold <?= $isOnline ? 'text-green-600 dark:text-green-400' : 'text-red-500 dark:text-red-400' ?>">
                        <?= $isOnline ? 'Terhubung' : 'Tidak Terhubung' ?>
                    </p>
                    <?php if (!$isOnline && $lastSeen): ?>
                    <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        Terakhir online: <?= date('d M Y, H:i', strtotime($lastSeen)) ?>
                    </p>
                    <?php endif; ?>
                </div>

                <!-- Detail Info -->
                <div class="space-y-3">
                    <div class="flex items-center justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                        <span class="text-xs text-gray-500 dark:text-gray-400 flex items-center gap-2">
                            <i class="fa-solid fa-clock w-3.5"></i> Uptime
                        </span>
                        <span class="text-sm font-bold text-gray-900 dark:text-white">
                            <?= formatUptimeHuman($uptime) ?>
                        </span>
                    </div>
                    <div class="flex items-center justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                        <span class="text-xs text-gray-500 dark:text-gray-400 flex items-center gap-2">
                            <i class="fa-solid fa-network-wired w-3.5"></i> IP Address
                        </span>
                        <span class="text-sm font-mono font-semibold text-gray-900 dark:text-white">
                            <?= htmlspecialchars($ipAddress) ?>
                        </span>
                    </div>
                    <div class="flex items-center justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                        <span class="text-xs text-gray-500 dark:text-gray-400 flex items-center gap-2">
                            <i class="fa-solid fa-wifi w-3.5"></i> Paket
                        </span>
                        <span class="text-sm font-semibold text-primary">
                            <?= htmlspecialchars($paket['nama_paket'] ?? '-') ?>
                        </span>
                    </div>
                    <div class="flex items-center justify-between py-2">
                        <span class="text-xs text-gray-500 dark:text-gray-400 flex items-center gap-2">
                            <i class="fa-solid fa-gauge-high w-3.5"></i> Kecepatan
                        </span>
                        <span class="text-sm font-bold text-gray-900 dark:text-white">
                            <?= htmlspecialchars($paketSpeed) ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===== KANAN: Penggunaan (2 col) ===== -->
        <div class="lg:col-span-2 bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
            <div class="p-5">
                <h2 class="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-5">
                    <i class="fa-solid fa-chart-line text-primary"></i>
                    Penggunaan Bandwidth
                </h2>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">

                    <!-- ===== Hari Ini ===== -->
                    <div class="rounded-xl border border-gray-200 dark:border-gray-700 p-5 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/10 dark:to-indigo-900/10">
                        <div class="flex items-center justify-between mb-4">
                            <div class="flex items-center gap-2">
                                <div class="w-9 h-9 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                                    <i class="fa-solid fa-calendar-day text-blue-600 dark:text-blue-400 text-sm"></i>
                                </div>
                                <div>
                                    <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Hari Ini</p>
                                    <p class="text-[10px] text-gray-400 dark:text-gray-500"><?= date('d M Y') ?></p>
                                </div>
                            </div>
                        </div>

                        <!-- Download -->
                        <div class="mb-4">
                            <div class="flex items-center justify-between mb-1.5">
                                <span class="text-xs font-medium text-gray-600 dark:text-gray-400 flex items-center gap-1.5">
                                    <i class="fa-solid fa-arrow-down text-green-500 text-[10px]"></i> Download
                                </span>
                                <span class="text-sm font-bold text-gray-900 dark:text-white">
                                    <?= formatBytes((int)($usageToday['rx_bytes'] ?? 0)) ?>
                                </span>
                            </div>
                            <div class="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                                <div class="h-full bg-gradient-to-r from-green-400 to-green-600 rounded-full transition-all duration-500"
                                     style="width: <?= min(100, ((int)($usageToday['rx_bytes'] ?? 0) / max(1, (int)($usageToday['rx_bytes'] ?? 0) + (int)($usageToday['tx_bytes'] ?? 0))) * 100) ?>%"></div>
                            </div>
                        </div>

                        <!-- Upload -->
                        <div class="mb-3">
                            <div class="flex items-center justify-between mb-1.5">
                                <span class="text-xs font-medium text-gray-600 dark:text-gray-400 flex items-center gap-1.5">
                                    <i class="fa-solid fa-arrow-up text-blue-500 text-[10px]"></i> Upload
                                </span>
                                <span class="text-sm font-bold text-gray-900 dark:text-white">
                                    <?= formatBytes((int)($usageToday['tx_bytes'] ?? 0)) ?>
                                </span>
                            </div>
                            <div class="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                                <div class="h-full bg-gradient-to-r from-blue-400 to-blue-600 rounded-full transition-all duration-500"
                                     style="width: <?= min(100, ((int)($usageToday['tx_bytes'] ?? 0) / max(1, (int)($usageToday['rx_bytes'] ?? 0) + (int)($usageToday['tx_bytes'] ?? 0))) * 100) ?>%"></div>
                            </div>
                        </div>

                        <!-- Total -->
                        <div class="pt-3 border-t border-gray-200 dark:border-gray-600 flex items-center justify-between">
                            <span class="text-xs font-semibold text-gray-500 dark:text-gray-400">Total</span>
                            <span class="text-base font-bold text-blue-600 dark:text-blue-400">
                                <?= formatBytes((int)($usageToday['rx_bytes'] ?? 0) + (int)($usageToday['tx_bytes'] ?? 0)) ?>
                            </span>
                        </div>
                    </div>

                    <!-- ===== Bulan Ini ===== -->
                    <div class="rounded-xl border border-gray-200 dark:border-gray-700 p-5 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/10 dark:to-pink-900/10">
                        <div class="flex items-center justify-between mb-4">
                            <div class="flex items-center gap-2">
                                <div class="w-9 h-9 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                                    <i class="fa-solid fa-calendar-days text-purple-600 dark:text-purple-400 text-sm"></i>
                                </div>
                                <div>
                                    <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Bulan Ini</p>
                                    <p class="text-[10px] text-gray-400 dark:text-gray-500"><?= date('F Y') ?></p>
                                </div>
                            </div>
                        </div>

                        <!-- Download -->
                        <div class="mb-4">
                            <div class="flex items-center justify-between mb-1.5">
                                <span class="text-xs font-medium text-gray-600 dark:text-gray-400 flex items-center gap-1.5">
                                    <i class="fa-solid fa-arrow-down text-green-500 text-[10px]"></i> Download
                                </span>
                                <span class="text-sm font-bold text-gray-900 dark:text-white">
                                    <?= formatBytes((int)($usageMonth['rx_bytes'] ?? 0)) ?>
                                </span>
                            </div>
                            <div class="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                                <div class="h-full bg-gradient-to-r from-green-400 to-emerald-600 rounded-full transition-all duration-500"
                                     style="width: <?= min(100, ((int)($usageMonth['rx_bytes'] ?? 0) / max(1, (int)($usageMonth['rx_bytes'] ?? 0) + (int)($usageMonth['tx_bytes'] ?? 0))) * 100) ?>%"></div>
                            </div>
                        </div>

                        <!-- Upload -->
                        <div class="mb-3">
                            <div class="flex items-center justify-between mb-1.5">
                                <span class="text-xs font-medium text-gray-600 dark:text-gray-400 flex items-center gap-1.5">
                                    <i class="fa-solid fa-arrow-up text-purple-500 text-[10px]"></i> Upload
                                </span>
                                <span class="text-sm font-bold text-gray-900 dark:text-white">
                                    <?= formatBytes((int)($usageMonth['tx_bytes'] ?? 0)) ?>
                                </span>
                            </div>
                            <div class="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                                <div class="h-full bg-gradient-to-r from-purple-400 to-purple-600 rounded-full transition-all duration-500"
                                     style="width: <?= min(100, ((int)($usageMonth['tx_bytes'] ?? 0) / max(1, (int)($usageMonth['rx_bytes'] ?? 0) + (int)($usageMonth['tx_bytes'] ?? 0))) * 100) ?>%"></div>
                            </div>
                        </div>

                        <!-- Total -->
                        <div class="pt-3 border-t border-gray-200 dark:border-gray-600 flex items-center justify-between">
                            <span class="text-xs font-semibold text-gray-500 dark:text-gray-400">Total</span>
                            <span class="text-base font-bold text-purple-600 dark:text-purple-400">
                                <?= formatBytes((int)($usageMonth['rx_bytes'] ?? 0) + (int)($usageMonth['tx_bytes'] ?? 0)) ?>
                            </span>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <!-- ===================== INFO PELANGGAN (compact) ===================== -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div class="px-5 py-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-indigo-50 to-white dark:from-indigo-900/10 dark:to-gray-800">
            <h2 class="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <i class="fa-solid fa-id-card text-primary"></i>
                Informasi Akun
            </h2>
        </div>
        <div class="p-5">
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
                <div>
                    <p class="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wide mb-1">Nama</p>
                    <p class="text-sm font-semibold text-gray-900 dark:text-white truncate"><?= htmlspecialchars($pelanggan['nama_lengkap'] ?? '-') ?></p>
                </div>
                <div>
                    <p class="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wide mb-1">Username</p>
                    <p class="text-sm font-mono font-semibold text-gray-900 dark:text-white"><?= htmlspecialchars($user['username'] ?? '-') ?></p>
                </div>
                <div>
                    <p class="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wide mb-1">No. Telepon</p>
                    <p class="text-sm font-semibold text-gray-900 dark:text-white"><?= htmlspecialchars($pelanggan['no_telp'] ?? '-') ?></p>
                </div>
                <div>
                    <p class="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wide mb-1">Paket</p>
                    <p class="text-sm font-semibold text-primary"><?= htmlspecialchars($paket['nama_paket'] ?? '-') ?></p>
                </div>
                <div>
                    <p class="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wide mb-1">Jatuh Tempo</p>
                    <p class="text-sm font-semibold text-gray-900 dark:text-white">Tgl <?= (int)($pelanggan['tgl_jatuh_tempo'] ?? 5) ?></p>
                </div>
                <div>
                    <p class="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wide mb-1">Biaya Bulanan</p>
                    <p class="text-sm font-bold text-gray-900 dark:text-white"><?= formatRupiah((float)($paket['harga'] ?? 0)) ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- ===================== TABEL TAGIHAN BELUM BAYAR ===================== -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div class="px-5 py-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-red-50 to-white dark:from-red-900/10 dark:to-gray-800">
            <div class="flex items-center justify-between">
                <h2 class="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                    <i class="fa-solid fa-file-invoice-dollar text-red-500"></i>
                    Tagihan Belum Dibayar
                    <?php if (count($tagihan) > 0): ?>
                    <span class="ml-1 px-2 py-0.5 rounded-full bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 text-[10px] font-bold">
                        <?= count($tagihan) ?>
                    </span>
                    <?php endif; ?>
                </h2>
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
                    <tr>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider w-10">#</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Periode</th>
                        <th class="px-5 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Jatuh Tempo</th>
                        <th class="px-5 py-3 text-right text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Jumlah</th>
                        <th class="px-5 py-3 text-center text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                        <th class="px-5 py-3 text-right text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider w-28">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                    <?php if (!empty($tagihan)): ?>
                        <?php foreach ($tagihan as $i => $t): ?>
                        <?php
                        $isOverdue = false;
                        if (!empty($t['jatuh_tempo'])) {
                            $isOverdue = strtotime($t['jatuh_tempo']) < time();
                        }
                        ?>
                        <tr class="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                            <td class="px-5 py-3 text-gray-400"><?= $i + 1 ?></td>
                            <td class="px-5 py-3 font-medium text-gray-900 dark:text-white">
                                <?= htmlspecialchars($t['periode'] ?? '-') ?>
                            </td>
                            <td class="px-5 py-3 text-gray-500 dark:text-gray-400">
                                <?php if (!empty($t['jatuh_tempo'])): ?>
                                    <span class="<?= $isOverdue ? 'text-red-600 dark:text-red-400 font-semibold' : '' ?>">
                                        <?= date('d M Y', strtotime($t['jatuh_tempo'])) ?>
                                        <?php if ($isOverdue): ?>
                                        <span class="ml-1 text-[10px] font-bold text-red-500">TERLAMBAT</span>
                                        <?php endif; ?>
                                    </span>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td class="px-5 py-3 text-right font-bold text-gray-900 dark:text-white">
                                <?= formatRupiah((float)($t['total'] ?? $t['jumlah'] ?? 0)) ?>
                            </td>
                            <td class="px-5 py-3 text-center">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide
                                    <?= $isOverdue ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' : 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' ?>">
                                    <?= $isOverdue ? 'Terlambat' : 'Belum Bayar' ?>
                                </span>
                            </td>
                            <td class="px-5 py-3 text-right">
                                <button onclick="alert('Hubungi admin untuk pembayaran')"
                                        class="inline-flex items-center gap-1 px-3 py-1.5 rounded-md bg-primary hover:bg-indigo-600 text-white text-xs font-medium transition-colors">
                                    <i class="fa-solid fa-credit-card"></i> Bayar
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="px-5 py-10 text-center">
                                <i class="fa-solid fa-circle-check text-3xl text-green-400 mb-3"></i>
                                <p class="text-sm font-medium text-gray-700 dark:text-gray-300">Tidak ada tagihan tertunggak</p>
                                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Semua tagihan Anda sudah lunas.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ===================== RIWAYAT PEMBAYARAN + PENGADUAN (2 kolom) ===================== -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">

        <!-- ===== RIWAYAT PEMBAYARAN ===== -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
            <div class="px-5 py-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-green-50 to-white dark:from-green-900/10 dark:to-gray-800">
                <h2 class="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                    <i class="fa-solid fa-receipt text-green-500"></i>
                    Riwayat Pembayaran
                </h2>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
                        <tr>
                            <th class="px-4 py-2.5 text-left text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Periode</th>
                            <th class="px-4 py-2.5 text-right text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Jumlah</th>
                            <th class="px-4 py-2.5 text-left text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Tgl Bayar</th>
                            <th class="px-4 py-2.5 text-center text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Metode</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                        <?php if (!empty($riwayat)): ?>
                            <?php foreach ($riwayat as $r): ?>
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                                <td class="px-4 py-3">
                                    <p class="font-medium text-gray-900 dark:text-white text-xs"><?= htmlspecialchars($r['periode'] ?? '-') ?></p>
                                    <?php if (!empty($r['deskripsi'])): ?>
                                    <p class="text-[10px] text-gray-400 mt-0.5"><?= htmlspecialchars($r['deskripsi']) ?></p>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3 text-right">
                                    <span class="text-xs font-bold text-gray-900 dark:text-white">
                                        <?= formatRupiah((float)($r['jumlah'] ?? 0)) ?>
                                    </span>
                                </td>
                                <td class="px-4 py-3 text-xs text-gray-500 dark:text-gray-400">
                                    <?= !empty($r['tgl_bayar']) ? date('d M Y, H:i', strtotime($r['tgl_bayar'])) : '-' ?>
                                </td>
                                <td class="px-4 py-3 text-center">
                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                                        <i class="fa-solid fa-circle-check mr-1"></i>
                                        <?= htmlspecialchars($r['metode'] ?? 'Tunai') ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="px-4 py-10 text-center">
                                    <i class="fa-solid fa-inbox text-2xl text-gray-300 dark:text-gray-600 mb-2"></i>
                                    <p class="text-xs text-gray-500 dark:text-gray-400">Belum ada riwayat pembayaran.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>


        <!-- ===== PENGADUAN SAYA ===== -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
            <div class="px-5 py-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-amber-50 to-white dark:from-amber-900/10 dark:to-gray-800">
                <div class="flex items-center justify-between">
                    <h2 class="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                        <i class="fa-solid fa-headset text-amber-500"></i>
                        Pengaduan Saya
                    </h2>
                    <a href="<?= $appUrl ?>/ticketing/buat"
                       class="text-xs font-medium text-primary hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center gap-1">
                        <i class="fa-solid fa-plus text-[10px]"></i> Baru
                    </a>
                </div>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
                        <tr>
                            <th class="px-4 py-2.5 text-left text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Judul</th>
                            <th class="px-4 py-2.5 text-center text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                            <th class="px-4 py-2.5 text-left text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Tanggal</th>
                       
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                        <?php if (!empty($pengaduan)): ?>
                            <?php foreach ($pengaduan as $pg): ?>
                            <?php
                            [$stBg, $stTxt, $stLabel] = match($pg['status'] ?? 'open') {
                                'open'    => ['bg-red-100 dark:bg-red-900/30', 'text-red-700 dark:text-red-400', 'Baru'],
                                'proses'  => ['bg-amber-100 dark:bg-amber-900/30', 'text-amber-700 dark:text-amber-400', 'Proses'],
                                'selesai' => ['bg-green-100 dark:bg-green-900/30', 'text-green-700 dark:text-green-400', 'Selesai'],
                                default   => ['bg-gray-100 dark:bg-gray-700', 'text-gray-700 dark:text-gray-300', ucfirst($pg['status'] ?? '-')],
                            };
                            ?>
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                                <td class="px-4 py-3">
                                    <p class="text-xs font-medium text-gray-900 dark:text-white truncate max-w-[180px]">
                                        <?= htmlspecialchars($pg['judul'] ?? '-') ?>
                                    </p>
                                    <?php if (!empty($pg['deskripsi'])): ?>
                                    <p class="text-[10px] text-gray-400 dark:text-gray-500 truncate max-w-[180px] mt-0.5">
                                        <?= htmlspecialchars($pg['deskripsi']) ?>
                                    </p>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3 text-center">
                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide <?= $stBg ?> <?= $stTxt ?>">
                                        <?= $stLabel ?>
                                    </span>
                                </td>
                                <td class="px-4 py-3 text-[10px] text-gray-500 dark:text-gray-400 whitespace-nowrap">
                                    <?= !empty($pg['created_at']) ? date('d M Y', strtotime($pg['created_at'])) : '-' ?>
                                </td>
                               
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="px-4 py-10 text-center">
                                    <i class="fa-solid fa-inbox text-2xl text-gray-300 dark:text-gray-600 mb-2"></i>
                                    <p class="text-xs text-gray-500 dark:text-gray-400">Belum ada pengaduan.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

</div>

<!-- ===================== LIVE CLOCK ===================== -->
<script>
(function() {
    const clock = document.getElementById('liveClock');
    if (!clock) return;
    function update() {
        const now = new Date();
        clock.textContent = now.toLocaleTimeString('id-ID', {hour:'2-digit', minute:'2-digit', second:'2-digit', hour12:false})
            + ' • ' + now.toLocaleDateString('id-ID', {weekday:'short', day:'numeric', month:'short'});
    }
    update();
    setInterval(update, 1000);

    // Auto-refresh status setiap 30 detik
    const pelangganId = '<?= $pelanggan['id'] ?? '' ?>';
    if (pelangganId) {
        setInterval(async () => {
            try {
                const res = await fetch('<?= $appUrl ?>/pelanggan/uptime/' + pelangganId);
                const data = await res.json();
                // Update bisa ditambahkan di sini jika diperlukan
            } catch(e) { /* silent */ }
        }, 30000);
    }
})();
</script>
