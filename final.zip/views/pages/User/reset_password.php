<?php
/**
 * views/pages/User/reset_password.php
 * Form Reset Password User (oleh Admin)
 * Variabel dari controller: $title, $user (array), $errors (array|null)
 */

$appUrl = $_ENV['APP_URL'] ?? '';
$errors = $errors ?? [];
?>

<!-- Breadcrumb -->
<div style="margin-bottom:1.5rem;">
    <nav style="font-size:.82rem;color:var(--text-muted,#6b7280);margin-bottom:.4rem;">
        <a href="<?= $appUrl ?>/users" style="color:var(--text-muted,#6b7280);text-decoration:none;">
            <i class="fa-solid fa-users" style="margin-right:.3rem;"></i>Manajemen User
        </a>
        <span style="margin:0 .4rem;">›</span>
        <a href="<?= $appUrl ?>/users/<?= $user['id'] ?>" style="color:var(--text-muted,#6b7280);text-decoration:none;">
            <?= htmlspecialchars($user['username']) ?>
        </a>
        <span style="margin:0 .4rem;">›</span>
        <span>Reset Password</span>
    </nav>
    <h1 class="page-title">
        <i class="fa-solid fa-key" style="color:#f59e0b;margin-right:.5rem;"></i>
        <?= htmlspecialchars($title) ?>
    </h1>
</div>

<?php if (!empty($errors)): ?>
    <div class="flash flash--danger" role="alert" style="margin-bottom:1.25rem;">
        <i class="fa-solid fa-circle-xmark"></i>
        <div>
            <strong>Perbaiki kesalahan berikut:</strong>
            <ul style="margin:.3rem 0 0;padding-left:1.2rem;">
                <?php foreach ($errors as $err): ?>
                    <li><?= htmlspecialchars($err) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <button class="flash-close" onclick="this.parentElement.remove()">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>
<?php endif; ?>

<div style="max-width:480px;margin:0 auto;display:flex;flex-direction:column;gap:1rem;">

    <!-- Info User -->
    <div style="display:flex;align-items:center;gap:.85rem;padding:1rem 1.25rem;border-radius:12px;background:#fffbeb;border:1.5px solid #fde68a;">
        <div style="width:42px;height:42px;border-radius:50%;background:#f59e0b;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:1.1rem;flex-shrink:0;">
            <?= strtoupper(substr($user['username'], 0, 1)) ?>
        </div>
        <div>
            <div style="font-weight:600;color:#92400e;display:flex;align-items:center;gap:.5rem;">
                <?= htmlspecialchars($user['username']) ?>
                <span style="padding:.15rem .5rem;border-radius:99px;font-size:.72rem;font-weight:600;background:#fef3c7;color:#b45309;border:1px solid #fde68a;">
                    <?= ucfirst($user['role']) ?>
                </span>
            </div>
            <div style="font-size:.8rem;color:#b45309;margin-top:.15rem;">
                <i class="fa-solid fa-triangle-exclamation" style="margin-right:.3rem;"></i>
                Password lama akan langsung diganti setelah disimpan.
            </div>
        </div>
    </div>

    <!-- Form Card -->
    <div class="card" style="border-radius:12px;overflow:hidden;">
        <div style="height:4px;background:#f59e0b;"></div>
        <div style="padding:1.75rem;">
            <form method="POST"
                  action="<?= $appUrl ?>/users/reset-password/<?= $user['id'] ?>"
                  autocomplete="off">
                <?= $this->csrfField() ?>

                <!-- Password Baru -->
                <div style="margin-bottom:1.1rem;">
                    <label for="password" style="display:block;font-weight:600;font-size:.875rem;margin-bottom:.4rem;">
                        Password Baru <span style="color:#ef4444;">*</span>
                    </label>
                    <div style="display:flex;gap:0;">
                        <input type="password" id="password" name="password"
                               placeholder="min. 8 karakter"
                               minlength="8" required autofocus
                               style="flex:1;padding:.55rem .85rem;border:1.5px solid var(--border,#e5e7eb);border-right:none;border-radius:8px 0 0 8px;font-size:.875rem;outline:none;background:#fff;color:var(--text-primary,#111827);">
                        <button type="button" id="togglePass"
                                style="padding:.55rem .85rem;border:1.5px solid var(--border,#e5e7eb);border-radius:0 8px 8px 0;background:#f9fafb;cursor:pointer;color:var(--text-muted,#6b7280);font-size:.85rem;">
                            <i class="fa-solid fa-eye" id="togglePassIcon"></i>
                        </button>
                    </div>
                    <div style="font-size:.78rem;color:var(--text-muted,#6b7280);margin-top:.3rem;">
                        Minimal 8 karakter. Hindari password yang mudah ditebak.
                    </div>
                </div>

                <!-- Konfirmasi Password -->
                <div style="margin-bottom:1.5rem;">
                    <label for="confirm_password" style="display:block;font-weight:600;font-size:.875rem;margin-bottom:.4rem;">
                        Konfirmasi Password <span style="color:#ef4444;">*</span>
                    </label>
                    <input type="password" id="confirm_password" name="confirm_password"
                           placeholder="Ulangi password baru"
                           minlength="8" required
                           style="width:100%;padding:.55rem .85rem;border:1.5px solid var(--border,#e5e7eb);border-radius:8px;font-size:.875rem;outline:none;background:#fff;color:var(--text-primary,#111827);box-sizing:border-box;">
                    <div id="matchFeedback" style="font-size:.78rem;margin-top:.3rem;"></div>
                </div>

                <!-- Tombol Aksi -->
                <div style="display:flex;gap:.6rem;">
                    <button type="submit"
                            onclick="return confirm('Yakin reset password user ini?')"
                            style="padding:.55rem 1.4rem;border-radius:8px;border:none;background:#f59e0b;color:#fff;font-weight:600;font-size:.875rem;cursor:pointer;display:inline-flex;align-items:center;gap:.4rem;">
                        <i class="fa-solid fa-key"></i> Reset Password
                    </button>
                    <a href="<?= $appUrl ?>/users/<?= $user['id'] ?>"
                       style="padding:.55rem 1.25rem;border-radius:8px;border:1.5px solid var(--border,#e5e7eb);color:var(--text-muted,#6b7280);text-decoration:none;font-weight:600;font-size:.875rem;display:inline-flex;align-items:center;">
                        Batal
                    </a>
                </div>

            </form>
        </div>
    </div>

</div>

<script>
// Toggle show/hide password
document.getElementById('togglePass').addEventListener('click', function () {
    const inp  = document.getElementById('password');
    const icon = document.getElementById('togglePassIcon');
    const show = inp.type === 'password';
    inp.type = show ? 'text' : 'password';
    icon.className = show ? 'fa-solid fa-eye-slash' : 'fa-solid fa-eye';
});

// Real-time match check
const passEl    = document.getElementById('password');
const confirmEl = document.getElementById('confirm_password');
const feedback  = document.getElementById('matchFeedback');

function checkMatch() {
    if (!confirmEl.value) { feedback.textContent = ''; return; }
    if (passEl.value === confirmEl.value) {
        feedback.textContent = '✓ Password cocok';
        feedback.style.color = '#16a34a';
    } else {
        feedback.textContent = '✗ Password tidak cocok';
        feedback.style.color = '#ef4444';
    }
}
passEl.addEventListener('input', checkMatch);
confirmEl.addEventListener('input', checkMatch);
</script>
