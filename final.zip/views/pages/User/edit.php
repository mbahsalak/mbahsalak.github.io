<?php
/**
 * views/pages/User/edit.php
 */
$appUrl = $_ENV['APP_URL'] ?? '';
$errors = $errors ?? [];
$u      = $user ?? [];
?>

<div style="max-width:520px;">

    <!-- Breadcrumb -->
    <div style="font-size:.8rem;color:var(--text-muted,#6b7280);margin-bottom:1rem;display:flex;align-items:center;gap:.4rem;">
        <a href="<?= $appUrl ?>/users" style="color:#6366f1;text-decoration:none;">Manajemen User</a>
        <i class="fa-solid fa-chevron-right" style="font-size:.65rem;"></i>
        <a href="<?= $appUrl ?>/users/<?= $u['id'] ?>" style="color:#6366f1;text-decoration:none;">
            <?= htmlspecialchars($u['username'] ?? '') ?>
        </a>
        <i class="fa-solid fa-chevron-right" style="font-size:.65rem;"></i>
        <span>Edit</span>
    </div>

    <h1 class="page-title" style="margin-bottom:1.25rem;">
        <i class="fa-solid fa-user-pen" style="color:#6366f1;margin-right:.5rem;"></i>
        <?= htmlspecialchars($title ?? 'Edit User') ?>
    </h1>

    <!-- Errors -->
    <?php if (!empty($errors)): ?>
        <div style="background:#fee2e2;border:1px solid #fca5a5;border-radius:10px;
                    padding:1rem 1.25rem;margin-bottom:1.25rem;">
            <div style="font-weight:600;color:#dc2626;margin-bottom:.4rem;">
                <i class="fa-solid fa-triangle-exclamation" style="margin-right:.4rem;"></i>
                Perbaiki kesalahan berikut:
            </div>
            <ul style="margin:0;padding-left:1.25rem;color:#dc2626;font-size:.875rem;">
                <?php foreach ($errors as $err): ?>
                    <li><?= htmlspecialchars($err) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Form Edit -->
    <div class="card" style="border-radius:12px;overflow:hidden;margin-bottom:1rem;">
        <div style="height:5px;background:#6366f1;"></div>
        <div style="padding:1.5rem;">
            <form method="POST" action="<?= $appUrl ?>/users/update/<?= $u['id'] ?>">
                <input type="hidden" name="csrf_token"
                       value="<?= htmlspecialchars(\Core\Middleware::generateCsrfToken()) ?>">

                <div style="display:flex;flex-direction:column;gap:1.1rem;">

                    <!-- Username -->
                    <div>
                        <label for="username"
                               style="font-weight:600;font-size:.875rem;display:block;margin-bottom:.4rem;">
                            Username <span style="color:#ef4444;">*</span>
                        </label>
                        <input type="text" id="username" name="username"
                               value="<?= htmlspecialchars($u['username'] ?? '') ?>"
                               minlength="4" maxlength="50" required autofocus
                               style="width:100%;padding:.6rem .85rem;border-radius:8px;
                                      border:1.5px solid var(--border,#e5e7eb);font-size:.875rem;
                                      background:var(--surface,#fff);box-sizing:border-box;">
                    </div>

                    <!-- Role -->
                    <div>
                        <label for="role"
                               style="font-weight:600;font-size:.875rem;display:block;margin-bottom:.4rem;">
                            Role <span style="color:#ef4444;">*</span>
                        </label>
                        <select id="role" name="role" required
                                style="width:100%;padding:.6rem .85rem;border-radius:8px;
                                       border:1.5px solid var(--border,#e5e7eb);font-size:.875rem;
                                       background:var(--surface,#fff);cursor:pointer;box-sizing:border-box;">
                            <?php
                            $roleOptions = [
                                'admin'     => 'Admin — Akses penuh',
                                'kasir'     => 'Kasir — Tagihan & Kas',
                                'teknisi'   => 'Teknisi — ODP & Peta',
                                'pelanggan' => 'Pelanggan — Portal mandiri',
                            ];
                            foreach ($roleOptions as $val => $label):
                            ?>
                                <option value="<?= $val ?>"
                                    <?= ($u['role'] ?? '') === $val ? 'selected' : '' ?>>
                                    <?= $label ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Status -->
                    <div>
                        <label style="font-weight:600;font-size:.875rem;display:block;margin-bottom:.6rem;">
                            Status Akun
                        </label>
                        <div style="display:flex;gap:1rem;">
                            <?php foreach (['active' => ['Aktif','#10b981','fa-circle-check'], 'inactive' => ['Nonaktif','#6b7280','fa-circle-xmark']] as $val => [$label, $color, $icon]): ?>
                            <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;
                                          padding:.5rem .9rem;border-radius:8px;font-size:.875rem;font-weight:600;
                                          border:1.5px solid <?= ($u['status'] ?? '') === $val ? $color : 'var(--border,#e5e7eb)' ?>;
                                          background:<?= ($u['status'] ?? '') === $val ? $color.'22' : 'transparent' ?>;
                                          color:<?= ($u['status'] ?? '') === $val ? $color : 'var(--text-muted,#6b7280)' ?>;"
                                   id="label_<?= $val ?>">
                                <input type="radio" name="status" value="<?= $val ?>"
                                       <?= ($u['status'] ?? '') === $val ? 'checked' : '' ?>
                                       onchange="updateStatusLabel()"
                                       style="display:none;">
                                <i class="fa-solid <?= $icon ?>"></i> <?= $label ?>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                </div>

                <div style="display:flex;gap:.75rem;margin-top:1.5rem;
                            padding-top:1.25rem;border-top:1px solid var(--border,#e5e7eb);">
                    <button type="submit"
                            style="padding:.6rem 1.5rem;border-radius:8px;border:none;cursor:pointer;
                                   font-weight:600;background:#6366f1;color:#fff;
                                   display:inline-flex;align-items:center;gap:.4rem;">
                        <i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan
                    </button>
                    <a href="<?= $appUrl ?>/users/<?= $u['id'] ?>"
                       style="padding:.6rem 1.25rem;border-radius:8px;text-decoration:none;
                              border:1.5px solid var(--border,#e5e7eb);font-weight:600;
                              color:var(--text-muted,#6b7280);display:inline-flex;align-items:center;gap:.4rem;">
                        <i class="fa-solid fa-xmark"></i> Batal
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Link Reset Password -->
    <div class="card" style="border-radius:12px;padding:1rem 1.25rem;
                              display:flex;justify-content:space-between;align-items:center;gap:1rem;">
        <div>
            <div style="font-weight:600;font-size:.875rem;">Ganti Password</div>
            <div style="font-size:.8rem;color:var(--text-muted,#6b7280);">
                Password tidak diubah di form ini
            </div>
        </div>
        <a href="<?= $appUrl ?>/users/reset-password/<?= $u['id'] ?>"
           style="padding:.5rem 1rem;border-radius:8px;text-decoration:none;font-weight:600;
                  font-size:.875rem;border:1.5px solid #f59e0b;color:#f59e0b;white-space:nowrap;
                  display:inline-flex;align-items:center;gap:.4rem;">
            <i class="fa-solid fa-key"></i> Reset Password
        </a>
    </div>

</div>

<script>
function updateStatusLabel() {
    const radios = document.querySelectorAll('input[name="status"]');
    const colors = { active: '#10b981', inactive: '#6b7280' };
    radios.forEach(r => {
        const lbl = document.getElementById('label_' + r.value);
        const c   = colors[r.value];
        if (r.checked) {
            lbl.style.borderColor  = c;
            lbl.style.background   = c + '22';
            lbl.style.color        = c;
        } else {
            lbl.style.borderColor  = 'var(--border,#e5e7eb)';
            lbl.style.background   = 'transparent';
            lbl.style.color        = 'var(--text-muted,#6b7280)';
        }
    });
}
</script>
