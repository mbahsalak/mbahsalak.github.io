<?php
/**
 * views/pages/User/show.php
 * Detail User — Admin only
 * Membedakan tampilan: pelanggan vs staff (admin/kasir/teknisi)
 */

$role        = $user['role'] ?? '';
$isPelanggan = $role === 'pelanggan';
$isActive    = ($user['status'] ?? '') === 'active';

$roleColor = match($role) {
    'admin'     => '#6366f1',
    'kasir'     => '#10b981',
    'teknisi'   => '#f59e0b',
    'pelanggan' => '#3b82f6',
    default     => '#6b7280',
};
$roleIcon = match($role) {
    'admin'     => 'fa-user-shield',
    'kasir'     => 'fa-cash-register',
    'teknisi'   => 'fa-screwdriver-wrench',
    'pelanggan' => 'fa-user',
    default     => 'fa-user',
};
$appUrl = $_ENV['APP_URL'] ?? '';
?>

<div style="max-width:900px;">

    <!-- Back -->
    <a href="<?= $appUrl ?>/users"
       style="display:inline-flex;align-items:center;gap:.4rem;color:var(--text-muted,#6b7280);
              font-size:.875rem;text-decoration:none;margin-bottom:1.25rem;">
        <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar User
    </a>

    <!-- Header Card -->
    <div class="card" style="border-radius:12px;margin-bottom:1.25rem;overflow:hidden;">
        <!-- Banner warna sesuai role -->
        <div style="height:6px;background:<?= $roleColor ?>;"></div>
        <div style="padding:1.5rem;display:flex;align-items:center;gap:1.25rem;flex-wrap:wrap;">

            <!-- Avatar -->
            <div style="width:64px;height:64px;border-radius:50%;background:<?= $roleColor ?>22;
                        display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                <i class="fa-solid <?= $roleIcon ?>" style="font-size:1.5rem;color:<?= $roleColor ?>;"></i>
            </div>

            <!-- Info utama -->
            <div style="flex:1;min-width:200px;">
                <div style="display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;">
                    <h2 style="margin:0;font-size:1.25rem;font-weight:700;">
                        <?= htmlspecialchars($user['username']) ?>
                    </h2>
                    <!-- Badge role -->
                    <span style="padding:.25rem .75rem;border-radius:99px;font-size:.75rem;
                                 font-weight:600;background:<?= $roleColor ?>22;color:<?= $roleColor ?>;">
                        <i class="fa-solid <?= $roleIcon ?>" style="margin-right:.3rem;"></i>
                        <?= ucfirst($role) ?>
                    </span>
                    <!-- Badge status -->
                    <span style="padding:.25rem .75rem;border-radius:99px;font-size:.75rem;font-weight:600;
                                 background:<?= $isActive ? '#dcfce7' : '#fee2e2' ?>;
                                 color:<?= $isActive ? '#16a34a' : '#dc2626' ?>;">
                        <i class="fa-solid fa-<?= $isActive ? 'circle-check' : 'circle-xmark' ?>"
                           style="margin-right:.3rem;"></i>
                        <?= $isActive ? 'Aktif' : 'Nonaktif' ?>
                    </span>
                </div>
                <?php if ($isPelanggan && !empty($user['nama_lengkap'])): ?>
                    <p style="margin:.25rem 0 0;color:var(--text-muted,#6b7280);font-size:.9rem;">
                        <i class="fa-solid fa-id-card" style="margin-right:.4rem;"></i>
                        <?= htmlspecialchars($user['nama_lengkap']) ?>
                    </p>
                <?php endif; ?>
                <p style="margin:.25rem 0 0;color:var(--text-muted,#6b7280);font-size:.8rem;">
                    ID #<?= $user['id'] ?>
                    <?php if (!empty($user['created_at'])): ?>
                        &bull; Terdaftar <?= date('d M Y', strtotime($user['created_at'])) ?>
                    <?php endif; ?>
                </p>
            </div>

            <!-- Tombol aksi -->
            <div style="display:flex;gap:.6rem;flex-wrap:wrap;">
                <a href="<?= $appUrl ?>/users/edit/<?= $user['id'] ?>"
                   style="padding:.5rem 1rem;border-radius:8px;border:1.5px solid #6366f1;
                          color:#6366f1;text-decoration:none;font-weight:600;font-size:.875rem;
                          display:inline-flex;align-items:center;gap:.4rem;">
                    <i class="fa-solid fa-pen-to-square"></i> Edit
                </a>
                <a href="<?= $appUrl ?>/users/reset-password/<?= $user['id'] ?>"
                   style="padding:.5rem 1rem;border-radius:8px;border:1.5px solid #f59e0b;
                          color:#f59e0b;text-decoration:none;font-weight:600;font-size:.875rem;
                          display:inline-flex;align-items:center;gap:.4rem;">
                    <i class="fa-solid fa-key"></i> Reset Password
                </a>
                <form method="POST" action="<?= $appUrl ?>/users/status/<?= $user['id'] ?>"
                      style="margin:0;" onsubmit="return confirm('Ubah status akun ini?')">
                    <input type="hidden" name="csrf_token"
                           value="<?= htmlspecialchars(\Core\Middleware::generateCsrfToken()) ?>">
                    <button type="submit"
                            style="padding:.5rem 1rem;border-radius:8px;cursor:pointer;font-weight:600;
                                   font-size:.875rem;display:inline-flex;align-items:center;gap:.4rem;
                                   border:1.5px solid <?= $isActive ? '#dc2626' : '#16a34a' ?>;
                                   color:<?= $isActive ? '#dc2626' : '#16a34a' ?>;background:transparent;">
                        <i class="fa-solid fa-<?= $isActive ? 'ban' : 'circle-check' ?>"></i>
                        <?= $isActive ? 'Nonaktifkan' : 'Aktifkan' ?>
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div style="display:grid;grid-template-columns:<?= $isPelanggan ? '1fr 1fr' : '1fr' ?>;gap:1.25rem;margin-bottom:1.25rem;">

        <?php if ($isPelanggan): ?>
        <!-- ── Info Pelanggan ── -->
        <div class="card" style="border-radius:12px;padding:1.25rem;">
            <h3 style="margin:0 0 1rem;font-size:.95rem;font-weight:700;color:#3b82f6;
                       display:flex;align-items:center;gap:.5rem;">
                <i class="fa-solid fa-user"></i> Data Pelanggan
            </h3>
            <table style="width:100%;font-size:.875rem;border-collapse:collapse;">
                <?php
                $fields = [
                    'nama_lengkap' => ['Nama Lengkap',  'fa-id-card'],
                    'alamat'       => ['Alamat',         'fa-location-dot'],
                    'no_hp'        => ['No. HP',         'fa-phone'],
                    'email'        => ['Email',          'fa-envelope'],
                    'paket'        => ['Paket Internet', 'fa-wifi'],
                    'odp'          => ['ODP',            'fa-tower-broadcast'],
                    'tgl_jatuh_tempo' => ['Jatuh Tempo', 'fa-calendar'],
                ];
                foreach ($fields as $key => [$label, $icon]):
                    $val = $user[$key] ?? null;
                    if ($val === null || $val === '') continue;
                ?>
                <tr style="border-bottom:1px solid var(--border,#e5e7eb);">
                    <td style="padding:.5rem .25rem;color:var(--text-muted,#6b7280);width:40%;white-space:nowrap;">
                        <i class="fa-solid <?= $icon ?>" style="margin-right:.4rem;width:14px;"></i><?= $label ?>
                    </td>
                    <td style="padding:.5rem .25rem;font-weight:500;">
                        <?= htmlspecialchars((string)$val) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
            <div style="margin-top:1rem;">
                <a href="<?= $appUrl ?>/pelanggan"
                   style="font-size:.8rem;color:#3b82f6;text-decoration:none;">
                    <i class="fa-solid fa-arrow-up-right-from-square" style="margin-right:.3rem;"></i>
                    Lihat di Data Pelanggan
                </a>
            </div>
        </div>

        <!-- ── Info Akun ── -->
        <div class="card" style="border-radius:12px;padding:1.25rem;">
            <h3 style="margin:0 0 1rem;font-size:.95rem;font-weight:700;color:#6366f1;
                       display:flex;align-items:center;gap:.5rem;">
                <i class="fa-solid fa-circle-user"></i> Info Akun
            </h3>
            <table style="width:100%;font-size:.875rem;border-collapse:collapse;">
                <tr style="border-bottom:1px solid var(--border,#e5e7eb);">
                    <td style="padding:.5rem .25rem;color:var(--text-muted,#6b7280);">
                        <i class="fa-solid fa-hashtag" style="margin-right:.4rem;"></i>User ID
                    </td>
                    <td style="padding:.5rem .25rem;font-weight:500;">#<?= $user['id'] ?></td>
                </tr>
                <tr style="border-bottom:1px solid var(--border,#e5e7eb);">
                    <td style="padding:.5rem .25rem;color:var(--text-muted,#6b7280);">
                        <i class="fa-solid fa-user" style="margin-right:.4rem;"></i>Username
                    </td>
                    <td style="padding:.5rem .25rem;font-weight:500;"><?= htmlspecialchars($user['username']) ?></td>
                </tr>
                <tr style="border-bottom:1px solid var(--border,#e5e7eb);">
                    <td style="padding:.5rem .25rem;color:var(--text-muted,#6b7280);">
                        <i class="fa-solid fa-shield" style="margin-right:.4rem;"></i>Role
                    </td>
                    <td style="padding:.5rem .25rem;">
                        <span style="padding:.2rem .6rem;border-radius:99px;font-size:.75rem;
                                     font-weight:600;background:#3b82f622;color:#3b82f6;">
                            <?= ucfirst($role) ?>
                        </span>
                    </td>
                </tr>
                <tr>
                    <td style="padding:.5rem .25rem;color:var(--text-muted,#6b7280);">
                        <i class="fa-solid fa-calendar-plus" style="margin-right:.4rem;"></i>Terdaftar
                    </td>
                    <td style="padding:.5rem .25rem;font-weight:500;">
                        <?= !empty($user['created_at']) ? date('d M Y H:i', strtotime($user['created_at'])) : '-' ?>
                    </td>
                </tr>
            </table>
        </div>

        <?php else: ?>
        <!-- ── Info Staff (admin/kasir/teknisi) ── -->
        <div class="card" style="border-radius:12px;padding:1.25rem;">
            <h3 style="margin:0 0 1rem;font-size:.95rem;font-weight:700;color:<?= $roleColor ?>;
                       display:flex;align-items:center;gap:.5rem;">
                <i class="fa-solid <?= $roleIcon ?>"></i> Info Akun Staff
            </h3>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <?php
                $infoItems = [
                    ['fa-hashtag',      'User ID',     '#' . $user['id']],
                    ['fa-user',         'Username',    $user['username']],
                    ['fa-shield-halved','Role',        ucfirst($role)],
                    ['fa-toggle-on',    'Status',      $isActive ? 'Aktif' : 'Nonaktif'],
                    ['fa-calendar-plus','Terdaftar',   !empty($user['created_at']) ? date('d M Y', strtotime($user['created_at'])) : '-'],
                ];
                foreach ($infoItems as [$icon, $label, $val]):
                ?>
                <div style="background:var(--surface-alt,#f9fafb);border-radius:8px;padding:.875rem;">
                    <div style="font-size:.75rem;color:var(--text-muted,#6b7280);margin-bottom:.25rem;">
                        <i class="fa-solid <?= $icon ?>" style="margin-right:.3rem;"></i><?= $label ?>
                    </div>
                    <div style="font-weight:600;font-size:.95rem;"><?= htmlspecialchars((string)$val) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

    </div>

    <!-- ── Riwayat Aktivitas ── -->
    <div class="card" style="border-radius:12px;overflow:hidden;">
        <div style="padding:1rem 1.25rem;border-bottom:1px solid var(--border,#e5e7eb);
                    display:flex;justify-content:space-between;align-items:center;">
            <h3 style="margin:0;font-size:.95rem;font-weight:700;
                       display:flex;align-items:center;gap:.5rem;">
                <i class="fa-solid fa-clock-rotate-left" style="color:#6366f1;"></i>
                Riwayat Aktivitas
            </h3>
            <span style="font-size:.8rem;color:var(--text-muted,#6b7280);">
                <?= count($logs ?? []) ?> entri terakhir
            </span>
        </div>

        <?php if (empty($logs)): ?>
            <div style="padding:2.5rem;text-align:center;color:var(--text-muted,#6b7280);">
                <i class="fa-solid fa-inbox" style="font-size:2rem;margin-bottom:.75rem;display:block;opacity:.4;"></i>
                Belum ada riwayat aktivitas
            </div>
        <?php else: ?>
            <div style="overflow-x:auto;">
                <table style="width:100%;border-collapse:collapse;font-size:.875rem;">
                    <thead>
                        <tr style="background:var(--surface-alt,#f9fafb);">
                            <th style="padding:.75rem 1.25rem;text-align:left;font-weight:600;
                                       color:var(--text-muted,#6b7280);white-space:nowrap;">Waktu</th>
                            <th style="padding:.75rem 1.25rem;text-align:left;font-weight:600;
                                       color:var(--text-muted,#6b7280);">Aktivitas</th>
                            <th style="padding:.75rem 1.25rem;text-align:left;font-weight:600;
                                       color:var(--text-muted,#6b7280);white-space:nowrap;">IP Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                        <tr style="border-top:1px solid var(--border,#e5e7eb);">
                            <td style="padding:.75rem 1.25rem;white-space:nowrap;color:var(--text-muted,#6b7280);">
                                <?= date('d M Y H:i', strtotime($log['created_at'])) ?>
                            </td>
                            <td style="padding:.75rem 1.25rem;">
                                <?= htmlspecialchars($log['aktivitas']) ?>
                            </td>
                            <td style="padding:.75rem 1.25rem;font-family:monospace;font-size:.8rem;
                                       color:var(--text-muted,#6b7280);">
                                <?= htmlspecialchars($log['ip_address'] ?? '-') ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

</div>
