<?php
/**
 * views/pages/User/create.php
 */
$appUrl = $_ENV['APP_URL'] ?? '';
$old    = $old    ?? [];
$errors = $errors ?? [];
?>

<div style="max-width:520px;">

    <!-- Breadcrumb -->
    <div style="font-size:.8rem;color:var(--text-muted,#6b7280);margin-bottom:1rem;
                display:flex;align-items:center;gap:.4rem;">
        <a href="<?= $appUrl ?>/users" style="color:#6366f1;text-decoration:none;">Manajemen User</a>
        <i class="fa-solid fa-chevron-right" style="font-size:.65rem;"></i>
        <span>Tambah User</span>
    </div>

    <h1 class="page-title" style="margin-bottom:1.25rem;">
        <i class="fa-solid fa-user-plus" style="color:#6366f1;margin-right:.5rem;"></i>
        <?= htmlspecialchars($title ?? 'Tambah User') ?>
    </h1>

    <!-- Errors -->
    <?php if (!empty($errors)): ?>
        <div style="background:#fee2e2;border:1px solid #fca5a5;border-radius:10px;
                    padding:1rem 1.25rem;margin-bottom:1.25rem;">
            <div style="font-weight:600;color:#dc2626;margin-bottom:.4rem;">
                <i class="fa-solid fa-triangle-exclamation" style="margin-right:.4rem;"></i>
                Perbaiki kesalahan berikut:
            </div>
            <ul style="margin:0;padding-left:1.25rem;color:#dc2626;font-size:.875rem;">
                <?php foreach ($errors as $err): ?>
                    <li><?= htmlspecialchars($err) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card" style="border-radius:12px;overflow:hidden;">
        <div style="height:5px;background:#6366f1;"></div>
        <div style="padding:1.5rem;">

            <form method="POST" action="<?= $appUrl ?>/users/simpan" autocomplete="off">
                <input type="hidden" name="csrf_token"
                       value="<?= htmlspecialchars(\Core\Middleware::generateCsrfToken()) ?>">

                <div style="display:flex;flex-direction:column;gap:1.1rem;">

                    <!-- Username -->
                    <div>
                        <label for="username"
                               style="font-weight:600;font-size:.875rem;display:block;margin-bottom:.4rem;">
                            Username <span style="color:#ef4444;">*</span>
                        </label>
                        <input type="text" id="username" name="username"
                               value="<?= htmlspecialchars($old['username'] ?? '') ?>"
                               placeholder="min. 4 karakter"
                               minlength="4" maxlength="50" required autofocus
                               style="width:100%;padding:.6rem .85rem;border-radius:8px;
                                      border:1.5px solid var(--border,#e5e7eb);font-size:.875rem;
                                      background:var(--surface,#fff);box-sizing:border-box;">
                        <small style="color:var(--text-muted,#6b7280);font-size:.75rem;">
                            Digunakan untuk login. Tidak bisa diubah setelah disimpan.
                        </small>
                    </div>

                    <!-- Role -->
                    <div>
                        <label for="role"
                               style="font-weight:600;font-size:.875rem;display:block;margin-bottom:.4rem;">
                            Role <span style="color:#ef4444;">*</span>
                        </label>
                        <select id="role" name="role" required
                                style="width:100%;padding:.6rem .85rem;border-radius:8px;
                                       border:1.5px solid var(--border,#e5e7eb);font-size:.875rem;
                                       background:var(--surface,#fff);cursor:pointer;box-sizing:border-box;">
                            <option value="" disabled <?= empty($old['role']) ? 'selected' : '' ?>>
                                — Pilih role —
                            </option>
                            <?php
                            $roleOptions = [
                                'admin'     => 'Admin — Akses penuh',
                                'kasir'     => 'Kasir — Tagihan & Kas',
                                'teknisi'   => 'Teknisi — ODP & Peta',
                                'pelanggan' => 'Pelanggan — Portal mandiri',
                            ];
                            foreach ($roleOptions as $val => $label):
                            ?>
                                <option value="<?= $val ?>"
                                    <?= ($old['role'] ?? '') === $val ? 'selected' : '' ?>>
                                    <?= $label ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Status -->
                    <div>
                        <label style="font-weight:600;font-size:.875rem;display:block;margin-bottom:.6rem;">
                            Status Akun
                        </label>
                        <div style="display:flex;gap:1rem;">
                            <?php foreach (['active' => ['Aktif','#10b981','fa-circle-check'], 'inactive' => ['Nonaktif','#6b7280','fa-circle-xmark']] as $val => [$label, $color, $icon]):
                                $checked = ($old['status'] ?? 'active') === $val;
                            ?>
                            <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;
                                          padding:.5rem .9rem;border-radius:8px;font-size:.875rem;font-weight:600;
                                          border:1.5px solid <?= $checked ? $color : 'var(--border,#e5e7eb)' ?>;
                                          background:<?= $checked ? $color.'22' : 'transparent' ?>;
                                          color:<?= $checked ? $color : 'var(--text-muted,#6b7280)' ?>;"
                                   id="label_<?= $val ?>">
                                <input type="radio" name="status" value="<?= $val ?>"
                                       <?= $checked ? 'checked' : '' ?>
                                       onchange="updateStatusLabel()"
                                       style="display:none;">
                                <i class="fa-solid <?= $icon ?>"></i> <?= $label ?>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <hr style="border:none;border-top:1px solid var(--border,#e5e7eb);margin:.25rem 0;">

                    <!-- Password -->
                    <div>
                        <label for="password"
                               style="font-weight:600;font-size:.875rem;display:block;margin-bottom:.4rem;">
                            Password <span style="color:#ef4444;">*</span>
                        </label>
                        <div style="position:relative;">
                            <input type="password" id="password" name="password"
                                   placeholder="min. 8 karakter"
                                   minlength="8" required
                                   oninput="checkMatch()"
                                   style="width:100%;padding:.6rem 2.5rem .6rem .85rem;border-radius:8px;
                                          border:1.5px solid var(--border,#e5e7eb);font-size:.875rem;
                                          background:var(--surface,#fff);box-sizing:border-box;">
                            <button type="button" onclick="togglePw('password', this)"
                                    style="position:absolute;right:.75rem;top:50%;transform:translateY(-50%);
                                           border:none;background:none;cursor:pointer;
                                           color:var(--text-muted,#6b7280);padding:0;">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Konfirmasi Password -->
                    <div>
                        <label for="confirm_password"
                               style="font-weight:600;font-size:.875rem;display:block;margin-bottom:.4rem;">
                            Konfirmasi Password <span style="color:#ef4444;">*</span>
                        </label>
                        <div style="position:relative;">
                            <input type="password" id="confirm_password" name="confirm_password"
                                   placeholder="Ulangi password"
                                   minlength="8" required
                                   oninput="checkMatch()"
                                   style="width:100%;padding:.6rem 2.5rem .6rem .85rem;border-radius:8px;
                                          border:1.5px solid var(--border,#e5e7eb);font-size:.875rem;
                                          background:var(--surface,#fff);box-sizing:border-box;">
                            <button type="button" onclick="togglePw('confirm_password', this)"
                                    style="position:absolute;right:.75rem;top:50%;transform:translateY(-50%);
                                           border:none;background:none;cursor:pointer;
                                           color:var(--text-muted,#6b7280);padding:0;">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                        </div>
                        <small id="matchFeedback" style="font-size:.75rem;"></small>
                    </div>

                </div>

                <div style="display:flex;gap:.75rem;margin-top:1.5rem;
                            padding-top:1.25rem;border-top:1px solid var(--border,#e5e7eb);">
                    <button type="submit"
                            style="padding:.6rem 1.5rem;border-radius:8px;border:none;cursor:pointer;
                                   font-weight:600;background:#6366f1;color:#fff;
                                   display:inline-flex;align-items:center;gap:.4rem;">
                        <i class="fa-solid fa-floppy-disk"></i> Simpan User
                    </button>
                    <a href="<?= $appUrl ?>/users"
                       style="padding:.6rem 1.25rem;border-radius:8px;text-decoration:none;
                              border:1.5px solid var(--border,#e5e7eb);font-weight:600;
                              color:var(--text-muted,#6b7280);display:inline-flex;align-items:center;gap:.4rem;">
                        <i class="fa-solid fa-xmark"></i> Batal
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function togglePw(id, btn) {
    const inp = document.getElementById(id);
    const ico = btn.querySelector('i');
    const hide = inp.type === 'password';
    inp.type = hide ? 'text' : 'password';
    ico.className = hide ? 'fa-solid fa-eye-slash' : 'fa-solid fa-eye';
}

function checkMatch() {
    const pw  = document.getElementById('password').value;
    const cfm = document.getElementById('confirm_password').value;
    const el  = document.getElementById('matchFeedback');
    if (!cfm) { el.textContent = ''; return; }
    if (pw === cfm) {
        el.textContent = '✓ Password cocok';
        el.style.color = '#10b981';
    } else {
        el.textContent = '✗ Password tidak cocok';
        el.style.color = '#ef4444';
    }
}

function updateStatusLabel() {
    const colors = { active: '#10b981', inactive: '#6b7280' };
    document.querySelectorAll('input[name="status"]').forEach(r => {
        const lbl = document.getElementById('label_' + r.value);
        const c   = colors[r.value];
        if (r.checked) {
            lbl.style.borderColor = c;
            lbl.style.background  = c + '22';
            lbl.style.color       = c;
        } else {
            lbl.style.borderColor = 'var(--border,#e5e7eb)';
            lbl.style.background  = 'transparent';
            lbl.style.color       = 'var(--text-muted,#6b7280)';
        }
    });
}
</script>
