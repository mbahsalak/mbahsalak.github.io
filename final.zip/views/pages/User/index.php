<?php
/**
 * views/pages/User/index.php
 */
$appUrl     = $_ENV['APP_URL'] ?? '';
$list       = $list ?? [];
$filterRole = $filterRole ?? '';

$rolesMeta = [
    ''          => ['label' => 'Semua',    'color' => '#6b7280', 'icon' => 'fa-users'],
    'admin'     => ['label' => 'Admin',    'color' => '#6366f1', 'icon' => 'fa-user-shield'],
    'kasir'     => ['label' => 'Kasir',    'color' => '#10b981', 'icon' => 'fa-cash-register'],
    'teknisi'   => ['label' => 'Teknisi',  'color' => '#f59e0b', 'icon' => 'fa-screwdriver-wrench'],
    'pelanggan' => ['label' => 'Pelanggan','color' => '#3b82f6', 'icon' => 'fa-user'],
];
?>

<div class="page-header" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem;">
    <div>
        <h1 class="page-title">
            <i class="fa-solid fa-users-gear" style="color:#6366f1;margin-right:.5rem;"></i>
            <?= htmlspecialchars($title ?? 'Manajemen User') ?>
        </h1>
        <p class="page-subtitle" style="margin:0;color:var(--text-muted,#6b7280);font-size:.875rem;">
            Kelola akun teknisi, kasir, dan pelanggan
        </p>
    </div>
    <div style="display:flex;gap:.6rem;flex-wrap:wrap;">
        <a href="<?= $appUrl ?>/users/export<?= $filterRole ? '?role='.urlencode($filterRole) : '' ?>"
           style="padding:.5rem 1rem;border-radius:8px;text-decoration:none;font-weight:600;font-size:.875rem;
                  border:1.5px solid #10b981;color:#10b981;display:inline-flex;align-items:center;gap:.4rem;">
            <i class="fa-solid fa-file-excel"></i> Export
        </a>
        <a href="<?= $appUrl ?>/users/tambah"
           style="padding:.5rem 1rem;border-radius:8px;text-decoration:none;font-weight:600;font-size:.875rem;
                  background:#6366f1;color:#fff;display:inline-flex;align-items:center;gap:.4rem;border:none;">
            <i class="fa-solid fa-user-plus"></i> Tambah User
        </a>
    </div>
</div>

<?php if (!empty($flash)): ?>
    <div class="flash flash--<?= $flash['type'] ?? 'info' ?>" role="alert" style="margin-bottom:1rem;">
        <i class="fa-solid fa-<?= ($flash['type'] ?? '') === 'success' ? 'circle-check' : 'circle-xmark' ?>"></i>
        <span><?= htmlspecialchars($flash['message'] ?? '') ?></span>
        <button class="flash-close" onclick="this.parentElement.remove()">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>
<?php endif; ?>

<!-- Filter Role + Search -->
<div class="card" style="border-radius:12px;padding:1rem 1.25rem;margin-bottom:1.25rem;">
    <div style="display:flex;flex-wrap:wrap;gap:.6rem;align-items:center;">
        <span style="font-size:.8rem;font-weight:600;color:var(--text-muted,#6b7280);">Filter:</span>
        <?php foreach ($rolesMeta as $val => $cfg):
            $active = $filterRole === $val;
        ?>
            <a href="<?= $appUrl ?>/users<?= $val ? '?role='.$val : '' ?>"
               style="padding:.35rem .85rem;border-radius:99px;font-size:.8rem;font-weight:600;
                      text-decoration:none;transition:all .15s;
                      background:<?= $active ? $cfg['color'] : 'transparent' ?>;
                      color:<?= $active ? '#fff' : $cfg['color'] ?>;
                      border:1.5px solid <?= $cfg['color'] ?>;">
                <i class="fa-solid <?= $cfg['icon'] ?>" style="margin-right:.3rem;"></i>
                <?= $cfg['label'] ?>
            </a>
        <?php endforeach; ?>

        <!-- Search -->
        <div style="margin-left:auto;position:relative;">
            <i class="fa-solid fa-magnifying-glass"
               style="position:absolute;left:.75rem;top:50%;transform:translateY(-50%);
                      color:var(--text-muted,#6b7280);font-size:.8rem;pointer-events:none;"></i>
            <input type="text" id="searchUser" placeholder="Cari username / nama…"
                   oninput="filterTable(this.value)"
                   style="padding:.45rem .75rem .45rem 2.25rem;border-radius:8px;font-size:.875rem;
                          border:1.5px solid var(--border,#e5e7eb);background:var(--surface,#fff);
                          min-width:200px;">
        </div>
    </div>
</div>

<!-- Tabel -->
<div class="card" style="border-radius:12px;overflow:hidden;">
    <div style="overflow-x:auto;">
        <table style="width:100%;border-collapse:collapse;font-size:.875rem;" id="tblUser">
            <thead>
                <tr style="background:var(--surface-alt,#f9fafb);">
                    <th style="padding:.75rem 1rem;text-align:left;font-weight:600;color:var(--text-muted,#6b7280);width:44px;">#</th>
                    <th style="padding:.75rem 1rem;text-align:left;font-weight:600;color:var(--text-muted,#6b7280);">Username</th>
                    <th style="padding:.75rem 1rem;text-align:left;font-weight:600;color:var(--text-muted,#6b7280);">Nama Lengkap</th>
                    <th style="padding:.75rem 1rem;text-align:left;font-weight:600;color:var(--text-muted,#6b7280);">Role</th>
                    <th style="padding:.75rem 1rem;text-align:left;font-weight:600;color:var(--text-muted,#6b7280);">Status</th>
                    <th style="padding:.75rem 1rem;text-align:left;font-weight:600;color:var(--text-muted,#6b7280);">Terdaftar</th>
                    <th style="padding:.75rem 1rem;text-align:center;font-weight:600;color:var(--text-muted,#6b7280);width:160px;">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($list)): ?>
                <tr>
                    <td colspan="7" style="padding:3rem;text-align:center;color:var(--text-muted,#6b7280);">
                        <i class="fa-solid fa-inbox" style="font-size:2rem;display:block;margin-bottom:.75rem;opacity:.4;"></i>
                        Belum ada user<?= $filterRole ? " dengan role <strong>{$filterRole}</strong>" : '' ?>.
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($list as $i => $u):
                    $role      = $u['role'] ?? '';
                    $isActive  = ($u['status'] ?? '') === 'active';
                    $roleMeta  = $rolesMeta[$role] ?? ['label' => ucfirst($role), 'color' => '#6b7280', 'icon' => 'fa-user'];
                ?>
                <tr style="border-top:1px solid var(--border,#e5e7eb);" class="user-row">
                    <td style="padding:.75rem 1rem;color:var(--text-muted,#6b7280);"><?= $i + 1 ?></td>
                    <td style="padding:.75rem 1rem;">
                        <div style="font-weight:600;"><?= htmlspecialchars($u['username']) ?></div>
                        <div style="font-size:.75rem;color:var(--text-muted,#6b7280);">#<?= $u['id'] ?></div>
                    </td>
                    <td style="padding:.75rem 1rem;color:var(--text-muted,#6b7280);">
                        <?= htmlspecialchars($u['nama_lengkap'] ?? '—') ?>
                    </td>
                    <td style="padding:.75rem 1rem;">
                        <span style="padding:.25rem .65rem;border-radius:99px;font-size:.75rem;font-weight:600;
                                     background:<?= $roleMeta['color'] ?>22;color:<?= $roleMeta['color'] ?>;">
                            <i class="fa-solid <?= $roleMeta['icon'] ?>" style="margin-right:.3rem;"></i>
                            <?= $roleMeta['label'] ?>
                        </span>
                    </td>
                    <td style="padding:.75rem 1rem;">
                        <span style="padding:.25rem .65rem;border-radius:99px;font-size:.75rem;font-weight:600;
                                     background:<?= $isActive ? '#dcfce7' : '#f3f4f6' ?>;
                                     color:<?= $isActive ? '#16a34a' : '#6b7280' ?>;">
                            <i class="fa-solid fa-<?= $isActive ? 'circle-check' : 'circle-xmark' ?>"
                               style="margin-right:.3rem;"></i>
                            <?= $isActive ? 'Aktif' : 'Nonaktif' ?>
                        </span>
                    </td>
                    <td style="padding:.75rem 1rem;color:var(--text-muted,#6b7280);font-size:.8rem;">
                        <?= date('d M Y', strtotime($u['created_at'] ?? 'now')) ?>
                    </td>
                    <td style="padding:.75rem 1rem;text-align:center;">
                        <div style="display:flex;gap:.35rem;justify-content:center;flex-wrap:wrap;">
                            <!-- Detail -->
                            <a href="<?= $appUrl ?>/users/<?= $u['id'] ?>" title="Detail"
                               style="padding:.35rem .55rem;border-radius:6px;text-decoration:none;
                                      border:1.5px solid #6366f1;color:#6366f1;font-size:.8rem;">
                                <i class="fa-solid fa-eye"></i>
                            </a>
                            <!-- Edit -->
                            <a href="<?= $appUrl ?>/users/edit/<?= $u['id'] ?>" title="Edit"
                               style="padding:.35rem .55rem;border-radius:6px;text-decoration:none;
                                      border:1.5px solid #f59e0b;color:#f59e0b;font-size:.8rem;">
                                <i class="fa-solid fa-pen-to-square"></i>
                            </a>
                            <!-- Reset Password -->
                            <a href="<?= $appUrl ?>/users/reset-password/<?= $u['id'] ?>" title="Reset Password"
                               style="padding:.35rem .55rem;border-radius:6px;text-decoration:none;
                                      border:1.5px solid #8b5cf6;color:#8b5cf6;font-size:.8rem;">
                                <i class="fa-solid fa-key"></i>
                            </a>
                            <!-- Toggle Status -->
                            <form method="POST" action="<?= $appUrl ?>/users/status/<?= $u['id'] ?>"
                                  style="margin:0;"
                                  onsubmit="return confirm('<?= $isActive ? 'Nonaktifkan' : 'Aktifkan' ?> akun ini?')">
                                <input type="hidden" name="csrf_token"
                                       value="<?= htmlspecialchars(\Core\Middleware::generateCsrfToken()) ?>">
                                <button type="submit" title="<?= $isActive ? 'Nonaktifkan' : 'Aktifkan' ?>"
                                        style="padding:.35rem .55rem;border-radius:6px;cursor:pointer;background:transparent;
                                               border:1.5px solid <?= $isActive ? '#f59e0b' : '#10b981' ?>;
                                               color:<?= $isActive ? '#f59e0b' : '#10b981' ?>;font-size:.8rem;">
                                    <i class="fa-solid fa-<?= $isActive ? 'pause' : 'play' ?>"></i>
                                </button>
                            </form>
                            <!-- Hapus -->
                            <form method="POST" action="<?= $appUrl ?>/users/hapus/<?= $u['id'] ?>"
                                  style="margin:0;"
                                  onsubmit="return confirm('Hapus user ini secara permanen?')">
                                <input type="hidden" name="csrf_token"
                                       value="<?= htmlspecialchars(\Core\Middleware::generateCsrfToken()) ?>">
                                <button type="submit" title="Hapus"
                                        style="padding:.35rem .55rem;border-radius:6px;cursor:pointer;background:transparent;
                                               border:1.5px solid #ef4444;color:#ef4444;font-size:.8rem;">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if (!empty($list)): ?>
        <div style="padding:.75rem 1.25rem;border-top:1px solid var(--border,#e5e7eb);
                    font-size:.8rem;color:var(--text-muted,#6b7280);">
            Total <strong><?= count($list) ?></strong> user<?= $filterRole ? " (filter: {$filterRole})" : '' ?>
        </div>
    <?php endif; ?>
</div>

<script>
function filterTable(q) {
    q = q.toLowerCase();
    document.querySelectorAll('#tblUser .user-row').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
}
</script>
