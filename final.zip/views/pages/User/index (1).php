<?php
/**
 * views/pages/User/index.php
 * Manajemen User — Daftar semua user
 * Variabel dari controller: $title, $list (array), $filterRole (string|null)
 */
?>

<div class="page-header d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="fw-bold mb-0"><?= htmlspecialchars($title) ?></h2>
        <p class="text-muted mb-0 small">Kelola akun teknisi, kasir, dan pelanggan</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= $_ENV['APP_URL'] ?>/users/export<?= $filterRole ? '?role=' . urlencode($filterRole) : '' ?>"
           class="btn btn-outline-success btn-sm">
            <i class="bi bi-file-earmark-excel me-1"></i> Export Excel
        </a>
        <a href="<?= $_ENV['APP_URL'] ?>/users/tambah" class="btn btn-primary btn-sm">
            <i class="bi bi-person-plus me-1"></i> Tambah User
        </a>
    </div>
</div>

<?php if ($flash = ($flash ?? null)): ?>
    <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show" role="alert">
        <i class="bi bi-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-triangle' ?> me-2"></i>
        <?= htmlspecialchars($flash['message']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

{{-- Filter Role --}}
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body py-3">
        <div class="d-flex flex-wrap gap-2 align-items-center">
            <span class="text-muted small fw-semibold me-1">Filter Role:</span>
            <?php
            $roles = [
                ''          => ['label' => 'Semua',    'color' => 'secondary'],
                'admin'     => ['label' => 'Admin',    'color' => 'danger'],
                'kasir'     => ['label' => 'Kasir',    'color' => 'warning'],
                'teknisi'   => ['label' => 'Teknisi',  'color' => 'info'],
                'pelanggan' => ['label' => 'Pelanggan','color' => 'primary'],
            ];
            foreach ($roles as $val => $cfg):
                $active = ($filterRole ?? '') === $val;
            ?>
                <a href="<?= $_ENV['APP_URL'] ?>/users<?= $val ? '?role=' . $val : '' ?>"
                   class="btn btn-sm btn-<?= $active ? $cfg['color'] : 'outline-' . $cfg['color'] ?>">
                    <?= $cfg['label'] ?>
                </a>
            <?php endforeach; ?>

            {{-- Search (client-side) --}}
            <div class="ms-auto">
                <input type="text" id="searchUser" class="form-control form-control-sm"
                       placeholder="Cari username / nama…" style="min-width:200px">
            </div>
        </div>
    </div>
</div>

{{-- Tabel User --}}
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" id="tblUser">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4" style="width:50px">#</th>
                        <th>Username</th>
                        <th>Nama Lengkap</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Terdaftar</th>
                        <th class="text-end pe-4">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($list)): ?>
                    <tr>
                        <td colspan="7" class="text-center py-5 text-muted">
                            <i class="bi bi-person-x fs-2 d-block mb-2"></i>
                            Belum ada user<?= $filterRole ? " dengan role <strong>{$filterRole}</strong>" : '' ?>.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($list as $i => $u): ?>
                    <tr class="user-row">
                        <td class="ps-4 text-muted small"><?= $i + 1 ?></td>
                        <td>
                            <div class="fw-semibold"><?= htmlspecialchars($u['username']) ?></div>
                            <div class="text-muted small">#<?= $u['id'] ?></div>
                        </td>
                        <td class="text-muted small">
                            <?= htmlspecialchars($u['nama_lengkap'] ?? '—') ?>
                        </td>
                        <td>
                            <?php
                            $roleColor = match($u['role']) {
                                'admin'     => 'danger',
                                'kasir'     => 'warning',
                                'teknisi'   => 'info',
                                'pelanggan' => 'primary',
                                default     => 'secondary',
                            };
                            ?>
                            <span class="badge bg-<?= $roleColor ?>-subtle text-<?= $roleColor ?> border border-<?= $roleColor ?>-subtle">
                                <?= ucfirst($u['role']) ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($u['status'] === 'active'): ?>
                                <span class="badge bg-success-subtle text-success border border-success-subtle">
                                    <i class="bi bi-circle-fill me-1" style="font-size:.5rem"></i>Aktif
                                </span>
                            <?php else: ?>
                                <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle">
                                    <i class="bi bi-circle me-1" style="font-size:.5rem"></i>Nonaktif
                                </span>
                            <?php endif; ?>
                        </td>
                        <td class="text-muted small">
                            <?= date('d M Y', strtotime($u['created_at'] ?? 'now')) ?>
                        </td>
                        <td class="text-end pe-4">
                            <div class="d-flex gap-1 justify-content-end">
                                {{-- Detail --}}
                                <a href="<?= $_ENV['APP_URL'] ?>/users/<?= $u['id'] ?>"
                                   class="btn btn-sm btn-outline-secondary" title="Detail">
                                    <i class="bi bi-eye"></i>
                                </a>
                                {{-- Edit --}}
                                <a href="<?= $_ENV['APP_URL'] ?>/users/edit/<?= $u['id'] ?>"
                                   class="btn btn-sm btn-outline-primary" title="Edit">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                {{-- Reset Password --}}
                                <a href="<?= $_ENV['APP_URL'] ?>/users/reset-password/<?= $u['id'] ?>"
                                   class="btn btn-sm btn-outline-warning" title="Reset Password">
                                    <i class="bi bi-key"></i>
                                </a>
                                {{-- Toggle Status --}}
                                <form method="POST"
                                      action="<?= $_ENV['APP_URL'] ?>/users/status/<?= $u['id'] ?>"
                                      class="d-inline"
                                      onsubmit="return confirm('<?= $u['status'] === 'active' ? 'Nonaktifkan' : 'Aktifkan' ?> akun ini?')">
                                    <?= $this->csrfField() ?>
                                    <button type="submit"
                                            class="btn btn-sm btn-outline-<?= $u['status'] === 'active' ? 'warning' : 'success' ?>"
                                            title="<?= $u['status'] === 'active' ? 'Nonaktifkan' : 'Aktifkan' ?>">
                                        <i class="bi bi-<?= $u['status'] === 'active' ? 'pause-circle' : 'play-circle' ?>"></i>
                                    </button>
                                </form>
                                {{-- Hapus --}}
                                <form method="POST"
                                      action="<?= $_ENV['APP_URL'] ?>/users/hapus/<?= $u['id'] ?>"
                                      class="d-inline"
                                      onsubmit="return confirm('Hapus user ini secara permanen?')">
                                    <?= $this->csrfField() ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Hapus">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if (!empty($list)): ?>
    <div class="card-footer bg-transparent text-muted small px-4 py-2">
        Total: <strong><?= count($list) ?></strong> user<?= $filterRole ? " (filter: {$filterRole})" : '' ?>
    </div>
    <?php endif; ?>
</div>

<script>
// Client-side search — filter baris berdasarkan username & nama
document.getElementById('searchUser').addEventListener('input', function () {
    const q = this.value.toLowerCase();
    document.querySelectorAll('#tblUser tbody .user-row').forEach(row => {
        const text = row.innerText.toLowerCase();
        row.style.display = text.includes(q) ? '' : 'none';
    });
});
</script>
