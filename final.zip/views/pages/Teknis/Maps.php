<?php
/**
 * views/pages/Teknis/maps.php
 * Peta Jaringan — ODP & Pelanggan menggunakan Leaflet.js
 * ✅ Tailwind CSS + Fully Responsive (Mobile / Tablet / Desktop)
 */
?>

<!-- Leaflet CSS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<!-- Leaflet JS -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<div class="max-w-[1100px] mx-auto px-3 sm:px-4 lg:px-6 py-4 sm:py-6">

    <!-- Page Header -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4 sm:mb-6">
        <div>
            <h4 class="text-lg sm:text-xl font-bold text-gray-900 flex items-center gap-2">
                <i class="bi bi-map-fill text-green-600"></i>Peta Jaringan
            </h4>
            <nav class="text-xs sm:text-sm text-gray-500 mt-1 flex items-center flex-wrap gap-1">
                <a href="/dashboard" class="hover:text-blue-600 transition">Dashboard</a>
                <span>/</span>
                <a href="/teknis" class="hover:text-blue-600 transition">Teknis</a>
                <span>/</span>
                <span class="text-gray-700 font-medium">Peta Jaringan</span>
            </nav>
        </div>
        <div class="flex gap-2 w-full sm:w-auto">
            <a href="/teknis/odp"
               class="inline-flex items-center justify-center gap-1.5 px-3 sm:px-4 py-2 border-2 border-blue-500 text-blue-500 rounded-lg text-sm font-medium bg-white hover:bg-blue-50 transition flex-1 sm:flex-initial">
                <i class="bi bi-router"></i>
                <span class="hidden xs:inline">Data</span> ODP
            </a>
            <button onclick="resetView()"
                    class="inline-flex items-center justify-center gap-1.5 px-3 sm:px-4 py-2 border-2 border-gray-200 text-gray-700 bg-white rounded-lg text-sm font-medium hover:bg-gray-50 transition flex-1 sm:flex-initial">
                <i class="bi bi-arrows-fullscreen"></i>
                <span class="hidden xs:inline">Reset</span>
            </button>
        </div>
    </div>

    <!-- Legend & Filter -->
    <div class="grid grid-cols-1 sm:grid-cols-[2fr_1fr] gap-2 sm:gap-3 mb-3">

        <!-- Legend + Toggle -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-3 sm:p-4">
            <div class="flex flex-wrap items-center gap-x-4 gap-y-2">
                <span class="font-semibold text-xs sm:text-sm text-gray-500">Legenda:</span>

                <div class="flex items-center gap-1.5">
                    <span class="w-3 h-3 rounded-full bg-blue-600 inline-block shrink-0"></span>
                    <span class="text-xs sm:text-sm text-gray-700">ODP (<?= count($koordinatODP) ?>)</span>
                </div>

                <div class="flex items-center gap-1.5">
                    <span class="w-3 h-3 rounded-full bg-green-600 inline-block shrink-0"></span>
                    <span class="text-xs sm:text-sm text-gray-700">Pelanggan (<?= count($koordinatPel) ?>)</span>
                </div>

                <div class="hidden sm:block w-px h-5 bg-gray-200"></div>

                <label class="flex items-center gap-1.5 text-xs sm:text-sm cursor-pointer select-none">
                    <input type="checkbox" id="toggleODP" checked onchange="toggleLayer('odp')"
                           class="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 cursor-pointer">
                    Tampilkan ODP
                </label>

                <label class="flex items-center gap-1.5 text-xs sm:text-sm cursor-pointer select-none">
                    <input type="checkbox" id="togglePelanggan" checked onchange="toggleLayer('pelanggan')"
                           class="w-4 h-4 rounded border-gray-300 text-green-600 focus:ring-green-500 cursor-pointer">
                    Tampilkan Pelanggan
                </label>
            </div>
        </div>

        <!-- Search -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-3 sm:p-4 flex items-center gap-2">
            <i class="bi bi-search text-gray-400 shrink-0"></i>
            <input type="text" id="searchMap"
                   placeholder="Cari ODP atau pelanggan..."
                   oninput="searchOnMap()"
                   class="flex-1 border-none outline-none text-sm bg-transparent text-gray-700 placeholder-gray-400 min-w-0">
            <button onclick="searchOnMap()"
                    class="sm:hidden shrink-0 p-1.5 bg-blue-50 text-blue-600 rounded-lg text-xs font-medium">
                Cari
            </button>
        </div>
    </div>

    <!-- Map Container -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 mb-4 sm:mb-6 overflow-hidden relative">
        <div id="map" class="w-full h-[300px] xs:h-[380px] sm:h-[440px] md:h-[520px] z-[1]"></div>
        <div id="mapLoading" class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center z-[2] hidden">
            <div class="w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto"></div>
            <p class="text-sm text-gray-500 mt-2">Memuat peta...</p>
        </div>
    </div>

    <!-- Stats Cards (Mobile Only) -->
    <div class="grid grid-cols-2 gap-2 sm:hidden mb-4">
        <div class="bg-blue-50 border border-blue-100 rounded-xl p-3 text-center">
            <div class="text-2xl font-bold text-blue-600"><?= count($koordinatODP) ?></div>
            <div class="text-xs text-blue-500 font-medium mt-0.5">Total ODP</div>
        </div>
        <div class="bg-green-50 border border-green-100 rounded-xl p-3 text-center">
            <div class="text-2xl font-bold text-green-600"><?= count($koordinatPel) ?></div>
            <div class="text-xs text-green-500 font-medium mt-0.5">Total Pelanggan</div>
        </div>
    </div>

    <!-- Data Panels -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-3 sm:gap-4">

        <!-- ODP List -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-100">
            <div class="px-3 sm:px-4 py-3 border-b border-gray-100 flex items-center gap-2">
                <span class="px-2 py-0.5 bg-blue-600 text-white rounded-md text-xs font-bold"><?= count($koordinatODP) ?></span>
                <h6 class="font-bold text-sm text-gray-700">Daftar ODP</h6>
            </div>
            <div class="max-h-[220px] sm:max-h-[280px] overflow-y-auto divide-y divide-gray-50">
                <?php if (empty($koordinatODP)): ?>
                    <div class="text-center text-gray-400 py-6 text-sm">
                        <i class="bi bi-router text-2xl block mb-2"></i>
                        Belum ada data ODP.
                    </div>
                <?php else: ?>
                    <?php foreach ($koordinatODP as $odp): ?>
                        <div onclick="flyTo(<?= $odp['latitude'] ?>, <?= $odp['longitude'] ?>, 16)"
                             class="px-3 sm:px-4 py-2.5 sm:py-3 cursor-pointer hover:bg-gray-50 active:bg-blue-50 transition-colors">
                            <div class="flex items-center gap-2">
                                <i class="bi bi-router-fill text-blue-600 shrink-0"></i>
                                <span class="text-xs sm:text-sm font-semibold text-gray-700 truncate flex-1 min-w-0"><?= htmlspecialchars($odp['nama_odp']) ?></span>
                                <span class="shrink-0 px-1.5 sm:px-2 py-0.5 bg-cyan-50 text-cyan-700 text-[10px] sm:text-xs font-bold rounded-md"><?= $odp['kapasitas'] ?? 16 ?> Port</span>
                            </div>
                            <div class="text-[10px] sm:text-xs text-gray-400 pl-5 sm:pl-6 font-mono mt-0.5">
                                <?= number_format((float)$odp['latitude'], 6) ?>,
                                <?= number_format((float)$odp['longitude'], 6) ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Pelanggan List -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-100">
            <div class="px-3 sm:px-4 py-3 border-b border-gray-100 flex items-center gap-2">
                <span class="px-2 py-0.5 bg-green-600 text-white rounded-md text-xs font-bold"><?= count($koordinatPel) ?></span>
                <h6 class="font-bold text-sm text-gray-700">Lokasi Pelanggan</h6>
            </div>
            <div class="max-h-[220px] sm:max-h-[280px] overflow-y-auto divide-y divide-gray-50">
                <?php if (empty($koordinatPel)): ?>
                    <div class="text-center text-gray-400 py-6 text-sm">
                        <i class="bi bi-people text-2xl block mb-2"></i>
                        Belum ada data koordinat pelanggan.
                    </div>
                <?php else: ?>
                    <?php foreach ($koordinatPel as $pel): ?>
                        <div onclick="flyTo(<?= $pel['latitude'] ?>, <?= $pel['longitude'] ?>, 17)"
                             class="px-3 sm:px-4 py-2.5 sm:py-3 cursor-pointer hover:bg-gray-50 active:bg-green-50 transition-colors">
                            <div class="flex items-center gap-2">
                                <i class="bi bi-person-fill text-green-600 shrink-0"></i>
                                <span class="text-xs sm:text-sm font-semibold text-gray-700 truncate flex-1 min-w-0"><?= htmlspecialchars($pel['nama_lengkap']) ?></span>
                            </div>
                            <div class="text-[10px] sm:text-xs text-gray-400 pl-5 sm:pl-6 mt-0.5 truncate">
                                <?= htmlspecialchars($pel['alamat'] ?? '') ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>

</div>

<!-- ============================================================
     Leaflet Override untuk mobile
     ============================================================ -->
<style>
/* Leaflet popup responsive */
.leaflet-popup-content-wrapper {
    border-radius: 10px !important;
    box-shadow: 0 4px 15px rgba(0,0,0,.15) !important;
}
.leaflet-popup-content {
    margin: 10px 14px !important;
    font-size: 13px !important;
    line-height: 1.5 !important;
}
/* Fix z-index agar tidak tertutup navbar */
.leaflet-top, .leaflet-bottom {
    z-index: 2 !important;
}
/* Custom breakpoint xs (480px) */
@media (min-width: 480px) {
    .xs\:inline { display: inline !important; }
    .xs\:h-$$380px$$ { height: 380px !important; }
}
/* Smooth scroll untuk list */
.divide-y > div {
    scroll-margin-top: 0;
}
</style>

<!-- ============================================================
     JAVASCRIPT
     ============================================================ -->
<script>
// ============================================================
// DATA DARI PHP
// ============================================================
const dataODP = <?= json_encode($koordinatODP) ?>;
const dataPel = <?= json_encode($koordinatPel) ?>;

// ============================================================
// DETEKSI DEVICE
// ============================================================
const isMobile = window.innerWidth < 640;
const isTablet = window.innerWidth >= 640 && window.innerWidth < 1024;

// ============================================================
// INISIALISASI PETA
// ============================================================
const defaultLat = dataODP.length > 0 ? parseFloat(dataODP[0].latitude) :
                   (dataPel.length > 0 ? parseFloat(dataPel[0].latitude) : -6.2);
const defaultLng = dataODP.length > 0 ? parseFloat(dataODP[0].longitude) :
                   (dataPel.length > 0 ? parseFloat(dataPel[0].longitude) : 106.81);

const defaultZoom = isMobile ? 11 : 13;

const map = L.map('map', {
    zoomControl: !isMobile,
    attributionControl: true,
}).setView([defaultLat, defaultLng], defaultZoom);

// Zoom control di kanan bawah untuk mobile
if (isMobile) {
    L.control.zoom({ position: 'bottomright' }).addTo(map);
}

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>',
    maxZoom: 19,
}).addTo(map);

// ============================================================
// ICON CUSTOM — ukuran berbeda untuk mobile vs desktop
// ============================================================
const odpSize = isMobile ? 22 : 28;
const pelSize = isMobile ? 16 : 22;

const iconODP = L.divIcon({
    html: `<div style="background:#2563eb;width:${odpSize}px;height:${odpSize}px;border-radius:50% 50% 50% 0;
                transform:rotate(-45deg);border:${isMobile ? 2 : 3}px solid white;box-shadow:0 2px 6px rgba(0,0,0,.3);">
           </div>`,
    iconSize: [odpSize, odpSize],
    iconAnchor: [odpSize / 2, odpSize],
    popupAnchor: [0, -odpSize - 2],
    className: '',
});

const iconPelanggan = L.divIcon({
    html: `<div style="background:#16a34a;width:${pelSize}px;height:${pelSize}px;border-radius:50%;
                border:${isMobile ? 2 : 3}px solid white;box-shadow:0 2px 6px rgba(0,0,0,.3);">
           </div>`,
    iconSize: [pelSize, pelSize],
    iconAnchor: [pelSize / 2, pelSize / 2],
    popupAnchor: [0, -pelSize / 2 - 2],
    className: '',
});

// ============================================================
// LAYER GROUPS
// ============================================================
const layerODP       = L.layerGroup().addTo(map);
const layerPelanggan = L.layerGroup().addTo(map);

dataODP.forEach(odp => {
    if (!odp.latitude || !odp.longitude) return;
    const lat = parseFloat(odp.latitude);
    const lng = parseFloat(odp.longitude);
    if (isNaN(lat) || isNaN(lng)) return;

    L.marker([lat, lng], { icon: iconODP })
     .bindPopup(`
        <div style="min-width:${isMobile ? '120px' : '160px'};">
          <strong style="font-size:${isMobile ? '12px' : '14px'}"><i class="bi bi-router-fill"></i> ${odp.nama_odp}</strong><br>
          <small style="color:#6b7280;">Kapasitas: ${odp.kapasitas ?? 16} Port</small><br>
          <small style="font-family:monospace;font-size:10px;">${lat.toFixed(6)}, ${lng.toFixed(6)}</small>
          <br>
          <a href="/teknis/odp/${odp.id ?? ''}" style="display:inline-block;margin-top:6px;padding:4px 10px;background:#2563eb;color:#fff;border-radius:6px;text-decoration:none;font-size:11px;font-weight:600;">Detail →</a>
        </div>
     `, { maxWidth: isMobile ? 200 : 300 })
     .addTo(layerODP);
});

dataPel.forEach(pel => {
    if (!pel.latitude || !pel.longitude) return;
    const lat = parseFloat(pel.latitude);
    const lng = parseFloat(pel.longitude);
    if (isNaN(lat) || isNaN(lng)) return;

    L.marker([lat, lng], { icon: iconPelanggan })
     .bindPopup(`
        <div style="min-width:${isMobile ? '120px' : '160px'};">
          <strong style="font-size:${isMobile ? '12px' : '14px'}"><i class="bi bi-person-fill"></i> ${pel.nama_lengkap}</strong><br>
          <small style="color:#6b7280;">${pel.alamat ?? ''}</small>
          <br>
          <a href="/pelanggan/${pel.id ?? ''}" style="display:inline-block;margin-top:6px;padding:4px 10px;background:#16a34a;color:#fff;border-radius:6px;text-decoration:none;font-size:11px;font-weight:600;">Detail →</a>
        </div>
     `, { maxWidth: isMobile ? 200 : 300 })
     .addTo(layerPelanggan);
});

// ============================================================
// FIT BOUNDS
// ============================================================
(function fitAll() {
    const allPoints = [
        ...dataODP.filter(o => o.latitude && o.longitude).map(o => [parseFloat(o.latitude), parseFloat(o.longitude)]),
        ...dataPel.filter(p => p.latitude && p.longitude).map(p => [parseFloat(p.latitude), parseFloat(p.longitude)]),
    ];
    if (allPoints.length > 1) {
        map.fitBounds(L.latLngBounds(allPoints).pad(isMobile ? 0.1 : 0.15));
    } else if (allPoints.length === 1) {
        map.setView(allPoints[0], 15);
    }
})();

// ============================================================
// FUNGSI TOGGLE LAYER
// ============================================================
function toggleLayer(type) {
    if (type === 'odp') {
        if (map.hasLayer(layerODP)) map.removeLayer(layerODP);
        else map.addLayer(layerODP);
    } else {
        if (map.hasLayer(layerPelanggan)) map.removeLayer(layerPelanggan);
        else map.addLayer(layerPelanggan);
    }
}

// ============================================================
// FLY TO — zoom lebih rendah di mobile
// ============================================================
function flyTo(lat, lng, zoom) {
    const targetZoom = isMobile ? Math.min(zoom, 15) : zoom;
    map.flyTo([lat, lng], targetZoom, { duration: 1.2 });

    // Buka popup marker terdekat (opsional)
    if (!isMobile) return;
    setTimeout(() => {
        map.eachLayer(layer => {
            if (layer instanceof L.Marker) {
                const pos = layer.getLatLng();
                if (Math.abs(pos.lat - lat) < 0.0001 && Math.abs(pos.lng - lng) < 0.0001) {
                    layer.openPopup();
                }
            }
        });
    }, 1300);
}

// ============================================================
// RESET VIEW
// ============================================================
function resetView() {
    const allPoints = [
        ...dataODP.filter(o => o.latitude && o.longitude).map(o => [parseFloat(o.latitude), parseFloat(o.longitude)]),
        ...dataPel.filter(p => p.latitude && p.longitude).map(p => [parseFloat(p.latitude), parseFloat(p.longitude)]),
    ];

    if (allPoints.length > 1) {
        map.fitBounds(L.latLngBounds(allPoints).pad(0.15));
    } else {
        map.setView([defaultLat, defaultLng], defaultZoom);
    }

    document.getElementById('toggleODP').checked = true;
    document.getElementById('togglePelanggan').checked = true;
    if (!map.hasLayer(layerODP)) map.addLayer(layerODP);
    if (!map.hasLayer(layerPelanggan)) map.addLayer(layerPelanggan);
}

// ============================================================
// SEARCH
// ============================================================
function searchOnMap() {
    const q = document.getElementById('searchMap').value.toLowerCase().trim();
    if (!q) return;

    const odp = dataODP.find(o => (o.nama_odp || '').toLowerCase().includes(q));
    if (odp && odp.latitude) {
        flyTo(parseFloat(odp.latitude), parseFloat(odp.longitude), 17);
        // Highlight list item di mobile
        if (isMobile) {
            document.querySelector('.lg\\:grid-cols-2')?.scrollIntoView({ behavior: 'smooth' });
        }
        return;
    }

    const pel = dataPel.find(p => (p.nama_lengkap || '').toLowerCase().includes(q));
    if (pel && pel.latitude) {
        flyTo(parseFloat(pel.latitude), parseFloat(pel.longitude), 17);
    }
}

// Enter key di search
document.getElementById('searchMap')?.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        searchOnMap();
    }
});

// ============================================================
// RESPONSIVE: Re-render saat resize
// ============================================================
let resizeTimeout;
window.addEventListener('resize', function() {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(function() {
        map.invalidateSize();
    }, 250);
});
</script>
