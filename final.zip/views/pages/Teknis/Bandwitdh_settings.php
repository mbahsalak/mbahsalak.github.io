<?php
/**
 * views/pages/Teknis/bandwidth_settings.php
 * Pengaturan koneksi MikroTik
 */
$appUrl = $_ENV['APP_URL'] ?? '';
?>

<div style="max-width:600px; margin:0 auto; padding:1.5rem 1rem;">

    <a href="<?= $appUrl ?>/teknis/bandwidth"
       style="display:inline-flex; align-items:center; gap:.4rem; color:#6b7280; font-size:.875rem; text-decoration:none; margin-bottom:1.25rem;">
        <i class="fa-solid fa-arrow-left"></i> Kembali ke Monitor Bandwidth
    </a>

    <!-- Flash -->
    <?php if (isset($_SESSION['flash'])): ?>
        <div style="padding:.75rem 1rem; border-radius:8px; font-size:.875rem; font-weight:500; margin-bottom:1rem;
            <?= $_SESSION['flash']['type'] === 'success'
                ? 'background:#f0fdf4; color:#166534; border:1px solid #bbf7d0;'
                : 'background:#fff1f2; color:#991b1b; border:1px solid #fecaca;' ?>">
            <i class="fa-solid fa-<?= $_SESSION['flash']['type'] === 'success' ? 'check-circle' : 'circle-exclamation' ?>" style="margin-right:.4rem;"></i>
            <?= htmlspecialchars($_SESSION['flash']['message']) ?>
        </div>
        <?php unset($_SESSION['flash']); ?>
    <?php endif; ?>

    <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1);">
        <div style="height:5px; background:#3b82f6; border-radius:12px 12px 0 0;"></div>
        <div style="padding:1.5rem; border-bottom:1px solid #e5e7eb;">
            <h2 style="margin:0; font-size:1.1rem; color:#374151; display:flex; align-items:center; gap:.5rem;">
                <i class="fa-solid fa-gear" style="color:#3b82f6;"></i> Pengaturan Koneksi MikroTik
            </h2>
            <p style="margin:.4rem 0 0; font-size:.8rem; color:#9ca3af;">
                Gunakan RouterOS API (port 8728). Pastikan API diaktifkan di <code>IP → Services</code> pada router.
            </p>
        </div>

        <form action="<?= $appUrl ?>/teknis/bandwidth/settings" method="POST" style="padding:1.5rem;">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">

            <!-- Host -->
            <div style="margin-bottom:1rem;">
                <label style="display:block; font-size:.75rem; font-weight:700; color:#6b7280; text-transform:uppercase; margin-bottom:.4rem;">
                    IP Address Router
                </label>
                <input type="text" name="mikrotik_host"
                       value="<?= htmlspecialchars($_ENV['MIKROTIK_HOST'] ?? '192.168.88.1') ?>"
                       placeholder="192.168.88.1" required
                       style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; font-family:monospace; box-sizing:border-box;">
                <small style="font-size:.7rem; color:#9ca3af;">IP atau hostname yang bisa dijangkau dari server ini.</small>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-bottom:1rem;">
                <!-- Username -->
                <div>
                    <label style="display:block; font-size:.75rem; font-weight:700; color:#6b7280; text-transform:uppercase; margin-bottom:.4rem;">
                        Username
                    </label>
                    <input type="text" name="mikrotik_user"
                           value="<?= htmlspecialchars($_ENV['MIKROTIK_USER'] ?? 'admin') ?>"
                           placeholder="admin" required
                           style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; box-sizing:border-box;">
                </div>

                <!-- Password -->
                <div>
                    <label style="display:block; font-size:.75rem; font-weight:700; color:#6b7280; text-transform:uppercase; margin-bottom:.4rem;">
                        Password
                    </label>
                    <div style="display:flex; gap:.4rem;">
                        <input type="password" name="mikrotik_pass" id="passInput"
                               value="<?= htmlspecialchars($_ENV['MIKROTIK_PASS'] ?? '') ?>"
                               placeholder="••••••••"
                               style="flex:1; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; box-sizing:border-box;">
                        <button type="button" onclick="togglePass()"
                                style="padding:.6rem .75rem; border:1.5px solid #e5e7eb; border-radius:8px; background:#fff; color:#6b7280; cursor:pointer;">
                            <i class="fa-solid fa-eye" id="passIcon"></i>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Max Bandwidth -->
            <div style="margin-bottom:1.5rem;">
                <label style="display:block; font-size:.75rem; font-weight:700; color:#6b7280; text-transform:uppercase; margin-bottom:.4rem;">
                    Kapasitas Bandwidth Maksimum (Mbps)
                </label>
                <input type="number" name="bandwidth_max_mbps" min="1" max="100000"
                       value="<?= htmlspecialchars((string)($_ENV['BANDWIDTH_MAX_MBPS'] ?? $_SESSION['bandwidth_max_mbps'] ?? 100)) ?>"
                       required
                       style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; box-sizing:border-box;">
                <small style="font-size:.7rem; color:#9ca3af;">
                    Digunakan untuk menghitung persentase utilisasi. Contoh: 100 untuk koneksi 100 Mbps.
                </small>
            </div>

            <!-- Info Box -->
            <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px; padding:.875rem 1rem; margin-bottom:1.5rem; font-size:.8rem; color:#1e40af;">
                <strong><i class="fa-solid fa-circle-info" style="margin-right:.4rem;"></i>Cara mengaktifkan RouterOS API:</strong>
                <ol style="margin:.4rem 0 0; padding-left:1.25rem; line-height:1.8;">
                    <li>Login ke Winbox atau WebFig</li>
                    <li>Buka <strong>IP → Services</strong></li>
                    <li>Aktifkan service <strong>api</strong> (port 8728)</li>
                    <li>Pastikan IP server ini diizinkan di kolom <strong>Available From</strong></li>
                </ol>
            </div>

            <!-- Actions -->
            <div style="display:flex; justify-content:flex-end; gap:.75rem; padding-top:1rem; border-top:1px solid #e5e7eb;">
                <a href="<?= $appUrl ?>/teknis/bandwidth"
                   style="padding:.6rem 1.25rem; border:1.5px solid #e5e7eb; border-radius:8px; text-decoration:none; color:#6b7280; font-weight:600; font-size:.875rem;">
                   Batal
                </a>
                <button type="submit"
                        style="padding:.6rem 1.5rem; background:#3b82f6; color:#fff; border:none; border-radius:8px; font-weight:600; cursor:pointer; font-size:.875rem; display:flex; align-items:center; gap:.4rem;">
                    <i class="fa-solid fa-plug"></i> Test & Simpan
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function togglePass() {
    const input = document.getElementById('passInput');
    const icon  = document.getElementById('passIcon');
    if (input.type === 'password') {
        input.type       = 'text';
        icon.className   = 'fa-solid fa-eye-slash';
    } else {
        input.type       = 'password';
        icon.className   = 'fa-solid fa-eye';
    }
}
</script>
