<?php
/**
 * views/pages/Teknis/bandwidth.php
 * Halaman Monitor Bandwidth MikroTik
 *
 * Variabel dari controller:
 *   $configured  bool
 *   $error       string|null
 *   $summary     array|null
 *   $identity    string
 *   $resource    array
 *   $maxMbps     int
 */

$appUrl = $_ENV['APP_URL'] ?? '';
?>

<div style="max-width:1100px; margin:0 auto; padding:1.5rem 1rem;">

    <!-- Page Header -->
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:.75rem; margin-bottom:1.5rem;">
        <div>
            <h4 style="margin:0 0 .25rem; font-weight:700; font-size:1.25rem; color:#111827;">
                <i class="fa-solid fa-wave-square" style="color:#3b82f6; margin-right:.5rem;"></i>Monitor Bandwidth
            </h4>
            <nav style="font-size:.8rem; color:#6b7280;">
                <a href="<?= $appUrl ?>/dashboard" style="color:#6b7280; text-decoration:none;">Dashboard</a>
                <span style="margin:0 .35rem;">/</span>
                <a href="<?= $appUrl ?>/teknis" style="color:#6b7280; text-decoration:none;">Teknis</a>
                <span style="margin:0 .35rem;">/</span>
                <span style="color:#374151;">Bandwidth</span>
            </nav>
        </div>
        <div style="display:flex; gap:.5rem; align-items:center;">
            <!-- Auto-refresh indicator -->
            <span id="refreshIndicator" style="font-size:.75rem; color:#6b7280; display:flex; align-items:center; gap:.3rem;">
                <span id="refreshDot" style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#9ca3af;"></span>
                <span id="refreshLabel">Menunggu...</span>
            </span>
            <a href="<?= $appUrl ?>/teknis/bandwidth/settings"
               style="display:inline-flex; align-items:center; gap:.35rem; padding:.4rem .9rem; border:1.5px solid #e5e7eb; color:#374151; border-radius:8px; font-size:.875rem; text-decoration:none; background:#fff;">
                <i class="fa-solid fa-gear"></i> Pengaturan
            </a>
            <a href="<?= $appUrl ?>/teknis"
               style="display:inline-flex; align-items:center; gap:.35rem; padding:.4rem .9rem; border:1.5px solid #e5e7eb; color:#6b7280; border-radius:8px; font-size:.875rem; text-decoration:none; background:#fff;">
                <i class="fa-solid fa-arrow-left"></i> Kembali
            </a>
        </div>
    </div>

    <?php if (!$configured): ?>
    <!-- ======== BELUM DIKONFIGURASI ======== -->
    <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); padding:3rem; text-align:center;">
        <div style="background:#eff6ff; border-radius:50%; display:inline-flex; padding:1.25rem; margin-bottom:1rem;">
            <i class="fa-solid fa-plug" style="font-size:2rem; color:#3b82f6;"></i>
        </div>
        <h5 style="margin:0 0 .5rem; font-weight:700; color:#374151;">Koneksi MikroTik Belum Dikonfigurasi</h5>
        <p style="margin:0 0 1.5rem; color:#6b7280; font-size:.875rem;">Atur host, username, dan password router MikroTik Anda untuk mulai memonitor bandwidth.</p>
        <a href="<?= $appUrl ?>/teknis/bandwidth/settings"
           style="display:inline-flex; align-items:center; gap:.4rem; padding:.6rem 1.5rem; background:#3b82f6; color:#fff; border-radius:8px; text-decoration:none; font-weight:600;">
            <i class="fa-solid fa-gear"></i> Atur Koneksi Sekarang
        </a>
    </div>

    <?php elseif ($error): ?>
    <!-- ======== ERROR KONEKSI ======== -->
    <div style="background:#fff1f2; border:1px solid #fecaca; border-radius:12px; padding:1.25rem 1.5rem; margin-bottom:1.25rem; display:flex; align-items:flex-start; gap:.75rem;">
        <i class="fa-solid fa-circle-exclamation" style="color:#ef4444; margin-top:.1rem;"></i>
        <div>
            <strong style="color:#991b1b; font-size:.875rem;">Gagal terhubung ke MikroTik</strong>
            <p style="margin:.2rem 0 0; font-size:.8rem; color:#b91c1c;"><?= htmlspecialchars($error) ?></p>
        </div>
        <a href="<?= $appUrl ?>/teknis/bandwidth/settings"
           style="margin-left:auto; padding:.35rem .9rem; border:1.5px solid #fca5a5; border-radius:8px; font-size:.8rem; color:#991b1b; text-decoration:none; white-space:nowrap; background:#fff;">
            Periksa Pengaturan
        </a>
    </div>

    <?php else: ?>
    <!-- ======== KONEKSI OK ======== -->

    <!-- Flash -->
    <?php if (isset($_SESSION['flash'])): ?>
        <div style="padding:.75rem 1rem; border-radius:8px; font-size:.875rem; font-weight:500; margin-bottom:1rem;
            <?= $_SESSION['flash']['type'] === 'success'
                ? 'background:#f0fdf4; color:#166534; border:1px solid #bbf7d0;'
                : 'background:#fff1f2; color:#991b1b; border:1px solid #fecaca;' ?>">
            <?= htmlspecialchars($_SESSION['flash']['message']) ?>
        </div>
        <?php unset($_SESSION['flash']); ?>
    <?php endif; ?>

    <!-- Router Info Bar -->
    <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); padding:.875rem 1.25rem; margin-bottom:1.25rem; display:flex; flex-wrap:wrap; gap:1.5rem; align-items:center;">
        <div style="display:flex; align-items:center; gap:.6rem;">
            <div style="background:#eff6ff; border-radius:8px; padding:.5rem;">
                <i class="fa-solid fa-server" style="color:#3b82f6;"></i>
            </div>
            <div>
                <div style="font-size:.7rem; color:#9ca3af; font-weight:600; text-transform:uppercase;">Router</div>
                <div style="font-weight:700; color:#111827; font-size:.95rem;" id="routerIdentity"><?= htmlspecialchars($identity) ?></div>
            </div>
        </div>

        <?php if (!empty($resource)): ?>
        <div>
            <div style="font-size:.7rem; color:#9ca3af; font-weight:600; text-transform:uppercase;">Platform</div>
            <div style="font-weight:600; color:#374151; font-size:.85rem;" id="routerBoard">
                <?= htmlspecialchars($resource['board-name'] ?? $resource['platform'] ?? '—') ?>
            </div>
        </div>
        <div>
            <div style="font-size:.7rem; color:#9ca3af; font-weight:600; text-transform:uppercase;">RouterOS</div>
            <div style="font-weight:600; color:#374151; font-size:.85rem;" id="routerVersion">
                <?= htmlspecialchars($resource['version'] ?? '—') ?>
            </div>
        </div>
        <div>
            <div style="font-size:.7rem; color:#9ca3af; font-weight:600; text-transform:uppercase;">Uptime</div>
            <div style="font-weight:600; color:#374151; font-size:.85rem;" id="routerUptime">
                <?= htmlspecialchars($resource['uptime'] ?? '—') ?>
            </div>
        </div>
        <div>
            <div style="font-size:.7rem; color:#9ca3af; font-weight:600; text-transform:uppercase;">CPU Load</div>
            <div style="font-weight:700; font-size:.85rem;" id="routerCpu"
                 style="color:<?= (int)($resource['cpu-load'] ?? 0) > 80 ? '#dc2626' : '#16a34a' ?>">
                <?= $resource['cpu-load'] ?? '0' ?>%
            </div>
        </div>
        <div>
            <div style="font-size:.7rem; color:#9ca3af; font-weight:600; text-transform:uppercase;">Free Memory</div>
            <div style="font-weight:600; color:#374151; font-size:.85rem;" id="routerMem">
                <?php
                    $freeMem  = (int)($resource['free-memory']  ?? 0);
                    $totalMem = (int)($resource['total-memory'] ?? 1);
                    echo MikrotikService::formatBytes($freeMem) . ' / ' . MikrotikService::formatBytes($totalMem);
                ?>
            </div>
        </div>
        <?php endif; ?>

        <div style="margin-left:auto; font-size:.75rem; color:#9ca3af;" id="lastUpdate">
            Update: <?= date('H:i:s') ?>
        </div>
    </div>

    <!-- Summary Cards -->
    <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(210px,1fr)); gap:1rem; margin-bottom:1.25rem;">

        <!-- Total Download -->
        <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); padding:1.25rem;">
            <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:.75rem;">
                <div style="background:#eff6ff; border-radius:8px; padding:.5rem;">
                    <i class="fa-solid fa-arrow-down" style="color:#3b82f6;"></i>
                </div>
                <span style="font-size:.7rem; color:#9ca3af; font-weight:600; text-transform:uppercase;">Download</span>
            </div>
            <div id="totalRxBps" style="font-size:1.6rem; font-weight:700; color:#2563eb; margin-bottom:.25rem;">
                <?= MikrotikService::formatBps($summary['total_rx_bps']) ?>
            </div>
            <div style="font-size:.75rem; color:#9ca3af;">
                Total: <span id="totalRxByte"><?= MikrotikService::formatBytes($summary['total_rx_byte']) ?></span>
            </div>
            <!-- Progress bar -->
            <div style="margin-top:.75rem; background:#e5e7eb; border-radius:4px; height:6px; overflow:hidden;">
                <?php $rxPct = MikrotikService::calcPercent($summary['total_rx_bps'], $maxMbps); ?>
                <div id="rxBar" style="height:100%; background:#3b82f6; border-radius:4px; width:<?= $rxPct ?>%; transition:width .5s;"></div>
            </div>
            <div style="font-size:.7rem; color:#9ca3af; margin-top:.2rem;">
                <span id="rxPct"><?= $rxPct ?>%</span> dari <?= $maxMbps ?> Mbps
            </div>
        </div>

        <!-- Total Upload -->
        <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); padding:1.25rem;">
            <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:.75rem;">
                <div style="background:#f0fdf4; border-radius:8px; padding:.5rem;">
                    <i class="fa-solid fa-arrow-up" style="color:#16a34a;"></i>
                </div>
                <span style="font-size:.7rem; color:#9ca3af; font-weight:600; text-transform:uppercase;">Upload</span>
            </div>
            <div id="totalTxBps" style="font-size:1.6rem; font-weight:700; color:#16a34a; margin-bottom:.25rem;">
                <?= MikrotikService::formatBps($summary['total_tx_bps']) ?>
            </div>
            <div style="font-size:.75rem; color:#9ca3af;">
                Total: <span id="totalTxByte"><?= MikrotikService::formatBytes($summary['total_tx_byte']) ?></span>
            </div>
            <div style="margin-top:.75rem; background:#e5e7eb; border-radius:4px; height:6px; overflow:hidden;">
                <?php $txPct = MikrotikService::calcPercent($summary['total_tx_bps'], $maxMbps); ?>
                <div id="txBar" style="height:100%; background:#16a34a; border-radius:4px; width:<?= $txPct ?>%; transition:width .5s;"></div>
            </div>
            <div style="font-size:.7rem; color:#9ca3af; margin-top:.2rem;">
                <span id="txPct"><?= $txPct ?>%</span> dari <?= $maxMbps ?> Mbps
            </div>
        </div>

        <!-- Active Interfaces -->
        <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); padding:1.25rem;">
            <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:.75rem;">
                <div style="background:#fffbeb; border-radius:8px; padding:.5rem;">
                    <i class="fa-solid fa-network-wired" style="color:#d97706;"></i>
                </div>
                <span style="font-size:.7rem; color:#9ca3af; font-weight:600; text-transform:uppercase;">Interface Aktif</span>
            </div>
            <div id="activeIfaceCount" style="font-size:1.6rem; font-weight:700; color:#d97706; margin-bottom:.25rem;">
                <?= count($summary['interfaces']) ?>
            </div>
            <div style="font-size:.75rem; color:#9ca3af;">interface running</div>
        </div>

        <!-- Combined Rate -->
        <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); padding:1.25rem;">
            <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:.75rem;">
                <div style="background:#fdf4ff; border-radius:8px; padding:.5rem;">
                    <i class="fa-solid fa-gauge-high" style="color:#9333ea;"></i>
                </div>
                <span style="font-size:.7rem; color:#9ca3af; font-weight:600; text-transform:uppercase;">Total Rate</span>
            </div>
            <div id="totalCombinedBps" style="font-size:1.6rem; font-weight:700; color:#9333ea; margin-bottom:.25rem;">
                <?= MikrotikService::formatBps($summary['total_rx_bps'] + $summary['total_tx_bps']) ?>
            </div>
            <div style="font-size:.75rem; color:#9ca3af;">↓ + ↑ gabungan</div>
        </div>

    </div>

    <!-- Grafik sederhana (sparkline bar) -->
    <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); padding:1.25rem; margin-bottom:1.25rem;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
            <h6 style="margin:0; font-weight:700; color:#374151; font-size:.9rem;">
                <i class="fa-solid fa-chart-area" style="color:#3b82f6; margin-right:.4rem;"></i>Grafik Bandwidth (60 detik terakhir)
            </h6>
            <div style="display:flex; gap:1rem; font-size:.75rem; color:#6b7280;">
                <span><span style="display:inline-block; width:10px; height:10px; background:#3b82f6; border-radius:2px; margin-right:.3rem;"></span>Download</span>
                <span><span style="display:inline-block; width:10px; height:10px; background:#16a34a; border-radius:2px; margin-right:.3rem;"></span>Upload</span>
            </div>
        </div>
        <canvas id="bwChart" style="width:100%; height:120px;"></canvas>
    </div>

    <!-- Tabel Per Interface -->
    <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); overflow:hidden;">
        <div style="padding:.875rem 1.25rem; border-bottom:1px solid #e5e7eb;">
            <h6 style="margin:0; font-weight:700; color:#374151;">
                <i class="fa-solid fa-list" style="color:#3b82f6; margin-right:.4rem;"></i>Detail Per Interface
            </h6>
        </div>
        <div style="overflow-x:auto;">
            <table style="width:100%; border-collapse:collapse; font-size:.875rem;">
                <thead>
                    <tr style="background:#f9fafb;">
                        <th style="padding:.75rem 1rem; text-align:left; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase;">Interface</th>
                        <th style="padding:.75rem 1rem; text-align:left; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase;">Tipe</th>
                        <th style="padding:.75rem 1rem; text-align:right; font-size:.7rem; font-weight:600; color:#3b82f6; text-transform:uppercase;">↓ Download</th>
                        <th style="padding:.75rem 1rem; text-align:right; font-size:.7rem; font-weight:600; color:#16a34a; text-transform:uppercase;">↑ Upload</th>
                        <th style="padding:.75rem 1rem; text-align:right; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase;">Total RX</th>
                        <th style="padding:.75rem 1rem; text-align:right; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase;">Total TX</th>
                        <th style="padding:.75rem 1rem; text-align:center; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase;">Utilisasi</th>
                    </tr>
                </thead>
                <tbody id="ifaceTableBody">
                    <?php foreach ($summary['interfaces'] as $iface): ?>
                    <tr style="border-top:1px solid #f3f4f6;"
                        onmouseover="this.style.background='#f9fafb'" onmouseout="this.style.background=''">
                        <td style="padding:.75rem 1rem;">
                            <div style="font-weight:600; color:#111827;"><?= htmlspecialchars($iface['name']) ?></div>
                            <?php if ($iface['comment']): ?>
                                <div style="font-size:.75rem; color:#9ca3af;"><?= htmlspecialchars($iface['comment']) ?></div>
                            <?php endif; ?>
                        </td>
                        <td style="padding:.75rem 1rem; color:#6b7280; font-size:.8rem;"><?= htmlspecialchars($iface['type']) ?></td>
                        <td style="padding:.75rem 1rem; text-align:right; font-weight:600; color:#2563eb; font-family:monospace;">
                            <?= MikrotikService::formatBps($iface['rx_bps']) ?>
                        </td>
                        <td style="padding:.75rem 1rem; text-align:right; font-weight:600; color:#16a34a; font-family:monospace;">
                            <?= MikrotikService::formatBps($iface['tx_bps']) ?>
                        </td>
                        <td style="padding:.75rem 1rem; text-align:right; color:#6b7280; font-size:.8rem; font-family:monospace;">
                            <?= MikrotikService::formatBytes($iface['rx_byte']) ?>
                        </td>
                        <td style="padding:.75rem 1rem; text-align:right; color:#6b7280; font-size:.8rem; font-family:monospace;">
                            <?= MikrotikService::formatBytes($iface['tx_byte']) ?>
                        </td>
                        <td style="padding:.75rem 1rem;">
                            <?php
                                $pct = MikrotikService::calcPercent($iface['rx_bps'] + $iface['tx_bps'], $maxMbps);
                                $barColor = $pct >= 80 ? '#ef4444' : ($pct >= 50 ? '#f59e0b' : '#16a34a');
                            ?>
                            <div style="background:#f3f4f6; border-radius:4px; height:6px; overflow:hidden;">
                                <div style="height:100%; background:<?= $barColor ?>; width:<?= $pct ?>%; border-radius:4px;"></div>
                            </div>
                            <div style="font-size:.7rem; color:#9ca3af; margin-top:.2rem; text-align:center;"><?= $pct ?>%</div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($summary['interfaces'])): ?>
                    <tr>
                        <td colspan="7" style="text-align:center; color:#9ca3af; padding:2rem;">
                            Tidak ada interface aktif
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php endif; ?>
</div>

<?php if ($configured && !$error): ?>
<script>
// ============================================================
// CONFIG
// ============================================================
const POLL_INTERVAL = 5000; // ms
const MAX_MBPS      = <?= (int)$maxMbps ?>;
const API_URL       = '<?= $appUrl ?>/teknis/bandwidth/api';

// ============================================================
// SPARKLINE DATA
// ============================================================
const MAX_POINTS = 60;
let rxHistory = [<?= $summary['total_rx_bps'] ?>];
let txHistory = [<?= $summary['total_tx_bps'] ?>];

// ============================================================
// CANVAS CHART
// ============================================================
const canvas  = document.getElementById('bwChart');
const ctx     = canvas.getContext('2d');

function resizeCanvas() {
    canvas.width  = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight || 120;
}
resizeCanvas();
window.addEventListener('resize', () => { resizeCanvas(); drawChart(); });

function drawChart() {
    const W = canvas.width, H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    const allVals = [...rxHistory, ...txHistory];
    const maxVal  = Math.max(...allVals, 1);

    function drawLine(data, color, fill) {
        if (data.length < 2) return;
        const step = W / (MAX_POINTS - 1);
        const offset = MAX_POINTS - data.length;

        ctx.beginPath();
        data.forEach((v, i) => {
            const x = (offset + i) * step;
            const y = H - (v / maxVal) * (H - 10) - 5;
            i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        });

        if (fill) {
            const lastX = (offset + data.length - 1) * step;
            ctx.lineTo(lastX, H);
            ctx.lineTo(offset * step, H);
            ctx.closePath();
            ctx.fillStyle = fill;
            ctx.fill();
        }

        ctx.strokeStyle = color;
        ctx.lineWidth   = 2;
        ctx.stroke();
    }

    // Grid lines
    ctx.strokeStyle = '#f3f4f6';
    ctx.lineWidth   = 1;
    for (let i = 1; i <= 3; i++) {
        const y = (H / 4) * i;
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }

    drawLine(rxHistory, '#3b82f6', 'rgba(59,130,246,.1)');
    drawLine(txHistory, '#16a34a', 'rgba(22,163,74,.1)');
}

drawChart();

// ============================================================
// FORMAT HELPERS (JS-side)
// ============================================================
function formatBps(bps) {
    if (bps >= 1e9) return (bps / 1e9).toFixed(2) + ' Gbps';
    if (bps >= 1e6) return (bps / 1e6).toFixed(2) + ' Mbps';
    if (bps >= 1e3) return (bps / 1e3).toFixed(2) + ' Kbps';
    return bps + ' bps';
}
function formatBytes(b) {
    if (b >= 1073741824) return (b / 1073741824).toFixed(2) + ' GB';
    if (b >= 1048576)    return (b / 1048576).toFixed(2)    + ' MB';
    if (b >= 1024)       return (b / 1024).toFixed(2)       + ' KB';
    return b + ' B';
}
function calcPct(bps, maxMbps) {
    return Math.min(((bps / (maxMbps * 1e6)) * 100).toFixed(1), 100);
}

// ============================================================
// POLLING
// ============================================================
const dot   = document.getElementById('refreshDot');
const label = document.getElementById('refreshLabel');

function setStatus(state) {
    if (state === 'loading') {
        dot.style.background   = '#f59e0b';
        label.textContent      = 'Memperbarui...';
    } else if (state === 'ok') {
        dot.style.background   = '#16a34a';
        label.textContent      = 'Live';
    } else {
        dot.style.background   = '#ef4444';
        label.textContent      = 'Error';
    }
}

function poll() {
    setStatus('loading');

    fetch(API_URL)
        .then(r => r.json())
        .then(data => {
            if (!data.ok) throw new Error(data.error || 'Unknown error');

            const s = data.summary;
            const r = data.resource || {};

            // Update summary cards
            document.getElementById('totalRxBps').textContent   = formatBps(s.total_rx_bps);
            document.getElementById('totalTxBps').textContent   = formatBps(s.total_tx_bps);
            document.getElementById('totalRxByte').textContent  = formatBytes(s.total_rx_byte);
            document.getElementById('totalTxByte').textContent  = formatBytes(s.total_tx_byte);
            document.getElementById('totalCombinedBps').textContent = formatBps(s.total_rx_bps + s.total_tx_bps);
            document.getElementById('activeIfaceCount').textContent = s.interfaces.length;

            // Progress bars
            const rxPct = calcPct(s.total_rx_bps, MAX_MBPS);
            const txPct = calcPct(s.total_tx_bps, MAX_MBPS);
            document.getElementById('rxBar').style.width = rxPct + '%';
            document.getElementById('txBar').style.width = txPct + '%';
            document.getElementById('rxPct').textContent = rxPct + '%';
            document.getElementById('txPct').textContent = txPct + '%';

            // Router info
            if (r.uptime)    document.getElementById('routerUptime').textContent  = r.uptime;
            if (r['cpu-load']) {
                const cpuEl = document.getElementById('routerCpu');
                cpuEl.textContent  = r['cpu-load'] + '%';
                cpuEl.style.color  = parseInt(r['cpu-load']) > 80 ? '#dc2626' : '#16a34a';
            }
            if (r['free-memory'] && r['total-memory']) {
                document.getElementById('routerMem').textContent =
                    formatBytes(parseInt(r['free-memory'])) + ' / ' + formatBytes(parseInt(r['total-memory']));
            }

            // Sparkline history
            rxHistory.push(s.total_rx_bps);
            txHistory.push(s.total_tx_bps);
            if (rxHistory.length > MAX_POINTS) rxHistory.shift();
            if (txHistory.length > MAX_POINTS) txHistory.shift();
            drawChart();

            // Interface table
            const tbody = document.getElementById('ifaceTableBody');
            if (s.interfaces.length > 0) {
                tbody.innerHTML = s.interfaces.map(iface => {
                    const pct      = calcPct(iface.rx_bps + iface.tx_bps, MAX_MBPS);
                    const barColor = pct >= 80 ? '#ef4444' : (pct >= 50 ? '#f59e0b' : '#16a34a');
                    return `
                    <tr style="border-top:1px solid #f3f4f6;"
                        onmouseover="this.style.background='#f9fafb'" onmouseout="this.style.background=''">
                        <td style="padding:.75rem 1rem;">
                            <div style="font-weight:600;color:#111827;">${iface.name}</div>
                            ${iface.comment ? `<div style="font-size:.75rem;color:#9ca3af;">${iface.comment}</div>` : ''}
                        </td>
                        <td style="padding:.75rem 1rem;color:#6b7280;font-size:.8rem;">${iface.type}</td>
                        <td style="padding:.75rem 1rem;text-align:right;font-weight:600;color:#2563eb;font-family:monospace;">${formatBps(iface.rx_bps)}</td>
                        <td style="padding:.75rem 1rem;text-align:right;font-weight:600;color:#16a34a;font-family:monospace;">${formatBps(iface.tx_bps)}</td>
                        <td style="padding:.75rem 1rem;text-align:right;color:#6b7280;font-size:.8rem;font-family:monospace;">${formatBytes(iface.rx_byte)}</td>
                        <td style="padding:.75rem 1rem;text-align:right;color:#6b7280;font-size:.8rem;font-family:monospace;">${formatBytes(iface.tx_byte)}</td>
                        <td style="padding:.75rem 1rem;">
                            <div style="background:#f3f4f6;border-radius:4px;height:6px;overflow:hidden;">
                                <div style="height:100%;background:${barColor};width:${pct}%;border-radius:4px;"></div>
                            </div>
                            <div style="font-size:.7rem;color:#9ca3af;margin-top:.2rem;text-align:center;">${pct}%</div>
                        </td>
                    </tr>`;
                }).join('');
            }

            document.getElementById('lastUpdate').textContent = 'Update: ' + new Date().toLocaleTimeString('id-ID');
            setStatus('ok');
        })
        .catch(err => {
            console.error('Polling error:', err);
            setStatus('error');
        });
}

// Mulai polling
setStatus('ok');
setInterval(poll, POLL_INTERVAL);
</script>
<?php endif; ?>
