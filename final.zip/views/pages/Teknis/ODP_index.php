<?php
/**
 * views/pages/ODP/index.php
 * Manajemen ODP — peta + tabel CRUD
 */
$appUrl = $_ENV['APP_URL'] ?? '';
$list   = $list ?? [];

$totalOdp       = count($list);
$totalPort      = array_sum(array_column($list, 'kapasitas'));
$totalTerpasang = array_sum(array_column($list, 'terpasang'));
$withCoord      = count(array_filter($list, fn($o) => $o['latitude'] && $o['longitude']));

$flash = $flash ?? ($_SESSION['flash'] ?? null);
unset($_SESSION['flash']);
?>

<!-- ===== HEADER ===== -->
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem;">
    <div>
        <h1 style="margin:0;font-size:1.25rem;font-weight:700;color:#1f2937;">
            <i class="fa-solid fa-diagram-project" style="color:#6366f1;margin-right:.5rem;"></i>
            Manajemen ODP
        </h1>
        <p style="margin:0;color:#6b7280;font-size:.875rem;">
            Optical Distribution Point — peta jaringan &amp; kapasitas port
        </p>
    </div>
    <button onclick="bukaModal('modalTambah')"
            style="padding:.6rem 1.25rem;border-radius:8px;border:none;cursor:pointer;font-weight:600;
                   background:#6366f1;color:#fff;display:inline-flex;align-items:center;gap:.4rem;font-size:.875rem;">
        <i class="fa-solid fa-plus"></i> Tambah ODP
    </button>
</div>

<!-- ===== FLASH ===== -->
<?php if (!empty($flash)): ?>
    <?php $isSuccess = ($flash['type'] ?? '') === 'success'; ?>
    <div style="display:flex;align-items:center;gap:.6rem;padding:.85rem 1rem;border-radius:8px;margin-bottom:1rem;
                background:<?= $isSuccess ? '#f0fdf4' : '#fef2f2' ?>;
                border:1px solid <?= $isSuccess ? '#bbf7d0' : '#fecaca' ?>;
                color:<?= $isSuccess ? '#15803d' : '#dc2626' ?>;font-size:.875rem;">
        <i class="fa-solid fa-<?= $isSuccess ? 'circle-check' : 'circle-xmark' ?>"></i>
        <span style="flex:1;"><?= htmlspecialchars($flash['message'] ?? '') ?></span>
        <button onclick="this.parentElement.remove()" style="background:none;border:none;cursor:pointer;color:inherit;font-size:1rem;padding:0;">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>
<?php endif; ?>

<!-- ===== STAT CARDS ===== -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem;margin-bottom:1.5rem;">
    <div style="background:#fff;box-shadow:0 1px 3px rgba(0,0,0,0.1);border-radius:12px;padding:1.25rem;border-left:4px solid #6366f1;">
        <div style="font-size:.8rem;color:#6b7280;margin-bottom:.4rem;">
            <i class="fa-solid fa-box" style="color:#6366f1;margin-right:.4rem;"></i>Total ODP
        </div>
        <div style="font-size:1.6rem;font-weight:700;color:#6366f1;"><?= $totalOdp ?></div>
    </div>
    <div style="background:#fff;box-shadow:0 1px 3px rgba(0,0,0,0.1);border-radius:12px;padding:1.25rem;border-left:4px solid #0ea5e9;">
        <div style="font-size:.8rem;color:#6b7280;margin-bottom:.4rem;">
            <i class="fa-solid fa-plug" style="color:#0ea5e9;margin-right:.4rem;"></i>Total Kapasitas
        </div>
        <div style="font-size:1.6rem;font-weight:700;color:#0ea5e9;"><?= $totalPort ?> <span style="font-size:.9rem;font-weight:400;">Port</span></div>
    </div>
    <div style="background:#fff;box-shadow:0 1px 3px rgba(0,0,0,0.1);border-radius:12px;padding:1.25rem;border-left:4px solid #10b981;">
        <div style="font-size:.8rem;color:#6b7280;margin-bottom:.4rem;">
            <i class="fa-solid fa-link" style="color:#10b981;margin-right:.4rem;"></i>Terpasang
        </div>
        <div style="font-size:1.6rem;font-weight:700;color:#10b981;"><?= $totalTerpasang ?> <span style="font-size:.9rem;font-weight:400;">Port</span></div>
    </div>
    <div style="background:#fff;box-shadow:0 1px 3px rgba(0,0,0,0.1);border-radius:12px;padding:1.25rem;border-left:4px solid #f59e0b;">
        <div style="font-size:.8rem;color:#6b7280;margin-bottom:.4rem;">
            <i class="fa-solid fa-location-dot" style="color:#f59e0b;margin-right:.4rem;"></i>Punya Koordinat
        </div>
        <div style="font-size:1.6rem;font-weight:700;color:#f59e0b;"><?= $withCoord ?></div>
    </div>
</div>

<!-- ===== PETA ===== -->
<div style="background:#fff;box-shadow:0 1px 3px rgba(0,0,0,0.1);border-radius:12px;margin-bottom:1.5rem;">
    <div style="padding:1rem 1.25rem;border-bottom:1px solid #e5e7eb;font-weight:700;font-size:.9rem;color:#374151;">
        <i class="fa-solid fa-map-location-dot" style="color:#6366f1;margin-right:.5rem;"></i>Peta Jaringan ODP
    </div>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <div id="petaOdp" style="width:100%;height:380px;z-index:0;"></div>
    <script>
    (function(){
        const map = L.map('petaOdp').setView([-6.200000, 106.810000], 13);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        const odps = <?= json_encode(array_values(array_filter($list, fn($o) => $o['latitude'] && $o['longitude']))) ?>;

        if (odps.length === 0) {
            document.getElementById('petaOdp').insertAdjacentHTML('afterend',
                '<p style="text-align:center;padding:.75rem;font-size:.8rem;color:#9ca3af;">Belum ada ODP dengan koordinat.</p>');
        }

        const bounds = [];
        odps.forEach(odp => {
            const used   = parseInt(odp.terpasang) || 0;
            const total  = parseInt(odp.kapasitas) || 16;
            const pct    = Math.round(used / total * 100);
            const color  = pct >= 100 ? '#ef4444' : pct >= 75 ? '#f59e0b' : '#10b981';

            const icon = L.divIcon({
                className: '',
                html: `<div style="width:14px;height:14px;border-radius:50%;background:${color};border:2px solid #fff;box-shadow:0 0 4px rgba(0,0,0,.35);"></div>`,
                iconSize: [14,14],
                iconAnchor: [7,7],
            });

            const marker = L.marker([odp.latitude, odp.longitude], {icon}).addTo(map);
            marker.bindPopup(
                `<b style="font-size:.85rem;">${odp.nama_odp}</b><br>
                 Kapasitas: <b>${used}/${total} Port</b><br>
                 <div style="background:#e5e7eb;border-radius:4px;height:6px;margin-top:4px;">
                   <div style="width:${Math.min(pct,100)}%;height:6px;border-radius:4px;background:${color};"></div>
                 </div>
                 <span style="font-size:.75rem;color:#6b7280;">${pct}% terpakai</span>`
            );
            bounds.push([odp.latitude, odp.longitude]);
        });

        if (bounds.length > 1) map.fitBounds(bounds, {padding:[30,30]});
    })();
    </script>
    <!-- Legenda -->
    <div style="padding:.6rem 1.25rem;border-top:1px solid #e5e7eb;display:flex;gap:1.5rem;font-size:.75rem;color:#6b7280;">
        <span><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#10b981;margin-right:.3rem;"></span>Tersedia</span>
        <span><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#f59e0b;margin-right:.3rem;"></span>&ge;75% Penuh</span>
        <span><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#ef4444;margin-right:.3rem;"></span>Penuh</span>
    </div>
</div>

<!-- ===== TABEL ===== -->
<div style="background:#fff;box-shadow:0 1px 3px rgba(0,0,0,0.1);border-radius:12px;">
    <div style="padding:1rem 1.25rem;border-bottom:1px solid #e5e7eb;
                display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.75rem;">
        <span style="font-weight:700;font-size:.9rem;">Daftar ODP</span>
        <input type="text" id="cariOdp" oninput="filterOdp()" placeholder="Cari nama ODP…"
               style="padding:.4rem .75rem;border:1px solid #e5e7eb;border-radius:8px;font-size:.8rem;outline:none;width:200px;">
    </div>
    <div style="overflow-x:auto;">
        <table style="width:100%;border-collapse:collapse;font-size:.875rem;">
            <thead>
                <tr style="background:#f9fafb;">
                    <th style="padding:.75rem 1rem;text-align:left;font-weight:600;color:#6b7280;width:40px;">#</th>
                    <th style="padding:.75rem 1rem;text-align:left;font-weight:600;color:#6b7280;">Nama ODP</th>
                    <th style="padding:.75rem 1rem;text-align:left;font-weight:600;color:#6b7280;">Koordinat</th>
                    <th style="padding:.75rem 1rem;text-align:center;font-weight:600;color:#6b7280;">Kapasitas</th>
                    <th style="padding:.75rem 1rem;text-align:center;font-weight:600;color:#6b7280;">Penggunaan</th>
                    <th style="padding:.75rem 1rem;text-align:center;font-weight:600;color:#6b7280;">Status</th>
                    <th style="padding:.75rem 1rem;text-align:center;font-weight:600;color:#6b7280;">Aksi</th>
                </tr>
            </thead>
            <tbody id="tbodyOdp">
            <?php if (empty($list)): ?>
                <tr>
                    <td colspan="7" style="padding:3rem;text-align:center;color:#6b7280;">
                        <i class="fa-solid fa-box-open" style="font-size:2rem;display:block;margin-bottom:.75rem;opacity:.3;"></i>
                        Belum ada data ODP. Klik <strong>Tambah ODP</strong> untuk memulai.
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($list as $i => $odp):
                    $used  = (int)($odp['terpasang'] ?? 0);
                    $total = (int)($odp['kapasitas']  ?? 16);
                    $pct   = $total > 0 ? round($used / $total * 100) : 0;
                    $penuh = $used >= $total;
                ?>
                <tr style="border-top:1px solid #e5e7eb;">
                    <td style="padding:.75rem 1rem;color:#6b7280;"><?= $i + 1 ?></td>
                    <td style="padding:.75rem 1rem;">
                        <div style="display:flex;align-items:center;gap:.6rem;">
                            <div style="background:#ede9fe;border-radius:8px;padding:.4rem .5rem;">
                                <i class="fa-solid fa-box" style="color:#6366f1;font-size:.85rem;"></i>
                            </div>
                            <span style="font-weight:600;" ><?= htmlspecialchars($odp['nama_odp']) ?></span>
                        </div>
                    </td>
                    <td style="padding:.75rem 1rem;font-size:.78rem;font-family:monospace;color:#6b7280;">
                        <?php if ($odp['latitude'] && $odp['longitude']): ?>
                            <i class="fa-solid fa-location-dot" style="color:#f59e0b;margin-right:.3rem;"></i>
                            <?= number_format((float)$odp['latitude'], 6) ?>, <?= number_format((float)$odp['longitude'], 6) ?>
                        <?php else: ?>
                            <span style="color:#d1d5db;">— belum diset —</span>
                        <?php endif; ?>
                    </td>
                    <td style="padding:.75rem 1rem;text-align:center;">
                        <span style="padding:.2rem .6rem;border-radius:99px;font-size:.75rem;font-weight:600;background:#e0f2fe;color:#0369a1;">
                            <?= $total ?> Port
                        </span>
                    </td>
                    <td style="padding:.75rem 1rem;text-align:center;">
                        <div style="font-size:.78rem;margin-bottom:.3rem;font-weight:600;"><?= $used ?>/<?= $total ?></div>
                        <div style="background:#e5e7eb;border-radius:4px;height:6px;width:80px;margin:0 auto;">
                            <div style="width:<?= min($pct,100) ?>%;height:6px;border-radius:4px;
                                        background:<?= $penuh ? '#ef4444' : ($pct >= 75 ? '#f59e0b' : '#10b981') ?>;"></div>
                        </div>
                    </td>
                    <td style="padding:.75rem 1rem;text-align:center;">
                        <?php if ($penuh): ?>
                            <span style="padding:.25rem .7rem;border-radius:99px;font-size:.75rem;font-weight:600;background:#fee2e2;color:#dc2626;">
                                <i class="fa-solid fa-circle-xmark" style="margin-right:.3rem;"></i>Penuh
                            </span>
                        <?php else: ?>
                            <span style="padding:.25rem .7rem;border-radius:99px;font-size:.75rem;font-weight:600;background:#dcfce7;color:#16a34a;">
                                <i class="fa-solid fa-circle-check" style="margin-right:.3rem;"></i>Tersedia
                            </span>
                        <?php endif; ?>
                    </td>
                    <td style="padding:.75rem 1rem;text-align:center;">
                        <div style="display:inline-flex;gap:.35rem;">
                            <button onclick='editODP(<?= htmlspecialchars(json_encode($odp), ENT_QUOTES) ?>)'
                                    title="Edit"
                                    style="padding:.35rem .6rem;border-radius:6px;border:1px solid #c7d2fe;background:#eef2ff;color:#4f46e5;cursor:pointer;font-size:.8rem;">
                                <i class="fa-solid fa-pencil"></i>
                            </button>
                            <button onclick="hapusODP(<?= $odp['id'] ?>, '<?= htmlspecialchars($odp['nama_odp'], ENT_QUOTES) ?>')"
                                    title="Hapus"
                                    style="padding:.35rem .6rem;border-radius:6px;border:1px solid #fecaca;background:#fff1f2;color:#dc2626;cursor:pointer;font-size:.8rem;">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if (!empty($list)): ?>
    <div style="padding:.6rem 1.25rem;border-top:1px solid #e5e7eb;font-size:.78rem;color:#6b7280;">
        <?= $totalOdp ?> ODP &bull; <?= $totalPort ?> total port &bull; <?= $withCoord ?> terpetakan
    </div>
    <?php endif; ?>
</div>


<!-- ==================== MODAL TAMBAH ==================== -->
<div id="modalTambah" onclick="backdropTutup(event,'modalTambah')"
     style="display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.45);
            display:none;align-items:center;justify-content:center;padding:1rem;">
    <div style="background:#fff;border-radius:14px;width:100%;max-width:460px;box-shadow:0 20px 60px rgba(0,0,0,.2);" onclick="event.stopPropagation()">
        <form method="POST" action="<?= $appUrl ?>/odp/store">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
            <div style="padding:1.25rem 1.5rem;border-bottom:1px solid #e5e7eb;display:flex;justify-content:space-between;align-items:center;">
                <span style="font-weight:700;font-size:.95rem;"><i class="fa-solid fa-plus" style="color:#6366f1;margin-right:.5rem;"></i>Tambah ODP Baru</span>
                <button type="button" onclick="tutupModal('modalTambah')" style="background:none;border:none;font-size:1.2rem;cursor:pointer;color:#9ca3af;">&times;</button>
            </div>
            <div style="padding:1.25rem 1.5rem;display:flex;flex-direction:column;gap:1rem;">
                <div>
                    <label style="display:block;font-size:.8rem;font-weight:600;margin-bottom:.4rem;">Nama ODP <span style="color:#ef4444;">*</span></label>
                    <input type="text" name="nama_odp" required placeholder="Contoh: ODP-A-001"
                           style="width:100%;padding:.55rem .75rem;border:1px solid #d1d5db;border-radius:8px;font-size:.875rem;box-sizing:border-box;outline:none;">
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem;">
                    <div>
                        <label style="display:block;font-size:.8rem;font-weight:600;margin-bottom:.4rem;">Latitude</label>
                        <input type="number" name="latitude" step="0.00000001" placeholder="-6.20000000"
                               style="width:100%;padding:.55rem .75rem;border:1px solid #d1d5db;border-radius:8px;font-size:.875rem;font-family:monospace;box-sizing:border-box;outline:none;">
                    </div>
                    <div>
                        <label style="display:block;font-size:.8rem;font-weight:600;margin-bottom:.4rem;">Longitude</label>
                        <input type="number" name="longitude" step="0.00000001" placeholder="106.81000000"
                               style="width:100%;padding:.55rem .75rem;border:1px solid #d1d5db;border-radius:8px;font-size:.875rem;font-family:monospace;box-sizing:border-box;outline:none;">
                    </div>
                </div>
                <div>
                    <label style="display:block;font-size:.8rem;font-weight:600;margin-bottom:.4rem;">Kapasitas Port</label>
                    <select name="kapasitas" style="width:100%;padding:.55rem .75rem;border:1px solid #d1d5db;border-radius:8px;font-size:.875rem;box-sizing:border-box;outline:none;">
                        <option value="8">8 Port</option>
                        <option value="16" selected>16 Port</option>
                        <option value="24">24 Port</option>
                        <option value="32">32 Port</option>
                    </select>
                </div>
            </div>
            <div style="padding:1rem 1.5rem;border-top:1px solid #e5e7eb;display:flex;justify-content:flex-end;gap:.5rem;">
                <button type="button" onclick="tutupModal('modalTambah')"
                        style="padding:.5rem 1rem;border-radius:8px;border:1px solid #d1d5db;background:#fff;cursor:pointer;font-size:.875rem;">Batal</button>
                <button type="submit"
                        style="padding:.5rem 1rem;border-radius:8px;border:none;background:#6366f1;color:#fff;cursor:pointer;font-weight:600;font-size:.875rem;">
                    <i class="fa-solid fa-save" style="margin-right:.3rem;"></i>Simpan
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ==================== MODAL EDIT ==================== -->
<div id="modalEdit" onclick="backdropTutup(event,'modalEdit')"
     style="display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.45);
            align-items:center;justify-content:center;padding:1rem;">
    <div style="background:#fff;border-radius:14px;width:100%;max-width:460px;box-shadow:0 20px 60px rgba(0,0,0,.2);" onclick="event.stopPropagation()">
        <form method="POST" id="formEditODP">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
            <input type="hidden" name="id" id="editId">
            <div style="padding:1.25rem 1.5rem;border-bottom:1px solid #e5e7eb;display:flex;justify-content:space-between;align-items:center;">
                <span style="font-weight:700;font-size:.95rem;"><i class="fa-solid fa-pencil" style="color:#f59e0b;margin-right:.5rem;"></i>Edit ODP</span>
                <button type="button" onclick="tutupModal('modalEdit')" style="background:none;border:none;font-size:1.2rem;cursor:pointer;color:#9ca3af;">&times;</button>
            </div>
            <div style="padding:1.25rem 1.5rem;display:flex;flex-direction:column;gap:1rem;">
                <div>
                    <label style="display:block;font-size:.8rem;font-weight:600;margin-bottom:.4rem;">Nama ODP <span style="color:#ef4444;">*</span></label>
                    <input type="text" name="nama_odp" id="editNama" required
                           style="width:100%;padding:.55rem .75rem;border:1px solid #d1d5db;border-radius:8px;font-size:.875rem;box-sizing:border-box;outline:none;">
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem;">
                    <div>
                        <label style="display:block;font-size:.8rem;font-weight:600;margin-bottom:.4rem;">Latitude</label>
                        <input type="number" name="latitude" id="editLat" step="0.00000001"
                               style="width:100%;padding:.55rem .75rem;border:1px solid #d1d5db;border-radius:8px;font-size:.875rem;font-family:monospace;box-sizing:border-box;outline:none;">
                    </div>
                    <div>
                        <label style="display:block;font-size:.8rem;font-weight:600;margin-bottom:.4rem;">Longitude</label>
                        <input type="number" name="longitude" id="editLng" step="0.00000001"
                               style="width:100%;padding:.55rem .75rem;border:1px solid #d1d5db;border-radius:8px;font-size:.875rem;font-family:monospace;box-sizing:border-box;outline:none;">
                    </div>
                </div>
                <div>
                    <label style="display:block;font-size:.8rem;font-weight:600;margin-bottom:.4rem;">Kapasitas Port</label>
                    <select name="kapasitas" id="editKap" style="width:100%;padding:.55rem .75rem;border:1px solid #d1d5db;border-radius:8px;font-size:.875rem;box-sizing:border-box;outline:none;">
                        <option value="8">8 Port</option>
                        <option value="16">16 Port</option>
                        <option value="24">24 Port</option>
                        <option value="32">32 Port</option>
                    </select>
                </div>
            </div>
            <div style="padding:1rem 1.5rem;border-top:1px solid #e5e7eb;display:flex;justify-content:flex-end;gap:.5rem;">
                <button type="button" onclick="tutupModal('modalEdit')"
                        style="padding:.5rem 1rem;border-radius:8px;border:1px solid #d1d5db;background:#fff;cursor:pointer;font-size:.875rem;">Batal</button>
                <button type="submit"
                        style="padding:.5rem 1rem;border-radius:8px;border:none;background:#f59e0b;color:#fff;cursor:pointer;font-weight:600;font-size:.875rem;">
                    <i class="fa-solid fa-save" style="margin-right:.3rem;"></i>Update
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ==================== MODAL HAPUS ==================== -->
<div id="modalHapus" onclick="backdropTutup(event,'modalHapus')"
     style="display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.45);
            align-items:center;justify-content:center;padding:1rem;">
    <div style="background:#fff;border-radius:14px;width:100%;max-width:360px;box-shadow:0 20px 60px rgba(0,0,0,.2);" onclick="event.stopPropagation()">
        <form method="POST" id="formHapusODP">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
            <div style="padding:2rem 1.5rem;text-align:center;">
                <div style="background:#fee2e2;border-radius:50%;width:56px;height:56px;display:inline-flex;align-items:center;justify-content:center;margin-bottom:1rem;">
                    <i class="fa-solid fa-trash" style="color:#ef4444;font-size:1.4rem;"></i>
                </div>
                <h3 style="margin:0 0 .5rem;font-size:1rem;font-weight:700;">Hapus ODP?</h3>
                <p style="margin:0;font-size:.875rem;color:#6b7280;">
                    ODP <strong id="hapusNama"></strong> akan dihapus permanen.
                </p>
            </div>
            <div style="padding:1rem 1.5rem;border-top:1px solid #e5e7eb;display:flex;justify-content:center;gap:.5rem;">
                <button type="button" onclick="tutupModal('modalHapus')"
                        style="padding:.5rem 1.25rem;border-radius:8px;border:1px solid #d1d5db;background:#fff;cursor:pointer;font-size:.875rem;">Batal</button>
                <button type="submit"
                        style="padding:.5rem 1.25rem;border-radius:8px;border:none;background:#ef4444;color:#fff;cursor:pointer;font-weight:600;font-size:.875rem;">
                    Ya, Hapus
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function bukaModal(id) {
    const el = document.getElementById(id);
    el.style.display = 'flex';
}
function tutupModal(id) {
    document.getElementById(id).style.display = 'none';
}
function backdropTutup(e, id) {
    if (e.target === document.getElementById(id)) tutupModal(id);
}

function editODP(odp) {
    document.getElementById('editId').value   = odp.id;
    document.getElementById('editNama').value = odp.nama_odp;
    document.getElementById('editLat').value  = odp.latitude  ?? '';
    document.getElementById('editLng').value  = odp.longitude ?? '';
    document.getElementById('editKap').value  = odp.kapasitas ?? 16;
    document.getElementById('formEditODP').action = `<?= $appUrl ?>/odp/edit/${odp.id}`;
    bukaModal('modalEdit');
}

function hapusODP(id, nama) {
    document.getElementById('hapusNama').textContent = nama;
    document.getElementById('formHapusODP').action   = `<?= $appUrl ?>/odp/hapus/${id}`;
    bukaModal('modalHapus');
}

function filterOdp() {
    const q = document.getElementById('cariOdp').value.toLowerCase();
    document.querySelectorAll('#tbodyOdp .odp-row').forEach(row => {
        const name = row.querySelector('.odp-name')?.textContent.toLowerCase() ?? '';
        row.style.display = name.includes(q) ? '' : 'none';
    });
}
</script>
