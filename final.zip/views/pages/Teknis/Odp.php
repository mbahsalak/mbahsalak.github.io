<?php
/**
 * views/pages/Teknis/odp.php
 * Halaman Data ODP (Optical Distribution Point)
 */
?>

<div style="max-width:1100px; margin:0 auto; padding:1.5rem 1rem;">

    <!-- Header -->
    <div style="background:#fff; padding:1rem 1.25rem; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:.75rem; margin-bottom:1.25rem;">
        <div>
            <h3 style="margin:0 0 .2rem; font-weight:700; color:#374151; font-size:1.1rem;">
                <i class="bi bi-router-fill" style="color:#3b82f6; margin-right:.4rem;"></i>Data ODP
            </h3>
            <p style="margin:0; font-size:.75rem; color:#9ca3af;">Optical Distribution Point — Manajemen kapasitas port fiber optik.</p>
        </div>
        <div style="display:flex; gap:.5rem;">
            <a href="/teknis/maps" style="display:inline-flex; align-items:center; gap:.35rem; padding:.4rem .9rem; border:1.5px solid #16a34a; color:#16a34a; border-radius:8px; font-size:.875rem; text-decoration:none; background:#fff;">
                <i class="bi bi-map"></i> Lihat Peta
            </a>
            <button onclick="bukaModalTambah()" style="display:inline-flex; align-items:center; gap:.35rem; padding:.4rem .9rem; background:#2563eb; color:#fff; border:none; border-radius:8px; font-size:.875rem; cursor:pointer;">
                <i class="bi bi-plus-circle"></i> Tambah ODP
            </button>
        </div>
    </div>

    <!-- Flash Message -->
    <?php if (isset($_SESSION['flash'])): ?>
        <div style="padding:.75rem 1rem; border-radius:8px; font-size:.875rem; font-weight:500; margin-bottom:1rem;
            <?= $_SESSION['flash']['type'] === 'success'
                ? 'background:#f0fdf4; color:#166534; border:1px solid #bbf7d0;'
                : 'background:#fff1f2; color:#991b1b; border:1px solid #fecaca;' ?>">
            <i class="bi bi-<?= $_SESSION['flash']['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>" style="margin-right:.4rem;"></i>
            <?= htmlspecialchars($_SESSION['flash']['message']) ?>
        </div>
        <?php unset($_SESSION['flash']); ?>
    <?php endif; ?>

    <!-- Stats -->
    <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:1rem; margin-bottom:1.25rem;">
        <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); padding:1rem; text-align:center;">
            <div style="font-size:1.6rem; font-weight:700; color:#2563eb;"><?= count($odps) ?></div>
            <div style="font-size:.75rem; color:#9ca3af; margin-top:.25rem;">Total ODP</div>
        </div>
        <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); padding:1rem; text-align:center;">
            <?php $totalKapasitas = array_sum(array_column($odps, 'kapasitas')); ?>
            <div style="font-size:1.6rem; font-weight:700; color:#0891b2;"><?= $totalKapasitas ?></div>
            <div style="font-size:.75rem; color:#9ca3af; margin-top:.25rem;">Total Port</div>
        </div>
        <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); padding:1rem; text-align:center;">
            <?php $odpsGeo = array_filter($odps, fn($o) => $o['latitude'] && $o['longitude']); ?>
            <div style="font-size:1.6rem; font-weight:700; color:#16a34a;"><?= count($odpsGeo) ?></div>
            <div style="font-size:.75rem; color:#9ca3af; margin-top:.25rem;">Punya Koordinat</div>
        </div>
    </div>

    <!-- Tabel -->
    <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); overflow:hidden;">
        <div style="padding:.75rem 1.25rem; border-bottom:1px solid #e5e7eb; display:flex; justify-content:space-between; align-items:center; gap:.75rem;">
            <h6 style="margin:0; font-weight:700; color:#374151;">Daftar Optical Distribution Point</h6>
            <input type="text" id="searchODP" oninput="filterODP()"
                   placeholder="Cari ODP..."
                   style="font-size:.875rem; border:1.5px solid #e5e7eb; border-radius:8px; padding:.35rem .75rem; width:12rem; outline:none;">
        </div>
        <div style="overflow-x:auto;">
            <table style="width:100%; border-collapse:collapse; font-size:.875rem;" id="tableODP">
                <thead>
                    <tr style="background:#f9fafb;">
                        <th style="padding:.75rem 1rem; text-align:left; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase; width:2.5rem;">#</th>
                        <th style="padding:.75rem 1rem; text-align:left; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase;">Nama ODP</th>
                        <th style="padding:.75rem 1rem; text-align:left; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase;">Latitude</th>
                        <th style="padding:.75rem 1rem; text-align:left; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase;">Longitude</th>
                        <th style="padding:.75rem 1rem; text-align:center; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase;">Kapasitas</th>
                        <th style="padding:.75rem 1rem; text-align:center; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase;">Status</th>
                        <th style="padding:.75rem 1rem; text-align:center; font-size:.7rem; font-weight:600; color:#6b7280; text-transform:uppercase;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($odps)): ?>
                        <tr>
                            <td colspan="7" style="text-align:center; color:#9ca3af; padding:3rem 1rem;">
                                <i class="bi bi-router" style="font-size:2.5rem; display:block; margin-bottom:.5rem; opacity:.3;"></i>
                                Belum ada data ODP.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($odps as $i => $odp): ?>
                            <tr class="odp-row" style="border-top:1px solid #f3f4f6;"
                                onmouseover="this.style.background='#f9fafb'" onmouseout="this.style.background=''">
                                <td style="padding:.75rem 1rem; color:#9ca3af;"><?= $i + 1 ?></td>
                                <td style="padding:.75rem 1rem;">
                                    <div style="display:flex; align-items:center; gap:.5rem;">
                                        <div style="background:#eff6ff; border-radius:8px; padding:.35rem;">
                                            <i class="bi bi-router-fill" style="color:#3b82f6;"></i>
                                        </div>
                                        <span class="odp-name" style="font-weight:600; color:#111827;"><?= htmlspecialchars($odp['nama_odp']) ?></span>
                                    </div>
                                </td>
                                <td style="padding:.75rem 1rem; color:#9ca3af; font-family:monospace; font-size:.75rem;">
                                    <?= $odp['latitude'] ? number_format((float)$odp['latitude'], 8) : '—' ?>
                                </td>
                                <td style="padding:.75rem 1rem; color:#9ca3af; font-family:monospace; font-size:.75rem;">
                                    <?= $odp['longitude'] ? number_format((float)$odp['longitude'], 8) : '—' ?>
                                </td>
                                <td style="padding:.75rem 1rem; text-align:center;">
                                    <span style="padding:.2rem .5rem; background:#ecfeff; color:#0e7490; font-size:.75rem; font-weight:700; border-radius:6px;"><?= $odp['kapasitas'] ?? 16 ?> Port</span>
                                </td>
                                <td style="padding:.75rem 1rem; text-align:center;">
                                    <?php if ($odp['latitude'] && $odp['longitude']): ?>
                                        <span style="padding:.2rem .5rem; background:#f0fdf4; color:#166534; font-size:.75rem; font-weight:700; border-radius:6px;">
                                            <i class="bi bi-geo-alt-fill" style="margin-right:.2rem;"></i>Terpetakan
                                        </span>
                                    <?php else: ?>
                                        <span style="padding:.2rem .5rem; background:#fffbeb; color:#92400e; font-size:.75rem; font-weight:700; border-radius:6px;">
                                            <i class="bi bi-geo-alt" style="margin-right:.2rem;"></i>Belum Ada Koordinat
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding:.75rem 1rem; text-align:center;">
                                    <div style="display:flex; justify-content:center; gap:.25rem;">
                                        <?php if ($odp['latitude'] && $odp['longitude']): ?>
                                            <a href="/teknis/maps" title="Lihat di Peta"
                                               style="padding:.35rem; color:#16a34a; border-radius:8px; text-decoration:none; display:inline-flex;"
                                               onmouseover="this.style.background='#f0fdf4'" onmouseout="this.style.background=''">
                                                <i class="bi bi-map"></i>
                                            </a>
                                        <?php endif; ?>
                                        <button title="Edit ODP"
                                                onclick='editODP(<?= htmlspecialchars(json_encode($odp), ENT_QUOTES) ?>)'
                                                style="padding:.35rem; color:#2563eb; background:none; border:none; border-radius:8px; cursor:pointer;"
                                                onmouseover="this.style.background='#eff6ff'" onmouseout="this.style.background=''">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button title="Hapus ODP"
                                                onclick="hapusODP(<?= $odp['id'] ?>, '<?= htmlspecialchars($odp['nama_odp'], ENT_QUOTES) ?>')"
                                                style="padding:.35rem; color:#dc2626; background:none; border:none; border-radius:8px; cursor:pointer;"
                                                onmouseover="this.style.background='#fff1f2'" onmouseout="this.style.background=''">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if (!empty($odps)): ?>
            <div style="padding:.5rem 1.25rem; border-top:1px solid #e5e7eb; font-size:.75rem; color:#9ca3af;">
                Menampilkan <?= count($odps) ?> ODP
            </div>
        <?php endif; ?>
    </div>

</div>

<!-- ===================== MODAL TAMBAH ===================== -->
<div id="modalTambah" style="display:none; position:fixed; inset:0; z-index:50; align-items:center; justify-content:center; background:rgba(0,0,0,.4); padding:1rem;">
    <div style="background:#fff; border-radius:12px; box-shadow:0 10px 25px rgba(0,0,0,.15); width:100%; max-width:28rem;">
        <form method="POST" action="/teknis/odp/simpan">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
            <div style="display:flex; justify-content:space-between; align-items:center; padding:1rem 1.25rem; border-bottom:1px solid #e5e7eb;">
                <h6 style="margin:0; font-weight:700; color:#374151;">
                    <i class="bi bi-plus-circle" style="color:#3b82f6; margin-right:.4rem;"></i>Tambah ODP Baru
                </h6>
                <button type="button" onclick="tutupModal('modalTambah')" style="background:none; border:none; font-size:1.25rem; color:#9ca3af; cursor:pointer; line-height:1;">&times;</button>
            </div>
            <div style="padding:1.25rem; display:flex; flex-direction:column; gap:1rem;">
                <div>
                    <label style="display:block; font-size:.75rem; font-weight:600; color:#6b7280; margin-bottom:.3rem;">Nama ODP <span style="color:#ef4444;">*</span></label>
                    <input type="text" name="nama_odp" required placeholder="Contoh: ODP-A-001"
                           style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; box-sizing:border-box;">
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:.75rem;">
                    <div>
                        <label style="display:block; font-size:.75rem; font-weight:600; color:#6b7280; margin-bottom:.3rem;">Latitude</label>
                        <input type="number" name="latitude" step="0.00000001" placeholder="-6.20000000"
                               style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; font-family:monospace; box-sizing:border-box;">
                    </div>
                    <div>
                        <label style="display:block; font-size:.75rem; font-weight:600; color:#6b7280; margin-bottom:.3rem;">Longitude</label>
                        <input type="number" name="longitude" step="0.00000001" placeholder="106.81000000"
                               style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; font-family:monospace; box-sizing:border-box;">
                    </div>
                </div>
                <div>
                    <label style="display:block; font-size:.75rem; font-weight:600; color:#6b7280; margin-bottom:.3rem;">Kapasitas Port</label>
                    <select name="kapasitas" style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; box-sizing:border-box;">
                        <option value="8">8 Port</option>
                        <option value="16" selected>16 Port</option>
                        <option value="24">24 Port</option>
                        <option value="32">32 Port</option>
                    </select>
                </div>
            </div>
            <div style="padding:.75rem 1.25rem; border-top:1px solid #e5e7eb; display:flex; justify-content:flex-end; gap:.5rem;">
                <button type="button" onclick="tutupModal('modalTambah')"
                        style="padding:.5rem 1rem; font-size:.875rem; border:1.5px solid #e5e7eb; border-radius:8px; color:#6b7280; background:#fff; cursor:pointer;">Batal</button>
                <button type="submit"
                        style="padding:.5rem 1rem; font-size:.875rem; background:#2563eb; color:#fff; border:none; border-radius:8px; cursor:pointer;">
                    <i class="bi bi-save" style="margin-right:.25rem;"></i>Simpan ODP
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ===================== MODAL EDIT ===================== -->
<div id="modalEdit" style="display:none; position:fixed; inset:0; z-index:50; align-items:center; justify-content:center; background:rgba(0,0,0,.4); padding:1rem;">
    <div style="background:#fff; border-radius:12px; box-shadow:0 10px 25px rgba(0,0,0,.15); width:100%; max-width:28rem;">
        <form method="POST" id="formEditODP">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
            <input type="hidden" name="id" id="editOdpId">
            <div style="display:flex; justify-content:space-between; align-items:center; padding:1rem 1.25rem; border-bottom:1px solid #e5e7eb;">
                <h6 style="margin:0; font-weight:700; color:#374151;">
                    <i class="bi bi-pencil" style="color:#f59e0b; margin-right:.4rem;"></i>Edit ODP
                </h6>
                <button type="button" onclick="tutupModal('modalEdit')" style="background:none; border:none; font-size:1.25rem; color:#9ca3af; cursor:pointer; line-height:1;">&times;</button>
            </div>
            <div style="padding:1.25rem; display:flex; flex-direction:column; gap:1rem;">
                <div>
                    <label style="display:block; font-size:.75rem; font-weight:600; color:#6b7280; margin-bottom:.3rem;">Nama ODP <span style="color:#ef4444;">*</span></label>
                    <input type="text" name="nama_odp" id="editNamaOdp" required
                           style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; box-sizing:border-box;">
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:.75rem;">
                    <div>
                        <label style="display:block; font-size:.75rem; font-weight:600; color:#6b7280; margin-bottom:.3rem;">Latitude</label>
                        <input type="number" name="latitude" id="editLatitude" step="0.00000001"
                               style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; font-family:monospace; box-sizing:border-box;">
                    </div>
                    <div>
                        <label style="display:block; font-size:.75rem; font-weight:600; color:#6b7280; margin-bottom:.3rem;">Longitude</label>
                        <input type="number" name="longitude" id="editLongitude" step="0.00000001"
                               style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; font-family:monospace; box-sizing:border-box;">
                    </div>
                </div>
                <div>
                    <label style="display:block; font-size:.75rem; font-weight:600; color:#6b7280; margin-bottom:.3rem;">Kapasitas Port</label>
                    <select name="kapasitas" id="editKapasitas" style="width:100%; padding:.6rem; border:1.5px solid #e5e7eb; border-radius:8px; font-size:.875rem; box-sizing:border-box;">
                        <option value="8">8 Port</option>
                        <option value="16">16 Port</option>
                        <option value="24">24 Port</option>
                        <option value="32">32 Port</option>
                    </select>
                </div>
            </div>
            <div style="padding:.75rem 1.25rem; border-top:1px solid #e5e7eb; display:flex; justify-content:flex-end; gap:.5rem;">
                <button type="button" onclick="tutupModal('modalEdit')"
                        style="padding:.5rem 1rem; font-size:.875rem; border:1.5px solid #e5e7eb; border-radius:8px; color:#6b7280; background:#fff; cursor:pointer;">Batal</button>
                <button type="submit"
                        style="padding:.5rem 1rem; font-size:.875rem; background:#f59e0b; color:#fff; border:none; border-radius:8px; cursor:pointer;">
                    <i class="bi bi-save" style="margin-right:.25rem;"></i>Update ODP
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ===================== MODAL HAPUS ===================== -->
<div id="modalHapus" style="display:none; position:fixed; inset:0; z-index:50; align-items:center; justify-content:center; background:rgba(0,0,0,.4); padding:1rem;">
    <div style="background:#fff; border-radius:12px; box-shadow:0 10px 25px rgba(0,0,0,.15); width:100%; max-width:22rem;">
        <form method="POST" id="formHapusODP">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
            <div style="padding:1.5rem 1.25rem; text-align:center;">
                <div style="background:#fff1f2; border-radius:50%; display:inline-flex; padding:1rem; margin-bottom:.75rem;">
                    <i class="bi bi-trash-fill" style="color:#ef4444; font-size:1.5rem;"></i>
                </div>
                <h6 style="margin:0 0 .3rem; font-weight:700; color:#374151;">Hapus ODP?</h6>
                <p style="margin:0; font-size:.875rem; color:#9ca3af;">
                    ODP <strong id="hapusNamaODP" style="color:#374151;"></strong> akan dihapus secara permanen.
                </p>
            </div>
            <div style="padding:.75rem 1.25rem; border-top:1px solid #e5e7eb; display:flex; justify-content:center; gap:.5rem;">
                <button type="button" onclick="tutupModal('modalHapus')"
                        style="padding:.5rem 1rem; font-size:.875rem; border:1.5px solid #e5e7eb; border-radius:8px; color:#6b7280; background:#fff; cursor:pointer;">Batal</button>
                <button type="submit"
                        style="padding:.5rem 1rem; font-size:.875rem; background:#dc2626; color:#fff; border:none; border-radius:8px; cursor:pointer;">Ya, Hapus</button>
            </div>
        </form>
    </div>
</div>

<script>
function bukaModal(id) {
    const el = document.getElementById(id);
    el.style.display = 'flex';
}
function tutupModal(id) {
    const el = document.getElementById(id);
    el.style.display = 'none';
}
function bukaModalTambah() {
    bukaModal('modalTambah');
}

function editODP(odp) {
    document.getElementById('editOdpId').value     = odp.id;
    document.getElementById('editNamaOdp').value   = odp.nama_odp;
    document.getElementById('editLatitude').value  = odp.latitude ?? '';
    document.getElementById('editLongitude').value = odp.longitude ?? '';
    const sel = document.getElementById('editKapasitas');
    sel.value = odp.kapasitas ?? 16;
    document.getElementById('formEditODP').action = `/teknis/odp/update/${odp.id}`;
    bukaModal('modalEdit');
}

function hapusODP(id, nama) {
    document.getElementById('hapusNamaODP').textContent = nama;
    document.getElementById('formHapusODP').action = `/teknis/odp/hapus/${id}`;
    bukaModal('modalHapus');
}

function filterODP() {
    const q = document.getElementById('searchODP').value.toLowerCase();
    document.querySelectorAll('.odp-row').forEach(row => {
        const name = row.querySelector('.odp-name')?.textContent.toLowerCase() ?? '';
        row.style.display = name.includes(q) ? '' : 'none';
    });
}

// Tutup modal kalau klik backdrop
['modalTambah','modalEdit','modalHapus'].forEach(id => {
    document.getElementById(id).addEventListener('click', function(e) {
        if (e.target === this) tutupModal(id);
    });
});
</script>
