<?php
/**
 * views/pages/Teknis/index.php
 * Halaman utama Manajemen Teknis
 */
?>

<div style="max-width:1100px; margin:0 auto; padding:1.5rem 1rem;">

    <!-- Page Header -->
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:.75rem; margin-bottom:1.5rem;">
        <div>
            <h4 style="margin:0 0 .25rem; font-weight:700; font-size:1.25rem; color:#111827;">
                <i class="bi bi-diagram-3-fill" style="color:#3b82f6; margin-right:.5rem;"></i>Manajemen Teknis
            </h4>
            <nav style="font-size:.8rem; color:#6b7280;">
                <a href="/dashboard" style="color:#6b7280; text-decoration:none;">Dashboard</a>
                <span style="margin:0 .35rem;">/</span>
                <span style="color:#374151;">Teknis</span>
            </nav>
        </div>
        <div style="display:flex; gap:.5rem;">
            <a href="/teknis/odp" style="display:inline-flex; align-items:center; gap:.35rem; padding:.4rem .9rem; border:1.5px solid #3b82f6; color:#3b82f6; border-radius:8px; font-size:.875rem; text-decoration:none; background:#fff;">
                <i class="bi bi-router-fill"></i> Data ODP
            </a>
            <a href="/teknis/maps" style="display:inline-flex; align-items:center; gap:.35rem; padding:.4rem .9rem; background:#3b82f6; color:#fff; border:none; border-radius:8px; font-size:.875rem; text-decoration:none;">
                <i class="bi bi-map-fill"></i> Peta Jaringan
            </a>
        </div>
    </div>

    <!-- Flash Message -->
    <?php if (isset($_SESSION['flash'])): ?>
        <div style="padding:.75rem 1rem; border-radius:8px; font-size:.875rem; font-weight:500; margin-bottom:1rem;
            <?= $_SESSION['flash']['type'] === 'success'
                ? 'background:#f0fdf4; color:#166534; border:1px solid #bbf7d0;'
                : 'background:#fff1f2; color:#991b1b; border:1px solid #fecaca;' ?>">
            <i class="bi bi-<?= $_SESSION['flash']['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>" style="margin-right:.4rem;"></i>
            <?= htmlspecialchars($_SESSION['flash']['message']) ?>
        </div>
        <?php unset($_SESSION['flash']); ?>
    <?php endif; ?>

    <!-- Summary Cards -->
    <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(210px,1fr)); gap:1rem; margin-bottom:1.5rem;">

        <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); padding:1.25rem;">
            <div style="display:flex; align-items:center; justify-content:space-between;">
                <div>
                    <p style="margin:0 0 .25rem; font-size:.8rem; color:#6b7280;">Total ODP</p>
                    <h3 style="margin:0; font-weight:700; font-size:1.75rem; color:#111827;"><?= count($odps) ?></h3>
                </div>
                <div style="background:#eff6ff; border-radius:10px; padding:.75rem;">
                    <i class="bi bi-router-fill" style="font-size:1.5rem; color:#3b82f6;"></i>
                </div>
            </div>
        </div>

        <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); padding:1.25rem;">
            <div style="display:flex; align-items:center; justify-content:space-between;">
                <div>
                    <p style="margin:0 0 .25rem; font-size:.8rem; color:#6b7280;">ODP Aktif</p>
                    <h3 style="margin:0; font-weight:700; font-size:1.75rem; color:#16a34a;"><?= count($odps) ?></h3>
                </div>
                <div style="background:#f0fdf4; border-radius:10px; padding:.75rem;">
                    <i class="bi bi-check-circle-fill" style="font-size:1.5rem; color:#16a34a;"></i>
                </div>
            </div>
        </div>

        <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); padding:1.25rem;">
            <div style="display:flex; align-items:center; justify-content:space-between;">
                <div>
                    <p style="margin:0 0 .25rem; font-size:.8rem; color:#6b7280;">Total Port</p>
                    <?php $totalPort = array_sum(array_column($odps, 'kapasitas')); ?>
                    <h3 style="margin:0; font-weight:700; font-size:1.75rem; color:#111827;"><?= $totalPort ?></h3>
                </div>
                <div style="background:#ecfeff; border-radius:10px; padding:.75rem;">
                    <i class="bi bi-plug-fill" style="font-size:1.5rem; color:#0891b2;"></i>
                </div>
            </div>
        </div>

        <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); padding:1.25rem;">
            <div style="display:flex; align-items:center; justify-content:space-between;">
                <div>
                    <p style="margin:0 0 .25rem; font-size:.8rem; color:#6b7280;">Peta Jaringan</p>
                    <h3 style="margin:0; font-weight:700; font-size:1.75rem; color:#d97706;">Live</h3>
                </div>
                <div style="background:#fffbeb; border-radius:10px; padding:.75rem;">
                    <i class="bi bi-geo-alt-fill" style="font-size:1.5rem; color:#d97706;"></i>
                </div>
            </div>
        </div>

    </div>

    <!-- Tabel ODP Ringkasan -->
    <div style="background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); margin-bottom:1.5rem;">
        <div style="padding:.875rem 1.25rem; border-bottom:1px solid #e5e7eb; display:flex; align-items:center; justify-content:space-between;">
            <h6 style="margin:0; font-weight:700; color:#374151;">
                <i class="bi bi-router" style="color:#3b82f6; margin-right:.4rem;"></i>Daftar ODP
            </h6>
            <a href="/teknis/odp" style="padding:.35rem .9rem; border:1.5px solid #3b82f6; border-radius:8px; font-size:.8rem; color:#3b82f6; text-decoration:none;">Lihat Semua</a>
        </div>
        <div style="overflow-x:auto;">
            <table style="width:100%; border-collapse:collapse; font-size:.875rem;">
                <thead>
                    <tr style="background:#f9fafb;">
                        <th style="padding:.75rem 1rem; text-align:left; font-size:.75rem; font-weight:600; color:#6b7280; text-transform:uppercase;">#</th>
                        <th style="padding:.75rem 1rem; text-align:left; font-size:.75rem; font-weight:600; color:#6b7280; text-transform:uppercase;">Nama ODP</th>
                        <th style="padding:.75rem 1rem; text-align:left; font-size:.75rem; font-weight:600; color:#6b7280; text-transform:uppercase;">Koordinat</th>
                        <th style="padding:.75rem 1rem; text-align:left; font-size:.75rem; font-weight:600; color:#6b7280; text-transform:uppercase;">Kapasitas</th>
                        <th style="padding:.75rem 1rem; text-align:center; font-size:.75rem; font-weight:600; color:#6b7280; text-transform:uppercase;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($odps)): ?>
                        <tr>
                            <td colspan="5" style="text-align:center; color:#9ca3af; padding:3rem 1rem;">
                                <i class="bi bi-inbox" style="font-size:1.5rem; display:block; margin-bottom:.5rem;"></i>
                                Belum ada data ODP.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach (array_slice($odps, 0, 5) as $i => $odp): ?>
                            <tr style="border-top:1px solid #f3f4f6;">
                                <td style="padding:.75rem 1rem; color:#9ca3af; font-size:.8rem;"><?= $i + 1 ?></td>
                                <td style="padding:.75rem 1rem;">
                                    <span style="font-weight:600; color:#111827;"><?= htmlspecialchars($odp['nama_odp']) ?></span>
                                </td>
                                <td style="padding:.75rem 1rem; color:#6b7280; font-size:.8rem; font-family:monospace;">
                                    <?php if ($odp['latitude'] && $odp['longitude']): ?>
                                        <i class="bi bi-geo-alt" style="color:#ef4444; margin-right:.2rem;"></i>
                                        <?= number_format((float)$odp['latitude'], 6) ?>,
                                        <?= number_format((float)$odp['longitude'], 6) ?>
                                    <?php else: ?>
                                        <span style="color:#9ca3af;">—</span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding:.75rem 1rem;">
                                    <span style="padding:.2rem .6rem; background:#ecfeff; color:#0e7490; font-size:.75rem; font-weight:700; border-radius:6px;">
                                        <?= $odp['kapasitas'] ?? 16 ?> Port
                                    </span>
                                </td>
                                <td style="padding:.75rem 1rem; text-align:center;">
                                    <a href="/teknis/maps" style="padding:.35rem .75rem; border:1.5px solid #16a34a; border-radius:8px; font-size:.8rem; color:#16a34a; text-decoration:none;">
                                        <i class="bi bi-map" style="margin-right:.25rem;"></i>Lihat Peta
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Quick Links -->
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem;">

        <a href="/teknis/odp" style="display:flex; align-items:center; gap:1rem; background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); padding:1.25rem; text-decoration:none;">
            <div style="background:#eff6ff; border-radius:10px; padding:.75rem;">
                <i class="bi bi-router-fill" style="font-size:1.75rem; color:#3b82f6;"></i>
            </div>
            <div style="flex:1;">
                <h6 style="margin:0 0 .2rem; font-weight:700; color:#111827;">Manajemen ODP</h6>
                <p style="margin:0; font-size:.8rem; color:#6b7280;">Kelola data Optical Distribution Point</p>
            </div>
            <i class="bi bi-arrow-right-circle" style="font-size:1.25rem; color:#9ca3af;"></i>
        </a>

        <a href="/teknis/maps" style="display:flex; align-items:center; gap:1rem; background:#fff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.1); padding:1.25rem; text-decoration:none;">
            <div style="background:#f0fdf4; border-radius:10px; padding:.75rem;">
                <i class="bi bi-map-fill" style="font-size:1.75rem; color:#16a34a;"></i>
            </div>
            <div style="flex:1;">
                <h6 style="margin:0 0 .2rem; font-weight:700; color:#111827;">Peta Jaringan</h6>
                <p style="margin:0; font-size:.8rem; color:#6b7280;">Visualisasi lokasi ODP & pelanggan</p>
            </div>
            <i class="bi bi-arrow-right-circle" style="font-size:1.25rem; color:#9ca3af;"></i>
        </a>

    </div>

</div>
