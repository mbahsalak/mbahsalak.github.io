<?php declare(strict_types=1);

$bannerTitle  = $authSettings['auth_banner_title']  ?? 'Selamat Datang';
$bannerDesc   = $authSettings['auth_banner_desc']   ?? 'Silakan masuk ke akun Billing ISP Anda';
$showRegister = ($authSettings['auth_show_register'] ?? 'no') === 'yes';
$primary      = $authSettings['auth_primary_color']  ?? '#6366f1';
?>

<div style="text-align:center;margin-bottom:1.75rem;">
    <h1 style="font-size:1.25rem;font-weight:700;color:#0f172a;margin:0 0 .25rem;">
        <?= htmlspecialchars($bannerTitle) ?>
    </h1>
    <p style="font-size:.83rem;color:#64748b;margin:0;"><?= htmlspecialchars($bannerDesc) ?></p>
</div>

<?php if (isset($error)): ?>
    <div style="display:flex;align-items:flex-start;gap:.55rem;padding:.72rem .9rem;border-radius:8px;
                font-size:.83rem;line-height:1.5;margin-bottom:1.25rem;
                background:#fef2f2;border:1px solid #fecaca;color:#dc2626;">
        <i class="fa-solid fa-circle-exclamation" style="margin-top:.15rem;flex-shrink:0;"></i>
        <span><?= htmlspecialchars($error) ?></span>
    </div>
<?php endif; ?>

<form method="POST" action="<?= htmlspecialchars($_ENV['APP_URL'] ?? '') ?>/login">
    <?= $this->csrfField() ?>

    <div style="margin-bottom:1.2rem;">
        <label for="username" style="display:block;font-size:.78rem;font-weight:600;color:#334155;
                                      margin-bottom:.45rem;letter-spacing:.01em;">
            <i class="fa-solid fa-user" style="color:<?= htmlspecialchars($primary) ?>;margin-right:.35rem;"></i>Username
        </label>
        <input
            class="auth-input"
            type="text"
            id="username"
            name="username"
            placeholder="Masukkan username"
            value="<?= htmlspecialchars($old['username'] ?? '') ?>"
            autocomplete="username"
            required
            style="width:100%;padding:.65rem .9rem;font-family:inherit;font-size:.9rem;
                   border:1.5px solid #e2e8f0;border-radius:8px;background:#f8fafc;
                   color:#0f172a;outline:none;">
    </div>

    <div style="margin-bottom:1.2rem;">
        <label for="password" style="display:block;font-size:.78rem;font-weight:600;color:#334155;
                                      margin-bottom:.45rem;letter-spacing:.01em;">
            <i class="fa-solid fa-lock" style="color:<?= htmlspecialchars($primary) ?>;margin-right:.35rem;"></i>Password
        </label>
        <input
            class="auth-input"
            type="password"
            id="password"
            name="password"
            placeholder="Masukkan password"
            autocomplete="current-password"
            required
            style="width:100%;padding:.65rem .9rem;font-family:inherit;font-size:.9rem;
                   border:1.5px solid #e2e8f0;border-radius:8px;background:#f8fafc;
                   color:#0f172a;outline:none;">
    </div>

    <button type="submit" class="auth-submit"
            style="width:100%;display:flex;align-items:center;justify-content:center;gap:.5rem;
                   padding:.72rem 1rem;background:<?= htmlspecialchars($primary) ?>;color:#fff;
                   font-family:inherit;font-size:.9rem;font-weight:600;border:none;border-radius:8px;
                   cursor:pointer;margin-top:.5rem;">
        <i class="fa-solid fa-right-to-bracket"></i> Masuk
    </button>
</form>

<?php if ($showRegister): ?>
    <div style="text-align:center;margin-top:1.5rem;font-size:.83rem;color:#64748b;">
        Belum punya akun?
        <a href="/register" class="auth-link"
           style="color:<?= htmlspecialchars($primary) ?>;font-weight:600;text-decoration:none;">Daftar di sini</a>
    </div>
<?php endif; ?>
