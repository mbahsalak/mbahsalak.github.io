<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Akun Pelanggan - <?= htmlspecialchars($title ?? 'ISP') ?></title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" 
          integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""/>
    
    <style>
        #map {
            height: 400px;
            width: 100%;
            border-radius: 0.5rem;
            border: 2px solid #e5e7eb;
        }
        
        .location-info {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem;
            border-radius: 0.5rem;
            margin-top: 1rem;
        }
        
        .pulse { animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: .5; }
        }

        /* Paket Card */
        .paket-card {
            position: relative;
            border: 2px solid #e5e7eb;
            border-radius: 1rem;
            padding: 1.5rem;
            cursor: pointer;
            transition: all 0.3s ease;
            background: white;
        }
        .paket-card:hover {
            border-color: #818cf8;
            transform: translateY(-4px);
            box-shadow: 0 10px 25px -5px rgba(99, 102, 241, 0.2);
        }
        .paket-card.selected {
            border-color: #4f46e5;
            background: linear-gradient(135deg, #eef2ff 0%, #e0e7ff 100%);
            box-shadow: 0 10px 25px -5px rgba(79, 70, 229, 0.3);
        }
        .paket-card.selected::after {
            content: '✓';
            position: absolute;
            top: 10px;
            right: 10px;
            width: 28px;
            height: 28px;
            background: #4f46e5;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 14px;
        }
        .paket-popular {
            position: absolute;
            top: -12px;
            left: 50%;
            transform: translateX(-50%);
            background: linear-gradient(135deg, #f59e0b 0%, #ef4444 100%);
            color: white;
            padding: 4px 16px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            box-shadow: 0 4px 6px rgba(245, 158, 11, 0.3);
        }
        .speed-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
            color: white;
            padding: 8px 16px;
            border-radius: 9999px;
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 12px;
        }
        .price-tag {
            font-size: 28px;
            font-weight: 800;
            color: #1f2937;
            line-height: 1;
        }
        .price-tag small {
            font-size: 14px;
            font-weight: 500;
            color: #6b7280;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100">
    <div class="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-5xl mx-auto">
            
            <!-- Header -->
            <div class="text-center mb-8">
                <h1 class="text-4xl font-bold text-gray-900 mb-2">
                    📡 Daftar Pelanggan ISP
                </h1>
                <p class="text-gray-600">Lengkapi formulir di bawah untuk berlangganan internet</p>
            </div>

            <!-- Flash Message -->
            <?php if (!empty($flash)): ?>
                <div class="mb-6 rounded-lg p-4 <?= ($flash['type'] ?? '') === 'success' ? 'bg-green-100 border border-green-400 text-green-800' : 'bg-red-100 border border-red-400 text-red-800' ?>">
                    <div class="flex items-center">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                        </svg>
                        <span class="font-medium"><?= htmlspecialchars($flash['message'] ?? '') ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Error Messages -->
            <?php if (!empty($errors)): ?>
                <div class="mb-6 rounded-lg p-4 bg-red-100 border border-red-400">
                    <div class="flex items-center mb-2">
                        <svg class="w-5 h-5 mr-2 text-red-800" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                        </svg>
                        <span class="font-bold text-red-800">Terjadi kesalahan:</span>
                    </div>
                    <ul class="list-disc list-inside text-red-700 ml-7">
                        <?php foreach ($errors as $error): ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- Form -->
            <form action="<?= APPURL ?>/pendaftaran" method="POST" id="formRegister" class="bg-white rounded-xl shadow-2xl overflow-hidden">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
                
                <!-- ============ SECTION 1: PAKET INTERNET ============ -->
                <div class="p-8 border-b border-gray-200 bg-gradient-to-br from-indigo-50 to-purple-50">
                    <h2 class="text-2xl font-bold text-gray-800 mb-2 flex items-center">
                        <span class="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center mr-3 text-sm font-bold">1</span>
                        Pilih Paket Internet
                    </h2>
                    <p class="text-sm text-gray-600 mb-6 ml-11">Pilih paket yang sesuai kebutuhan Anda</p>

                    <input type="hidden" id="paket_id" name="paket_id" value="<?= (int)($old['paket_id'] ?? 0) ?>">

                    <?php 
                    $paketList = $paketList ?? [];
                    $selectedPaketId = (int)($old['paket_id'] ?? 0);
                    
                    // Tentukan paket populer (harga menengah)
                    $populerIdx = 0;
                    if (count($paketList) > 2) {
                        $populerIdx = (int)floor(count($paketList) / 2);
                    }
                    ?>

                    <?php if (empty($paketList)): ?>
                        <div class="text-center py-10 text-gray-500">
                            <svg class="w-16 h-16 mx-auto mb-3 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                            </svg>
                            <p class="font-medium">Belum ada paket tersedia</p>
                            <p class="text-sm">Hubungi admin untuk informasi lebih lanjut</p>
                        </div>
                    <?php else: ?>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-<?= min(count($paketList), 4) ?> gap-5">
                            <?php foreach ($paketList as $idx => $paket): 
                                $isPopuler = ($idx === $populerIdx && count($paketList) > 2);
                                $isSelected = ($selectedPaketId === (int)$paket['id']);
                            ?>
                                <div class="paket-card <?= $isSelected ? 'selected' : '' ?> <?= $isPopuler ? 'pt-8' : '' ?>" 
                                     data-paket-id="<?= (int)$paket['id'] ?>"
                                     onclick="selectPaket(this, <?= (int)$paket['id'] ?>)">
                                    
                                    <?php if ($isPopuler): ?>
                                        <div class="paket-popular">⭐ Paling Populer</div>
                                    <?php endif; ?>

                                    <!-- Kecepatan -->
                                    <div class="text-center mb-3">
                                        <h3 class="text-lg font-bold text-gray-800 mb-2">
                                            <?= htmlspecialchars($paket['nama_paket'] ?? 'Paket') ?>
                                        </h3>
                                        <div class="speed-badge mx-auto">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                                            </svg>
                                            <?= htmlspecialchars($paket['kecepatan'] ?? '0') ?> Mbps
                                        </div>
                                    </div>

                                    <!-- Harga -->
                                    <div class="text-center mb-4 pb-4 border-b border-gray-200">
                                        <div class="price-tag">
                                            Rp <?= number_format((float)($paket['harga'] ?? 0), 0, ',', '.') ?>
                                            <small>/bulan</small>
                                        </div>
                                    </div>

                                    <!-- Deskripsi / Fitur -->
                                    <div class="space-y-2 mb-4">
                                        <?php 
                                        $deskripsi = $paket['deskripsi'] ?? '';
                                        if ($deskripsi):
                                            // Pisahkan per baris atau koma
                                            $fitur = preg_split('/[\n,]+/', $deskripsi);
                                            foreach ($fitur as $f):
                                                $f = trim($f);
                                                if (empty($f)) continue;
                                        ?>
                                                <div class="flex items-start gap-2 text-sm text-gray-600">
                                                    <svg class="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                                                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                                                    </svg>
                                                    <span><?= htmlspecialchars($f) ?></span>
                                                </div>
                                        <?php 
                                            endforeach;
                                        else:
                                        ?>
                                            <div class="flex items-start gap-2 text-sm text-gray-600">
                                                <svg class="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                                                </svg>
                                                <span>Internet <?= htmlspecialchars($paket['kecepatan'] ?? '0') ?> Mbps</span>
                                            </div>
                                            <div class="flex items-start gap-2 text-sm text-gray-600">
                                                <svg class="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                                                </svg>
                                                <span>Unlimited tanpa FUP</span>
                                            </div>
                                            <div class="flex items-start gap-2 text-sm text-gray-600">
                                                <svg class="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                                                </svg>
                                                <span>Support 24/7</span>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <!-- Tombol Pilih -->
                                    <button type="button" 
                                            class="w-full py-2 px-4 rounded-lg text-sm font-semibold transition
                                                   <?= $isSelected 
                                                       ? 'bg-indigo-600 text-white' 
                                                       : 'bg-gray-100 text-gray-700 hover:bg-indigo-100 hover:text-indigo-700' ?>">
                                        <?= $isSelected ? '✓ Terpilih' : 'Pilih Paket Ini' ?>
                                    </button>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <!-- Info Paket Terpilih -->
                        <div id="paketSelectedInfo" class="mt-6 p-4 bg-indigo-50 border border-indigo-200 rounded-lg <?= $selectedPaketId > 0 ? '' : 'hidden' ?>">
                            <div class="flex items-center gap-2 text-indigo-800">
                                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                                </svg>
                                <span class="font-semibold text-sm">Paket dipilih: <span id="selectedPaketName">-</span></span>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- ============ SECTION 2: DATA PRIBADI ============ -->
                <div class="p-8 border-b border-gray-200">
                    <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                        <span class="bg-indigo-100 text-indigo-600 rounded-full w-8 h-8 flex items-center justify-center mr-3 text-sm font-bold">2</span>
                        Data Pribadi
                    </h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="nama_lengkap" class="block text-sm font-medium text-gray-700 mb-2">
                                Nama Lengkap <span class="text-red-500">*</span>
                            </label>
                            <input type="text" id="nama_lengkap" name="nama_lengkap" required
                                   value="<?= htmlspecialchars($old['nama_lengkap'] ?? '') ?>"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                                   placeholder="Masukkan nama lengkap">
                        </div>

                        <div>
                            <label for="username" class="block text-sm font-medium text-gray-700 mb-2">
                                Username <span class="text-red-500">*</span>
                            </label>
                            <input type="text" id="username" name="username" required
                                   value="<?= htmlspecialchars($old['username'] ?? '') ?>"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                                   placeholder="Username untuk login">
                        </div>

                        <div>
                            <label for="no_telp" class="block text-sm font-medium text-gray-700 mb-2">
                                No. Telepon/WhatsApp <span class="text-red-500">*</span>
                            </label>
                            <input type="tel" id="no_telp" name="no_telp" required
                                   value="<?= htmlspecialchars($old['no_telp'] ?? '') ?>"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                                   placeholder="08xxxxxxxxxx">
                        </div>

                        <div>
                            <label for="email" class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                            <input type="email" id="email" name="email"
                                   value="<?= htmlspecialchars($old['email'] ?? '') ?>"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                                   placeholder="email@example.com">
                        </div>
                    </div>

                    <div class="mt-6">
                        <label for="alamat" class="block text-sm font-medium text-gray-700 mb-2">
                            Alamat Lengkap <span class="text-red-500">*</span>
                        </label>
                        <textarea id="alamat" name="alamat" rows="3" required
                                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                                  placeholder="Jalan, RT/RW, Kelurahan, Kecamatan, Kota"><?= htmlspecialchars($old['alamat'] ?? '') ?></textarea>
                    </div>
                </div>

                <!-- ============ SECTION 3: KEAMANAN ============ -->
                <div class="p-8 border-b border-gray-200 bg-gray-50">
                    <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                        <span class="bg-indigo-100 text-indigo-600 rounded-full w-8 h-8 flex items-center justify-center mr-3 text-sm font-bold">3</span>
                        Keamanan Akun
                    </h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="password" class="block text-sm font-medium text-gray-700 mb-2">
                                Password <span class="text-red-500">*</span>
                            </label>
                            <input type="password" id="password" name="password" required
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                                   placeholder="Minimal 8 karakter">
                            <p class="text-xs text-gray-500 mt-1">Gunakan kombinasi huruf, angka, dan simbol</p>
                        </div>

                        <div>
                            <label for="confirm_password" class="block text-sm font-medium text-gray-700 mb-2">
                                Konfirmasi Password <span class="text-red-500">*</span>
                            </label>
                            <input type="password" id="confirm_password" name="confirm_password" required
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                                   placeholder="Ulangi password">
                        </div>
                    </div>
                </div>

                <!-- ============ SECTION 4: LOKASI PETA ============ -->
                <div class="p-8 border-b border-gray-200">
                    <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                        <span class="bg-indigo-100 text-indigo-600 rounded-full w-8 h-8 flex items-center justify-center mr-3 text-sm font-bold">4</span>
                        Lokasi Pemasangan
                    </h2>
                    
                    <div class="mb-4">
                        <p class="text-sm text-gray-600 mb-2">📍 Klik pada peta untuk menandai lokasi pemasangan internet Anda</p>
                        
                        <button type="button" id="btnLocate" 
                                class="mb-3 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition flex items-center gap-2">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                            </svg>
                            Gunakan Lokasi Saya
                        </button>
                    </div>

                    <div id="map"></div>

                    <div id="locationInfo" class="location-info hidden">
                        <div class="flex items-start gap-3">
                            <svg class="w-6 h-6 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"/>
                            </svg>
                            <div class="flex-1">
                                <p class="font-bold text-sm mb-1">Lokasi Dipilih:</p>
                                <p id="coordText" class="text-sm opacity-90 mb-1"></p>
                                <p id="addressText" class="text-xs opacity-75"></p>
                            </div>
                        </div>
                    </div>

                    <input type="hidden" id="latitude" name="latitude" value="<?= htmlspecialchars($old['latitude'] ?? '') ?>">
                    <input type="hidden" id="longitude" name="longitude" value="<?= htmlspecialchars($old['longitude'] ?? '') ?>">
                    
                    <p class="text-xs text-gray-500 mt-3">💡 Tips: Zoom in untuk akurasi lebih baik.</p>
                </div>

                <!-- ============ SUBMIT ============ -->
                <div class="p-8 bg-gradient-to-r from-indigo-600 to-purple-600">
                    <button type="submit" 
                            class="w-full py-4 px-6 bg-white text-indigo-600 font-bold rounded-lg hover:bg-gray-100 transition transform hover:scale-[1.02] shadow-lg">
                        🚀 Daftar Sekarang
                    </button>
                    
                    <p class="text-center text-white/80 text-sm mt-4">
                        Sudah punya akun? 
                        <a href="<?= APPURL ?>/login" class="font-bold text-white hover:underline">Login di sini</a>
                    </p>
                </div>
            </form>
        </div>
    </div>

    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" 
            integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
    
    <script>
        // ===== PAKET SELECTION =====
        function selectPaket(card, paketId) {
            // Remove selected dari semua card
            document.querySelectorAll('.paket-card').forEach(c => {
                c.classList.remove('selected');
                const btn = c.querySelector('button');
                if (btn) {
                    btn.textContent = 'Pilih Paket Ini';
                    btn.className = 'w-full py-2 px-4 rounded-lg text-sm font-semibold transition bg-gray-100 text-gray-700 hover:bg-indigo-100 hover:text-indigo-700';
                }
            });

            // Tandai card ini sebagai selected
            card.classList.add('selected');
            const btn = card.querySelector('button');
            if (btn) {
                btn.textContent = '✓ Terpilih';
                btn.className = 'w-full py-2 px-4 rounded-lg text-sm font-semibold transition bg-indigo-600 text-white';
            }

            // Set hidden input
            document.getElementById('paket_id').value = paketId;

            // Ambil nama paket
            const nama = card.querySelector('h3').textContent;
            const harga = card.querySelector('.price-tag').textContent.trim();
            
            // Tampilkan info
            const info = document.getElementById('paketSelectedInfo');
            document.getElementById('selectedPaketName').textContent = nama + ' — ' + harga;
            info.classList.remove('hidden');

            // Smooth scroll ke section berikutnya
            setTimeout(() => {
                document.querySelector('#nama_lengkap').scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 300);
        }

        // ===== MAP =====
        const map = L.map('map').setView([-6.200000, 106.816666], 13);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 19
        }).addTo(map);

        let marker = null;

        function updateLocation(lat, lng, fromGPS = false) {
            if (marker) map.removeLayer(marker);

            marker = L.marker([lat, lng], { draggable: true }).addTo(map);

            document.getElementById('latitude').value = lat;
            document.getElementById('longitude').value = lng;

            const infoDiv = document.getElementById('locationInfo');
            const coordText = document.getElementById('coordText');
            const addressText = document.getElementById('addressText');
            
            infoDiv.classList.remove('hidden');
            coordText.textContent = `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
            addressText.textContent = 'Mengambil alamat...';

            fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`)
                .then(r => r.json())
                .then(data => {
                    addressText.textContent = data.display_name || 'Alamat tidak ditemukan';
                })
                .catch(() => {
                    addressText.textContent = 'Gagal mengambil alamat';
                });

            marker.on('dragend', function() {
                const pos = marker.getLatLng();
                updateLocation(pos.lat, pos.lng);
            });

            map.setView([lat, lng], fromGPS ? 17 : map.getZoom());
        }

        map.on('click', function(e) {
            updateLocation(e.latlng.lat, e.latlng.lng);
        });

        // GPS Button
        document.getElementById('btnLocate').addEventListener('click', function() {
            if (!navigator.geolocation) {
                alert('Browser Anda tidak mendukung geolokasi');
                return;
            }

            const btn = this;
            btn.disabled = true;
            btn.innerHTML = '<span class="pulse">📡 Mencari lokasi...</span>';

            navigator.geolocation.getCurrentPosition(
                function(pos) {
                    updateLocation(pos.coords.latitude, pos.coords.longitude, true);
                    btn.disabled = false;
                    btn.innerHTML = `
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                        </svg>
                        Gunakan Lokasi Saya
                    `;
                },
                function(err) {
                    btn.disabled = false;
                    btn.innerHTML = `
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                        </svg>
                        Gunakan Lokasi Saya
                    `;
                    alert('Gagal mendapatkan lokasi. Izinkan akses lokasi di browser.');
                },
                { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
            );
        });

        // Load existing coordinates
        const exLat = document.getElementById('latitude').value;
        const exLng = document.getElementById('longitude').value;
        if (exLat && exLng) updateLocation(parseFloat(exLat), parseFloat(exLng));

        // ===== FORM VALIDATION =====
        document.getElementById('formRegister').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const confirm  = document.getElementById('confirm_password').value;
            const lat      = document.getElementById('latitude').value;
            const lng      = document.getElementById('longitude').value;
            const paketId  = document.getElementById('paket_id').value;

            if (!paketId || paketId === '0') {
                e.preventDefault();
                alert('❌ Silakan pilih paket internet terlebih dahulu!');
                document.querySelector('.paket-card').scrollIntoView({ behavior: 'smooth' });
                return false;
            }

            if (password !== confirm) {
                e.preventDefault();
                alert('❌ Password dan konfirmasi password tidak cocok!');
                return false;
            }

            if (password.length < 8) {
                e.preventDefault();
                alert('❌ Password minimal 8 karakter!');
                return false;
            }

            if (!lat || !lng) {
                e.preventDefault();
                alert('❌ Silakan pilih lokasi pemasangan pada peta!');
                document.getElementById('map').scrollIntoView({ behavior: 'smooth' });
                return false;
            }

            return true;
        });
    </script>
</body>
</html>
