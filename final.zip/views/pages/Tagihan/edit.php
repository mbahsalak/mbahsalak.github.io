<?php declare(strict_types=1);
$t      = $tagihan ?? [];
$old    = $old    ?? [];
$errors = $errors ?? [];
$appUrl = $_ENV['APP_URL'] ?? '';
$val    = fn(string $k) => htmlspecialchars($old[$k] ?? $t[$k] ?? '');
$isPaid = ($t['status'] ?? '') === 'paid';
$role   = $_SESSION['user']['role'] ?? '';
?>

<!-- Header -->
<div class="flex items-center justify-between flex-wrap gap-4 mb-6">
    <div>
        <h1 class="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <i class="fa-solid fa-pencil text-amber-500"></i>
            Edit Tagihan <span class="text-gray-400 dark:text-gray-500 font-normal">#<?= $t['id'] ?></span>
        </h1>
        <p class="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
            <?= htmlspecialchars($t['nama_lengkap'] ?? '') ?> — <?= htmlspecialchars($t['nama_paket'] ?? '') ?>
        </p>
    </div>
    <a href="<?= $appUrl ?>/tagihan/<?= $t['id'] ?>"
       class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-gray-200
              dark:border-gray-600 text-gray-600 dark:text-gray-300 text-sm font-semibold
              hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
        <i class="fa-solid fa-arrow-left"></i> Kembali
    </a>
</div>

<?php if (!empty($flash['error'])): ?>
<div class="flex items-center gap-2 px-4 py-3 rounded-lg mb-4 text-sm
            bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400">
    <i class="fa-solid fa-circle-exclamation"></i> <?= htmlspecialchars($flash['error']) ?>
</div>
<?php endif; ?>

<div class="max-w-2xl space-y-4">

    <!-- Pelanggan strip -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-full bg-indigo-500 text-white flex items-center justify-center
                        font-bold text-sm flex-shrink-0">
                <?= strtoupper(substr($t['nama_lengkap'] ?? 'X', 0, 1)) ?>
            </div>
            <div class="flex-1 min-w-0">
                <p class="font-semibold text-gray-900 dark:text-white text-sm">
                    <?= htmlspecialchars($t['nama_lengkap'] ?? '') ?>
                </p>
                <p class="text-xs text-gray-400 dark:text-gray-500">
                    <?= htmlspecialchars($t['nama_paket'] ?? '') ?>
                    · Rp <?= number_format((float)($t['harga'] ?? 0), 0, ',', '.') ?>/bln
                </p>
                <?php if (!empty($t['alamat'])): ?>
                <p class="text-xs text-gray-400 dark:text-gray-500 mt-0.5">
                    <i class="fa-solid fa-location-dot mr-1"></i><?= htmlspecialchars($t['alamat']) ?>
                </p>
                <?php endif; ?>
            </div>
            <span class="px-2.5 py-1 rounded-full text-xs font-semibold
                         <?= $isPaid
                             ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400'
                             : 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400' ?>">
                <?= $isPaid ? 'Lunas' : 'Belum Lunas' ?>
            </span>
        </div>
    </div>

    <!-- Form -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5">
        <form method="POST" action="<?= $appUrl ?>/tagihan/update/<?= $t['id'] ?>">
            <input type="hidden" name="csrf_token"
                   value="<?= htmlspecialchars($csrf_token ?? '', ENT_QUOTES) ?>">

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <!-- Periode -->
                <div>
                    <label class="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1.5">
                        Periode Bulan <span class="text-red-500">*</span>
                    </label>
                    <input type="month" name="periode_bulan" id="periode_bulan" required
                           value="<?= $val('periode_bulan') ?>"
                           class="w-full px-3 py-2 rounded-lg border text-sm bg-white dark:bg-gray-900
                                  text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-300
                                  <?= !empty($errors['periode_bulan']) ? 'border-red-400' : 'border-gray-200 dark:border-gray-600' ?>">
                    <?php if (!empty($errors['periode_bulan'])): ?>
                    <p class="text-red-500 text-xs mt-1"><?= htmlspecialchars($errors['periode_bulan']) ?></p>
                    <?php endif; ?>
                </div>
                <!-- Jatuh Tempo -->
                <div>
                    <label class="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1.5">
                        Jatuh Tempo <span class="text-red-500">*</span>
                    </label>
                    <input type="date" name="jatuh_tempo" id="jatuh_tempo" required
                           value="<?= $val('jatuh_tempo') ?>"
                           class="w-full px-3 py-2 rounded-lg border text-sm bg-white dark:bg-gray-900
                                  text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-300
                                  <?= !empty($errors['jatuh_tempo']) ? 'border-red-400' : 'border-gray-200 dark:border-gray-600' ?>">
                    <?php if (!empty($errors['jatuh_tempo'])): ?>
                    <p class="text-red-500 text-xs mt-1"><?= htmlspecialchars($errors['jatuh_tempo']) ?></p>
                    <?php endif; ?>
                </div>
                <!-- Total -->
                <div>
                    <label class="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1.5">
                        Total Tagihan <span class="text-red-500">*</span>
                    </label>
                    <div class="relative">
                        <span class="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-semibold
                                     text-gray-400 dark:text-gray-500 pointer-events-none">Rp</span>
                        <input type="text" name="total" id="total" required inputmode="numeric"
                               value="<?= !empty($old['total']) ? htmlspecialchars($old['total']) : number_format((float)($t['total']??0), 0, ',', '.') ?>"
                               class="w-full pl-9 pr-3 py-2 rounded-lg border text-sm bg-white dark:bg-gray-900
                                      text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-300
                                      <?= !empty($errors['total']) ? 'border-red-400' : 'border-gray-200 dark:border-gray-600' ?>">
                    </div>
                    <?php if (!empty($errors['total'])): ?>
                    <p class="text-red-500 text-xs mt-1"><?= htmlspecialchars($errors['total']) ?></p>
                    <?php endif; ?>
                </div>
                <!-- Status -->
                <div>
                    <label class="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1.5">
                        Status <span class="text-red-500">*</span>
                    </label>
                    <select name="status" id="status" required onchange="togglePembayaranFields(this.value)"
                            class="w-full px-3 py-2 rounded-lg border text-sm bg-white dark:bg-gray-900
                                   text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-300
                                   <?= !empty($errors['status']) ? 'border-red-400' : 'border-gray-200 dark:border-gray-600' ?>">
                        <?php $curStatus = $old['status'] ?? $t['status'] ?? 'unpaid';
                        foreach (['unpaid'=>'Belum Lunas','paid'=>'Lunas','suspend'=>'Suspend','cancel'=>'Batal'] as $v=>$lbl): ?>
                        <option value="<?= $v ?>" <?= $curStatus===$v?'selected':'' ?>><?= $lbl ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="text-xs text-gray-400 dark:text-gray-500 mt-1">
                        Mengubah ke Lunas akan mengisi tanggal bayar otomatis.
                    </p>
                    <?php if (!empty($errors['status'])): ?>
                    <p class="text-red-500 text-xs mt-1"><?= htmlspecialchars($errors['status']) ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Info Pembayaran (paid) -->
            <div id="pembayaranFields" class="<?= $isPaid ? '' : 'hidden' ?> mb-4">
                <div class="bg-emerald-50 dark:bg-emerald-950 border border-emerald-200 dark:border-emerald-800
                            rounded-lg p-4">
                    <p class="text-xs font-bold uppercase tracking-wide text-emerald-700 dark:text-emerald-400 mb-3
                               flex items-center gap-1.5">
                        <i class="fa-solid fa-circle-check"></i> Info Pembayaran
                    </p>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                            <label class="block text-xs font-semibold text-emerald-700 dark:text-emerald-400 mb-1">
                                Metode Pembayaran
                            </label>
                            <select name="metode_pembayaran" id="metode_pembayaran"
                                    class="w-full px-3 py-2 rounded-lg border border-emerald-200 dark:border-emerald-700
                                           text-sm bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100
                                           focus:outline-none focus:ring-2 focus:ring-emerald-300">
                                <option value="">— Pilih —</option>
                                <?php $curMetode = $old['metode_pembayaran'] ?? $t['metode_pembayaran'] ?? '';
                                foreach (['tunai'=>'Tunai','transfer'=>'Transfer Bank','qris'=>'QRIS'] as $v=>$lbl): ?>
                                <option value="<?= $v ?>" <?= $curMetode===$v?'selected':'' ?>><?= $lbl ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-emerald-700 dark:text-emerald-400 mb-1">
                                Penerima Pembayaran
                            </label>
                            <input type="text" name="penerima" id="penerima"
                                   value="<?= htmlspecialchars($old['penerima'] ?? $t['penerima'] ?? ($_SESSION['user']['username'] ?? '')) ?>"
                                   placeholder="Nama kasir / penerima"
                                   class="w-full px-3 py-2 rounded-lg border border-emerald-200 dark:border-emerald-700
                                          text-sm bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100
                                          focus:outline-none focus:ring-2 focus:ring-emerald-300">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Riwayat bayar -->
            <?php if (!empty($t['tgl_bayar'])): ?>
            <div class="flex items-center gap-2 px-4 py-2.5 rounded-lg mb-4 text-xs
                        bg-emerald-50 dark:bg-emerald-950 border border-emerald-200 dark:border-emerald-800
                        text-emerald-700 dark:text-emerald-400">
                <i class="fa-solid fa-circle-check"></i>
                Dibayar pada <strong><?= date('d M Y H:i', strtotime($t['tgl_bayar'])) ?></strong>
                <?php if (!empty($t['metode_pembayaran'])): ?>
                    · via <strong><?= htmlspecialchars(ucfirst($t['metode_pembayaran'])) ?></strong>
                <?php endif; ?>
                <?php if (!empty($t['penerima'])): ?>
                    · oleh <strong><?= htmlspecialchars($t['penerima']) ?></strong>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <!-- Actions -->
            <div class="flex items-center pt-4 border-t border-gray-100 dark:border-gray-700">
                <?php if ($role === 'admin'): ?>
                <button type="button" id="btnHapus"
                        class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-red-300
                               text-red-500 dark:text-red-400 text-sm font-semibold
                               hover:bg-red-50 dark:hover:bg-red-950 transition-colors bg-transparent cursor-pointer">
                    <i class="fa-solid fa-trash"></i> Hapus
                </button>
                <?php endif; ?>
                <div class="ml-auto flex gap-2">
                    <a href="<?= $appUrl ?>/tagihan/<?= $t['id'] ?>"
                       class="px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-600 text-gray-600
                              dark:text-gray-300 text-sm font-semibold hover:bg-gray-50 dark:hover:bg-gray-700
                              transition-colors">
                        Batal
                    </a>
                    <button type="submit"
                            class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-500 text-white
                                   text-sm font-semibold hover:bg-indigo-600 transition-colors cursor-pointer">
                        <i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan
                    </button>
                </div>
            </div>
        </form>
    </div>

</div>

<?php if ($role === 'admin'): ?>
<form method="POST" action="<?= $appUrl ?>/tagihan/hapus/<?= $t['id'] ?>" id="formHapus">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token ?? '', ENT_QUOTES) ?>">
</form>
<?php endif; ?>

<script>
function togglePembayaranFields(status) {
    const el = document.getElementById('pembayaranFields');
    if (status === 'paid') el.classList.remove('hidden');
    else el.classList.add('hidden');
}
document.getElementById('btnHapus')?.addEventListener('click', function() {
    if (confirm('Yakin ingin menghapus tagihan ini? Tindakan tidak dapat dibatalkan.'))
        document.getElementById('formHapus').submit();
});
const inpTotal = document.getElementById('total');
inpTotal?.addEventListener('blur', function() {
    const raw = parseFloat(this.value.replace(/\./g,'').replace(',','.'));
    if (!isNaN(raw) && raw > 0) this.value = raw.toLocaleString('id-ID');
});
document.querySelector('form[action*="/tagihan/update"]')?.addEventListener('submit', function() {
    inpTotal.value = inpTotal.value.replace(/\./g,'').replace(',','.');
});
</script>