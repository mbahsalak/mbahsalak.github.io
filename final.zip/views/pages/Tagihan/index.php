<?php
/**
 * views/pages/Tagihan/index.php
 */
$appUrl  = $_ENV['APP_URL'] ?? '';
$list    = $tagihan ?? [];
$filter  = $filter  ?? ['status' => '', 'bulan' => ''];

$totalPaid = $totalUnpaid = $nomPaid = $nomUnpaid = 0;
foreach ($list as $row) {
    if ($row['status'] === 'paid') { $totalPaid++;   $nomPaid   += (float)$row['total']; }
    else                           { $totalUnpaid++; $nomUnpaid += (float)$row['total']; }
}


// ── Setting WA dari controller ─────────────────────────────────────────────
$settings   = $settings ?? [];
$waPrefix   = $settings['msg_wa_prefix']     ?? '62';
$msgFooter  = $settings['msg_footer']        ?? '';
$tplBaru    = $settings['msg_tagihan_baru']  ?? 'Halo {nama_pelanggan}, tagihan Anda periode {periode} sebesar {total} jatuh tempo pada {jatuh_tempo}. Terima kasih!';
$tplLunas   = $settings['msg_tagihan_lunas'] ?? 'Terima kasih {nama_pelanggan}! Pembayaran tagihan periode {periode} sebesar {total} telah kami terima.';
$tplJatuh   = $settings['msg_jatuh_tempo']   ?? 'Peringatan! Tagihan Anda periode {periode} sebesar {total} akan jatuh tempo pada {jatuh_tempo}.';
$tplIsolir  = $settings['msg_isolir']        ?? 'Akun Anda akan diisolir karena tagihan periode {periode} belum dibayar. Segera lakukan pembayaran!';
$namaPerush = $settings['company_name']      ?? ($settings['app_name'] ?? 'ISP');
$csPhone    = $settings['company_phone']     ?? '';
// Render template WA dengan data tagihan aktual
$renderWa = function(array $row, string $tpl) use ($namaPerush, $csPhone, $msgFooter): string {
    $map = [
        '{nama_pelanggan}'  => $row['nama_lengkap'] ?? '',
        '{periode}'         => $row['periode_bulan'] ?? '',
        '{total}'           => 'Rp ' . number_format((float)($row['total'] ?? 0), 0, ',', '.'),
        '{jatuh_tempo}'     => !empty($row['jatuh_tempo']) ? date('d M Y', strtotime($row['jatuh_tempo'])) : '-',
        '{nama_perusahaan}' => $namaPerush,
        '{company_phone}'   => $csPhone,
    ];
    $msg = str_replace(array_keys($map), array_values($map), $tpl);
    if ($msgFooter && !str_contains($msg, $msgFooter)) {
        $msg .= "\n\n" . str_replace(array_keys($map), array_values($map), $msgFooter);
    }
    return $msg;
};

// Buat URL WA
$waUrl = function(string $phone, string $msg) use ($waPrefix): string {
    $n = preg_replace('/[^0-9]/', '', $phone);
    if (str_starts_with($n, '0')) $n = substr($n, 1);
    if (!str_starts_with($n, $waPrefix)) $n = $waPrefix . $n;
    return 'https://wa.me/' . $n . '?text=' . urlencode($msg);
};
?>
 <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5">
<!-- ── Page Header ── -->
<div class="flex items-center justify-between flex-wrap gap-4 mb-6">
    <div>
        <h1 class="text-xl font-bold text-gray-900 flex items-center gap-2">
            <i class="fa-solid fa-file-invoice-dollar text-indigo-500"></i>
            Tagihan
        </h1>
        <p class="text-sm text-gray-500 mt-0.5">Kelola tagihan dan pembayaran pelanggan</p>
    </div>
    <div class="flex gap-2 flex-wrap">
        <a href="<?= $appUrl ?>/tagihan/generate"
           class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-amber-400 text-amber-500
                  bg-white text-sm font-semibold hover:bg-amber-50 transition-colors">
            <i class="fa-solid fa-bolt"></i> Generate Tagihan
        </a>
        <a href="<?= $appUrl ?>/tagihan/buat"
           class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-500 text-white
                  text-sm font-semibold hover:bg-indigo-600 transition-colors">
            <i class="fa-solid fa-plus"></i> Buat Tagihan
        </a>
    </div>
</div>

<!-- ── Flash ── -->
<?php if (!empty($flash)): ?>
<div class="flex items-center gap-2 px-4 py-3 rounded-lg mb-4 text-sm font-medium
            <?= ($flash['type'] ?? '') === 'success'
                ? 'bg-green-50 border border-green-200 text-green-700'
                : 'bg-red-50 border border-red-200 text-red-600' ?>" role="alert">
    <i class="fa-solid fa-<?= ($flash['type'] ?? '') === 'success' ? 'circle-check' : 'circle-xmark' ?>"></i>
    <span class="flex-1"><?= htmlspecialchars($flash['message'] ?? '') ?></span>
    <button onclick="this.parentElement.remove()" class="ml-auto text-current opacity-60 hover:opacity-100">
        <i class="fa-solid fa-xmark"></i>
    </button>
</div>
<?php endif; ?>

<!-- ── Summary Cards ── -->
<div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
    <!-- Lunas -->
    <div class="bg-white rounded-xl border-l-4 border-emerald-500 p-5 shadow-sm">
        <p class="text-xs text-gray-500 mb-1 flex items-center gap-1">
            <i class="fa-solid fa-circle-check text-emerald-500"></i> Sudah Lunas
        </p>
        <p class="text-2xl font-bold text-emerald-500"><?= $totalPaid ?></p>
        <p class="text-xs text-gray-400 mt-0.5">Rp <?= number_format($nomPaid, 0, ',', '.') ?></p>
    </div>
    <!-- Belum Lunas -->
    <div class="bg-white rounded-xl border-l-4 border-red-500 p-5 shadow-sm">
        <p class="text-xs text-gray-500 mb-1 flex items-center gap-1">
            <i class="fa-solid fa-clock text-red-500"></i> Belum Lunas
        </p>
        <p class="text-2xl font-bold text-red-500"><?= $totalUnpaid ?></p>
        <p class="text-xs text-gray-400 mt-0.5">Rp <?= number_format($nomUnpaid, 0, ',', '.') ?></p>
    </div>
    <!-- Total -->
    <div class="bg-white rounded-xl border-l-4 border-indigo-500 p-5 shadow-sm">
        <p class="text-xs text-gray-500 mb-1 flex items-center gap-1">
            <i class="fa-solid fa-list text-indigo-500"></i> Total Tagihan
        </p>
        <p class="text-2xl font-bold text-indigo-500"><?= count($list) ?></p>
        <p class="text-xs text-gray-400 mt-0.5">Rp <?= number_format($nomPaid + $nomUnpaid, 0, ',', '.') ?></p>
    </div>
</div>

<!-- ── Filter & Tabel ── -->
<div class="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100">

    <!-- Filter Bar -->
    <div class="flex flex-wrap gap-2 items-center px-5 py-3 border-b border-gray-100">
        <form method="GET" action="<?= $appUrl ?>/tagihan" class="flex flex-wrap gap-2 items-center">
            <select name="status" onchange="this.form.submit()"
                    class="px-3 py-1.5 rounded-lg border border-gray-200 bg-white text-sm cursor-pointer
                           focus:outline-none focus:ring-2 focus:ring-indigo-300">
                <option value="">Semua Status</option>
                <option value="unpaid" <?= ($filter['status'] ?? '') === 'unpaid' ? 'selected' : '' ?>>Belum Lunas</option>
                <option value="paid"   <?= ($filter['status'] ?? '') === 'paid'   ? 'selected' : '' ?>>Sudah Lunas</option>
            </select>
            <input type="month" name="bulan"
                   value="<?= htmlspecialchars($filter['bulan'] ?? '') ?>"
                   onchange="this.form.submit()"
                   class="px-3 py-1.5 rounded-lg border border-gray-200 bg-white text-sm
                          focus:outline-none focus:ring-2 focus:ring-indigo-300">
            <?php if (!empty($filter['status']) || !empty($filter['bulan'])): ?>
            <a href="<?= $appUrl ?>/tagihan"
               class="px-3 py-1.5 rounded-lg border border-gray-200 text-gray-500 text-sm
                      hover:bg-gray-50 transition-colors">
                <i class="fa-solid fa-xmark"></i> Reset
            </a>
            <?php endif; ?>
        </form>
        <!-- Search -->
        <div class="ml-auto relative">
            <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xs pointer-events-none"></i>
            <input type="text" id="searchTagihan" placeholder="Cari pelanggan..."
                   oninput="filterTable(this.value)"
                   class="pl-8 pr-3 py-1.5 rounded-lg border border-gray-200 text-sm w-48
                          focus:outline-none focus:ring-2 focus:ring-indigo-300">
        </div>
    </div>

    <!-- Tabel -->
    <div class="overflow-x-auto">
        <table class="w-full text-sm" id="tabelTagihan">
            <thead>
                <tr class="bg-gray-50 text-xs font-semibold text-gray-500 uppercase tracking-wide">
                    <th class="px-4 py-3 text-left">#</th>
                    <th class="px-4 py-3 text-left">Pelanggan</th>
                    <th class="px-4 py-3 text-left">Paket</th>
                    <th class="px-4 py-3 text-left">Periode</th>
                    <th class="px-4 py-3 text-left">Jatuh Tempo</th>
                    <th class="px-4 py-3 text-right">Total</th>
                    <th class="px-4 py-3 text-center">Status</th>
                    <th class="px-4 py-3 text-left">Tgl Bayar</th>
                    <th class="px-4 py-3 text-left">Metode</th>
                    <th class="px-4 py-3 text-center">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php if (empty($list)): ?>
                <tr>
                    <td colspan="10" class="py-16 text-center text-gray-400">
                        <i class="fa-regular fa-folder-open text-3xl mb-2 block"></i>
                        <p class="text-sm">Belum ada tagihan</p>
                    </td>
                </tr>
                <?php else: foreach ($list as $i => $t):
                    $isPaid    = $t['status'] === 'paid';
                    $isOverdue = !$isPaid && strtotime($t['jatuh_tempo']) < time();
                    $phone     = $t['no_telp'] ?? $t['phone'] ?? '';

                    // Template WA berdasarkan kondisi
                    if ($isPaid) {
                        $waMsg      = $renderWa($t, $tplLunas);
                        $waCls      = 'border-emerald-400 text-emerald-600 hover:bg-emerald-50';
                        $waTitle    = 'Konfirmasi Lunas via WA';
                    } elseif ($isOverdue) {
                        $waMsg      = $renderWa($t, $tplIsolir);
                        $waCls      = 'border-red-400 text-red-600 hover:bg-red-50';
                        $waTitle    = 'Notifikasi Isolir via WA';
                    } else {
                        $daysLeft   = (strtotime($t['jatuh_tempo']) - time()) / 86400;
                        $waMsg      = $renderWa($t, $daysLeft <= 3 ? $tplJatuh : $tplBaru);
                        $waCls      = 'border-emerald-400 text-emerald-600 hover:bg-emerald-50';
                        $waTitle    = $daysLeft <= 3 ? 'Pengingat Jatuh Tempo via WA' : 'Tagihan Baru via WA';
                    }
                ?>
                <tr class="tagihan-row hover:bg-gray-50 transition-colors">
                    <td class="px-4 py-3 text-gray-400 text-xs"><?= $i + 1 ?></td>

                    <!-- Pelanggan -->
                    <td class="px-4 py-3">
                        <div class="flex items-center gap-2">
                            <span class="w-7 h-7 rounded-full bg-indigo-100 text-indigo-600 text-xs font-bold
                                         flex items-center justify-center flex-shrink-0">
                                <?= strtoupper(substr($t['nama_lengkap'], 0, 1)) ?>
                            </span>
                            <span class="font-medium text-gray-800 whitespace-nowrap">
                                <?= htmlspecialchars($t['nama_lengkap']) ?>
                            </span>
                        </div>
                    </td>

                    <!-- Paket -->
                    <td class="px-4 py-3">
                        <span class="px-2 py-0.5 rounded-md bg-gray-100 text-gray-600 text-xs font-medium whitespace-nowrap">
                            <?= htmlspecialchars($t['nama_paket'] ?? '-') ?>
                        </span>
                    </td>

                    <!-- Periode -->
                    <td class="px-4 py-3 text-gray-600 whitespace-nowrap">
                        <?= htmlspecialchars($t['periode_bulan'] ?? '-') ?>
                    </td>

                    <!-- Jatuh Tempo -->
                    <td class="px-4 py-3 whitespace-nowrap">
                        <?php if ($isOverdue): ?>
                            <span class="text-red-500 font-medium text-xs flex items-center gap-1">
                                <i class="fa-solid fa-triangle-exclamation"></i>
                                <?= date('d M Y', strtotime($t['jatuh_tempo'])) ?>
                            </span>
                        <?php else: ?>
                            <span class="text-gray-600 text-xs"><?= date('d M Y', strtotime($t['jatuh_tempo'])) ?></span>
                        <?php endif; ?>
                    </td>

                    <!-- Total -->
                    <td class="px-4 py-3 text-right font-semibold text-gray-800 whitespace-nowrap">
                        Rp <?= number_format((float)$t['total'], 0, ',', '.') ?>
                    </td>

                    <!-- Status badge -->
                    <td class="px-4 py-3 text-center whitespace-nowrap">
                        <?php if ($isPaid): ?>
                            <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold
                                         bg-emerald-100 text-emerald-700">
                                <i class="fa-solid fa-circle-check"></i> Lunas
                            </span>
                        <?php elseif ($isOverdue): ?>
                            <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold
                                         bg-red-100 text-red-600">
                                <i class="fa-solid fa-triangle-exclamation"></i> Jatuh Tempo
                            </span>
                        <?php else: ?>
                            <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold
                                         bg-amber-100 text-amber-600">
                                <i class="fa-solid fa-clock"></i> Belum Lunas
                            </span>
                        <?php endif; ?>
                    </td>

                    <!-- Tgl Bayar -->
                    <td class="px-4 py-3 text-xs text-gray-600 whitespace-nowrap">
                        <?= ($isPaid && !empty($t['tgl_bayar']))
                            ? date('d M Y', strtotime($t['tgl_bayar']))
                            : '<span class="text-gray-300">—</span>' ?>
                    </td>

                    <!-- Metode -->
                    <td class="px-4 py-3">
                        <?php if (!empty($t['metode_pembayaran'])): ?>
                            <span class="px-2 py-0.5 rounded bg-gray-100 text-gray-600 text-xs">
                                <?= htmlspecialchars(ucfirst($t['metode_pembayaran'])) ?>
                            </span>
                        <?php else: ?>
                            <span class="text-gray-300">—</span>
                        <?php endif; ?>
                    </td>

                    <!-- Aksi -->
                    <td class="px-4 py-3">
                        <div class="flex items-center justify-center gap-1">

                            <!-- WA -->
                            <?php if ($phone): ?>
                            <a href="<?= $waUrl($phone, $waMsg) ?>"
                               target="_blank" rel="noopener noreferrer"
                               title="<?= htmlspecialchars($waTitle) ?>"
                               class="p-1.5 rounded-md border text-xs transition-colors <?= $waCls ?>">
                                <i class="fa-brands fa-whatsapp"></i>
                            </a>
                            <?php endif; ?>

                            <!-- Detail -->
                            <a href="<?= $appUrl ?>/tagihan/<?= $t['id'] ?>" title="Detail"
                               class="p-1.5 rounded-md border border-indigo-300 text-indigo-500
                                      text-xs hover:bg-indigo-50 transition-colors">
                                <i class="fa-solid fa-eye"></i>
                            </a>

                            <!-- Edit -->
                            <a href="<?= $appUrl ?>/tagihan/edit/<?= $t['id'] ?>" title="Edit"
                               class="p-1.5 rounded-md border border-amber-300 text-amber-500
                                      text-xs hover:bg-amber-50 transition-colors">
                                <i class="fa-solid fa-pencil"></i>
                            </a>

                            <!-- Bayar (hanya unpaid) -->
                            <?php if (!$isPaid): ?>
                            <a href="<?= $appUrl ?>/tagihan/bayar/<?= $t['id'] ?>" title="Bayar"
                               class="p-1.5 rounded-md border border-emerald-300 text-emerald-600
                                      text-xs hover:bg-emerald-50 transition-colors">
                                <i class="fa-solid fa-money-bill-wave"></i>
                            </a>
                            <?php endif; ?>

                            <!-- Cetak -->
                            <a href="<?= $appUrl ?>/tagihan/cetak/<?= $t['id'] ?>" title="Cetak Invoice"
                               class="p-1.5 rounded-md border border-gray-300 text-gray-500
                                      text-xs hover:bg-gray-50 transition-colors">
                                <i class="fa-solid fa-print"></i>
                            </a>

                            <!-- Hapus -->
                            <button onclick="hapusTagihan(<?= $t['id'] ?>)" title="Hapus"
                                    class="p-1.5 rounded-md border border-red-300 text-red-500
                                           text-xs hover:bg-red-50 transition-colors bg-transparent cursor-pointer">
                                <i class="fa-solid fa-trash"></i>
                            </button>

                        </div>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Footer count -->
    <?php if (!empty($list)): ?>
    <div class="px-5 py-2.5 border-t border-gray-100 text-xs text-gray-400">
        Menampilkan <?= count($list) ?> tagihan
    </div>
    <?php endif; ?>
</div>

<!-- ── Modal Hapus ── -->
<div id="modalHapus" onclick="if(event.target===this)this.style.display='none'"
     class="hidden fixed inset-0 z-50 bg-black/40 items-center justify-center p-4"
     style="display:none">
    <div class="bg-white rounded-2xl w-full max-w-sm shadow-2xl" onclick="event.stopPropagation()">
        <form method="POST" id="formHapus">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
            <div class="p-8 text-center">
                <div class="w-14 h-14 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4">
                    <i class="fa-solid fa-trash text-red-500 text-xl"></i>
                </div>
                <h3 class="font-bold text-gray-900 mb-1">Hapus Tagihan?</h3>
                <p class="text-sm text-gray-500">Tagihan ini akan dihapus permanen.</p>
            </div>
            <div class="flex justify-center gap-2 px-6 pb-6">
                <button type="button"
                        onclick="document.getElementById('modalHapus').style.display='none'"
                        class="px-5 py-2 rounded-lg border border-gray-200 text-gray-600
                               text-sm hover:bg-gray-50 transition-colors cursor-pointer">
                    Batal
                </button>
                <button type="submit"
                        class="px-5 py-2 rounded-lg bg-red-500 text-white text-sm font-semibold
                               hover:bg-red-600 transition-colors cursor-pointer">
                    Ya, Hapus
                </button>
            </div>
        </form>
    </div>
</div>
</div>
<script>
function filterTable(q) {
    q = q.toLowerCase();
    document.querySelectorAll('#tabelTagihan .tagihan-row').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
}
function hapusTagihan(id) {
    document.getElementById('formHapus').action = `<?= $appUrl ?>/tagihan/hapus/${id}`;
    document.getElementById('modalHapus').style.display = 'flex';
}
</script>
