<?php declare(strict_types=1);
$appUrl = $_ENV['APP_URL'] ?? '';
$old    = $old    ?? [];
$errors = $errors ?? [];
?>

<!-- Header -->
<div class="flex items-center justify-between flex-wrap gap-4 mb-6">
    <div>
        <h1 class="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <i class="fa-solid fa-plus text-indigo-500"></i> Buat Tagihan
        </h1>
        <p class="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Buat tagihan manual untuk satu pelanggan</p>
    </div>
    <div class="flex gap-2">
        <a href="<?= $appUrl ?>/tagihan/generate"
           onclick="return confirm('Generate tagihan otomatis semua pelanggan bulan ini?')"
           class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-amber-400
                  text-amber-500 text-sm font-semibold hover:bg-amber-50 dark:hover:bg-amber-950 transition-colors">
            <i class="fa-solid fa-bolt"></i> Generate Otomatis
        </a>
        <a href="<?= $appUrl ?>/tagihan"
           class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-gray-200
                  dark:border-gray-600 text-gray-600 dark:text-gray-300 text-sm font-semibold
                  hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            <i class="fa-solid fa-arrow-left"></i> Kembali
        </a>
    </div>
</div>

<?php if (!empty($flash['error'])): ?>
<div class="flex items-center gap-2 px-4 py-3 rounded-lg mb-4 text-sm
            bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400">
    <i class="fa-solid fa-circle-exclamation"></i>
    <?= htmlspecialchars($flash['error']) ?>
</div>
<?php endif; ?>

<div class="max-w-2xl">
<form method="POST" action="<?= $appUrl ?>/tagihan/simpan" id="formBuatTagihan">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token ?? '', ENT_QUOTES) ?>">

    <!-- ── Data Pelanggan ── -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5 mb-4">
        <h3 class="text-xs font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-4 pb-2
                   border-b border-gray-100 dark:border-gray-700 flex items-center gap-1.5">
            <i class="fa-solid fa-user text-indigo-500"></i> Data Pelanggan
        </h3>

        <div class="mb-4">
            <label class="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1.5">
                Pelanggan <span class="text-red-500">*</span>
            </label>
            <select name="pelanggan_id" id="pelanggan_id" required
                    class="w-full px-3 py-2 rounded-lg border text-sm bg-white dark:bg-gray-900
                           text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-300
                           <?= !empty($errors['pelanggan_id'])
                               ? 'border-red-400 dark:border-red-600'
                               : 'border-gray-200 dark:border-gray-600' ?>">
                <option value="">— Pilih Pelanggan —</option>
                <?php foreach ($pelanggans as $p): ?>
                <option value="<?= $p['id'] ?>"
                        data-harga="<?= (float)$p['harga'] ?>"
                        data-paket="<?= htmlspecialchars($p['nama_paket']) ?>"
                        <?= ((string)($old['pelanggan_id'] ?? '')) === ((string)$p['id']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($p['nama_lengkap']) ?> — <?= htmlspecialchars($p['nama_paket']) ?>
                    (Rp <?= number_format((float)$p['harga'], 0, ',', '.') ?>)
                </option>
                <?php endforeach; ?>
            </select>
            <?php if (!empty($errors['pelanggan_id'])): ?>
            <p class="text-red-500 text-xs mt-1"><?= htmlspecialchars($errors['pelanggan_id']) ?></p>
            <?php endif; ?>
        </div>

        <!-- Info paket -->
        <div id="paketInfo" class="hidden flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium
                                   bg-indigo-50 dark:bg-indigo-950 border border-indigo-100 dark:border-indigo-800
                                   text-indigo-700 dark:text-indigo-300">
            <i class="fa-solid fa-box"></i>
            <span>Paket: <strong id="paketNama">—</strong></span>
            <span class="text-gray-300 dark:text-gray-600">·</span>
            <span>Harga: <strong id="paketHarga">—</strong></span>
        </div>
    </div>

    <!-- ── Tipe Tagihan ── -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5 mb-4">
        <h3 class="text-xs font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-4 pb-2
                   border-b border-gray-100 dark:border-gray-700 flex items-center gap-1.5">
            <i class="fa-solid fa-tag text-indigo-500"></i> Tipe Tagihan
        </h3>

        <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
            <?php
            $tipes   = [
                'paket'      => ['fa-wifi',                '#6366f1', 'Paket Bulanan'],
                'pemasangan' => ['fa-screwdriver-wrench',  '#f59e0b', 'Pemasangan'],
                'perbaikan'  => ['fa-wrench',              '#ef4444', 'Perbaikan'],
                'lainnya'    => ['fa-ellipsis',            '#6b7280', 'Lainnya'],
            ];
            $curTipe = $old['tipe'] ?? 'paket';
            foreach ($tipes as $val => [$icon, $color, $label]):
            ?>
            <label class="cursor-pointer">
                <input type="radio" name="tipe" value="<?= $val ?>"
                       <?= $curTipe === $val ? 'checked' : '' ?>
                       class="sr-only tipe-radio" onchange="onTipeChange('<?= $val ?>')">
                <div class="tipe-card text-center rounded-xl p-3 border-2 transition-all select-none
                            <?= $curTipe === $val ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-950' : 'border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-900' ?>"
                     data-val="<?= $val ?>" data-color="<?= $color ?>"
                     onclick="selectTipe('<?= $val ?>','<?= $color ?>')">
                    <i class="fa-solid <?= $icon ?> text-lg block mb-1" style="color:<?= $color ?>"></i>
                    <span class="text-xs font-semibold text-gray-700 dark:text-gray-200"><?= $label ?></span>
                </div>
            </label>
            <?php endforeach; ?>
        </div>
        <?php if (!empty($errors['tipe'])): ?>
        <p class="text-red-500 text-xs"><?= htmlspecialchars($errors['tipe']) ?></p>
        <?php endif; ?>

        <!-- Deskripsi (muncul jika bukan paket) -->
        <div id="deskripsiGroup" class="<?= $curTipe === 'paket' ? 'hidden' : '' ?>">
            <label class="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1.5">
                Keterangan / Deskripsi
            </label>
            <input type="text" name="deskripsi" id="deskripsi"
                   value="<?= htmlspecialchars($old['deskripsi'] ?? '') ?>"
                   placeholder="Contoh: Pemasangan baru di Gang Mawar No.5"
                   class="w-full px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-600 text-sm
                          bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100
                          focus:outline-none focus:ring-2 focus:ring-indigo-300">
            <p class="text-xs text-gray-400 dark:text-gray-500 mt-1">Jelaskan pekerjaan atau layanan yang ditagihkan.</p>
        </div>
    </div>

    <!-- ── Detail Tagihan ── -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5 mb-4">
        <h3 class="text-xs font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-4 pb-2
                   border-b border-gray-100 dark:border-gray-700 flex items-center gap-1.5">
            <i class="fa-solid fa-file-invoice text-indigo-500"></i> Detail Tagihan
        </h3>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
            <div>
                <label class="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1.5">
                    Periode Bulan <span class="text-red-500">*</span>
                </label>
                <input type="month" name="periode_bulan" id="periode_bulan" required
                       value="<?= htmlspecialchars($old['periode_bulan'] ?? $bulan_ini) ?>"
                       class="w-full px-3 py-2 rounded-lg border text-sm bg-white dark:bg-gray-900
                              text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-300
                              <?= !empty($errors['periode_bulan']) ? 'border-red-400' : 'border-gray-200 dark:border-gray-600' ?>">
                <?php if (!empty($errors['periode_bulan'])): ?>
                <p class="text-red-500 text-xs mt-1"><?= htmlspecialchars($errors['periode_bulan']) ?></p>
                <?php endif; ?>
            </div>
            <div>
                <label class="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1.5">
                    Jatuh Tempo <span class="text-red-500">*</span>
                </label>
                <input type="date" name="jatuh_tempo" id="jatuh_tempo" required
                       value="<?= htmlspecialchars($old['jatuh_tempo'] ?? '') ?>"
                       class="w-full px-3 py-2 rounded-lg border text-sm bg-white dark:bg-gray-900
                              text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-300
                              <?= !empty($errors['jatuh_tempo']) ? 'border-red-400' : 'border-gray-200 dark:border-gray-600' ?>">
                <?php if (!empty($errors['jatuh_tempo'])): ?>
                <p class="text-red-500 text-xs mt-1"><?= htmlspecialchars($errors['jatuh_tempo']) ?></p>
                <?php endif; ?>
            </div>
        </div>

        <div>
            <label class="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1.5">
                Total Tagihan <span class="text-red-500">*</span>
            </label>
            <div class="relative">
                <span class="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-semibold
                             text-gray-400 dark:text-gray-500 pointer-events-none">Rp</span>
                <input type="text" name="total" id="total" required inputmode="numeric"
                       value="<?= htmlspecialchars($old['total'] ?? '') ?>"
                       placeholder="0"
                       class="w-full pl-9 pr-3 py-2 rounded-lg border text-sm bg-white dark:bg-gray-900
                              text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-300
                              <?= !empty($errors['total']) ? 'border-red-400' : 'border-gray-200 dark:border-gray-600' ?>">
            </div>
            <?php if (!empty($errors['total'])): ?>
            <p class="text-red-500 text-xs mt-1"><?= htmlspecialchars($errors['total']) ?></p>
            <?php endif; ?>
            <p class="text-xs text-gray-400 dark:text-gray-500 mt-1" id="hintTotal">
                Otomatis terisi dari harga paket. Bisa diubah manual.
            </p>
        </div>
    </div>

    <!-- Preview -->
    <div id="tagihanPreview"
         class="hidden bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 mb-4 overflow-hidden">
        <div class="px-5 py-3 bg-gray-50 dark:bg-gray-900 border-b border-gray-100 dark:border-gray-700
                    text-xs font-bold text-gray-500 dark:text-gray-400 flex items-center gap-1.5">
            <i class="fa-solid fa-eye text-indigo-500"></i> Preview Tagihan
        </div>
        <div class="p-5 space-y-2">
            <?php foreach (['prevNama'=>'Pelanggan','prevTipe'=>'Tipe','prevPeriode'=>'Periode','prevTempo'=>'Jatuh Tempo'] as $id=>$lbl): ?>
            <div class="flex justify-between text-sm border-b border-gray-50 dark:border-gray-700 pb-1.5">
                <span class="text-gray-400 dark:text-gray-500"><?= $lbl ?></span>
                <strong class="text-gray-800 dark:text-gray-100" id="<?= $id ?>">—</strong>
            </div>
            <?php endforeach; ?>
            <div id="prevDeskripsiRow" class="hidden flex justify-between text-sm pb-1.5">
                <span class="text-gray-400 dark:text-gray-500">Keterangan</span>
                <strong class="text-gray-800 dark:text-gray-100" id="prevDeskripsi">—</strong>
            </div>
            <div class="flex justify-between text-sm pt-1">
                <span class="text-gray-400 dark:text-gray-500">Total</span>
                <strong class="text-indigo-600 dark:text-indigo-400 text-base" id="prevTotal">—</strong>
            </div>
        </div>
    </div>

    <!-- Actions -->
    <div class="flex justify-end gap-3 pt-2">
        <a href="<?= $appUrl ?>/tagihan"
           class="px-5 py-2 rounded-lg border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-300
                  text-sm font-semibold hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            Batal
        </a>
        <button type="submit"
                class="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg bg-indigo-500 text-white
                       text-sm font-semibold hover:bg-indigo-600 transition-colors">
            <i class="fa-solid fa-floppy-disk"></i> Simpan Tagihan
        </button>
    </div>

</form>
</div>

<script>
(function () {
    const selPel     = document.getElementById('pelanggan_id');
    const inpTotal   = document.getElementById('total');
    const inpPeriode = document.getElementById('periode_bulan');
    const inpTempo   = document.getElementById('jatuh_tempo');
    const inpDesk    = document.getElementById('deskripsi');
    const paketInfo  = document.getElementById('paketInfo');
    const preview    = document.getElementById('tagihanPreview');
    const tipeLabels = {paket:'Paket Bulanan',pemasangan:'Pemasangan',perbaikan:'Perbaikan',lainnya:'Lainnya'};

    function fmtNum(n) { return Math.round(n).toLocaleString('id-ID'); }
    function curTipe() { return document.querySelector('input[name="tipe"]:checked')?.value || 'paket'; }

    window.selectTipe = function(val, color) {
        document.querySelectorAll('.tipe-card').forEach(c => {
            c.classList.remove('border-indigo-500','bg-indigo-50','dark:bg-indigo-950');
            c.classList.add('border-gray-200','dark:border-gray-600','bg-white','dark:bg-gray-900');
        });
        const card = document.querySelector(`.tipe-card[data-val="${val}"]`);
        if (card) {
            card.classList.remove('border-gray-200','dark:border-gray-600','bg-white','dark:bg-gray-900');
            card.classList.add('border-indigo-500','bg-indigo-50','dark:bg-indigo-950');
        }
        const radio = document.querySelector(`input[name="tipe"][value="${val}"]`);
        if (radio) radio.checked = true;
        onTipeChange(val);
    };

    window.onTipeChange = function(val) {
        const deskGroup = document.getElementById('deskripsiGroup');
        const hint      = document.getElementById('hintTotal');
        if (val === 'paket') {
            deskGroup.classList.add('hidden');
            hint.textContent = 'Otomatis terisi dari harga paket. Bisa diubah manual.';
            const opt = selPel.options[selPel.selectedIndex];
            if (opt?.value && !inpTotal.value) inpTotal.value = fmtNum(parseFloat(opt.dataset.harga||'0'));
        } else {
            deskGroup.classList.remove('hidden');
            hint.textContent = 'Masukkan nominal tagihan untuk layanan ini.';
            inpTotal.value = '';
        }
        updatePreview();
    };

    function updatePreview() {
        const opt  = selPel.options[selPel.selectedIndex];
        const nama = opt?.text?.split(' — ')[0] ?? '—';
        const tipe = curTipe();
        const desk = inpDesk?.value.trim() || '';
        const total= parseFloat(inpTotal.value.replace(/\./g,'').replace(',','.')) || 0;
        const tempo= inpTempo.value;
        const per  = inpPeriode.value;

        if (selPel.value && total > 0) {
            preview.classList.remove('hidden');
            document.getElementById('prevNama').textContent    = nama;
            document.getElementById('prevTipe').textContent    = tipeLabels[tipe]||tipe;
            document.getElementById('prevPeriode').textContent = per||'—';
            document.getElementById('prevTempo').textContent   = tempo
                ? new Date(tempo+'T00:00').toLocaleDateString('id-ID',{day:'numeric',month:'long',year:'numeric'}) : '—';
            document.getElementById('prevTotal').textContent   = 'Rp '+fmtNum(total);
            const deskRow = document.getElementById('prevDeskripsiRow');
            if (desk && tipe !== 'paket') {
                deskRow.classList.remove('hidden');
                document.getElementById('prevDeskripsi').textContent = desk;
            } else deskRow.classList.add('hidden');
        } else preview.classList.add('hidden');
    }

    selPel.addEventListener('change', function() {
        const opt = this.options[this.selectedIndex];
        if (!opt.value) { paketInfo.classList.add('hidden'); inpTotal.value=''; updatePreview(); return; }
        const harga = parseFloat(opt.dataset.harga||'0');
        document.getElementById('paketNama').textContent = opt.dataset.paket||'—';
        document.getElementById('paketHarga').textContent = 'Rp '+fmtNum(harga);
        paketInfo.classList.remove('hidden');
        if (curTipe()==='paket' && !inpTotal.value) inpTotal.value = fmtNum(harga);
        updatePreview();
    });

    inpTotal.addEventListener('blur', function() {
        const raw = parseFloat(this.value.replace(/\./g,'').replace(',','.'));
        if (!isNaN(raw) && raw > 0) this.value = fmtNum(raw);
        updatePreview();
    });
    inpPeriode.addEventListener('change', updatePreview);
    inpTempo.addEventListener('change', updatePreview);
    inpDesk?.addEventListener('input', updatePreview);

    document.getElementById('formBuatTagihan').addEventListener('submit', function() {
        inpTotal.value = inpTotal.value.replace(/\./g,'').replace(',','.');
    });
})();
</script>