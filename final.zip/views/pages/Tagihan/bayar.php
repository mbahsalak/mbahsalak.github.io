<?php
$appUrl = $_ENV['APP_URL'] ?? '';
$t      = $tagihan ?? [];
?>

<div class="max-w-lg space-y-4">

    <a href="<?= $appUrl ?>/tagihan"
       class="inline-flex items-center gap-1.5 text-sm text-gray-500 dark:text-gray-400
              hover:text-indigo-500 transition-colors">
        <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar Tagihan
    </a>

    <?php if (!empty($flash)): ?>
    <div class="flex items-center gap-2 px-4 py-3 rounded-lg text-sm
                <?= ($flash['type']??'')==='success'
                    ? 'bg-emerald-50 dark:bg-emerald-950 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400'
                    : 'bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400' ?>">
        <i class="fa-solid fa-<?= ($flash['type']??'')==='success'?'circle-check':'circle-xmark' ?>"></i>
        <span class="flex-1"><?= htmlspecialchars($flash['message']??'') ?></span>
        <button onclick="this.parentElement.remove()" class="opacity-60 hover:opacity-100">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>
    <?php endif; ?>

    <!-- Card -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div class="h-1 bg-emerald-500"></div>
        <div class="p-6">

            <h2 class="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-5">
                <i class="fa-solid fa-money-bill-wave text-emerald-500"></i> Konfirmasi Pembayaran
            </h2>

            <!-- Ringkasan -->
            <div class="bg-gray-50 dark:bg-gray-900 rounded-xl p-4 mb-5">
                <div class="flex justify-between items-start pb-3 mb-3 border-b border-gray-200 dark:border-gray-700">
                    <div>
                        <p class="text-xs text-gray-400 dark:text-gray-500 mb-0.5">Pelanggan</p>
                        <p class="font-bold text-gray-900 dark:text-white">
                            <?= htmlspecialchars($t['nama_lengkap'] ?? '-') ?>
                        </p>
                        <?php if (!empty($t['no_telp'])): ?>
                        <p class="text-xs text-gray-500 dark:text-gray-400"><?= htmlspecialchars($t['no_telp']) ?></p>
                        <?php endif; ?>
                        <?php if (!empty($t['alamat'])): ?>
                        <p class="text-xs text-gray-400 dark:text-gray-500 mt-0.5">
                            <i class="fa-solid fa-location-dot mr-1"></i><?= htmlspecialchars($t['alamat']) ?>
                        </p>
                        <?php endif; ?>
                    </div>
                    <div class="text-right">
                        <p class="text-xs text-gray-400 dark:text-gray-500 mb-0.5">ID Tagihan</p>
                        <p class="font-semibold text-gray-800 dark:text-gray-100">#<?= $t['id'] ?? '-' ?></p>
                    </div>
                </div>

                <!-- Detail rows -->
                <div class="space-y-2">
                    <?php
                    $rows = [
                        ['fa-wifi',           'Paket',       $t['nama_paket'] ?? '-'],
                        ['fa-gauge-high',     'Kecepatan',   !empty($t['kecepatan']) ? $t['kecepatan'].' Mbps' : '-'],
                        ['fa-calendar',       'Periode',     $t['periode_bulan'] ?? '-'],
                        ['fa-calendar-xmark', 'Jatuh Tempo', !empty($t['jatuh_tempo']) ? date('d M Y', strtotime($t['jatuh_tempo'])) : '-'],
                    ];
                    foreach ($rows as [$icon, $lbl, $val]):
                    ?>
                    <div class="flex justify-between text-sm border-b border-gray-100 dark:border-gray-700 pb-2">
                        <span class="text-gray-500 dark:text-gray-400 flex items-center gap-1.5">
                            <i class="fa-solid <?= $icon ?> w-4 text-center"></i><?= $lbl ?>
                        </span>
                        <span class="font-medium text-gray-800 dark:text-gray-100"><?= htmlspecialchars((string)$val) ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Total -->
                <div class="flex justify-between items-center mt-3 pt-3 border-t-2 border-gray-200 dark:border-gray-600">
                    <span class="font-bold text-sm text-gray-800 dark:text-gray-100">Total Pembayaran</span>
                    <span class="font-bold text-xl text-emerald-500">
                        Rp <?= number_format((float)($t['total']??0), 0, ',', '.') ?>
                    </span>
                </div>
            </div>

            <!-- Form -->
            <form method="POST" action="<?= $appUrl ?>/tagihan/bayar/<?= $t['id'] ?>">
                <input type="hidden" name="csrf_token"
                       value="<?= htmlspecialchars(\Core\Middleware::generateCsrfToken()) ?>">

                <!-- Metode Pembayaran -->
                <div class="mb-5">
                    <label class="block text-xs font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-2">
                        <i class="fa-solid fa-credit-card text-indigo-500 mr-1"></i>
                        Metode Pembayaran <span class="text-red-500">*</span>
                    </label>
                    <div class="grid grid-cols-3 gap-2">
                        <?php foreach ([
                            ['tunai',    'fa-money-bill-wave',   'Tunai',    '#10b981'],
                            ['transfer', 'fa-building-columns',  'Transfer', '#6366f1'],
                            ['qris',     'fa-qrcode',            'QRIS',     '#f59e0b'],
                        ] as [$v, $icon, $lbl, $color]): ?>
                        <label class="cursor-pointer">
                            <input type="radio" name="metode_pembayaran" value="<?= $v ?>"
                                   class="sr-only metode-radio">
                            <div class="metode-card text-center rounded-xl p-3 border-2 border-gray-200
                                        dark:border-gray-600 bg-white dark:bg-gray-900 transition-all select-none"
                                 data-val="<?= $v ?>" data-color="<?= $color ?>"
                                 onclick="selectMetode('<?= $v ?>','<?= $color ?>')">
                                <i class="fa-solid <?= $icon ?> text-xl block mb-1" style="color:<?= $color ?>"></i>
                                <span class="text-xs font-semibold text-gray-700 dark:text-gray-200"><?= $lbl ?></span>
                            </div>
                        </label>
                        <?php endforeach; ?>
                    </div>
                    <p id="metodeError" class="hidden text-red-500 text-xs mt-1.5">
                        <i class="fa-solid fa-circle-exclamation mr-1"></i>Pilih metode pembayaran.
                    </p>
                </div>

                <!-- Penerima -->
                <div class="mb-5">
                    <label class="block text-xs font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-2">
                        <i class="fa-solid fa-user-check text-indigo-500 mr-1"></i>
                        Penerima Pembayaran <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="penerima" required
                           value="<?= htmlspecialchars($_SESSION['user']['username'] ?? '') ?>"
                           placeholder="Nama penerima / kasir"
                           class="w-full px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-600 text-sm
                                  bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100
                                  focus:outline-none focus:ring-2 focus:ring-indigo-300">
                    <p class="text-xs text-gray-400 dark:text-gray-500 mt-1">Default: nama akun yang sedang login.</p>
                </div>

                <!-- Note -->
                <p class="flex items-start gap-2 text-xs text-gray-500 dark:text-gray-400 mb-5">
                    <i class="fa-solid fa-circle-info text-indigo-500 mt-0.5 flex-shrink-0"></i>
                    Dengan menekan <strong>Tandai Lunas</strong>, tagihan ini akan dicatat sebagai sudah dibayar.
                </p>

                <div class="flex justify-end gap-2">
                    <a href="<?= $appUrl ?>/tagihan"
                       class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-gray-200
                              dark:border-gray-600 text-gray-600 dark:text-gray-300 text-sm font-semibold
                              hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                        <i class="fa-solid fa-xmark"></i> Batal
                    </a>
                    <button type="submit" onclick="return validateForm()"
                            class="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg bg-emerald-500 text-white
                                   text-sm font-semibold hover:bg-emerald-600 transition-colors cursor-pointer">
                        <i class="fa-solid fa-circle-check"></i> Tandai Lunas
                    </button>
                </div>
            </form>

        </div>
    </div>

</div>

<script>
function selectMetode(val, color) {
    document.querySelectorAll('.metode-card').forEach(c => {
        c.style.borderColor = '';
        c.style.background  = '';
        c.classList.add('border-gray-200','dark:border-gray-600');
        c.classList.remove('border-opacity-100');
    });
    const card = document.querySelector(`.metode-card[data-val="${val}"]`);
    if (card) { card.style.borderColor = color; card.style.background = color+'18'; }
    const radio = document.querySelector(`input[value="${val}"]`);
    if (radio) radio.checked = true;
    document.getElementById('metodeError').classList.add('hidden');
}
function validateForm() {
    if (!document.querySelector('input[name="metode_pembayaran"]:checked')) {
        document.getElementById('metodeError').classList.remove('hidden');
        return false;
    }
    return true;
}
</script>