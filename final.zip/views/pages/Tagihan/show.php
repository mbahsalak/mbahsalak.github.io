<?php declare(strict_types=1);
$appUrl  = $_ENV['APP_URL'] ?? '';
$appName = $_ENV['APP_NAME'] ?? 'ISP';
$t       = $tagihan ?? [];
$isPaid  = ($t['status'] ?? '') === 'paid';
$role    = $_SESSION['user']['role'] ?? '';
?>

<div class="max-w-2xl mx-auto space-y-4">

    <!-- Back -->
    <a href="<?= $appUrl ?>/tagihan"
       class="inline-flex items-center gap-1.5 text-sm text-gray-500 dark:text-gray-400
              hover:text-indigo-500 dark:hover:text-indigo-400 transition-colors">
        <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar Tagihan
    </a>

    <!-- ── Invoice Card ── -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">

        <!-- Header dark bar -->
        <div class="bg-gray-900 dark:bg-gray-950 px-6 py-4 flex justify-between items-center">
            <div>
                <p class="text-white font-bold text-base"><?= htmlspecialchars($appName) ?></p>
                <p class="text-gray-400 text-xs mt-0.5">Sistem Faktur Penagihan Digital</p>
            </div>
            <?php if ($isPaid): ?>
            <span class="px-2.5 py-1 rounded-md text-xs font-bold uppercase tracking-wider
                         bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <i class="fa-solid fa-circle-check mr-1"></i>Lunas
            </span>
            <?php else: ?>
            <span class="px-2.5 py-1 rounded-md text-xs font-bold uppercase tracking-wider
                         bg-red-500/20 text-red-400 border border-red-500/30">
                <i class="fa-solid fa-clock mr-1"></i>Belum Bayar
            </span>
            <?php endif; ?>
        </div>

        <div class="p-6">

            <!-- Info Grid -->
            <div class="grid grid-cols-2 gap-4 mb-6">
                <div>
                    <p class="text-xs font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-1">
                        Ditagih Kepada
                    </p>
                    <p class="font-bold text-gray-900 dark:text-white text-sm">
                        <?= htmlspecialchars($t['nama_lengkap'] ?? '-') ?>
                    </p>
                    <?php if (!empty($t['no_telp'])): ?>
                    <p class="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                        <?= htmlspecialchars($t['no_telp']) ?>
                    </p>
                    <?php endif; ?>
                    <?php if (!empty($t['alamat'])): ?>
                    <p class="text-xs text-gray-400 dark:text-gray-500 mt-0.5">
                        <i class="fa-solid fa-location-dot mr-1"></i><?= htmlspecialchars($t['alamat']) ?>
                    </p>
                    <?php endif; ?>
                </div>
                <div class="text-right">
                    <p class="text-xs font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-1">
                        No. Invoice
                    </p>
                    <p class="font-bold text-gray-900 dark:text-white font-mono text-sm">
                        INV/<?= $t['id'] ?? '-' ?>/<?= str_replace('-', '', $t['periode_bulan'] ?? '') ?>
                    </p>
                    <p class="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                        Periode: <?= htmlspecialchars($t['periode_bulan'] ?? '-') ?>
                    </p>
                </div>
            </div>

            <!-- Tabel Layanan -->
            <div class="rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden mb-5">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-gray-50 dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700">
                            <th class="px-4 py-2.5 text-left text-xs font-bold uppercase tracking-widest text-gray-400">
                                Deskripsi Layanan
                            </th>
                            <th class="px-4 py-2.5 text-right text-xs font-bold uppercase tracking-widest text-gray-400">
                                Subtotal
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="border-b border-gray-100 dark:border-gray-700">
                            <td class="px-4 py-3">
                                <p class="font-semibold text-gray-800 dark:text-gray-100">
                                    <?= htmlspecialchars($t['nama_paket'] ?? '-') ?>
                                </p>
                                <p class="text-xs text-gray-400 dark:text-gray-500 mt-0.5">
                                    Biaya langganan bulanan internet
                                    <?php if (!empty($t['deskripsi'])): ?>
                                        · <?= htmlspecialchars($t['deskripsi']) ?>
                                    <?php endif; ?>
                                </p>
                            </td>
                            <td class="px-4 py-3 text-right font-mono font-medium text-gray-700 dark:text-gray-200">
                                Rp <?= number_format((float)($t['total'] ?? 0), 0, ',', '.') ?>
                            </td>
                        </tr>
                        <tr class="bg-gray-50 dark:bg-gray-900">
                            <td class="px-4 py-3 text-right text-xs font-bold uppercase tracking-wide text-gray-400">
                                Total Pembayaran
                            </td>
                            <td class="px-4 py-3 text-right font-mono font-bold text-indigo-600 dark:text-indigo-400 text-base">
                                Rp <?= number_format((float)($t['total'] ?? 0), 0, ',', '.') ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Info Lunas -->
            <?php if ($isPaid): ?>
            <div class="flex items-start gap-3 px-4 py-3 rounded-lg mb-5
                        bg-emerald-50 dark:bg-emerald-950 border border-emerald-200 dark:border-emerald-800">
                <i class="fa-solid fa-circle-check text-emerald-500 mt-0.5"></i>
                <div>
                    <p class="text-xs font-bold text-emerald-700 dark:text-emerald-400 mb-1">Pembayaran Diterima</p>
                    <div class="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-emerald-800 dark:text-emerald-300">
                        <span>Tgl Bayar: <strong>
                            <?= !empty($t['tgl_bayar']) ? date('d M Y H:i', strtotime($t['tgl_bayar'])) : '-' ?>
                        </strong></span>
                        <span>Metode: <strong>
                            <?= !empty($t['metode_pembayaran']) ? htmlspecialchars(ucfirst($t['metode_pembayaran'])) : '-' ?>
                        </strong></span>
                        <span>Penerima: <strong>
                            <?= !empty($t['penerima']) ? htmlspecialchars($t['penerima']) : '-' ?>
                        </strong></span>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Actions -->
            <div class="flex justify-end gap-2 pt-4 border-t border-gray-100 dark:border-gray-700">
                <?php if (in_array($role, ['admin','kasir'])): ?>
                <a href="<?= $appUrl ?>/tagihan/edit/<?= $t['id'] ?>"
                   class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-amber-300
                          text-amber-600 dark:text-amber-400 text-sm font-semibold
                          hover:bg-amber-50 dark:hover:bg-amber-950 transition-colors">
                    <i class="fa-solid fa-pencil"></i> Edit
                </a>
                <?php endif; ?>
                <a href="<?= $appUrl ?>/tagihan/cetak/<?= $t['id'] ?>" target="_blank"
                   class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-gray-900 dark:bg-gray-700
                          text-white text-sm font-semibold hover:bg-gray-700 dark:hover:bg-gray-600 transition-colors">
                    <i class="fa-solid fa-print"></i> Cetak Invoice
                </a>
                <?php if (!$isPaid && in_array($role, ['admin','kasir'])): ?>
                <a href="<?= $appUrl ?>/tagihan/bayar/<?= $t['id'] ?>"
                   class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-500
                          text-white text-sm font-semibold hover:bg-emerald-600 transition-colors">
                    <i class="fa-solid fa-check-double"></i> Terima Pembayaran
                </a>
                <?php endif; ?>
            </div>

        </div>
    </div>

</div>