<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice #<?= $tagihan['id'] ?? '' ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            font-size: 13px;
            color: #111;
            background: #fff;
            padding: 2rem;
        }
        .invoice-wrap { max-width: 680px; margin: 0 auto; }

        /* Header */
        .inv-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 2rem;
            padding-bottom: 1.25rem;
            border-bottom: 2px solid #6366f1;
        }
        .inv-logo { font-size: 1.5rem; font-weight: 800; color: #6366f1; }
        .inv-logo span { color: #111; }
        .inv-company-sub { font-size: .75rem; color: #6b7280; margin-top: .2rem; }
        .inv-badge {
            text-align: right;
        }
        .inv-badge .label {
            font-size: 1.5rem; font-weight: 800;
            color: #6366f1; letter-spacing: 2px;
        }
        .inv-badge .num { font-size: .85rem; color: #6b7280; }
        .inv-badge .status {
            display: inline-block;
            margin-top: .4rem;
            padding: .25rem .75rem;
            border-radius: 99px;
            font-size: .75rem;
            font-weight: 700;
        }
        .status-paid   { background: #dcfce7; color: #16a34a; }
        .status-unpaid { background: #fef3c7; color: #d97706; }

        /* Info Grid */
        .inv-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.25rem;
            margin-bottom: 1.75rem;
        }
        .inv-box {
            background: #f9fafb;
            border-radius: 8px;
            padding: 1rem;
        }
        .inv-box h4 {
            font-size: .7rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #6b7280;
            margin-bottom: .6rem;
        }
        .inv-box p { margin-bottom: .2rem; font-size: .875rem; }
        .inv-box p strong { font-weight: 600; }

        /* Tabel Item */
        table { width: 100%; border-collapse: collapse; margin-bottom: 1.5rem; }
        thead tr { background: #6366f1; color: #fff; }
        thead th { padding: .6rem 1rem; text-align: left; font-size: .8rem; font-weight: 600; }
        tbody tr { border-bottom: 1px solid #e5e7eb; }
        tbody td { padding: .65rem 1rem; font-size: .875rem; }
        tfoot tr td { padding: .6rem 1rem; font-size: .875rem; }
        .tr-total td { border-top: 2px solid #111; font-weight: 700; font-size: 1rem; }
        .tr-total .amount { color: #10b981; }

        /* Footer */
        .inv-footer {
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .inv-footer .note { font-size: .8rem; color: #6b7280; max-width: 320px; }
        .inv-footer .ttd { text-align: center; font-size: .8rem; }
        .inv-footer .ttd .line {
            width: 150px;
            border-top: 1px solid #111;
            margin: 3rem auto .4rem;
        }

        /* Print */
        @media print {
            body { padding: 0; }
            .no-print { display: none !important; }
            @page { margin: 1.5cm; }
        }
    </style>
</head>
<body>
<?php
$t      = $tagihan ?? [];
$isPaid = ($t['status'] ?? '') === 'paid';
$appUrl = $_ENV['APP_URL'] ?? '';

// Info perusahaan dari SettingModel jika tersedia
$companyName  = $_ENV['APP_NAME']    ?? 'FiberNet';
$companyAddr  = '';
$companyPhone = '';
try {
    $setting = new \Model\SettingModel();
    $companyName  = $setting->get('company_name')  ?: $companyName;
    $companyAddr  = $setting->get('company_address') ?: '';
    $companyPhone = $setting->get('company_phone')   ?: '';
} catch (\Throwable $e) { /* setting tidak tersedia, pakai default */ }
?>

<div class="invoice-wrap">

    <!-- Header -->
    <div class="inv-header">
        <div>
            <div class="inv-logo"><?= htmlspecialchars($companyName) ?></div>
            <div class="inv-company-sub">Billing System</div>
            <?php if ($companyAddr): ?>
                <div class="inv-company-sub" style="margin-top:.3rem;">
                    <?= htmlspecialchars($companyAddr) ?>
                </div>
            <?php endif; ?>
            <?php if ($companyPhone): ?>
                <div class="inv-company-sub"><?= htmlspecialchars($companyPhone) ?></div>
            <?php endif; ?>
        </div>
        <div class="inv-badge">
            <div class="label">INVOICE</div>
            <div class="num">#<?= str_pad((string)($t['id'] ?? 0), 6, '0', STR_PAD_LEFT) ?></div>
            <div>
                <span class="status <?= $isPaid ? 'status-paid' : 'status-unpaid' ?>">
                    <?= $isPaid ? '✓ LUNAS' : '⏳ BELUM LUNAS' ?>
                </span>
            </div>
        </div>
    </div>

    <!-- Info Pelanggan & Tagihan -->
    <div class="inv-info">
        <div class="inv-box">
            <h4>Tagihan Kepada</h4>
            <p><strong><?= htmlspecialchars($t['nama_lengkap'] ?? '-') ?></strong></p>
            <?php if (!empty($t['alamat'])): ?>
                <p><?= htmlspecialchars($t['alamat']) ?></p>
            <?php endif; ?>
            <?php if (!empty($t['no_telp'])): ?>
                <p><?= htmlspecialchars($t['no_telp']) ?></p>
            <?php endif; ?>
        </div>
        <div class="inv-box">
            <h4>Detail Invoice</h4>
            <p>No. Invoice: <strong>#<?= str_pad((string)($t['id'] ?? 0), 6, '0', STR_PAD_LEFT) ?></strong></p>
            <p>Periode: <strong><?= htmlspecialchars($t['periode_bulan'] ?? '-') ?></strong></p>
            <p>Jatuh Tempo: <strong><?= !empty($t['jatuh_tempo']) ? date('d M Y', strtotime($t['jatuh_tempo'])) : '-' ?></strong></p>
            <?php if ($isPaid && !empty($t['tgl_bayar'])): ?>
                <p>Tgl. Bayar: <strong><?= date('d M Y', strtotime($t['tgl_bayar'])) ?></strong></p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Tabel Item -->
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Deskripsi</th>
                <th>Kecepatan</th>
                <th style="text-align:right;">Jumlah</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>
                    Biaya Langganan Internet<br>
                    <span style="color:#6b7280;font-size:.8rem;">
                        <?= htmlspecialchars($t['nama_paket'] ?? '-') ?>
                        &bull; Periode <?= htmlspecialchars($t['periode_bulan'] ?? '-') ?>
                    </span>
                </td>
                <td><?= !empty($t['kecepatan']) ? htmlspecialchars($t['kecepatan']) . ' Mbps' : '-' ?></td>
                <td style="text-align:right;">Rp <?= number_format($t['harga'] ?? $t['total'] ?? 0, 0, ',', '.') ?></td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" style="text-align:right;color:#6b7280;">Subtotal</td>
                <td style="text-align:right;">Rp <?= number_format($t['harga'] ?? $t['total'] ?? 0, 0, ',', '.') ?></td>
            </tr>
            <?php
            $ppn = 0; // tambahkan jika ada PPN
            ?>
            <tr class="tr-total">
                <td colspan="3" style="text-align:right;">Total</td>
                <td style="text-align:right;" class="amount">
                    Rp <?= number_format($t['total'] ?? 0, 0, ',', '.') ?>
                </td>
            </tr>
        </tfoot>
    </table>

    <!-- Footer -->
    <div class="inv-footer">
        <div class="note">
            Terima kasih atas kepercayaan Anda menggunakan layanan kami.<br>
            Harap simpan invoice ini sebagai bukti pembayaran yang sah.
        </div>
        <div class="ttd">
            <div class="line"></div>
            <div>Petugas / Kasir</div>
            <div style="color:#6b7280;font-size:.75rem;margin-top:.2rem;">
                <?= htmlspecialchars($companyName) ?>
            </div>
        </div>
    </div>

    <!-- Tombol Print (tidak ikut tercetak) -->
    <div class="no-print" style="text-align:center;margin-top:2rem;display:flex;gap:.75rem;justify-content:center;">
        <button onclick="window.print()"
                style="padding:.6rem 1.5rem;border-radius:8px;border:none;cursor:pointer;
                       font-weight:600;background:#6366f1;color:#fff;font-size:.875rem;">
            <i class="fa-solid fa-print" style="margin-right:.4rem;"></i>Cetak Invoice
        </button>
        <a href="<?= $appUrl ?>/tagihan"
           style="padding:.6rem 1.25rem;border-radius:8px;text-decoration:none;
                  border:1.5px solid #e5e7eb;font-weight:600;color:#6b7280;font-size:.875rem;">
            Kembali
        </a>
    </div>

</div>
</body>
</html>
