<?php
/**
 * Application Single Entry Point
 * PHP 8.4 Native Semi Framework (MVC)
 */

declare(strict_types=1);

// Definisi path konstanta root aplikasi
define('APP_ROOT', __DIR__);

// 1. Jalankan PHP Session secara aman
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_lifetime' => 86400,
        'cookie_secure'   => isset($_SERVER['HTTPS']),
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax'
    ]);
}

// 2. Muat Sistem Autoloader Komponen
require_once APP_ROOT . '/config/Autoloader.php';

// 3. Muat & Inisialisasi Environment Variables (.env)
require_once APP_ROOT . '/config/env.php';
\Config\Env::load(APP_ROOT . '/.env');

// 4. Proteksi CSRF Token Generator otomatis jika belum ada
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// 5. Jalankan Sistem Routing Web Aplikasi
require_once APP_ROOT . '/routes/web.php';
