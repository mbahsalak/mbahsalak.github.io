<?php
/**
 * controller/Master/ODPController.php
 * CRUD ODP
 */

declare(strict_types=1);

namespace Controller\Master;

use Controller\BaseController;
use Core\Auth;
use Model\ODPModel;
use Model\AuditLogModel;

class ODPController extends BaseController
{
    private ODPModel      $model;
    private AuditLogModel $audit;

    public function __construct()
    {
        $this->model = new ODPModel();
        $this->audit = new AuditLogModel();
    }

    public function index(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);
        $this->render('ODP/index', [
            'title' => 'Manajemen ODP',
            'list'  => $this->model->getAll(),
        ]);
    }

    public function create(): void
    {
        Auth::roleGuard(['admin']);
        $this->render('ODP/create', ['title' => 'Tambah ODP']);
    }

    public function store(): void
    {
        Auth::roleGuard(['admin']);
        $input = $this->requestBody();

        $id = $this->model->create([
            'nama_odp'  => $input['nama_odp'],
            'latitude'  => $input['latitude']  ?: null,
            'longitude' => $input['longitude'] ?: null,
            'kapasitas' => (int)($input['kapasitas'] ?? 16),
        ]);

        $this->audit->log(Auth::id() ?? 0, "Tambah ODP #{$id} {$input['nama_odp']}");
        $this->setFlash('success', 'ODP berhasil ditambahkan.');
        $this->redirectTo('/odp');
    }

    public function edit(string $id): void
    {
        Auth::roleGuard(['admin']);
        $data = $this->model->find((int)$id);
        if (!$data) { http_response_code(404); die('ODP tidak ditemukan.'); }
        $this->render('ODP/edit', ['title' => 'Edit ODP', 'odp' => $data]);
    }

    public function update(string $id): void
    {
        Auth::roleGuard(['admin']);
        $input = $this->requestBody();

        $this->model->edit((int)$id, [
            'nama_odp'  => $input['nama_odp'],
            'latitude'  => $input['latitude']  ?: null,
            'longitude' => $input['longitude'] ?: null,
            'kapasitas' => (int)($input['kapasitas'] ?? 16),
        ]);

        $this->audit->log(Auth::id() ?? 0, "Edit ODP #{$id}");
        $this->setFlash('success', 'ODP berhasil diperbarui.');
        $this->redirectTo('/odp');
    }

    public function hapus(string $id): void
    {
        Auth::roleGuard(['admin']);
        $this->model->hapus((int)$id);
        $this->audit->log(Auth::id() ?? 0, "Hapus ODP #{$id}");
        $this->setFlash('success', 'ODP berhasil dihapus.');
        $this->redirectTo('/odp');
    }
}
