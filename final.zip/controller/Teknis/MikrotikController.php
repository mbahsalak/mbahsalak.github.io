<?php

declare(strict_types=1);

namespace Controller\Teknis;

use Controller\BaseController;
use Core\Auth;
use Core\Logger;
use Config\Database;
use Service\MikrotikService;

/**
 * Controller untuk monitoring & manajemen MikroTik (VLAN-based ISP)
 */
class MikrotikController extends BaseController
{
    private MikrotikService $service;

    public function __construct()
    {
        $this->service = new MikrotikService();
    }

    // =========================================================================
    // HALAMAN UTAMA MONITORING
    // =========================================================================

    public function index(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $db = Database::getConnection();

        $stmt = $db->prepare("
            SELECT p.id, p.nama_lengkap, p.mac_address, p.alamat, p.no_telp,
                   pk.nama_paket, pk.kecepatan
            FROM pelanggan p
            LEFT JOIN paket pk ON p.paket_id = pk.id
            WHERE p.mac_address IS NOT NULL
              AND p.mac_address != ''
            ORDER BY p.nama_lengkap
        ");
        $stmt->execute();
        $pelanggans = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $info       = [];
        $identity   = 'MikroTik (Not Connected)';
        $interfaces = [];
        $error      = null;

        if (!empty($pelanggans)) {
            $firstMac = $pelanggans[0]['mac_address'];
            $result   = $this->service->getRouterDetail($firstMac);

            if ($result['success']) {
                $data     = $result['data'];
                $identity = $data['identity'] ?? 'MikroTik';
                $info = [
                    'board-name'     => $data['board_name'] ?? '-',
                    'version'        => $data['version'] ?? '-',
                    'cpu-load'       => $data['cpu_load'] ?? 0,
                    'uptime'         => $data['uptime'] ?? '-',
                    'free-memory'    => $data['free_memory'] ?? 0,
                    'total-memory'   => $data['total_memory'] ?? 0,
                    'free-hdd-space' => $data['free_hdd_space'] ?? 0,
                ];
                $interfaces = $data['interfaces'] ?? [];
            } else {
                $error = $result['error'];
            }
        }

        $this->render('Teknis/mikrotik_index', [
            'title'      => 'Monitoring MikroTik (VLAN)',
            'activeMenu' => 'mikrotik',
            'user'       => Auth::user(),
            'info'       => $info,
            'identity'   => $identity,
            'interfaces' => $interfaces,
            'error'      => $error,
            'pelanggans' => $pelanggans,
        ]);
    }

    // =========================================================================
    // API: TEST KONEKSI
    // =========================================================================

    public function testConnection(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);
        header('Content-Type: application/json');
        echo json_encode($this->service->testConnection());
        exit;
    }

    // =========================================================================
    // API: STATUS SEMUA ROUTER (AJAX polling)
    // =========================================================================

    public function status(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);
        header('Content-Type: application/json');

        $db = Database::getConnection();

        $stmt = $db->prepare("
            SELECT p.id, p.nama_lengkap, p.mac_address, p.alamat, p.no_telp,
                   pk.kecepatan
            FROM pelanggan p
            LEFT JOIN paket pk ON p.paket_id = pk.id
            WHERE p.mac_address IS NOT NULL
              AND p.mac_address != ''
            ORDER BY p.nama_lengkap
        ");
        $stmt->execute();
        $pelanggans = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $results = [];

        foreach ($pelanggans as $p) {
            $mac    = $p['mac_address'];
            $detail = $this->service->getRouterDetail($mac);

            if ($detail['success']) {
                $d = $detail['data'];
                $results[] = [
                    'id'          => $p['id'],
                    'nama'        => $p['nama_lengkap'],
                    'alamat'      => $p['alamat'] ?? '-',
                    'no_telp'     => $p['no_telp'] ?? '-',
                    'mac_address' => $mac,
                    'kecepatan'   => $p['kecepatan'] ?? '-',
                    'identity'    => $d['identity'] ?? '-',
                    'uptime'      => $d['uptime'] ?? '-',
                    'cpu_load'    => $d['cpu_load'] ?? 0,
                    'rx_mbps'     => $d['bandwidth_usage']['rx_mbps'] ?? 0,
                    'tx_mbps'     => $d['bandwidth_usage']['tx_mbps'] ?? 0,
                    'total_mbps'  => round(
                        ($d['bandwidth_usage']['rx_mbps'] ?? 0) +
                        ($d['bandwidth_usage']['tx_mbps'] ?? 0), 2
                    ),
                    'status'      => 'online',
                    'cpu_status'  => match (true) {
                        ($d['cpu_load'] ?? 0) > 80 => 'critical',
                        ($d['cpu_load'] ?? 0) > 50 => 'warning',
                        default                    => 'normal',
                    },
                ];
            } else {
                $results[] = [
                    'id'          => $p['id'],
                    'nama'        => $p['nama_lengkap'],
                    'alamat'      => $p['alamat'] ?? '-',
                    'no_telp'     => $p['no_telp'] ?? '-',
                    'mac_address' => $mac,
                    'kecepatan'   => $p['kecepatan'] ?? '-',
                    'status'      => 'offline',
                    'error'       => $detail['error'] ?? 'Unknown error',
                ];
            }
        }

        echo json_encode([
            'success' => true,
            'data'    => $results,
            'count'   => count($results),
            'time'    => date('Y-m-d H:i:s'),
        ]);
        exit;
    }

    // =========================================================================
    // API: DETAIL SATU ROUTER
    // =========================================================================

    public function detail(string $mac): void
    {
        Auth::roleGuard(['admin', 'teknisi']);
        header('Content-Type: application/json');
        echo json_encode($this->service->getRouterDetail($mac));
        exit;
    }

    // =========================================================================
    // VLAN MANAGEMENT
    // =========================================================================

    public function vlan(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $db = Database::getConnection();

        $stmt = $db->prepare("
            SELECT p.id, p.nama_lengkap, p.mac_address, p.alamat, p.no_telp,
                   pk.nama_paket, pk.kecepatan,
                   u.status AS status_internet
            FROM pelanggan p
            LEFT JOIN paket pk ON p.paket_id = pk.id
            LEFT JOIN users  u  ON p.user_id  = u.id
            WHERE p.mac_address IS NOT NULL
              AND p.mac_address != ''
            ORDER BY p.nama_lengkap
        ");
        $stmt->execute();
        $pelanggans = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $this->render('Teknis/mikrotik_vlan', [
            'title'      => 'VLAN Management',
            'activeMenu' => 'mikrotik',
            'user'       => Auth::user(),
            'pelanggans' => $pelanggans,
            'flash'      => $this->getFlash(),
        ]);
    }

    public function vlanUpdate(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $pelangganId = (int) ($_POST['pelanggan_id'] ?? 0);
        $vlanId      = (int) ($_POST['vlan_id'] ?? 0);

        if ($pelangganId <= 0 || $vlanId < 1 || $vlanId > 4094) {
            $this->setFlash('error', 'VLAN ID tidak valid (1-4094).');
            $this->redirect('/mikrotik/vlan');
            return;
        }

        $db = Database::getConnection();

        try {
            $db->prepare("UPDATE pelanggan SET vlan_id = ? WHERE id = ?")->execute([$vlanId, $pelangganId]);
        } catch (\PDOException $e) {
            $db->exec("ALTER TABLE pelanggan ADD COLUMN vlan_id INT NULL DEFAULT NULL");
            $db->prepare("UPDATE pelanggan SET vlan_id = ? WHERE id = ?")->execute([$vlanId, $pelangganId]);
        }

        $stmt = $db->prepare("SELECT nama_lengkap, mac_address FROM pelanggan WHERE id = ?");
        $stmt->execute([$pelangganId]);
        $info = $stmt->fetch(\PDO::FETCH_ASSOC);

        Logger::info('MikrotikController', "VLAN updated: {$info['nama_lengkap']} → VLAN {$vlanId}");

        $user = Auth::user();
        $db->prepare("
            INSERT INTO audit_logs (user_id, aktivitas, ip_address, created_at)
            VALUES (?, ?, ?, NOW())
        ")->execute([
            $user['id'],
            "Update VLAN '{$info['nama_lengkap']}' (MAC: {$info['mac_address']}) ke VLAN {$vlanId}",
            $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        ]);

        $this->setFlash('success', "VLAN ID berhasil diperbarui untuk {$info['nama_lengkap']}.");
        $this->redirect('/mikrotik/vlan');
    }

    // =========================================================================
    // SIMPLE QUEUE MANAGEMENT
    // =========================================================================

    public function queue(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $db = Database::getConnection();

        $stmt = $db->prepare("
            SELECT p.id, p.nama_lengkap, p.mac_address,
                   pk.nama_paket, pk.kecepatan,
                   u.status AS status_internet
            FROM pelanggan p
            LEFT JOIN paket pk ON p.paket_id = pk.id
            LEFT JOIN users  u  ON p.user_id  = u.id
            WHERE p.mac_address IS NOT NULL
              AND p.mac_address != ''
            ORDER BY p.nama_lengkap
        ");
        $stmt->execute();
        $pelanggans = array_map(
            fn($p) => $p + self::parseKecepatan($p['kecepatan'] ?? ''),
            $stmt->fetchAll(\PDO::FETCH_ASSOC)
        );

        $this->render('Mikrotik/queues', [
            'title'      => 'Simple Queue Management',
            'activeMenu' => 'mikrotik',
            'user'       => Auth::user(),
            'pelanggans' => $pelanggans,
            'flash'      => $this->getFlash(),
        ]);
    }

    public function services(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $db   = Database::getConnection();
        $stmt = $db->query("
            SELECT p.id, p.nama_lengkap, p.mac_address, p.alamat, p.no_telp,
                   pk.nama_paket, pk.kecepatan
            FROM pelanggan p
            LEFT JOIN paket pk ON p.paket_id = pk.id
            ORDER BY p.mac_address IS NULL ASC, p.nama_lengkap ASC
        ");
        $pelanggans = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $this->render('Mikrotik/services', [
            'title'      => 'Layanan Teknis',
            'activeMenu' => 'mikrotik',
            'user'       => Auth::user(),
            'pelanggans' => $pelanggans,
            'flash'      => $this->getFlash(),
        ]);
    }

    public function active(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $db = Database::getConnection();

        $stmt = $db->query("
            SELECT p.id, p.nama_lengkap, p.mac_address, p.no_telp,
                   pk.nama_paket, pk.kecepatan
            FROM pelanggan p
            LEFT JOIN paket pk ON p.paket_id = pk.id
            WHERE p.mac_address IS NOT NULL AND p.mac_address != ''
            ORDER BY p.nama_lengkap
        ");
        $pelanggans = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $active = [];
        $error  = null;

        try {
            $active = $this->service->getActiveSessions();
        } catch (\Throwable $e) {
            $error = $e->getMessage();
        }

        $this->render('Mikrotik/active', [
            'title'      => 'Sesi Aktif',
            'activeMenu' => 'mikrotik',
            'user'       => Auth::user(),
            'active'     => $active,
            'pelanggans' => $pelanggans,
            'error'      => $error,
            'flash'      => $this->getFlash(),
        ]);
    }

    public function queues(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $db = Database::getConnection();

        $stmt = $db->query("
            SELECT p.id, p.nama_lengkap, p.mac_address,
                   pk.nama_paket, pk.kecepatan,
                   u.status AS status_internet
            FROM pelanggan p
            LEFT JOIN paket pk ON p.paket_id = pk.id
            LEFT JOIN users  u  ON p.user_id  = u.id
            WHERE p.mac_address IS NOT NULL AND p.mac_address != ''
            ORDER BY p.nama_lengkap
        ");
        $pelanggans = array_map(
            fn($p) => $p + self::parseKecepatan($p['kecepatan'] ?? ''),
            $stmt->fetchAll(\PDO::FETCH_ASSOC)
        );

        $queues = [];
        $error  = null;

        try {
            $allQueues = $this->service->getSimpleQueues();

            if (is_array($allQueues)) {
                $macSet = array_map(
                    fn($p) => strtolower(trim($p['mac_address'])),
                    $pelanggans
                );

                foreach ($allQueues as $q) {
                    $target = strtolower(trim($q['target'] ?? ''));
                    $targetMac = strtok($target, '/');
                    if (in_array($targetMac, $macSet, true)) {
                        $idx = array_search($targetMac, $macSet, true);
                        $q['_pelanggan'] = $pelanggans[$idx] ?? null;
                        $queues[] = $q;
                    }
                }
            }
        } catch (\Throwable $e) {
            $error = $e->getMessage();
        }

        $this->render('Mikrotik/queues', [
            'title'      => 'Manajemen Queue',
            'activeMenu' => 'mikrotik',
            'user'       => Auth::user(),
            'pelanggans' => $pelanggans,
            'queues'     => $queues,
            'error'      => $error,
            'flash'      => $this->getFlash(),
        ]);
    }

    public function queueUpdate(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $pelangganId = (int) ($_POST['pelanggan_id'] ?? 0);
        $paketId     = (int) ($_POST['paket_id'] ?? 0);

        if ($pelangganId <= 0 || $paketId <= 0) {
            $this->setFlash('error', 'Data tidak valid.');
            $this->redirect('/mikrotik/queue');
            return;
        }

        $db = Database::getConnection();

        $db->prepare("UPDATE pelanggan SET paket_id = ? WHERE id = ?")->execute([$paketId, $pelangganId]);

        $stmt = $db->prepare("
            SELECT p.nama_lengkap, p.mac_address, pk.nama_paket, pk.kecepatan
            FROM pelanggan p
            LEFT JOIN paket pk ON p.paket_id = pk.id
            WHERE p.id = ?
        ");
        $stmt->execute([$pelangganId]);
        $info = $stmt->fetch(\PDO::FETCH_ASSOC);

        Logger::info('MikrotikController', "Queue updated: {$info['nama_lengkap']} → {$info['nama_paket']} ({$info['kecepatan']})");

        $user = Auth::user();
        $db->prepare("
            INSERT INTO audit_logs (user_id, aktivitas, ip_address, created_at)
            VALUES (?, ?, ?, NOW())
        ")->execute([
            $user['id'],
            "Update queue '{$info['nama_lengkap']}' (MAC: {$info['mac_address']}) ke paket '{$info['nama_paket']}' ({$info['kecepatan']})",
            $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        ]);

        $this->setFlash('success', "Bandwidth queue berhasil diperbarui untuk {$info['nama_lengkap']}.");
        $this->redirect('/mikrotik/queue');
    }

    // =========================================================================
    // ISOLIR / AKTIFKAN PELANGGAN
    // =========================================================================

    public function toggleStatus(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $pelangganId = (int) ($_POST['pelanggan_id'] ?? 0);
        $newStatus   = $_POST['status'] ?? 'active';

        if ($pelangganId <= 0 || !in_array($newStatus, ['active', 'isolir', 'suspend'])) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Data tidak valid']);
            exit;
        }

        $db = Database::getConnection();

        $stmt = $db->prepare("SELECT nama_lengkap, mac_address FROM pelanggan WHERE id = ?");
        $stmt->execute([$pelangganId]);
        $pelanggan = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$pelanggan) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Pelanggan tidak ditemukan']);
            exit;
        }

        $mappedStatus = ($newStatus === 'active') ? 'active' : 'inactive';
        $db->prepare("
            UPDATE users u
            JOIN pelanggan p ON p.user_id = u.id
            SET u.status = ?
            WHERE p.id = ?
        ")->execute([$mappedStatus, $pelangganId]);

        Logger::warning('MikrotikController', "Status changed: {$pelanggan['nama_lengkap']} → {$newStatus}");

        $user = Auth::user();
        $db->prepare("
            INSERT INTO audit_logs (user_id, aktivitas, ip_address, created_at)
            VALUES (?, ?, ?, NOW())
        ")->execute([
            $user['id'],
            "Ubah status '{$pelanggan['nama_lengkap']}' (MAC: {$pelanggan['mac_address']}) ke '{$newStatus}'",
            $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        ]);

        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'message' => "Status {$pelanggan['nama_lengkap']} diubah ke '{$newStatus}'",
        ]);
        exit;
    }
    // =========================================================================
    // KICK CLIENT BY MAC ADDRESS
    // =========================================================================

    /**
     * Putus koneksi klien berdasarkan MAC address
     * Route: GET /mikrotik/active/kick/<mac>
     */
    public function kickByMac(string $mac): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

            $macNorm = \Core\MikrotikClient::normalizeMac(str_replace('-', ':', $mac));


        try {
            $ok = $this->service->kickClientByMac($macNorm);

            if ($ok) {
                Logger::warning('MikrotikController', "Klien di-kick: {$macNorm}");

                // Audit log
                $user = Auth::user();
                $db   = Database::getConnection();
                $db->prepare("
                    INSERT INTO audit_logs (user_id, aktivitas, ip_address, created_at)
                    VALUES (?, ?, ?, NOW())
                ")->execute([
                    $user['id'],
                    "Kick klien MAC: {$macNorm}",
                    $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                ]);

                $this->setFlash('success', "Klien {$macNorm} berhasil diputus.");
            } else {
                $this->setFlash('error', "Gagal memutus klien {$macNorm}.");
            }
        } catch (\Throwable $e) {
            $this->setFlash('error', "Error: " . $e->getMessage());
        }

        $this->redirect('/mikrotik/active');
    }

    // =========================================================================
    // HELPER
    // =========================================================================

    private static function parseKecepatan(string $kecepatan): array
    {
        $str = strtoupper(trim($kecepatan));
        $str = str_replace(['MBPS', 'KBPS', 'M', 'K', ' '], ['', '', '', '', ''], $str);

        if (str_contains($str, '/')) {
            [$down, $up] = explode('/', $str, 2);
        } else {
            $down = $up = $str;
        }

        return [
            'download_speed' => (int) $down ?: 0,
            'upload_speed'   => (int) $up   ?: 0,
        ];
    }
        /**
     * GET /mikrotik/testpage
     * Halaman visual test endpoint
     */
    public function testPage(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);
        $this->render('Mikrotik/test', [
            'title'      => 'Test Koneksi MikroTik',
            'activeMenu' => 'mikrotik',
        ]);
    }

}
