<?php
/**
 * controller/Master/PaketController.php
 * CRUD Paket Internet
 */

declare(strict_types=1);

namespace Controller\Master;

use Controller\BaseController;
use Core\Auth;
use Model\PaketModel;
use Model\AuditLogModel;

class PaketController extends BaseController
{
    private PaketModel    $model;
    private AuditLogModel $audit;

    public function __construct()
    {
        $this->model = new PaketModel();
        $this->audit = new AuditLogModel();
    }

    public function index(): void
    {
        Auth::roleGuard(['admin']);
        $this->render('Paket/index', [
            'title' => 'Manajemen Paket',
            'list'  => $this->model->getAll(),
        ]);
    }

    public function create(): void
    {
        Auth::roleGuard(['admin']);
        $this->render('Paket/create', ['title' => 'Tambah Paket']);
    }

    public function store(): void
    {
        Auth::roleGuard(['admin']);
        $input = $this->requestBody();
        $harga = (float) str_replace(['.', ','], ['', '.'], $input['harga'] ?? '0');

        $id = $this->model->create([
            'nama_paket' => $input['nama_paket'],
            'kecepatan'  => $input['kecepatan'],
            'harga'      => $harga,
        ]);

        $this->audit->log(Auth::id() ?? 0, "Tambah paket #{$id} {$input['nama_paket']}");
        $this->setFlash('success', 'Paket berhasil ditambahkan.');
        $this->redirectTo('/paket');
    }

    public function edit(string $id): void
    {
        Auth::roleGuard(['admin']);
        $data = $this->model->find((int)$id);
        if (!$data) { http_response_code(404); die('Paket tidak ditemukan.'); }
        $this->render('Paket/edit', ['title' => 'Edit Paket', 'paket' => $data]);
    }

    public function update(string $id): void
    {
        Auth::roleGuard(['admin']);
        $input = $this->requestBody();
        $harga = (float) str_replace(['.', ','], ['', '.'], $input['harga'] ?? '0');

        $this->model->edit((int)$id, [
            'nama_paket' => $input['nama_paket'],
            'kecepatan'  => $input['kecepatan'],
            'harga'      => $harga,
        ]);

        $this->audit->log(Auth::id() ?? 0, "Edit paket #{$id}");
        $this->setFlash('success', 'Paket berhasil diperbarui.');
        $this->redirectTo('/paket');
    }

    public function hapus(string $id): void
    {
        Auth::roleGuard(['admin']);
        $this->model->hapus((int)$id);
        $this->audit->log(Auth::id() ?? 0, "Hapus paket #{$id}");
        $this->setFlash('success', 'Paket berhasil dihapus.');
        $this->redirectTo('/paket');
    }
}
