<?php
/**
 * controller/Master/SettingController.php
 * Pengaturan Aplikasi — Admin only
 * PHP 8.4 Native Semi-Framework
 *
 * Fitur:
 *   index()  — tampilkan semua setting dikelompokkan per grup
 *   update() — POST: simpan semua perubahan sekaligus
 *   logo()   — POST: upload logo ISP
 */

declare(strict_types=1);

namespace Controller\Master;

use Controller\BaseController;
use Core\Auth;
use Model\SettingModel;
use Model\AuditLogModel;

class SettingController extends BaseController
{
    private SettingModel  $model;
    private AuditLogModel $audit;

    public function __construct()
    {
        $this->model = new SettingModel();
        $this->audit = new AuditLogModel();
    }

    // -------------------------------------------------------------------------
    // Tampilkan Form
    // -------------------------------------------------------------------------

    /** GET /setting */
    public function index(): void
    {
        Auth::roleGuard(['admin']);

        // Kelompokkan per group untuk tampilan tab
        $rows   = $this->model->getAllWithMeta();
        $groups = [];
        foreach ($rows as $row) {
            $groups[$row['group']][] = $row;
        }

        $flash = $this->getFlash();

        $this->render('Setting/index', [
            'title'  => 'Pengaturan Aplikasi',
            'groups' => $groups,
            'flash'  => $flash,
        ]);
    }

    // -------------------------------------------------------------------------
    // Simpan Setting
    // -------------------------------------------------------------------------

    /**
     * POST /setting/update
     * Terima semua field form (kecuali csrf_token & _method)
     * Sanitasi: htmlspecialchars sudah dilakukan requestBody(); trim lagi di sini.
     */
    public function update(): void
    {
        Auth::roleGuard(['admin']);

        $input = $this->requestBody();

        // Buang key sistem yang bukan setting
        $skip   = ['csrf_token', '_method'];
        $data   = [];
        foreach ($input as $key => $val) {
            if (in_array($key, $skip, true)) continue;
            $data[$key] = trim($val);
        }

        $ok = $this->model->setMany($data);

        if ($ok) {
            $this->audit->log(
                Auth::id() ?? 0,
                'Perbarui pengaturan aplikasi (' . implode(', ', array_keys($data)) . ')'
            );
            $this->setFlash('success', 'Pengaturan berhasil disimpan.');
        } else {
            $this->setFlash('error', 'Gagal menyimpan pengaturan. Coba lagi.');
        }

        $this->redirectTo('/setting');
    }

    // -------------------------------------------------------------------------
    // Upload Logo
    // -------------------------------------------------------------------------

    /**
     * POST /setting/logo
     * Validasi: JPG/PNG/SVG/WEBP, maks 2 MB
     * Simpan ke public/assets/images/logo.{ext}
     */
    public function uploadLogo(): void
    {
        Auth::roleGuard(['admin']);

        if (empty($_FILES['logo']['tmp_name'])) {
            $this->setFlash('error', 'Tidak ada file yang diunggah.');
            $this->redirectTo('/setting');
        }

        $file     = $_FILES['logo'];
        $maxSize  = 2 * 1024 * 1024; // 2 MB
        $allowed  = ['image/jpeg', 'image/png', 'image/svg+xml', 'image/webp'];

        // Validasi ukuran
        if ($file['size'] > $maxSize) {
            $this->setFlash('error', 'Ukuran file maksimal 2 MB.');
            $this->redirectTo('/setting');
        }

        // Validasi MIME type (tidak percaya ekstensi saja)
        $mimeType = mime_content_type($file['tmp_name']);
        if (!in_array($mimeType, $allowed, true)) {
            $this->setFlash('error', 'Format file tidak didukung. Gunakan JPG, PNG, SVG, atau WEBP.');
            $this->redirectTo('/setting');
        }

        // Tentukan ekstensi dari MIME
        $ext = match($mimeType) {
            'image/jpeg'   => 'jpg',
            'image/png'    => 'png',
            'image/svg+xml'=> 'svg',
            'image/webp'   => 'webp',
        };

        $destDir  = APP_ROOT . '/public/assets/images/';
        $filename = 'logo.' . $ext;
        $destPath = $destDir . $filename;

        // Pastikan direktori ada
        if (!is_dir($destDir)) {
            mkdir($destDir, 0755, true);
        }

        // Hapus logo lama dengan ekstensi lain jika ada
        foreach (['jpg', 'png', 'svg', 'webp'] as $oldExt) {
            $old = $destDir . 'logo.' . $oldExt;
            if ($ext !== $oldExt && file_exists($old)) {
                unlink($old);
            }
        }

        if (!move_uploaded_file($file['tmp_name'], $destPath)) {
            $this->setFlash('error', 'Gagal menyimpan file. Periksa izin direktori.');
            $this->redirectTo('/setting');
        }

        // Simpan path relatif ke database
        $logoPath = 'public/assets/images/' . $filename;
        $this->model->set('app_logo', $logoPath);

        $this->audit->log(Auth::id() ?? 0, "Upload logo aplikasi: {$filename}");

        $this->setFlash('success', 'Logo berhasil diunggah.');
        $this->redirectTo('/setting');
    }
}
