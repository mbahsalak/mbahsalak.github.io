<?php
/**
 * controller/Teknis/MikrotikController.php
 *
 * Handles semua fitur MikroTik API:
 *   - Dashboard status router
 *   - Manajemen PPPoE Secret
 *   - Koneksi aktif & kick session
 *   - Simple Queue
 *   - Bandwidth polling (AJAX) + fallback demo
 *   - Test koneksi
 */

declare(strict_types=1);

namespace Controller\Teknis;

use Controller\BaseController;
use Core\Auth;
use Service\MikrotikService;
use RuntimeException;

class MikrotikController extends BaseController
{
    private function service(): MikrotikService
    {
        return MikrotikService::getInstance();
    }

    // =========================================================================
    // Dashboard MikroTik
    // =========================================================================

    public function index(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $data = [
            'title'      => 'MikroTik — Dashboard',
            'user'       => Auth::user(),
            'info'       => null,
            'identity'   => '-',
            'interfaces' => [],
            'error'      => null,
        ];

        try {
            $svc                = $this->service();
            $data['identity']   = $svc->getIdentity();
            $data['info']       = $svc->getSystemInfo();
            $data['interfaces'] = $svc->getInterfaces();
        } catch (RuntimeException $e) {
            $data['error'] = $e->getMessage();
        }

        $this->render('Mikrotik/index', $data);
    }

    // =========================================================================
    // PPPoE Secrets
    // =========================================================================

    public function secrets(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $data = [
            'title'   => 'MikroTik — PPPoE Secrets',
            'user'    => Auth::user(),
            'secrets' => [],
            'active'  => [],
            'error'   => null,
        ];

        try {
            $svc             = $this->service();
            $data['secrets'] = $svc->getPppoeSecrets();
            $data['active']  = $svc->getPppoeActive();
        } catch (RuntimeException $e) {
            $data['error'] = $e->getMessage();
        }

        $this->render('Mikrotik/secrets', $data);
    }

    public function addSecret(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/mikrotik/secrets');
            return;
        }

        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $profile  = trim($_POST['profile']  ?? 'default');
        $comment  = trim($_POST['comment']  ?? '');

        if ($username === '' || $password === '') {
            $_SESSION['flash_error'] = 'Username dan password wajib diisi.';
            $this->redirect('/mikrotik/secrets');
            return;
        }

        try {
            $ok = $this->service()->addPppoeSecret($username, $password, $profile, 'pppoe', $comment);
            $_SESSION['flash_' . ($ok ? 'success' : 'error')] = $ok
                ? "Secret '{$username}' berhasil ditambahkan."
                : "Gagal menambahkan secret '{$username}'.";
        } catch (RuntimeException $e) {
            $_SESSION['flash_error'] = $e->getMessage();
        }

        $this->redirect('/mikrotik/secrets');
    }

    public function toggleSecret(string $username): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        try {
            $svc    = $this->service();
            $secret = $svc->getPppoeSecretByName($username);

            if (!$secret) {
                $_SESSION['flash_error'] = "Secret '{$username}' tidak ditemukan.";
            } else {
                $isDisabled = ($secret['disabled'] ?? 'false') === 'true';
                $ok = $isDisabled
                    ? $svc->enablePppoeSecret($username)
                    : $svc->disablePppoeSecret($username);

                $_SESSION['flash_' . ($ok ? 'success' : 'error')] = $ok
                    ? "Secret '{$username}' berhasil " . ($isDisabled ? 'diaktifkan.' : 'dinonaktifkan.')
                    : "Gagal mengubah status secret.";
            }
        } catch (RuntimeException $e) {
            $_SESSION['flash_error'] = $e->getMessage();
        }

        $this->redirect('/mikrotik/secrets');
    }

    public function changePassword(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/mikrotik/secrets');
            return;
        }

        $username    = trim($_POST['username']     ?? '');
        $newPassword = trim($_POST['new_password'] ?? '');

        if ($username === '' || $newPassword === '') {
            $_SESSION['flash_error'] = 'Username dan password baru wajib diisi.';
            $this->redirect('/mikrotik/secrets');
            return;
        }

        try {
            $ok = $this->service()->updatePppoePassword($username, $newPassword);
            $_SESSION['flash_' . ($ok ? 'success' : 'error')] = $ok
                ? "Password '{$username}' berhasil diubah."
                : "Gagal mengubah password.";
        } catch (RuntimeException $e) {
            $_SESSION['flash_error'] = $e->getMessage();
        }

        $this->redirect('/mikrotik/secrets');
    }

    public function deleteSecret(string $username): void
    {
        Auth::roleGuard(['admin']);

        try {
            $ok = $this->service()->deletePppoeSecret($username);
            $_SESSION['flash_' . ($ok ? 'success' : 'error')] = $ok
                ? "Secret '{$username}' berhasil dihapus."
                : "Gagal menghapus secret.";
        } catch (RuntimeException $e) {
            $_SESSION['flash_error'] = $e->getMessage();
        }

        $this->redirect('/mikrotik/secrets');
    }

    // =========================================================================
    // Active Connections
    // =========================================================================

    public function activeConnections(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $data = [
            'title'  => 'MikroTik — Koneksi Aktif',
            'user'   => Auth::user(),
            'active' => [],
            'error'  => null,
        ];

        try {
            $data['active'] = $this->service()->getPppoeActive();
        } catch (RuntimeException $e) {
            $data['error'] = $e->getMessage();
        }

        $this->render('Mikrotik/active', $data);
    }

    public function kickSession(string $username): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        try {
            $ok = $this->service()->kickPppoeSession($username);
            $_SESSION['flash_' . ($ok ? 'success' : 'error')] = $ok
                ? "Sesi '{$username}' berhasil diputus."
                : "Gagal memutus sesi. Mungkin sudah offline.";
        } catch (RuntimeException $e) {
            $_SESSION['flash_error'] = $e->getMessage();
        }

        $this->redirect('/mikrotik/active');
    }

    // =========================================================================
    // Simple Queue
    // =========================================================================

    public function queues(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $data = [
            'title'  => 'MikroTik — Simple Queue',
            'user'   => Auth::user(),
            'queues' => [],
            'error'  => null,
        ];

        try {
            $data['queues'] = $this->service()->getQueues();
        } catch (RuntimeException $e) {
            $data['error'] = $e->getMessage();
        }

        $this->render('Mikrotik/queues', $data);
    }

    public function addQueue(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/mikrotik/queues');
            return;
        }

        $name     = trim($_POST['name']      ?? '');
        $target   = trim($_POST['target']    ?? '');
        $maxLimit = trim($_POST['max_limit'] ?? '');
        $comment  = trim($_POST['comment']   ?? '');

        if ($name === '' || $target === '' || $maxLimit === '') {
            $_SESSION['flash_error'] = 'Nama, target, dan max-limit wajib diisi.';
            $this->redirect('/mikrotik/queues');
            return;
        }

        try {
            $ok = $this->service()->addQueue($name, $target, $maxLimit, $comment);
            $_SESSION['flash_' . ($ok ? 'success' : 'error')] = $ok
                ? "Queue '{$name}' berhasil ditambahkan."
                : "Gagal menambahkan queue.";
        } catch (RuntimeException $e) {
            $_SESSION['flash_error'] = $e->getMessage();
        }

        $this->redirect('/mikrotik/queues');
    }

    public function updateQueue(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/mikrotik/queues');
            return;
        }

        $name     = trim($_POST['name']      ?? '');
        $maxLimit = trim($_POST['max_limit'] ?? '');

        if ($name === '' || $maxLimit === '') {
            $_SESSION['flash_error'] = 'Nama dan max-limit wajib diisi.';
            $this->redirect('/mikrotik/queues');
            return;
        }

        try {
            $ok = $this->service()->updateQueueLimit($name, $maxLimit);
            $_SESSION['flash_' . ($ok ? 'success' : 'error')] = $ok
                ? "Queue '{$name}' berhasil diupdate."
                : "Gagal mengupdate queue.";
        } catch (RuntimeException $e) {
            $_SESSION['flash_error'] = $e->getMessage();
        }

        $this->redirect('/mikrotik/queues');
    }

    public function deleteQueue(string $name): void
    {
        Auth::roleGuard(['admin']);

        try {
            $ok = $this->service()->deleteQueue($name);
            $_SESSION['flash_' . ($ok ? 'success' : 'error')] = $ok
                ? "Queue '{$name}' berhasil dihapus."
                : "Gagal menghapus queue.";
        } catch (RuntimeException $e) {
            $_SESSION['flash_error'] = $e->getMessage();
        }

        $this->redirect('/mikrotik/queues');
    }

    
              
    // =========================================================================
    // Test Koneksi (AJAX)
    // =========================================================================

    public function testConnection(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        header('Content-Type: application/json');
        try {
            $result = $this->service()->testConnection();
        } catch (RuntimeException $e) {
            $result = ['success' => false, 'message' => $e->getMessage(), 'identity' => ''];
        }
        echo json_encode($result);
        exit;
    }
}
