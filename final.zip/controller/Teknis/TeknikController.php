<?php
/**
 * controller/Teknis/TeknikController.php
 */
declare(strict_types=1);

namespace Controller\Teknis;

use Controller\BaseController;
use Core\Auth;
use Model\ODPModel;
use Model\PelangganModel;

class TeknikController extends BaseController
{
    private ODPModel       $odp;
    private PelangganModel $pelanggan;

    public function __construct()
    {
        $this->odp       = new ODPModel();
        $this->pelanggan = new PelangganModel();
    }

    public function index(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);
        $this->render('Teknis/index', [
            'title'      => 'Manajemen Teknis',
            'activeMenu' => 'teknis',
            'odps'       => $this->odp->getAll(),
        ]);
    }

    public function odp(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);
        $this->render('Teknis/odp', [
            'title'      => 'Data ODP',
            'activeMenu' => 'teknis',
            'odps'       => $this->odp->getAll(),
        ]);
    }

    public function maps(): void
    {
        Auth::roleGuard(['admin', 'teknisi']);
        $this->render('Teknis/maps', [
            'title'        => 'Peta Jaringan',
            'activeMenu'   => 'teknis',
            'koordinatODP' => $this->odp->getAllKoordinat(),
            'koordinatPel' => $this->pelanggan->getAllKoordinat(),
        ]);
    }

    
}
