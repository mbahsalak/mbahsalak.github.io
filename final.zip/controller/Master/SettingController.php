<?php
declare(strict_types=1);

namespace Controller\Master;

use Controller\BaseController;
use Core\Auth;
use Model\SettingModel;
use Model\AuditLogModel;

class SettingController extends BaseController
{
    private SettingModel  $model;
    private AuditLogModel $audit;

    public function __construct()
    {
        $this->model = new SettingModel();
        $this->audit = new AuditLogModel();
    }

    /** GET /setting */
    public function index(): void
    {
        Auth::roleGuard(['admin']);

        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }

        $this->model->mergeDefaults();

        $rows   = $this->model->getAllWithMeta();
        $groups = [];
        foreach ($rows as $row) {
            $groups[$row['group']][] = $row;
        }

        $this->render('Setting/index', [
            'title'      => 'Pengaturan Aplikasi',
            'activeMenu' => 'setting',
            'groups'     => $groups,
            'flash'      => $this->getFlash(),
        ]);
    }

    /** POST /setting/update */
    public function update(): void
    {
        Auth::roleGuard(['admin']);
        $input = $this->requestBody();

        $token        = $input['csrf_token'] ?? '';
        $sessionToken = $_SESSION['csrf_token'] ?? '';
        if ($token === '' || $sessionToken === '' || !hash_equals($sessionToken, $token)) {
            $this->setFlash('error', 'Akses ditolak: Validasi CSRF Token gagal. Silakan muat ulang halaman.');
            $this->redirectTo('/setting');
            return;
        }

        $skip = ['csrf_token', '_method'];
        $data = [];
        foreach ($input as $key => $val) {
            if (in_array($key, $skip, true)) continue;
            $data[$key] = trim((string) $val);
        }

        if ($this->model->setMany($data)) {
            $this->audit->log(Auth::id() ?? 0, 'Perbarui pengaturan: ' . implode(', ', array_keys($data)));
            $this->setFlash('success', 'Pengaturan berhasil disimpan.');
        } else {
            $this->setFlash('error', 'Gagal menyimpan pengaturan.');
        }

        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $this->redirectTo('/setting');
    }

    /** POST /setting/logo */
    public function uploadLogo(): void
    {
        Auth::roleGuard(['admin']);

        $token        = $_POST['csrf_token'] ?? '';
        $sessionToken = $_SESSION['csrf_token'] ?? '';
        if ($token === '' || $sessionToken === '' || !hash_equals($sessionToken, $token)) {
            $this->setFlash('error', 'Akses ditolak: Validasi CSRF Token gagal. Silakan muat ulang halaman.');
            $this->redirectTo('/setting');
            return;
        }

        if (empty($_FILES['logo']['tmp_name'])) {
            $this->setFlash('error', 'Tidak ada file yang diunggah.');
            $this->redirectTo('/setting');
            return;
        }

        $file    = $_FILES['logo'];
        $maxSize = 2 * 1024 * 1024;
        $allowed = ['image/jpeg', 'image/png', 'image/svg+xml', 'image/webp'];

        if ($file['size'] > $maxSize) {
            $this->setFlash('error', 'Ukuran file maksimal 2 MB.');
            $this->redirectTo('/setting');
            return;
        }

        $mimeType = mime_content_type($file['tmp_name']);
        if (!in_array($mimeType, $allowed, true)) {
            $this->setFlash('error', 'Format tidak didukung. Gunakan JPG, PNG, SVG, atau WEBP.');
            $this->redirectTo('/setting');
            return;
        }

        $ext = match ($mimeType) {
            'image/jpeg'    => 'jpg',
            'image/png'     => 'png',
            'image/svg+xml' => 'svg',
            'image/webp'    => 'webp',
            default         => 'bin',
        };

        $destDir  = APP_ROOT . '/public/assets/images/';
        $filename = 'logo.' . $ext;
        $destPath = $destDir . $filename;

        if (!is_dir($destDir)) mkdir($destDir, 0755, true);

        foreach (['jpg', 'png', 'svg', 'webp'] as $oldExt) {
            $old = $destDir . 'logo.' . $oldExt;
            if ($ext !== $oldExt && file_exists($old)) unlink($old);
        }

        if (!move_uploaded_file($file['tmp_name'], $destPath)) {
            $this->setFlash('error', 'Gagal menyimpan file. Periksa izin direktori.');
            $this->redirectTo('/setting');
            return;
        }

        $this->model->set('app_logo', 'public/assets/images/' . $filename);
        $this->audit->log(Auth::id() ?? 0, "Upload logo: {$filename}");
        $this->setFlash('success', 'Logo berhasil diunggah.');

        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $this->redirectTo('/setting');
    }
}
