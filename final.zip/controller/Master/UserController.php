<?php
/**
 * controller/Master/UserController.php
 * Manajemen User — Admin only
 * PHP 8.4 Native Semi-Framework
 *
 * Fitur:
 *   index()         — List semua user, filter per role, search username
 *   create()        — Form tambah user baru (teknisi / kasir / pelanggan)
 *   store()         — Proses simpan user baru
 *   edit()          — Form edit user (username, role, status)
 *   update()        — Proses simpan perubahan user
 *   show()          — Detail user + riwayat aktivitas (jika ada)
 *   toggleStatus()  — Aktifkan / nonaktifkan akun (POST)
 *   resetPassword() — Form reset password user (GET)
 *   doResetPassword()— Proses reset password (POST)
 *   hapus()         — Hapus user (POST + confirm)
 *   exportExcel()   — Export daftar user ke file .xlsx (via CSV + header)
 */

declare(strict_types=1);

namespace Controller\Master;

use Controller\BaseController;
use Core\Auth;
use Model\UserModel;
use Model\AuditLogModel;

class UserController extends BaseController
{
    private UserModel     $model;
    private AuditLogModel $audit;

    public function __construct()
    {
        $this->model = new UserModel();
        $this->audit = new AuditLogModel();
    }

    // -------------------------------------------------------------------------
    // List & Filter
    // -------------------------------------------------------------------------

    /**
     * GET /users
     * Query param: ?role=teknisi|kasir|pelanggan|admin  (opsional)
     */
    public function index(): void
    {
        Auth::roleGuard(['admin']);

        $role = isset($_GET['role']) && $_GET['role'] !== ''
            ? htmlspecialchars($_GET['role'], ENT_QUOTES, 'UTF-8')
            : null;

        $list = $this->model->getAllWithRole($role);

        $this->render('User/index', [
            'title'      => 'Manajemen User',
            'activeMenu' => 'users',
            'list'       => $list,
            'filterRole' => $role,
            'flash'      => $this->getFlash(),
        ]);
    }

    // -------------------------------------------------------------------------
    // Create
    // -------------------------------------------------------------------------

    /** GET /users/tambah */
    public function create(): void
    {
        Auth::roleGuard(['admin']);
        $flash = $this->getFlash();
        $this->render('User/create', [
            'title'      => 'Tambah User',
            'activeMenu' => 'users',
            'flash'      => $flash,
        ]);
    }

    /** POST /users/simpan */
    public function store(): void
    {
        Auth::roleGuard(['admin']);

        $input    = $this->requestBody();
        $username = trim($input['username'] ?? '');
        $password = $input['password'] ?? '';
        $confirm  = $input['confirm_password'] ?? '';
        $role     = $input['role'] ?? '';
        $status   = $input['status'] ?? 'active';

        // --- Validasi ---
        $errors = $this->validateUserInput($username, $password, $confirm, $role);
        if ($errors) {
            $this->render('User/create', [
                'title'  => 'Tambah User',
                'errors' => $errors,
                'old'    => $input,
            ]);
            return;
        }

        // Cek username duplikat
        if ($this->model->isUsernameTaken($username)) {
            $this->render('User/create', [
                'title'  => 'Tambah User',
                'errors' => ['Username sudah digunakan.'],
                'old'    => $input,
            ]);
            return;
        }

        $newId = $this->model->create([
            'username' => $username,
            'password' => Auth::hashPassword($password),
            'role'     => $role,
            'status'   => $status,
        ]);

        $this->audit->log(
            Auth::id() ?? 0,
            "Tambah user #{$newId} ({$username}) role={$role}"
        );

        $this->setFlash('success', "User \"{$username}\" berhasil ditambahkan.");
        $this->redirectTo('/users');
    }

    // -------------------------------------------------------------------------
    // Edit
    // -------------------------------------------------------------------------

    /** GET /users/edit/{id} */
    public function edit(string $id): void
    {
        Auth::roleGuard(['admin']);

        $user = $this->model->find((int) $id);
        if (!$user) {
            http_response_code(404);
            die('User tidak ditemukan.');
        }

        // Jangan tampilkan password hash ke form
        unset($user['password']);

        $flash = $this->getFlash();
        $this->render('User/edit', [
            'title'      => 'Edit User',
            'activeMenu' => 'users',
            'user'       => $user,
            'flash'      => $flash,
        ]);
    }

    /** POST /users/update/{id} */
    public function update(string $id): void
    {
        Auth::roleGuard(['admin']);

        $userId = (int) $id;
        $user   = $this->model->find($userId);
        if (!$user) {
            http_response_code(404);
            die('User tidak ditemukan.');
        }

        $input    = $this->requestBody();
        $username = trim($input['username'] ?? '');
        $role     = $input['role'] ?? '';
        $status   = $input['status'] ?? 'active';

        // Validasi username & role (tanpa validasi password karena tidak diubah di sini)
        $errors = [];
        if (strlen($username) < 4 || strlen($username) > 50) {
            $errors[] = 'Username harus antara 4–50 karakter.';
        }
        if (!in_array($role, ['admin', 'kasir', 'teknisi', 'pelanggan'], true)) {
            $errors[] = 'Role tidak valid.';
        }
        if (!in_array($status, ['active', 'inactive'], true)) {
            $errors[] = 'Status tidak valid.';
        }
        if ($this->model->isUsernameTaken($username, $userId)) {
            $errors[] = 'Username sudah digunakan oleh user lain.';
        }

        if ($errors) {
            $this->render('User/edit', [
                'title'  => 'Edit User',
                'user'   => array_merge($user, $input),
                'errors' => $errors,
            ]);
            return;
        }

        $this->model->edit($userId, [
            'username' => $username,
            'role'     => $role,
            'status'   => $status,
        ]);

        $this->audit->log(
            Auth::id() ?? 0,
            "Edit user #{$userId} ({$username}) role={$role} status={$status}"
        );

        $this->setFlash('success', "Data user \"{$username}\" berhasil diperbarui.");
        $this->redirectTo('/users');
    }

    // -------------------------------------------------------------------------
    // Detail
    // -------------------------------------------------------------------------

    /** GET /users/{id} */
    public function show(string $id): void
    {
        Auth::roleGuard(['admin']);

        $user = $this->model->find((int) $id);
        if (!$user) {
            http_response_code(404);
            die('User tidak ditemukan.');
        }
        unset($user['password']);

        // Riwayat aktivitas user ini (maks 50 entri)
        $logs = $this->audit->getByUser((int) $id, 50);

        $this->render('User/show', [
            'title'      => 'Detail User',
            'activeMenu' => 'users',
            'user'       => $user,
            'logs'       => $logs,
        ]);
    }

    // -------------------------------------------------------------------------
    // Toggle Status (Aktif / Nonaktif)
    // -------------------------------------------------------------------------

    /**
     * POST /users/status/{id}
     * Input: status = 'active' | 'inactive'
     * Hanya admin yang boleh; admin tidak bisa me-nonaktifkan dirinya sendiri.
     */
    public function toggleStatus(string $id): void
    {
        Auth::roleGuard(['admin']);

        $userId = (int) $id;

        // Cegah admin nonaktifkan akun sendiri
        if ($userId === Auth::id()) {
            $this->setFlash('error', 'Anda tidak dapat menonaktifkan akun Anda sendiri.');
            $this->redirectTo('/users');
        }

        $user = $this->model->find($userId);
        if (!$user) {
            http_response_code(404);
            die('User tidak ditemukan.');
        }

        $newStatus = $user['status'] === 'active' ? 'inactive' : 'active';
        $this->model->setStatus($userId, $newStatus);

        $label = $newStatus === 'active' ? 'diaktifkan' : 'dinonaktifkan';
        $this->audit->log(
            Auth::id() ?? 0,
            "Akun user #{$userId} ({$user['username']}) {$label}"
        );

        $this->setFlash('success', "Akun \"{$user['username']}\" berhasil {$label}.");
        $this->redirectTo('/users');
    }

    // -------------------------------------------------------------------------
    // Reset Password
    // -------------------------------------------------------------------------

    /** GET /users/reset-password/{id} */
    public function resetPassword(string $id): void
    {
        Auth::roleGuard(['admin']);

        $user = $this->model->find((int) $id);
        if (!$user) {
            http_response_code(404);
            die('User tidak ditemukan.');
        }
        unset($user['password']);

        $flash = $this->getFlash();
        $this->render('User/reset_password', [
            'title'      => 'Reset Password',
            'activeMenu' => 'users',
            'user'       => $user,
            'flash'      => $flash,
        ]);
    }

    /** POST /users/reset-password/{id} */
    public function doResetPassword(string $id): void
    {
        Auth::roleGuard(['admin']);

        $userId = (int) $id;
        $user   = $this->model->find($userId);
        if (!$user) {
            http_response_code(404);
            die('User tidak ditemukan.');
        }

        $input    = $this->requestBody();
        $password = $input['password'] ?? '';
        $confirm  = $input['confirm_password'] ?? '';

        $errors = [];
        if (strlen($password) < 8) {
            $errors[] = 'Password minimal 8 karakter.';
        }
        if ($password !== $confirm) {
            $errors[] = 'Konfirmasi password tidak cocok.';
        }

        if ($errors) {
            unset($user['password']);
            $this->render('User/reset_password', [
                'title'  => 'Reset Password',
                'user'   => $user,
                'errors' => $errors,
            ]);
            return;
        }

        $this->model->resetPassword($userId, Auth::hashPassword($password));

        $this->audit->log(
            Auth::id() ?? 0,
            "Reset password user #{$userId} ({$user['username']})"
        );

        $this->setFlash('success', "Password user \"{$user['username']}\" berhasil direset.");
        $this->redirectTo('/users/' . $userId);
    }

    // -------------------------------------------------------------------------
    // Hapus
    // -------------------------------------------------------------------------

    /**
     * POST /users/hapus/{id}
     * Admin tidak bisa hapus akun sendiri.
     * Transaksi cascade: hapus pelanggan dulu lalu users.
     */
    public function hapus(string $id): void
    {
        Auth::roleGuard(['admin']);

        $userId = (int) $id;

        if ($userId === Auth::id()) {
            $this->setFlash('error', 'Anda tidak dapat menghapus akun Anda sendiri.');
            $this->redirectTo('/users');
        }

        $user = $this->model->find($userId);
        if (!$user) {
            http_response_code(404);
            die('User tidak ditemukan.');
        }

        $ok = $this->model->hapus($userId);

        if ($ok) {
            $this->audit->log(
                Auth::id() ?? 0,
                "Hapus user #{$userId} ({$user['username']}) role={$user['role']}"
            );
            $this->setFlash('success', "User \"{$user['username']}\" berhasil dihapus.");
        } else {
            $this->setFlash('error', 'Gagal menghapus user. Mungkin masih memiliki data terkait.');
        }

        $this->redirectTo('/users');
    }

    // -------------------------------------------------------------------------
    // Export Excel (CSV with Excel-compatible headers)
    // -------------------------------------------------------------------------

    /**
     * GET /users/export
     * Kirim file CSV yang bisa dibuka Excel, opsional filter ?role=...
     */
    public function exportExcel(): void
    {
        Auth::roleGuard(['admin']);

        $role = isset($_GET['role']) && $_GET['role'] !== ''
            ? htmlspecialchars($_GET['role'], ENT_QUOTES, 'UTF-8')
            : null;

        $rows = $this->model->getAllForExport($role);

        $filename = 'users_' . ($role ?? 'semua') . '_' . date('Ymd_His') . '.csv';

        // Header HTTP agar browser treat sebagai file download
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');

        // BOM UTF-8 agar Excel Windows tidak salah encode karakter Indonesia
        echo "\xEF\xBB\xBF";

        $out = fopen('php://output', 'w');

        // Header kolom
        fputcsv($out, ['ID', 'Username', 'Role', 'Status', 'Nama Lengkap', 'Terdaftar'], ';');

        foreach ($rows as $row) {
            fputcsv($out, [
                $row['id'],
                $row['username'],
                $row['role'],
                $row['status'],
                $row['nama_lengkap'],
                $row['created_at'],
            ], ';');
        }

        fclose($out);

        $this->audit->log(
            Auth::id() ?? 0,
            "Export data user" . ($role ? " role={$role}" : " (semua)") . ", {$filename}"
        );

        exit;
    }

    // -------------------------------------------------------------------------
    // Private Helper
    // -------------------------------------------------------------------------

    /**
     * Validasi input create user — return array error (kosong = valid)
     */
    private function validateUserInput(
        string $username,
        string $password,
        string $confirm,
        string $role
    ): array {
        $errors = [];

        if ($username === '') {
            $errors[] = 'Username wajib diisi.';
        } elseif (strlen($username) < 4 || strlen($username) > 50) {
            $errors[] = 'Username harus antara 4–50 karakter.';
        }

        if (strlen($password) < 8) {
            $errors[] = 'Password minimal 8 karakter.';
        }

        if ($password !== $confirm) {
            $errors[] = 'Konfirmasi password tidak cocok.';
        }

        $validRoles = ['admin', 'kasir', 'teknisi', 'pelanggan'];
        if (!in_array($role, $validRoles, strict: true)) {
            $errors[] = 'Pilih role yang valid (admin / kasir / teknisi / pelanggan).';
        }

        return $errors;
    }
}
