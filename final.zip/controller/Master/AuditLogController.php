<?php
/**
 * controller/Master/AuditLogController.php
 * Riwayat Aktivitas / Audit Log — Admin only
 * PHP 8.4 Native Semi-Framework
 *
 * Fitur:
 *   index()  — tampilkan semua log, filter tanggal & user
 *   prune()  — hapus log lama (POST, admin only)
 */

declare(strict_types=1);

namespace Controller\Master;

use Controller\BaseController;
use Core\Auth;
use Model\AuditLogModel;
use Model\UserModel;

class AuditLogController extends BaseController
{
    private AuditLogModel $model;

    public function __construct()
    {
        $this->model = new AuditLogModel();
    }

    /**
     * GET /audit-log
     * Query params (opsional):
     *   ?from=2025-01-01  tanggal mulai
     *   ?to=2025-12-31    tanggal akhir
     *   ?user_id=3        filter per user
     */
    public function index(): void
    {
        Auth::roleGuard(['admin']);

        $from   = isset($_GET['from']) && $_GET['from'] !== '' ? $_GET['from'] : null;
        $to     = isset($_GET['to'])   && $_GET['to']   !== '' ? $_GET['to']   : null;
        $userId = isset($_GET['user_id']) && (int)$_GET['user_id'] > 0
                    ? (int)$_GET['user_id'] : null;

        // Ambil log sesuai filter
        if ($from && $to) {
            $logs = $this->model->getByDateRange(
                htmlspecialchars($from, ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($to,   ENT_QUOTES, 'UTF-8')
            );
        } elseif ($userId) {
            $logs = $this->model->getByUser($userId, 500);
        } else {
            $logs = $this->model->getAll(300);
        }

        // Dropdown pilih user untuk filter
        $userModel = new UserModel();
        $users     = $userModel->getAllWithRole();

        $flash = $this->getFlash();

        $this->render('AuditLog/index', [
            'title'      => 'Riwayat Aktivitas',
            'activeMenu' => 'audit',
            'logs'       => $logs,
            'users'      => $users,
            'filter'     => [
                'from'    => $from    ?? '',
                'to'      => $to      ?? '',
                'user_id' => $userId  ?? '',
            ],
            'flash'      => $flash,
        ]);
    }

    /**
     * POST /audit-log/prune
     * Hapus log lebih lama dari N hari (default 90)
     * Hanya admin, konfirmasi di frontend sebelum submit
     */
    public function prune(): void
    {
        Auth::roleGuard(['admin']);

        $input = $this->requestBody();
        $days  = max(1, (int)($input['days'] ?? 90));

        $deleted = $this->model->pruneOlderThan($days);

        // Catat aksi prune itu sendiri
        $this->model->log(
            Auth::id() ?? 0,
            "Prune audit log: {$deleted} entri lebih dari {$days} hari dihapus"
        );

        $this->setFlash('success', "{$deleted} entri log lama berhasil dihapus.");
        $this->redirectTo('/audit-log');
    }
}
