<?php

declare(strict_types=1);

namespace Controller\Master;

use Controller\BaseController;
use Service\UsageLogService;
use Model\UsageLogModel;
use Config\Database;

/**
 * UsageLogController
 *
 * Routes (tambahkan ke routes/web.php):
 *   $router->get('/usage-log',             [UsageLogController::class, 'index'],     [AuthMiddleware::class]);
 *   $router->get('/usage-log/cron',        [UsageLogController::class, 'cronLog'],   [AuthMiddleware::class]);
 *   $router->post('/usage-log/cron/prune', [UsageLogController::class, 'cronPrune'], [AuthMiddleware::class]);
 *   $router->get('/usage-log/export',      [UsageLogController::class, 'export'],    [AuthMiddleware::class]);
 */
class UsageLogController extends BaseController
{
    private UsageLogService $service;
    private UsageLogModel   $model;

    public function __construct()
    {
        // Panggil parent constructor jika ada
        if (method_exists(parent::class, '__construct')) {
            parent::__construct();
        }

        // ✅ FIXED: Ambil koneksi PDO dan inject ke Service + Model
        $db = Database::getConnection();

        $this->service = new UsageLogService($db);
        $this->model   = new UsageLogModel($db);
    }

    // =========================================================================
    // HALAMAN ADMIN
    // =========================================================================

    public function index(): void
    {
        $this->guardRole(['admin', 'teknisi']);

        $ym      = $_GET['ym'] ?? date('Y-m');
        $summary = $this->service->getMonthlySummaryAll($ym);
        $cronSum = $this->model->getCronSummary();
        $totalRx = array_sum(array_column($summary, 'rx_bytes'));
        $totalTx = array_sum(array_column($summary, 'tx_bytes'));

        $this->render('pages/UsageLog/index', compact(
            'summary', 'cronSum', 'ym', 'totalRx', 'totalTx'
        ));
    }

    public function cronLog(): void
    {
        $this->guardRole(['admin']);

        $limit   = min(500, max(20, (int) ($_GET['limit'] ?? 100)));
        $logs    = $this->model->getCronLogs($limit);
        $cronSum = $this->model->getCronSummary();

        $this->render('pages/UsageLog/cron_log', compact('logs', 'cronSum', 'limit'));
    }

    public function cronPrune(): void
    {
        $this->guardRole(['admin']);

        $days    = max(7, (int) ($_POST['days'] ?? 30));
        $deleted = $this->model->pruneCronLogs($days);

        $this->setFlashMessage('success', "Berhasil menghapus $deleted baris cron_log lebih tua dari $days hari.");
        $this->doRedirect('/usage-log/cron');
    }

    public function export(): void
    {
        $this->guardRole(['admin']);

        $ym      = $_GET['ym'] ?? date('Y-m');
        $summary = $this->service->getMonthlySummaryAll($ym);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="usage_' . $ym . '.csv"');
        header('Cache-Control: no-cache');

        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF"); // BOM UTF-8 untuk Excel

        fputcsv($out, [
            'Pelanggan ID', 'Nama', 'MAC Address', 'Paket', 'Kecepatan',
            'Download', 'Upload', 'Total', 'Online', 'Last Active',
        ]);

        foreach ($summary as $row) {
            fputcsv($out, [
                $row['pelanggan_id'],
                $row['nama_lengkap'],
                $row['mac_address']  ?? '-',
                $row['nama_paket'],
                $row['kecepatan'],
                $row['rx_human'],
                $row['tx_human'],
                $row['total_human'],
                $row['online_human'],
                $row['last_active'],
            ]);
        }

        fclose($out);
        exit;
    }

    // =========================================================================
    // API — dipanggil show.php via fetch()
    // GET /pelanggan/{id}/usageToday
    // GET /pelanggan/{id}/usageMonth?ym=YYYY-MM
    // =========================================================================

    public function usageToday(int $id): void
    {
        $pel  = $this->findPelanggan($id);
        $data = $this->service->getUsageToday($id, $pel['mac_address'] ?? null);
        $this->outputJson($data);
    }

    public function usageMonth(int $id): void
    {
        $this->findPelanggan($id);
        $data = $this->service->getUsageMonth($id, $_GET['ym'] ?? null);
        $this->outputJson($data);
    }

    // =========================================================================
    // PRIVATE HELPER
    // =========================================================================

    /**
     * Kirim JSON dan exit.
     */
    private function outputJson(mixed $data, int $code = 200): never
    {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    /**
     * Ambil pelanggan by ID atau kirim 404 JSON.
     */
    private function findPelanggan(int $id): array
    {
        $db   = Database::getConnection();
        $stmt = $db->prepare("SELECT id, mac_address FROM pelanggan WHERE id = ?");
        $stmt->execute([$id]);
        $row  = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$row) {
            $this->outputJson(['error' => 'Pelanggan tidak ditemukan.'], 404);
        }

        return $row;
    }

    /**
     * Guard role
     */
    private function guardRole(array $roles): void
    {
        if (method_exists($this, 'requireRole')) {
            $this->requireRole($roles);
        } elseif (method_exists($this, 'checkRole')) {
            $this->checkRole($roles);
        } elseif (method_exists($this, 'authorizeRole')) {
            $this->authorizeRole($roles);
        } else {
            $userRole = \Core\Auth::user()['role'] ?? '';
            if (!in_array($userRole, $roles, true)) {
                http_response_code(403);
                if (file_exists(dirname(__DIR__, 2) . '/views/errors/403.php')) {
                    require dirname(__DIR__, 2) . '/views/errors/403.php';
                } else {
                    echo '<h1>403 Forbidden</h1><p>Anda tidak punya akses ke halaman ini.</p>';
                }
                exit;
            }
        }
    }

    /**
     * Flash message
     */
    private function setFlashMessage(string $type, string $message): void
    {
        if (method_exists($this, 'flash')) {
            $this->flash($type, $message);
        } elseif (method_exists($this, 'setFlash')) {
            $this->setFlash($type, $message);
        } elseif (method_exists($this, 'flashMessage')) {
            $this->flashMessage($type, $message);
        } else {
            $_SESSION['flash'] = ['type' => $type, 'message' => $message];
        }
    }

    /**
     * Redirect
     */
    private function doRedirect(string $path): never
    {
        if (method_exists($this, 'redirect')) {
            $this->redirect($path);
        } else {
            $appUrl = $_ENV['APP_URL'] ?? '';
            header('Location: ' . $appUrl . $path);
        }
        exit;
    }
}
