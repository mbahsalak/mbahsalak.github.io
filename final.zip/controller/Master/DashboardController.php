<?php

declare(strict_types=1);

namespace Controller\Master;

use Controller\BaseController;
use Core\Auth;
use Config\Database;
use Service\MikrotikService;

class DashboardController extends BaseController
{
    public function index(): void
    {
        $user = Auth::user();
        $role = $user['role'] ?? 'pelanggan';

        match ($role) {
            'admin'   => $this->renderAdmin($user),
            'teknisi' => $this->renderTeknisi($user),
            'kasir'   => $this->renderKasir($user),
            default   => $this->renderPelanggan($user),
        };
    }

    /**
     * Helper: jalankan query aman, return default jika error
     * 
     * Logika return type:
     *  - Query dengan GROUP BY → SELALU fetchAll() → return array
     *  - Query COUNT/SUM tanpa GROUP BY → fetchColumn() → return scalar
     *  - Query SELECT biasa → fetchAll() → return array
     *  - forceAll = true → paksa fetchAll() apapun query-nya
     *
     * @param string $sql       Query SQL
     * @param array  $params    Parameter binding
     * @param mixed  $default   Default value jika error
     * @param bool   $forceAll  Paksa fetchAll meski ada COUNT/SUM (untuk query multi-kolom tanpa GROUP BY)
     */
    private function safeQuery(string $sql, array $params = [], mixed $default = null, bool $forceAll = false): mixed
    {
        try {
            $db   = Database::getConnection();
            $stmt = $db->prepare($sql);
            $stmt->execute($params);

            // Query dengan GROUP BY → SELALU fetchAll (return array of rows)
            $hasGroupBy = stripos($sql, 'GROUP BY') !== false;

            if ($forceAll || $hasGroupBy) {
                $result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
                return $result !== false ? $result : ($default ?? []);
            }

            // Single-value query (COUNT, SUM tanpa GROUP BY) → fetchColumn
            if (
                stripos($sql, 'COUNT(') !== false
                || stripos($sql, 'SUM(') !== false
                || stripos($sql, 'COALESCE(') !== false
            ) {
                $result = $stmt->fetchColumn();
                return $result !== false ? $result : ($default ?? 0);
            }

            // Default: fetchAll
            $result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            return $result !== false ? $result : ($default ?? []);

        } catch (\PDOException $e) {
            error_log("[Dashboard] Query error: {$e->getMessage()} | SQL: " . substr($sql, 0, 200));
            return $default ?? [];
        }
    }

    /**
     * Helper: count baris dari tabel
     */
    private function safeCount(string $table, string $where = '1=1'): int
    {
        try {
            $db = Database::getConnection();
            return (int) $db->query("SELECT COUNT(*) FROM `{$table}` WHERE {$where}")->fetchColumn();
        } catch (\PDOException) {
            return 0;
        }
    }

    // =========================================================================
    // ADMIN
    // =========================================================================
    private function renderAdmin(array $user): void
    {
    	    $prefs = $this->getUserPreferences();
        // ── STATISTIK UTAMA ──
        $totalPelanggan  = (int) $this->safeQuery("SELECT COUNT(*) FROM pelanggan");
        $pelangganAktif  = (int) $this->safeQuery("SELECT COUNT(*) FROM pelanggan WHERE status_internet = 'aktif'");
        $pelangganIsolir = (int) $this->safeQuery("SELECT COUNT(*) FROM pelanggan WHERE status_internet = 'isolir'");

        // ── REVENUE ──
        $revenueHariIni = (float) $this->safeQuery("
            SELECT COALESCE(SUM(total), 0) 
            FROM tagihan 
            WHERE status = 'paid' AND DATE(tgl_bayar) = CURDATE()
        ");

        $revenueBulanIni = (float) $this->safeQuery("
            SELECT COALESCE(SUM(total), 0) 
            FROM tagihan 
            WHERE status = 'paid' 
            AND YEAR(tgl_bayar) = YEAR(CURDATE()) 
            AND MONTH(tgl_bayar) = MONTH(CURDATE())
        ");

        $revenueBulanLalu = (float) $this->safeQuery("
            SELECT COALESCE(SUM(total), 0) 
            FROM tagihan 
            WHERE status = 'paid' 
            AND YEAR(tgl_bayar) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))
            AND MONTH(tgl_bayar) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))
        ");

        // tagihanPending → multi-kolom tanpa GROUP BY → pakai forceAll
        $tagihanPendingRaw = $this->safeQuery("
            SELECT COUNT(*) AS cnt, COALESCE(SUM(total), 0) AS total 
            FROM tagihan WHERE status = 'unpaid'
        ", [], ['cnt' => 0, 'total' => 0], true);

        if (is_array($tagihanPendingRaw) && !empty($tagihanPendingRaw)) {
            $tagihanPending = $tagihanPendingRaw[0];
        } else {
            $tagihanPending = ['cnt' => 0, 'total' => 0];
        }

        // ── PENGADUAN ──
        $pengaduanOpen   = (int) $this->safeQuery("SELECT COUNT(*) FROM pengaduan WHERE status = 'open'");
        $pengaduanProses = (int) $this->safeQuery("SELECT COUNT(*) FROM pengaduan WHERE status = 'proses'");

        // ── CANDLESTICK: Revenue 30 Hari (OHLC per hari) ──
        // Query ini punya GROUP BY → safeQuery otomatis return array
        $revenueDaily = $this->safeQuery("
            SELECT 
                DATE(tgl_bayar) AS tanggal,
                COUNT(*) AS transaksi,
                MIN(total) AS low,
                MAX(total) AS high,
                SUM(total) AS volume
            FROM tagihan 
            WHERE status = 'paid' 
            AND tgl_bayar >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
            GROUP BY DATE(tgl_bayar)
            ORDER BY tanggal ASC
        ");

        $candleRevenue = [];
        if (is_array($revenueDaily)) {
            foreach ($revenueDaily as $row) {
                $candleRevenue[] = [
                    'x' => strtotime($row['tanggal']) * 1000,
                    'y' => [
                        (float)($row['volume'] * 0.85),   // open
                        (float)$row['high'],               // high
                        (float)$row['low'],                // low
                        (float)$row['volume'],             // close
                    ]
                ];
            }
        }

        // ── CANDLESTICK: Bandwidth Usage 30 Hari ──
        $bandwidthDaily = $this->safeQuery("
            SELECT 
                tanggal,
                SUM(rx_bytes) AS total_rx,
                SUM(tx_bytes) AS total_tx,
                MIN(rx_bytes + tx_bytes) AS low,
                MAX(rx_bytes + tx_bytes) AS high
            FROM usage_daily_summary
            WHERE tanggal >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
            GROUP BY tanggal
            ORDER BY tanggal ASC
        ");

        $candleBandwidth = [];
        if (is_array($bandwidthDaily)) {
            foreach ($bandwidthDaily as $row) {
                $total = (int)($row['total_rx'] ?? 0) + (int)($row['total_tx'] ?? 0);
                $candleBandwidth[] = [
                    'x' => strtotime($row['tanggal']) * 1000,
                    'y' => [
                        $total * 0.9,
                        (int)($row['high'] ?? 0),
                        (int)($row['low'] ?? 0),
                        $total,
                    ]
                ];
            }
        }

        // ── LINE: Pelanggan Growth 12 Bulan ──
        $pelangganGrowth = $this->safeQuery("
            SELECT 
                DATE_FORMAT(created_at, '%Y-%m') AS bulan,
                COUNT(*) AS new_pelanggan
            FROM pelanggan
            WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
            GROUP BY DATE_FORMAT(created_at, '%Y-%m')
            ORDER BY bulan ASC
        ");
        if (!is_array($pelangganGrowth)) {
            $pelangganGrowth = [];
        }

        // ── PIE: Paket Distribution ──
        $paketDist = $this->safeQuery("
            SELECT pk.nama_paket, COUNT(p.id) AS cnt
            FROM paket pk
            LEFT JOIN pelanggan p ON p.paket_id = pk.id
            GROUP BY pk.id, pk.nama_paket
            ORDER BY cnt DESC
        ");
        if (!is_array($paketDist)) {
            $paketDist = [];
        }

        // ── PIE: Status Pelanggan ──
        $statusDist = $this->safeQuery("
            SELECT status_internet, COUNT(*) AS cnt
            FROM pelanggan
            GROUP BY status_internet
        ");
        if (!is_array($statusDist)) {
            $statusDist = [];
        }

        // ── AREA: Pengaduan per Hari (14 hari) ──
        $pengaduanDaily = $this->safeQuery("
            SELECT DATE(created_at) AS tanggal, COUNT(*) AS cnt
            FROM pengaduan
            WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 14 DAY)
            GROUP BY DATE(created_at)
            ORDER BY tanggal ASC
        ");
        if (!is_array($pengaduanDaily)) {
            $pengaduanDaily = [];
        }

        // ── TABEL: Pembayaran Terbaru ──
        $pembayaranTerbaru = $this->safeQuery("
            SELECT t.id, t.periode_bulan, t.total, t.tgl_bayar, t.metode_pembayaran,
                   p.nama_lengkap AS pelanggan
            FROM tagihan t
            LEFT JOIN pelanggan p ON t.pelanggan_id = p.id
            WHERE t.status = 'paid'
            ORDER BY t.tgl_bayar DESC
            LIMIT 8
        ");
        if (!is_array($pembayaranTerbaru)) {
            $pembayaranTerbaru = [];
        }

        // ── TABEL: Pengaduan Terbaru ──
        $pengaduanTerbaru = $this->safeQuery("
            SELECT pg.id, pg.judul, pg.status, pg.created_at,
                   p.nama_lengkap AS pelanggan
            FROM pengaduan pg
            LEFT JOIN pelanggan p ON pg.pelanggan_id = p.id
            ORDER BY pg.created_at DESC
            LIMIT 8
        ");
        if (!is_array($pengaduanTerbaru)) {
            $pengaduanTerbaru = [];
        }

        // ── TREND INDICATORS ──
        $revTrend = $revenueBulanLalu > 0
            ? round((($revenueBulanIni - $revenueBulanLalu) / $revenueBulanLalu) * 100, 1)
            : 0;

        $this->render('Dashboard/index_admin', [
            'title'      => 'Admin Dashboard',
            'activeMenu' => 'dashboard',
            'user'       => Auth::user(),
            'flash'      => $this->getFlash(),
            'prefs' => $prefs,
            'stats' => [
                'totalPelanggan'   => $totalPelanggan,
                'pelangganAktif'   => $pelangganAktif,
                'pelangganIsolir'  => $pelangganIsolir,
                'revenueHariIni'   => $revenueHariIni,
                'revenueBulanIni'  => $revenueBulanIni,
                'revenueBulanLalu' => $revenueBulanLalu,
                'revTrend'         => $revTrend,
                'tagihanPending'   => (int)($tagihanPending['cnt'] ?? 0),
                'tunggakanTotal'   => (float)($tagihanPending['total'] ?? 0),
                'pengaduanOpen'    => $pengaduanOpen,
                'pengaduanProses'  => $pengaduanProses,
            ],
            'candleRevenue'     => $candleRevenue,
            'candleBandwidth'   => $candleBandwidth,
            'pelangganGrowth'   => $pelangganGrowth,
            'paketDist'         => $paketDist,
            'statusDist'        => $statusDist,
            'pengaduanDaily'    => $pengaduanDaily,
            'pembayaranTerbaru' => $pembayaranTerbaru,
            'pengaduanTerbaru'  => $pengaduanTerbaru,
        ]);
    }

    // =========================================================================
    // TEKNISI
    // =========================================================================
    private function renderTeknisi(array $user): void
    {
        $stats = [
            'tiket_open'      => (int) $this->safeQuery("SELECT COUNT(*) FROM pengaduan WHERE status = 'open'", [], 0),
            'tiket_proses'    => (int) $this->safeQuery("SELECT COUNT(*) FROM pengaduan WHERE status = 'proses'", [], 0),
            'total_pelanggan' => $this->safeCount('pelanggan'),
            'pelanggan_aktif' => (int) $this->safeQuery(
                "SELECT COUNT(*) FROM pelanggan WHERE status_internet = 'aktif'", [], 0
            ),
        ];

        $ticketOpen = $this->safeQuery("
            SELECT pg.*, p.nama_lengkap
            FROM pengaduan pg
            LEFT JOIN pelanggan p ON pg.pelanggan_id = p.id
            WHERE pg.status IN ('open', 'proses')
            ORDER BY pg.created_at DESC
            LIMIT 15
        ", [], []);

        if (!is_array($ticketOpen)) {
            $ticketOpen = [];
        }

        $pelangganModel = new \Model\PelangganModel();
        $pelanggan = $pelangganModel->getAll();

        $this->render('Dashboard/index_teknisi', [
            'title'      => 'Dashboard Teknisi',
            'activeMenu' => 'dashboard',
            'user'       => $user,
            'stats'      => $stats,
            'ticketOpen' => $ticketOpen,
            'pelanggan'  => $pelanggan,
        ]);
    }

    // =========================================================================
    // KASIR
    // =========================================================================
    private function renderKasir(array $user): void
    {
        $stats = [
            'tagihan_paid'     => (int) $this->safeQuery("SELECT COUNT(*) FROM tagihan WHERE status = 'paid'", [], 0),
            'tagihan_unpaid'   => (int) $this->safeQuery("SELECT COUNT(*) FROM tagihan WHERE status = 'unpaid'", [], 0),
            'pendapatan_bulan' => (float) $this->safeQuery(
                "SELECT COALESCE(SUM(total), 0) FROM tagihan WHERE status = 'paid' AND MONTH(tgl_bayar) = MONTH(NOW()) AND YEAR(tgl_bayar) = YEAR(NOW())",
                [], 0
            ),
            'piutang'   => (float) $this->safeQuery("SELECT COALESCE(SUM(total), 0) FROM tagihan WHERE status = 'unpaid'", [], 0),
            'kas_masuk' => (float) $this->safeQuery(
                "SELECT COALESCE(SUM(jumlah), 0) FROM kas WHERE tipe = 'masuk' AND MONTH(tanggal) = MONTH(NOW()) AND YEAR(tanggal) = YEAR(NOW())",
                [], 0
            ),
            'kas_keluar' => (float) $this->safeQuery(
                "SELECT COALESCE(SUM(jumlah), 0) FROM kas WHERE tipe = 'keluar' AND MONTH(tanggal) = MONTH(NOW()) AND YEAR(tanggal) = YEAR(NOW())",
                [], 0
            ),
        ];

        $rekap = $this->safeQuery("
            SELECT 
                DATE_FORMAT(tgl_bayar, '%Y-%m') AS bulan,
                SUM(CASE WHEN status = 'paid' THEN total ELSE 0 END) AS paid,
                SUM(CASE WHEN status = 'unpaid' THEN total ELSE 0 END) AS unpaid
            FROM tagihan
            WHERE tgl_bayar >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
            GROUP BY DATE_FORMAT(tgl_bayar, '%Y-%m')
            ORDER BY bulan ASC
        ", [], []);

        if (!is_array($rekap)) {
            $rekap = [];
        }

        $chartData = [
            'labels'     => array_column($rekap, 'bulan'),
            'pendapatan' => array_map('floatval', array_column($rekap, 'paid')),
            'unpaid'     => array_map('floatval', array_column($rekap, 'unpaid')),
        ];

        $recentTagihan = $this->safeQuery("
            SELECT t.*, p.nama_lengkap
            FROM tagihan t
            LEFT JOIN pelanggan p ON t.pelanggan_id = p.id
            ORDER BY t.created_at DESC
            LIMIT 15
        ", [], []);

        if (!is_array($recentTagihan)) {
            $recentTagihan = [];
        }

        $this->render('Dashboard/index_kasir', [
            'title'         => 'Dashboard Kasir',
            'activeMenu'    => 'dashboard',
            'user'          => $user,
            'flash'         => $this->getFlash(),
            'stats'         => $stats,
            'chartData'     => $chartData,
            'recentTagihan' => $recentTagihan,
        ]);
    }

    // =========================================================================
    // PELANGGAN
    // =========================================================================
    private function renderPelanggan(array $user): void
    {
        // ── Ambil pelanggan_id dari session, atau cari via user_id ──
        $pelangganId = $user['pelanggan_id'] ?? null;
        $userId      = $user['id'] ?? null;

        if (!$pelangganId && $userId) {
            $found = $this->safeQuery(
                "SELECT id FROM pelanggan WHERE user_id = ? LIMIT 1",
                [$userId], []
            );
            if (is_array($found) && !empty($found)) {
                $pelangganId = (int)$found[0]['id'];
            }
        }

        // ── Data pelanggan + paket ──
        $pelanggan = null;
        $paket     = [];
        if ($pelangganId) {
            $rows = $this->safeQuery(
                "SELECT p.*, pk.nama_paket, pk.kecepatan, pk.harga, pk.id AS paket_id
                 FROM pelanggan p
                 LEFT JOIN paket pk ON p.paket_id = pk.id
                 WHERE p.id = ?
                 LIMIT 1",
                [$pelangganId], []
            );
            $pelanggan = (is_array($rows) && !empty($rows)) ? $rows[0] : null;

            if ($pelanggan) {
                $paket = [
                    'nama_paket' => $pelanggan['nama_paket'] ?? '-',
                    'kecepatan'  => $pelanggan['kecepatan']  ?? '10 Mbps',
                    'harga'      => $pelanggan['harga']      ?? 0,
                ];
            }
        }

        // ── Normalisasi status_internet ──
        $rawStatus = $pelanggan['status_internet'] ?? null;
        $statusInternet = match (true) {
            $rawStatus === null || $rawStatus === '' || $rawStatus === false => 'pending',
            in_array($rawStatus, ['isolir', 'isolated', 'suspend', 'suspended'], true) => 'isolir',
            in_array($rawStatus, ['nonaktif', 'inactive', 'non-aktif'], true) => 'nonaktif',
            in_array($rawStatus, ['pending', 'menunggu'], true) => 'pending',
            $rawStatus === 'aktif' || $rawStatus === 'active' => 'aktif',
            default => 'aktif',
        };

        error_log("[Dashboard] pelangganId={$pelangganId}, rawStatus={$rawStatus}, normalized={$statusInternet}");

        // ── PENDING → tampilkan halaman menunggu aktivasi ──
        if ($statusInternet === 'pending') {
            $this->render('Dashboard/index_pelanggan_pending', [
                'title'      => 'Menunggu Aktivasi',
                'activeMenu' => 'dashboard',
                'user'       => $user,
                'flash'      => $this->getFlash(),
                'pelanggan'  => $pelanggan,
            ]);
            return;
        }

        // ── NONAKTIF → tampilkan halaman info nonaktif ──
        if ($statusInternet === 'nonaktif') {
            $this->render('Dashboard/index_pelanggan_nonaktif', [
                'title'      => 'Akun Tidak Aktif',
                'activeMenu' => 'dashboard',
                'user'       => $user,
                'flash'      => $this->getFlash(),
                'pelanggan'  => $pelanggan,
            ]);
            return;
        }

        // =====================================================================
        // AKTIF / ISOLIR → Dashboard Lengkap
        // =====================================================================

        // ── USAGE & UPTIME ──
        $usageToday = ['rx_bytes' => 0, 'tx_bytes' => 0, 'hourly' => []];
        $usageMonth = ['rx_bytes' => 0, 'tx_bytes' => 0, 'daily' => []];
        $uptime     = 0;
        $isOnline   = false;
        $lastSeen   = null;
        $ipAddress  = '-';
        $mac        = $pelanggan['mac_address'] ?? null;

        if ($pelangganId) {
            // ── Coba ambil dari MikroTik API ──
            try {
                $mikrotik = new \Core\MikrotikClient(
                    $_ENV['MIKROTIK_URL']     ?? 'http://localhost:5000',
                    $_ENV['MIKROTIK_USER']    ?? 'admin',
                    $_ENV['MIKROTIK_PASS']    ?? 'admin123',
                    (int)($_ENV['MIKROTIK_TIMEOUT'] ?? 5)
                );

                // Uptime / Online status
                if ($mac) {
                    $clients  = $mikrotik->getConnectedClients();
                    $macUpper = strtoupper($mac);

                    foreach ($clients as $client) {
                        $clientMac = strtoupper($client['mac-address'] ?? $client['mac_address'] ?? '');
                        if ($clientMac === $macUpper) {
                            $isOnline  = true;
                            $ipAddress = $client['ip-address'] ?? $client['ip_address'] ?? '-';
                            $uptimeRaw = $client['uptime'] ?? '0s';

                            // Parse uptime string
                            $uptime = 0;
                            if (preg_match('/(\d+)w/', $uptimeRaw, $m)) $uptime += (int)$m[1] * 604800;
                            if (preg_match('/(\d+)d/', $uptimeRaw, $m)) $uptime += (int)$m[1] * 86400;
                            if (preg_match('/(\d+)h/', $uptimeRaw, $m)) $uptime += (int)$m[1] * 3600;
                            if (preg_match('/(\d+)m(?!s)/', $uptimeRaw, $m)) $uptime += (int)$m[1] * 60;
                            if (preg_match('/(\d+)s/', $uptimeRaw, $m)) $uptime += (int)$m[1];
                            if (preg_match('/(\d+):(\d+):(\d+)/', $uptimeRaw, $m)) {
                                $uptime = (int)$m[1] * 3600 + (int)$m[2] * 60 + (int)$m[3];
                            }
                            break;
                        }
                    }
                }

                // Usage today dari MikroTik
                if ($mac) {
                    $todayData = $mikrotik->getClientUsageToday(strtoupper($mac));
                    if (!empty($todayData['rx_bytes']) || !empty($todayData['tx_bytes'])) {
                        $usageToday = [
                            'rx_bytes' => (int)($todayData['rx_bytes'] ?? 0),
                            'tx_bytes' => (int)($todayData['tx_bytes'] ?? 0),
                            'hourly'   => $todayData['hourly'] ?? [],
                        ];
                    }

                    $monthData = $mikrotik->getClientUsageMonth(strtoupper($mac));
                    if (!empty($monthData['rx_bytes']) || !empty($monthData['tx_bytes'])) {
                        $usageMonth = [
                            'rx_bytes' => (int)($monthData['rx_bytes'] ?? 0),
                            'tx_bytes' => (int)($monthData['tx_bytes'] ?? 0),
                            'daily'    => $monthData['daily'] ?? [],
                        ];
                    }
                }
            } catch (\Throwable $e) {
                error_log("[Dashboard] MikroTik API error: " . $e->getMessage());
            }

            // ── Fallback: Usage today dari database ──
            if ($usageToday['rx_bytes'] === 0 && $usageToday['tx_bytes'] === 0) {
                // Coba dari usage_daily_summary
                $dailySummary = $this->safeQuery("
                    SELECT COALESCE(rx_bytes, 0) AS rx_bytes, COALESCE(tx_bytes, 0) AS tx_bytes
                    FROM usage_daily_summary
                    WHERE pelanggan_id = ? AND tanggal = CURDATE()
                    LIMIT 1
                ", [$pelangganId], []);

                if (is_array($dailySummary) && !empty($dailySummary)) {
                    $usageToday = [
                        'rx_bytes' => (int)($dailySummary[0]['rx_bytes'] ?? 0),
                        'tx_bytes' => (int)($dailySummary[0]['tx_bytes'] ?? 0),
                        'hourly'   => [],
                    ];
                }

                // Fallback ke usage_log
                if ($usageToday['rx_bytes'] === 0 && $usageToday['tx_bytes'] === 0) {
                    $todayDb = $this->safeQuery("
                        SELECT 
                            COALESCE(MAX(rx_bytes), 0) AS rx_bytes,
                            COALESCE(MAX(tx_bytes), 0) AS tx_bytes
                        FROM usage_log
                        WHERE pelanggan_id = ? AND DATE(snapshot_at) = CURDATE()
                    ", [$pelangganId], []);

                    if (is_array($todayDb) && !empty($todayDb)) {
                        $usageToday = [
                            'rx_bytes' => (int)($todayDb[0]['rx_bytes'] ?? 0),
                            'tx_bytes' => (int)($todayDb[0]['tx_bytes'] ?? 0),
                            'hourly'   => [],
                        ];
                    }
                }

                // Hourly breakdown
                $hourlyRaw = $this->safeQuery("
                    SELECT 
                        HOUR(snapshot_at) AS hour,
                        MAX(rx_bytes) AS rx_bytes,
                        MAX(tx_bytes) AS tx_bytes
                    FROM usage_log
                    WHERE pelanggan_id = ? AND DATE(snapshot_at) = CURDATE()
                    GROUP BY HOUR(snapshot_at)
                    ORDER BY hour ASC
                ", [$pelangganId], []);

                if (is_array($hourlyRaw)) {
                    $hourlyMap = [];
                    foreach ($hourlyRaw as $row) {
                        $hourlyMap[(int)$row['hour']] = $row;
                    }
                    $hourly = [];
                    for ($h = 0; $h < 24; $h++) {
                        $hourly[] = [
                            'hour'     => $h,
                            'rx_bytes' => (int)($hourlyMap[$h]['rx_bytes'] ?? 0),
                            'tx_bytes' => (int)($hourlyMap[$h]['tx_bytes'] ?? 0),
                        ];
                    }
                    $usageToday['hourly'] = $hourly;
                }
            }

            // ── Fallback: Usage month dari database ──
            if ($usageMonth['rx_bytes'] === 0 && $usageMonth['tx_bytes'] === 0) {
                $monthDb = $this->safeQuery("
                    SELECT 
                        COALESCE(SUM(rx_bytes), 0) AS rx_bytes,
                        COALESCE(SUM(tx_bytes), 0) AS tx_bytes
                    FROM usage_daily_summary
                    WHERE pelanggan_id = ?
                    AND YEAR(tanggal) = YEAR(CURDATE())
                    AND MONTH(tanggal) = MONTH(CURDATE())
                ", [$pelangganId], []);

                if (is_array($monthDb) && !empty($monthDb)) {
                    $usageMonth = [
                        'rx_bytes' => (int)($monthDb[0]['rx_bytes'] ?? 0),
                        'tx_bytes' => (int)($monthDb[0]['tx_bytes'] ?? 0),
                        'daily'    => [],
                    ];
                }

                // Fallback ke usage_log
                if ($usageMonth['rx_bytes'] === 0 && $usageMonth['tx_bytes'] === 0) {
                    $monthLog = $this->safeQuery("
                        SELECT 
                            COALESCE(SUM(rx_bytes), 0) AS rx_bytes,
                            COALESCE(SUM(tx_bytes), 0) AS tx_bytes
                        FROM usage_log
                        WHERE pelanggan_id = ?
                        AND YEAR(snapshot_at) = YEAR(CURDATE())
                        AND MONTH(snapshot_at) = MONTH(CURDATE())
                    ", [$pelangganId], []);

                    if (is_array($monthLog) && !empty($monthLog)) {
                        $usageMonth = [
                            'rx_bytes' => (int)($monthLog[0]['rx_bytes'] ?? 0),
                            'tx_bytes' => (int)($monthLog[0]['tx_bytes'] ?? 0),
                            'daily'    => [],
                        ];
                    }
                }

                // Daily breakdown
                $dailyRaw = $this->safeQuery("
                    SELECT 
                        tanggal AS date,
                        COALESCE(rx_bytes, 0) AS rx_bytes,
                        COALESCE(tx_bytes, 0) AS tx_bytes
                    FROM usage_daily_summary
                    WHERE pelanggan_id = ?
                    AND YEAR(tanggal) = YEAR(CURDATE())
                    AND MONTH(tanggal) = MONTH(CURDATE())
                    ORDER BY tanggal ASC
                ", [$pelangganId], []);

                if (is_array($dailyRaw)) {
                    $usageMonth['daily'] = $dailyRaw;
                }
            }

            // ── Fallback: Last seen & IP dari database ──
            if (!$isOnline) {
                $lastSeenRow = $this->safeQuery("
                    SELECT snapshot_at, ip_address 
                    FROM usage_log 
                    WHERE pelanggan_id = ? AND is_online = 1
                    ORDER BY snapshot_at DESC 
                    LIMIT 1
                ", [$pelangganId], []);

                if (is_array($lastSeenRow) && !empty($lastSeenRow)) {
                    $lastSeen  = $lastSeenRow[0]['snapshot_at'] ?? null;
                    $ipAddress = $lastSeenRow[0]['ip_address'] ?? '-';
                }

                if ($ipAddress === '-' && !empty($pelanggan['ip_address'])) {
                    $ipAddress = $pelanggan['ip_address'];
                }
            }
        }

        // =====================================================================
        // TAGIHAN BELUM BAYAR
        // =====================================================================
        $tagihan = [];
        if ($pelangganId) {
            $tagihanRaw = $this->safeQuery("
                SELECT t.id, t.periode_bulan AS periode, t.status,
                       t.tipe, t.deskripsi,
                       t.jatuh_tempo,
                       t.total,
                       t.created_at
                FROM tagihan t
                WHERE t.pelanggan_id = ? 
                AND t.status = 'unpaid'
                ORDER BY t.jatuh_tempo ASC
            ", [$pelangganId], []);

            if (is_array($tagihanRaw)) {
                $tagihan = $tagihanRaw;
            }
        }

        // =====================================================================
        // RIWAYAT PEMBAYARAN (dari tabel tagihan yang status = 'paid')
        // =====================================================================
        $riwayat = [];
        if ($pelangganId) {
            $riwayatRaw = $this->safeQuery("
                SELECT 
                    t.periode_bulan AS periode,
                    t.total AS jumlah,
                    t.tgl_bayar,
                    t.metode_pembayaran AS metode,
                    t.penerima,
                    t.tipe, t.deskripsi
                FROM tagihan t
                WHERE t.pelanggan_id = ? 
                AND t.status = 'paid'
                ORDER BY t.tgl_bayar DESC
                LIMIT 12
            ", [$pelangganId], []);

            if (is_array($riwayatRaw)) {
                $riwayat = $riwayatRaw;
            }
        }

        // =====================================================================
        // PENGADUAN SAYA
        // =====================================================================
        $pengaduan = [];
        if ($pelangganId) {
            $pengaduanRaw = $this->safeQuery("
                SELECT pg.id, pg.judul, pg.deskripsi, pg.status, 
                       pg.latitude, pg.longitude,
                       pg.created_at, pg.updated_at
                FROM pengaduan pg
                WHERE pg.pelanggan_id = ?
                ORDER BY pg.id DESC
                LIMIT 10
            ", [$pelangganId], []);

            if (is_array($pengaduanRaw)) {
                $pengaduan = $pengaduanRaw;
            }
        }

        // =====================================================================
        // STATISTIK RINGKASAN
        // =====================================================================
        $stats = [
            'total_tagihan'     => count($tagihan),
            'total_pengaduan'   => count($pengaduan),
            'pengaduan_open'    => count(array_filter($pengaduan, fn($p) => ($p['status'] ?? '') === 'open')),
            'pengaduan_proses'  => count(array_filter($pengaduan, fn($p) => ($p['status'] ?? '') === 'proses')),
            'pengaduan_selesai' => count(array_filter($pengaduan, fn($p) => ($p['status'] ?? '') === 'selesai')),
            'total_pembayaran'  => count($riwayat),
            'usage_today_total' => (int)($usageToday['rx_bytes'] ?? 0) + (int)($usageToday['tx_bytes'] ?? 0),
            'usage_month_total' => (int)($usageMonth['rx_bytes'] ?? 0) + (int)($usageMonth['tx_bytes'] ?? 0),
        ];

        // =====================================================================
        // RENDER
        // =====================================================================
        $this->render('Dashboard/index_pelanggan', [
            'title'          => 'Dashboard Saya',
            'activeMenu'     => 'dashboard',
            'user'           => $user,
            'flash'          => $this->getFlash(),
            'pelanggan'      => $pelanggan ?? [],
            'paket'          => $paket,
            'statusInternet' => $statusInternet,
            'usageToday'     => $usageToday,
            'usageMonth'     => $usageMonth,
            'uptime'         => $uptime,
            'isOnline'       => $isOnline,
            'lastSeen'       => $lastSeen,
            'ipAddress'      => $ipAddress,
            'tagihan'        => $tagihan,
            'riwayat'        => $riwayat,
            'pengaduan'      => $pengaduan,
            'stats'          => $stats,
        ]);
    }

    // =========================================================================
    // API ENDPOINTS
    // =========================================================================

    public function bandwidthTotal(): void
    {
        Auth::roleGuard(['admin']);
        header('Content-Type: application/json');
        $service = new MikrotikService();
        echo json_encode($service->getTotalBandwidth());
        exit;
    }

    public function bandwidth(): void
    {
        Auth::roleGuard(['admin']);
        header('Content-Type: application/json');

        try {
            $mikrotik = new \Core\Mikrotik();
            $interfaces = $mikrotik->getInterfaces();

            $result = [];
            foreach ($interfaces as $iface) {
                $result[] = [
                    'name'    => $iface['name'] ?? 'unknown',
                    'rx'      => (int)($iface['rx-byte'] ?? 0),
                    'tx'      => (int)($iface['tx-byte'] ?? 0),
                    'rx-rate' => (int)($iface['rx-bits-per-second'] ?? 0),
                    'tx-rate' => (int)($iface['tx-bits-per-second'] ?? 0),
                ];
            }

            echo json_encode([
                'success'   => true,
                'data'      => $result,
                'timestamp' => time()
            ]);
        } catch (\Throwable $e) {
            echo json_encode([
                'success' => false,
                'error'   => $e->getMessage()
            ]);
        }
        exit;
    }

    public function pelangganUptime(int $id): void
    {
        header('Content-Type: application/json');

        $db   = Database::getConnection();
        $stmt = $db->prepare("SELECT mac_address FROM pelanggan WHERE id = ?");
        $stmt->execute([$id]);
        $pelanggan = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$pelanggan || empty($pelanggan['mac_address'])) {
            echo json_encode(['status' => 'offline', 'uptime' => 0, 'uptime_human' => '—', 'mode' => 'no_mac']);
            exit;
        }

        $service = new MikrotikService();
        echo json_encode($service->getUptimeByMac($pelanggan['mac_address']));
        exit;
    }

    public function pelangganBandwidth(int $id): void
    {
        header('Content-Type: application/json');

        $db   = Database::getConnection();
        $stmt = $db->prepare("SELECT mac_address FROM pelanggan WHERE id = ?");
        $stmt->execute([$id]);
        $pelanggan = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$pelanggan || empty($pelanggan['mac_address'])) {
            echo json_encode(['ok' => false, 'message' => 'MAC Address tidak ditemukan', 'mode' => 'no_mac']);
            exit;
        }

        $service = new MikrotikService();
        echo json_encode($service->getBandwidthByMac($pelanggan['mac_address']));
        exit;
    }
        // =========================================================================
    // DASHBOARD MODE & SETTINGS
    // =========================================================================

    /**
     * Switch mode dashboard  →  POST /dashboard/switch-mode
     */
    public function switchMode(): void
    {
        $mode = $_POST['mode'] ?? 'classic';
        if (!in_array($mode, ['classic', 'trade'], true)) {
            $mode = 'classic';
        }

        $_SESSION['dashboard_mode'] = $mode;

        // Simpan ke database (preferensi user)
        try {
            $user = Auth::user();
            $db = Database::getConnection();
            
            // Cek apakah kolom dashboard_mode ada
            $check = $db->query("SHOW COLUMNS FROM users LIKE 'dashboard_mode'")->fetch();
            if ($check) {
                $stmt = $db->prepare("UPDATE users SET dashboard_mode = ? WHERE id = ?");
                $stmt->execute([$mode, $user['id']]);
            } else {
                // Fallback: simpan di session saja
                $_SESSION['dashboard_mode'] = $mode;
            }
        } catch (\Throwable $e) {
            error_log("[Dashboard] switchMode error: " . $e->getMessage());
        }

        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'mode' => $mode]);
        exit;
    }

    /**
     * Simpan pengaturan layout  →  POST /dashboard/settings
     */
    public function saveSettings(): void
    {
        $settings = [
            'layout'       => $_POST['layout']       ?? 'comfortable', // compact | comfortable
            'sidebar'      => $_POST['sidebar']      ?? 'expanded',    // collapsed | expanded
            'auto_refresh' => (int)($_POST['auto_refresh'] ?? 0),      // 0 = off, else seconds
            'widgets'      => $_POST['widgets']      ?? 'revenue,bandwidth,growth,paket,status,pengaduan,pembayaran,pengaduan_table',
        ];

        $_SESSION['dashboard_settings'] = $settings;

        // Simpan ke database
        try {
            $user = Auth::user();
            $db = Database::getConnection();
            $check = $db->query("SHOW COLUMNS FROM users LIKE 'dashboard_settings'")->fetch();
            if ($check) {
                $stmt = $db->prepare("UPDATE users SET dashboard_settings = ? WHERE id = ?");
                $stmt->execute([json_encode($settings), $user['id']]);
            }
        } catch (\Throwable $e) {
            error_log("[Dashboard] saveSettings error: " . $e->getMessage());
        }

        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'settings' => $settings]);
        exit;
    }

    /**
     * Helper: ambil preferensi user (mode + settings)
     */
    private function getUserPreferences(): array
    {
        $user = Auth::user();
        $mode = $_SESSION['dashboard_mode'] ?? 'classic';
        $settings = $_SESSION['dashboard_settings'] ?? [
            'layout'       => 'comfortable',
            'sidebar'      => 'expanded',
            'auto_refresh' => 0,
            'widgets'      => 'revenue,bandwidth,growth,paket,status,pengaduan,pembayaran,pengaduan_table',
        ];

        // Coba load dari database
        try {
            $db = Database::getConnection();
            
            $check = $db->query("SHOW COLUMNS FROM users LIKE 'dashboard_mode'")->fetch();
            if ($check) {
                $row = $db->prepare("SELECT dashboard_mode, dashboard_settings FROM users WHERE id = ?");
                $row->execute([$user['id']]);
                $data = $row->fetch(\PDO::FETCH_ASSOC);
                
                if (!empty($data['dashboard_mode'])) {
                    $mode = $data['dashboard_mode'];
                    $_SESSION['dashboard_mode'] = $mode;
                }
                if (!empty($data['dashboard_settings'])) {
                    $settings = json_decode($data['dashboard_settings'], true) ?: $settings;
                    $_SESSION['dashboard_settings'] = $settings;
                }
            }
        } catch (\Throwable $e) {
            // ignore
        }

        return [
            'mode'     => $mode,
            'settings' => $settings,
        ];
    }

}
