<?php
/**
 * controller/Master/DashboardController.php
 */
declare(strict_types=1);

namespace Controller\Master;

use Controller\BaseController;
use Core\Auth;
use Core\Database;
use Model\PelangganModel;
use Model\TagihanModel;
use Model\KasModel;
use Model\PengaduanModel;
use Model\ODPModel;
use Model\PaketModel;
use Service\MikrotikService;

class DashboardController extends BaseController
{
    public function index(): void
    {
        $user = Auth::user();
        $role = $user['role'] ?? 'pelanggan';

        match ($role) {
            'admin'   => $this->renderAdmin($user),
            'teknisi' => $this->renderTeknisi($user),
            'kasir'   => $this->renderKasir($user),
            default   => $this->renderPelanggan($user),
        };
    }

    // =========================================================================
    // ADMIN
    // =========================================================================
    private function renderAdmin(array $user): void
    {
        $pelangganM = new PelangganModel();
        $tagihanM   = new TagihanModel();
        $kasM       = new KasModel();
        $pengaduanM = new PengaduanModel();
        $odpM       = new ODPModel();
        $paketM     = new PaketModel();

        $stats = [
            'total_pelanggan'      => $pelangganM->count(),
            'pelanggan_baru_bulan' => $pelangganM->countBaruBulanIni(),
            'tagihan_paid'         => $tagihanM->countPaid(),
            'tagihan_unpaid'       => $tagihanM->countUnpaid(),
            'pendapatan_bulan'     => $tagihanM->totalPendapatanBulanIni(),
            'piutang'              => $tagihanM->totalPiutang(),
            'tiket_open'           => $pengaduanM->countOpen(),
            'tiket_proses'         => $pengaduanM->countProses(),
            'kas_masuk'            => $kasM->getTotalMasukBulanIni(),
            'kas_keluar'           => $kasM->getTotalKeluarBulanIni(),
            'odp_aktif'            => $odpM->countAktif(),
            'odp_total'            => $odpM->count(),
        ];

        $rekap     = $tagihanM->getRekapPendapatanBulanan(12);
        $chartData = [
            'labels'     => array_column($rekap, 'bulan'),
            'pendapatan' => array_column($rekap, 'paid'),
            'unpaid'     => array_column($rekap, 'unpaid'),
        ];

        $this->render('Dashboard/index_admin', [
            'title'         => 'Dashboard Admin',
            'activeMenu'    => 'dashboard',
            'user'          => $user,
            'flash'         => $this->getFlash(),
            'stats'         => $stats,
            'chartData'     => $chartData,
            'topPaket'      => $paketM->getDistribusiPelanggan(),
            'recentTagihan' => $tagihanM->getRecent(10),
            'ticketOpen'    => $pengaduanM->getOpenDanProses(10),
        ]);
    }

    // =========================================================================
    // TEKNISI
    // =========================================================================
    private function renderTeknisi(array $user): void
    {
        $pengaduanM = new PengaduanModel();
        $odpM       = new ODPModel();
        $pelangganM = new PelangganModel();

        $stats = [
            'tiket_open'      => $pengaduanM->countOpen(),
            'tiket_proses'    => $pengaduanM->countProses(),
            'odp_aktif'       => $odpM->countAktif(),
            'odp_total'       => $odpM->count(),
            'total_pelanggan' => $pelangganM->count(),
        ];

        $this->render('Dashboard/index_teknisi', [
            'title'      => 'Dashboard Teknisi',
            'activeMenu' => 'dashboard',
            'user'       => $user,
            'flash'      => $this->getFlash(),
            'stats'      => $stats,
            'ticketOpen' => $pengaduanM->getOpenDanProses(15),
        ]);
    }

    // =========================================================================
    // KASIR
    // =========================================================================
    private function renderKasir(array $user): void
    {
        $tagihanM = new TagihanModel();
        $kasM     = new KasModel();

        $rekap     = $tagihanM->getRekapPendapatanBulanan(12);
        $chartData = [
            'labels'     => array_column($rekap, 'bulan'),
            'pendapatan' => array_column($rekap, 'paid'),
            'unpaid'     => array_column($rekap, 'unpaid'),
        ];

        $stats = [
            'tagihan_paid'     => $tagihanM->countPaid(),
            'tagihan_unpaid'   => $tagihanM->countUnpaid(),
            'pendapatan_bulan' => $tagihanM->totalPendapatanBulanIni(),
            'piutang'          => $tagihanM->totalPiutang(),
            'kas_masuk'        => $kasM->getTotalMasukBulanIni(),
            'kas_keluar'       => $kasM->getTotalKeluarBulanIni(),
        ];

        $this->render('Dashboard/index_kasir', [
            'title'         => 'Dashboard Kasir',
            'activeMenu'    => 'dashboard',
            'user'          => $user,
            'flash'         => $this->getFlash(),
            'stats'         => $stats,
            'chartData'     => $chartData,
            'recentTagihan' => $tagihanM->getRecent(15),
        ]);
    }

    // =========================================================================
    // PELANGGAN
    // =========================================================================
    private function renderPelanggan(array $user): void
    {
        $tagihanM   = new TagihanModel();
        $pengaduanM = new PengaduanModel();

        $pelangganId = $user['pelanggan_id'] ?? null;

        $this->render('Dashboard/index_pelanggan', [
            'title'      => 'Dashboard',
            'activeMenu' => 'dashboard',
            'user'       => $user,
            'flash'      => $this->getFlash(),
            'tagihan'    => $pelangganId ? $tagihanM->getByPelanggan($pelangganId, 5) : [],
            'tiket'      => $pelangganId ? $pengaduanM->getByPelanggan($pelangganId, 5) : [],
        ]);
    }

    // =========================================================================
    // API ENDPOINTS — DUMMY MIKROTIK SERVER
    // =========================================================================

    /**
     * API: Total bandwidth semua router (AJAX dari dashboard)
     * Route: GET /dashboard/bandwidth-total
     */
    public function bandwidthTotal(): void
    {
        Auth::roleGuard(['admin']);
        header('Content-Type: application/json');

        $service = new MikrotikService();
        echo json_encode($service->getTotalBandwidth());
        exit;
    }

    /**
     * API: Uptime pelanggan berdasarkan ID (AJAX dari show.php)
     * Route: GET /pelanggan/{id}/uptime
     */
    public function pelangganUptime(int $id): void
    {
        header('Content-Type: application/json');

        $db   = Database::getInstance();
        $stmt = $db->prepare("SELECT mac_address FROM pelanggan WHERE id = ? AND deleted_at IS NULL");
        $stmt->execute([$id]);
        $pelanggan = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$pelanggan || empty($pelanggan['mac_address'])) {
            echo json_encode([
                'status'       => 'offline',
                'uptime'       => 0,
                'uptime_human' => '—',
                'mode'         => 'no_mac',
            ]);
            exit;
        }

        $service = new MikrotikService();
        echo json_encode($service->getUptimeByMac($pelanggan['mac_address']));
        exit;
    }

    /**
     * API: Bandwidth pelanggan berdasarkan ID (AJAX polling 3 detik)
     * Route: GET /pelanggan/{id}/bandwidth
     */
    public function pelangganBandwidth(int $id): void
    {
        header('Content-Type: application/json');

        $db   = Database::getInstance();
        $stmt = $db->prepare("SELECT mac_address FROM pelanggan WHERE id = ? AND deleted_at IS NULL");
        $stmt->execute([$id]);
        $pelanggan = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$pelanggan || empty($pelanggan['mac_address'])) {
            echo json_encode([
                'ok'      => false,
                'message' => 'MAC Address tidak ditemukan',
                'mode'    => 'no_mac',
            ]);
            exit;
        }

        $service = new MikrotikService();
        echo json_encode($service->getBandwidthByMac($pelanggan['mac_address']));
        exit;
    }
}
