<?php
/**
 * controller/Master/PelangganController.php
 * ✅ FULL FIXED: ENUM konsisten (pending, aktif, isolir, nonaktif)
 * ✅ Sinkron dengan sidebar & dashboard controller
 * ✅ Catch \Throwable + tampil error asli untuk debug
 */

declare(strict_types=1);

namespace Controller\Master;

use Controller\BaseController;
use Core\Auth;
use Core\Logger;
use Config\Database;
use Model\PelangganModel;
use Model\PaketModel;
use Model\ODPModel;
use Model\UserModel;
use Model\AuditLogModel;
use PDO;

class PelangganController extends BaseController
{
    private PelangganModel $model;
    private PaketModel     $paket;
    private ODPModel       $odp;
    private AuditLogModel  $audit;
    private PDO            $db;

    public function __construct()
    {
        $this->db    = Database::getConnection();
        $this->model = new PelangganModel();
        $this->paket = new PaketModel();
        $this->odp   = new ODPModel();
        $this->audit = new AuditLogModel();
    }

    // =========================================================================
    // CRUD
    // =========================================================================

    public function index(): void
    {
        Auth::roleGuard(['admin','teknisi' ,'kasir']);
        $this->render('Pelanggan/index', [
            'title'      => 'Data Pelanggan',
            'activeMenu' => 'pelanggan',
            'list'       => $this->model->getAll(),
            'flash'      => $this->getFlash(),
        ]);
    }

    public function create(): void
    {
        Auth::roleGuard(['admin','teknisi' ,'kasir']);
        $this->render('Pelanggan/create', [
            'title'      => 'Tambah Pelanggan',
            'activeMenu' => 'pelanggan',
            'pakets'     => $this->paket->getAll(),
            'odps'       => $this->odp->getAll(),
            'flash'      => $this->getFlash(),
        ]);
    }

    public function store(): void
    {
        Auth::roleGuard(['admin','teknisi' ,'kasir']);
        $this->verifyCsrf();

        $input = $this->requestBody();

        $errors = [];
        if (empty($input['username']))     $errors[] = 'Username wajib diisi.';
        if (empty($input['password']))     $errors[] = 'Password wajib diisi.';
        if (empty($input['nama_lengkap'])) $errors[] = 'Nama lengkap wajib diisi.';
        if (empty($input['no_telp']))      $errors[] = 'No. telepon wajib diisi.';
        if (empty($input['alamat']))       $errors[] = 'Alamat wajib diisi.';

        if ($errors) {
            $this->render('Pelanggan/create', [
                'title'  => 'Tambah Pelanggan',
                'errors' => $errors,
                'old'    => $input,
                'pakets' => $this->paket->getAll(),
                'odps'   => $this->odp->getAll(),
            ]);
            return;
        }

        $userModel = new UserModel();
        if ($userModel->isUsernameTaken($input['username'])) {
            $this->render('Pelanggan/create', [
                'title'  => 'Tambah Pelanggan',
                'errors' => ['Username sudah digunakan.'],
                'old'    => $input,
                'pakets' => $this->paket->getAll(),
                'odps'   => $this->odp->getAll(),
            ]);
            return;
        }

        $lat = $input['latitude'] ?? null;
        $lng = $input['longitude'] ?? null;
        if (!empty($input['koordinat'])) {
            $parts = explode(',', $input['koordinat']);
            if (count($parts) === 2) {
                $lat = trim($parts[0]);
                $lng = trim($parts[1]);
            }
        }

        $userId = $userModel->create([
            'username' => $input['username'],
            'password' => Auth::hashPassword($input['password']),
            'role'     => 'pelanggan',
            'status'   => 'active', // ✅ Ini untuk tabel users, bukan pelanggan
        ]);

        $pelangganId = $this->model->create([
            'user_id'         => $userId,
            'nama_lengkap'    => $input['nama_lengkap'],
            'no_telp'         => $input['no_telp'],
            'alamat'          => $input['alamat'],
            'latitude'        => $lat,
            'longitude'       => $lng,
            'odp_id'          => (int)($input['odp_id'] ?? 0) ?: null,
            'mac_address'     => $input['mac_address'] ?: null,
            'paket_id'        => (int)$input['paket_id'],
            'tgl_jatuh_tempo' => (int)($input['tgl_jatuh_tempo'] ?? 5),
            'status_internet' => 'aktif', // ✅ FIX: 'active' → 'aktif'
        ]);

        $this->audit->log(Auth::id() ?? 0, "Tambah pelanggan #{$pelangganId} {$input['nama_lengkap']}");
        $this->setFlash('success', "Pelanggan \"{$input['nama_lengkap']}\" berhasil ditambahkan.");
        $this->redirectTo('/pelanggan');
    }

    public function show(string $id): void
    {
        $currentRole   = $_SESSION['user']['role'] ?? 'guest';
        $currentUserId = (int)($_SESSION['user']['id'] ?? 0);

        Auth::roleGuard(['admin', 'kasir', 'teknisi']);

        $data = $this->model->getDetail((int)$id);
        if (!$data) {
            http_response_code(404);
            die('Pelanggan tidak ditemukan.');
        }

        if ($currentRole === 'pelanggan') {
            $pelangganUserId = (int)($data['user_id'] ?? 0);
            if ($pelangganUserId !== $currentUserId) {
                http_response_code(403);
                die('Akses ditolak. Anda hanya bisa melihat profil sendiri.');
            }
        }

        $this->render('Pelanggan/show', [
            'title'      => 'Detail Pelanggan',
            'activeMenu' => 'pelanggan',
            'pelanggan'  => $data,
            'flash'      => $this->getFlash(),
        ]);
    }

    public function edit(string $id): void
    {
        Auth::roleGuard(['admin','teknisi' ,'kasir']);
        $data = $this->model->getDetail((int)$id);
        if (!$data) {
            http_response_code(404);
            die('Pelanggan tidak ditemukan.');
        }
        $this->render('Pelanggan/edit', [
            'title'     => 'Edit Pelanggan',
            'activeMenu' => 'pelanggan',
            'pelanggan' => $data,
            'pakets'    => $this->paket->getAll(),
            'odps'      => $this->odp->getAll(),
        ]);
    }

    public function update(string $id): void
    {
        Auth::roleGuard(['admin','teknisi' ,'kasir']);
        $this->verifyCsrf();

        $input = $this->requestBody();

        $lat = $input['latitude'] ?? null;
        $lng = $input['longitude'] ?? null;
        if (!empty($input['koordinat'])) {
            $parts = explode(',', $input['koordinat']);
            if (count($parts) === 2) {
                $lat = trim($parts[0]);
                $lng = trim($parts[1]);
            }
        }

        // ✅ FIX: Normalisasi status_internet
        $rawStatus = $input['status_internet'] ?? 'aktif';
        $statusInternet = $this->normalizeStatus($rawStatus);

        $this->model->edit((int)$id, [
            'nama_lengkap'    => $input['nama_lengkap'],
            'no_telp'         => $input['no_telp'],
            'alamat'          => $input['alamat'],
            'latitude'        => $lat,
            'longitude'       => $lng,
            'odp_id'          => (int)($input['odp_id'] ?? 0) ?: null,
            'mac_address'     => $input['mac_address'] ?: null,
            'paket_id'        => (int)$input['paket_id'],
            'tgl_jatuh_tempo' => (int)($input['tgl_jatuh_tempo'] ?? 5),
            'status_internet' => $statusInternet, // ✅ Sudah dinormalisasi
        ]);

        if (!empty($input['status_akun'])) {
            $pelanggan = $this->model->getDetail((int)$id);
            if (!empty($pelanggan['user_id'])) {
                $userModel = new UserModel();
                $userModel->setStatus((int)$pelanggan['user_id'], $input['status_akun']);
            }
        }

        if (!empty($input['password'])) {
            $pelanggan = $pelanggan ?? $this->model->getDetail((int)$id);
            if (!empty($pelanggan['user_id'])) {
                $userModel = $userModel ?? new UserModel();
                $userModel->resetPassword((int)$pelanggan['user_id'], Auth::hashPassword($input['password']));
            }
        }

        $this->audit->log(Auth::id() ?? 0, "Edit pelanggan #{$id}");
        $this->setFlash('success', 'Data pelanggan berhasil diperbarui.');
        $this->redirectTo('/pelanggan');
    }

    public function delete(string $id): void
    {
        Auth::roleGuard(['admin','teknisi' ,'kasir']);
        $this->verifyCsrf();

        $pelanggan = $this->model->getDetail((int)$id);

        if ($pelanggan) {
            $this->model->hapus((int)$id);

            if (!empty($pelanggan['user_id'])) {
                $userModel = new UserModel();
                $userModel->hapus((int)$pelanggan['user_id']);
            }

            $this->audit->log(Auth::id() ?? 0, "Hapus pelanggan #{$id} dan user terkait");
            $this->setFlash('success', 'Pelanggan dan akun user terkait berhasil dihapus.');
        } else {
            $this->setFlash('danger', 'Data pelanggan tidak ditemukan.');
        }

        $this->redirectTo('/pelanggan');
    }

    // =========================================================================
    // HELPER: Normalisasi Status
    // =========================================================================

    /**
     * Normalisasi status_internet ke nilai ENUM yang valid
     * ENUM: ('pending','aktif','isolir','nonaktif')
     */
    private function normalizeStatus(string $raw): string
    {
        $raw = trim(strtolower($raw));
        
        return match (true) {
            in_array($raw, ['aktif', 'active'], true) => 'aktif',
            in_array($raw, ['isolir', 'isolated', 'suspend', 'suspended'], true) => 'isolir',
            in_array($raw, ['nonaktif', 'inactive', 'non-aktif'], true) => 'nonaktif',
            in_array($raw, ['pending', 'menunggu'], true) => 'pending',
            default => 'aktif', // Fallback aman
        };
    }

    // =========================================================================
    // MIKROTIK API ENDPOINTS
    // =========================================================================

    public function uptimeApi(string $id): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $pelangganId = (int)$id;
        $mac = $this->getMacById($pelangganId);

        if (!$mac) {
            $this->json([
                'status'    => 'offline',
                'error'     => 'MAC address tidak ditemukan',
                'last_seen' => $this->getLastSeenFromDb($pelangganId),
                'ip'        => $this->getIpFromPelanggan($pelangganId),
                'source'    => 'no_mac',
            ]);
            return;
        }

        try {
            $mikrotik = $this->getMikrotikClient();
            $clients  = $mikrotik->getConnectedClients();
            $macUpper = strtoupper($mac);

            foreach ($clients as $client) {
                $clientMac = strtoupper($client['mac-address'] ?? $client['mac_address'] ?? '');
                if ($clientMac === $macUpper) {
                    $uptimeSec   = $this->parseUptimeString($client['uptime'] ?? '0s');
                    $connectedAt = date('Y-m-d H:i:s', time() - $uptimeSec);

                    $this->json([
                        'status'       => 'online',
                        'ip'           => $client['ip-address'] ?? $client['ip_address'] ?? '—',
                        'mac'          => $clientMac,
                        'uptime'       => $uptimeSec,
                        'uptime_human' => $this->formatUptime($uptimeSec),
                        'connected_at' => $connectedAt,
                        'signal'       => $client['signal'] ?? '—',
                        'interface'    => $client['interface'] ?? '—',
                        'mode'         => $client['source'] ?? 'dhcp',
                        'source'       => 'live',
                    ]);
                    return;
                }
            }
        } catch (\Throwable $e) {
            Logger::warning('PelangganController', "MikroTik error uptime({$pelangganId}): " . $e->getMessage());
        }

        $this->json([
            'status'    => 'offline',
            'last_seen' => $this->getLastSeenFromDb($pelangganId),
            'ip'        => $this->getIpFromPelanggan($pelangganId),
            'source'    => 'db_fallback',
        ]);
    }

    public function usageTodayApi(string $id): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $pelangganId = (int)$id;
        $mac = $this->getMacById($pelangganId);

        if (!$mac) {
            $data = $this->getUsageTodayFromDb($pelangganId);
            $data['source'] = 'db_no_mac';
            $this->json($data);
            return;
        }

        try {
            $mikrotik  = $this->getMikrotikClient();
            $todayData = $mikrotik->getClientUsageToday(strtoupper($mac));

            if (!empty($todayData['rx_bytes']) || !empty($todayData['tx_bytes'])) {
                $this->json([
                    'rx_bytes' => (int)($todayData['rx_bytes'] ?? 0),
                    'tx_bytes' => (int)($todayData['tx_bytes'] ?? 0),
                    'hourly'   => $todayData['hourly'] ?? [],
                    'source'   => 'live',
                ]);
                return;
            }
        } catch (\Throwable $e) {
            Logger::warning('PelangganController', "MikroTik error usageToday({$pelangganId}): " . $e->getMessage());
        }

        $data = $this->getUsageTodayFromDb($pelangganId);
        $data['source'] = 'db_fallback';
        $this->json($data);
    }

    public function usageMonthApi(string $id): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $pelangganId = (int)$id;
        $mac = $this->getMacById($pelangganId);

        if (!$mac) {
            $data = $this->getUsageMonthFromDb($pelangganId);
            $data['source'] = 'db_no_mac';
            $this->json($data);
            return;
        }

        try {
            $mikrotik  = $this->getMikrotikClient();
            $monthData = $mikrotik->getClientUsageMonth(strtoupper($mac));

            if (!empty($monthData['rx_bytes']) || !empty($monthData['tx_bytes'])) {
                $this->json([
                    'rx_bytes' => (int)($monthData['rx_bytes'] ?? 0),
                    'tx_bytes' => (int)($monthData['tx_bytes'] ?? 0),
                    'daily'    => $monthData['daily'] ?? [],
                    'source'   => 'live',
                ]);
                return;
            }
        } catch (\Throwable $e) {
            Logger::warning('PelangganController', "MikroTik error usageMonth({$pelangganId}): " . $e->getMessage());
        }

        $data = $this->getUsageMonthFromDb($pelangganId);
        $data['source'] = 'db_fallback';
        $this->json($data);
    }

    // =========================================================================
    // HELPER: MikroTik Client (lazy init)
    // =========================================================================

    private ?\Core\MikrotikClient $mikrotikInstance = null;

    private function getMikrotikClient(): \Core\MikrotikClient
    {
        if ($this->mikrotikInstance === null) {
            $this->mikrotikInstance = new \Core\MikrotikClient(
                $_ENV['MIKROTIK_URL']     ?? 'http://localhost:5000',
                $_ENV['MIKROTIK_USER']    ?? 'admin',
                $_ENV['MIKROTIK_PASS']    ?? 'admin123',
                (int)($_ENV['MIKROTIK_TIMEOUT'] ?? 10)
            );
        }
        return $this->mikrotikInstance;
    }

    // =========================================================================
    // HELPER: Database queries
    // =========================================================================

    private function getMacById(int $id): ?string
    {
        try {
            $stmt = $this->db->prepare("SELECT mac_address FROM pelanggan WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $mac = $stmt->fetchColumn();
            return ($mac && $mac !== '-') ? strtoupper(trim($mac)) : null;
        } catch (\Throwable) {
            return null;
        }
    }

    private function getLastSeenFromDb(int $pelangganId): ?string
    {
        try {
            $stmt = $this->db->prepare("
                SELECT snapshot_at 
                FROM usage_log 
                WHERE pelanggan_id = :id AND is_online = 1
                ORDER BY snapshot_at DESC 
                LIMIT 1
            ");
            $stmt->execute([':id' => $pelangganId]);
            $val = $stmt->fetchColumn();
            return $val ?: null;
        } catch (\Throwable) {
            return null;
        }
    }

    private function getIpFromPelanggan(int $pelangganId): ?string
    {
        try {
            $stmt = $this->db->prepare("
                SELECT ip_address FROM usage_log 
                WHERE pelanggan_id = :id AND is_online = 1
                ORDER BY snapshot_at DESC LIMIT 1
            ");
            $stmt->execute([':id' => $pelangganId]);
            $ip = $stmt->fetchColumn();
            if ($ip) return $ip;

            $stmt2 = $this->db->prepare("SELECT ip_address FROM pelanggan WHERE id = :id");
            $stmt2->execute([':id' => $pelangganId]);
            return $stmt2->fetchColumn() ?: null;
        } catch (\Throwable) {
            return null;
        }
    }

    private function getUsageTodayFromDb(int $pelangganId): array
    {
        $empty = ['rx_bytes' => 0, 'tx_bytes' => 0, 'hourly' => []];

        try {
            $stmt = $this->db->prepare("
                SELECT COALESCE(rx_bytes, 0) AS rx_bytes, COALESCE(tx_bytes, 0) AS tx_bytes
                FROM usage_daily_summary
                WHERE pelanggan_id = :id AND tanggal = CURDATE()
                LIMIT 1
            ");
            $stmt->execute([':id' => $pelangganId]);
            $daily = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$daily) {
                $stmt2 = $this->db->prepare("
                    SELECT MAX(rx_bytes) AS rx_bytes, MAX(tx_bytes) AS tx_bytes
                    FROM usage_log
                    WHERE pelanggan_id = :id AND DATE(snapshot_at) = CURDATE()
                ");
                $stmt2->execute([':id' => $pelangganId]);
                $daily = $stmt2->fetch(PDO::FETCH_ASSOC);
            }

            $rx = (int)($daily['rx_bytes'] ?? 0);
            $tx = (int)($daily['tx_bytes'] ?? 0);

            $hourlyStmt = $this->db->prepare("
                SELECT 
                    HOUR(snapshot_at) AS hour,
                    MAX(rx_bytes) AS rx_bytes,
                    MAX(tx_bytes) AS tx_bytes
                FROM usage_log
                WHERE pelanggan_id = :id AND DATE(snapshot_at) = CURDATE()
                GROUP BY HOUR(snapshot_at)
                ORDER BY hour ASC
            ");
            $hourlyStmt->execute([':id' => $pelangganId]);
            $hourlyRows = $hourlyStmt->fetchAll(PDO::FETCH_ASSOC);

            $hourlyMap = [];
            foreach ($hourlyRows as $row) {
                $hourlyMap[(int)$row['hour']] = $row;
            }

            $hourly = [];
            for ($h = 0; $h < 24; $h++) {
                if (isset($hourlyMap[$h])) {
                    $hourly[] = [
                        'hour'     => $h,
                        'rx_bytes' => (int)$hourlyMap[$h]['rx_bytes'],
                        'tx_bytes' => (int)$hourlyMap[$h]['tx_bytes'],
                    ];
                } else {
                    $hourly[] = ['hour' => $h, 'rx_bytes' => 0, 'tx_bytes' => 0];
                }
            }

            return ['rx_bytes' => $rx, 'tx_bytes' => $tx, 'hourly' => $hourly];

        } catch (\Throwable $e) {
            Logger::error('PelangganController', "getUsageTodayFromDb({$pelangganId}): " . $e->getMessage());
            return $empty;
        }
    }

    private function getUsageMonthFromDb(int $pelangganId): array
    {
        $empty = ['rx_bytes' => 0, 'tx_bytes' => 0, 'daily' => []];

        try {
            $ym = date('Y-m');

            $stmt = $this->db->prepare("
                SELECT COALESCE(total_rx_bytes, 0) AS rx_bytes, COALESCE(total_tx_bytes, 0) AS tx_bytes
                FROM usage_monthly_summary
                WHERE pelanggan_id = :id AND month_year = :ym
                LIMIT 1
            ");
            $stmt->execute([':id' => $pelangganId, ':ym' => $ym]);
            $monthly = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$monthly) {
                $stmt2 = $this->db->prepare("
                    SELECT 
                        COALESCE(SUM(rx_bytes), 0) AS rx_bytes,
                        COALESCE(SUM(tx_bytes), 0) AS tx_bytes
                    FROM usage_daily_summary
                    WHERE pelanggan_id = :id
                    AND YEAR(tanggal) = YEAR(CURDATE())
                    AND MONTH(tanggal) = MONTH(CURDATE())
                ");
                $stmt2->execute([':id' => $pelangganId]);
                $monthly = $stmt2->fetch(PDO::FETCH_ASSOC);
            }

            $rx = (int)($monthly['rx_bytes'] ?? 0);
            $tx = (int)($monthly['tx_bytes'] ?? 0);

            $dailyStmt = $this->db->prepare("
                SELECT 
                    tanggal AS date,
                    COALESCE(rx_bytes, 0) AS rx_bytes,
                    COALESCE(tx_bytes, 0) AS tx_bytes
                FROM usage_daily_summary
                WHERE pelanggan_id = :id
                AND YEAR(tanggal) = YEAR(CURDATE())
                AND MONTH(tanggal) = MONTH(CURDATE())
                ORDER BY tanggal ASC
            ");
            $dailyStmt->execute([':id' => $pelangganId]);
            $daily = $dailyStmt->fetchAll(PDO::FETCH_ASSOC);

            return ['rx_bytes' => $rx, 'tx_bytes' => $tx, 'daily' => $daily];

        } catch (\Throwable $e) {
            Logger::error('PelangganController', "getUsageMonthFromDb({$pelangganId}): " . $e->getMessage());
            return $empty;
        }
    }

    // =========================================================================
    // HELPER: Uptime parsing
    // =========================================================================

    private function parseUptimeString(string $uptime): int
    {
        $total = 0;
        if (preg_match('/(\d+)w/', $uptime, $m)) $total += (int)$m[1] * 604800;
        if (preg_match('/(\d+)d/', $uptime, $m)) $total += (int)$m[1] * 86400;
        if (preg_match('/(\d+)h/', $uptime, $m)) $total += (int)$m[1] * 3600;
        if (preg_match('/(\d+)m(?!s)/', $uptime, $m)) $total += (int)$m[1] * 60;
        if (preg_match('/(\d+)s/', $uptime, $m)) $total += (int)$m[1];
        if (preg_match('/(\d+):(\d+):(\d+)/', $uptime, $m)) {
            $total += (int)$m[1] * 3600 + (int)$m[2] * 60 + (int)$m[3];
        }
        return $total;
    }

    private function formatUptime(int $seconds): string
    {
        if ($seconds <= 0) return '0 detik';

        $weeks   = intdiv($seconds, 604800);
        $seconds %= 604800;
        $days    = intdiv($seconds, 86400);
        $seconds %= 86400;
        $hours   = intdiv($seconds, 3600);
        $seconds %= 3600;
        $minutes = intdiv($seconds, 60);

        $parts = [];
        if ($weeks > 0)   $parts[] = "{$weeks}m";
        if ($days > 0)    $parts[] = "{$days}h";
        if ($hours > 0)   $parts[] = "{$hours}j";
        if ($minutes > 0) $parts[] = "{$minutes}m";

        return implode(' ', $parts) ?: '0m';
    }

    // =========================================================================
    // IMPORT
    // =========================================================================

    public function importTemplate(): void
    {
        Auth::roleGuard(['admin']);

        $filename = 'template_import_pelanggan.csv';

        while (ob_get_level() > 0) ob_end_clean();

        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: no-cache, no-store, must-revalidate');

        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, [
            'nama_lengkap', 'username', 'password', 'no_telp',
            'alamat', 'paket_id', 'odp_id', 'tgl_jatuh_tempo',
        ], ';', '"', '');
        fputcsv($out, [
            'Budi Santoso', 'budi01', 'rahasia123', '08123456789',
            'Jl. Merdeka No. 10', '1', '1', '5',
        ], ';', '"', '');
        fclose($out);
        exit;
    }

    public function importProcess(): void
    {
        Auth::roleGuard(['admin']);
        $this->verifyCsrf();

        if (empty($_FILES['csv_file']['tmp_name'])) {
            $this->setFlash('danger', 'File CSV tidak ditemukan.');
            $this->redirectTo('/pelanggan');
            return;
        }

        $tmpPath = $_FILES['csv_file']['tmp_name'];

        $raw = file_get_contents($tmpPath);
        if (str_starts_with($raw, "\xEF\xBB\xBF")) {
            $raw = substr($raw, 3);
        }

        $firstLine = strtok($raw, "\n");
        $delim = substr_count($firstLine, ';') >= substr_count($firstLine, ',') ? ';' : ',';

        $lines  = array_filter(explode("\n", str_replace("\r\n", "\n", $raw)), fn($l) => trim($l) !== '');
        $lines  = array_values($lines);

        if (count($lines) < 2) {
            $this->setFlash('danger', 'File CSV kosong atau hanya berisi header.');
            $this->redirectTo('/pelanggan');
            return;
        }

        $header = str_getcsv(array_shift($lines), $delim, '"');
        $header = array_map(fn($h) => strtolower(trim($h)), $header);

        if (!in_array('nama_lengkap', $header) && !in_array('username', $header)) {
            $this->setFlash('danger', 'Format CSV tidak valid.');
            $this->redirectTo('/pelanggan');
            return;
        }

        $rows = [];
        foreach ($lines as $line) {
            $cols = str_getcsv($line, $delim, '"');
            if (count(array_filter($cols, fn($c) => trim($c) !== '')) === 0) continue;
            if (count($cols) !== count($header)) {
                $cols = array_pad(array_slice($cols, 0, count($header)), count($header), '');
            }
            $rows[] = array_combine($header, $cols);
        }

        if (empty($rows)) {
            $this->setFlash('danger', 'Tidak ada data dalam file CSV.');
            $this->redirectTo('/pelanggan');
            return;
        }

        $userModel = new UserModel();
        $result    = $this->model->importFromCsv($rows, $userModel);

        $this->audit->log(
            Auth::id() ?? 0,
            "Import pelanggan: {$result['imported']} berhasil, {$result['skipped']} dilewati"
        );

        $msg = "Import selesai: <strong>{$result['imported']} pelanggan</strong> berhasil diimpor";
        if ($result['skipped'] > 0) $msg .= ", {$result['skipped']} dilewati";
        if (!empty($result['errors'])) {
            $msg .= '. Detail: ' . implode(' | ', array_slice($result['errors'], 0, 5));
        }

        $type = $result['imported'] > 0 ? 'success' : 'danger';
        $this->setFlash($type, $msg);
        $this->redirectTo('/pelanggan');
    }

    // =========================================================================
    // EXPORT
    // =========================================================================

    public function exportExcel(): void
    {
        Auth::roleGuard(['admin', 'kasir']);

        $rows     = $this->model->getAll();
        $filename = 'pelanggan_' . date('Ymd_His') . '.csv';
        $tmpFile  = sys_get_temp_dir() . DIRECTORY_SEPARATOR . $filename;

        $out = fopen($tmpFile, 'w');
        fwrite($out, "\xEF\xBB\xBF");

        fputcsv($out, [
            'No', 'Nama Lengkap', 'Username', 'No. Telepon', 'Alamat',
            'Paket', 'Kecepatan', 'Harga (Rp)', 'MAC Address',
            'ODP', 'Tgl. Install', 'Jatuh Tempo', 'Koordinat (Lat,Lng)',
        ], ';', '"', '');

        foreach ($rows as $i => $row) {
            $lat       = $row['latitude']  ?? '';
            $lng       = $row['longitude'] ?? '';
            $koordinat = ($lat !== '' && $lng !== '') ? "{$lat},{$lng}" : '';

            fputcsv($out, [
                $i + 1,
                $row['nama_lengkap']    ?? '',
                $row['username']        ?? '',
                $row['no_telp']         ?? '',
                $row['alamat']          ?? '',
                $row['nama_paket']      ?? '',
                $row['kecepatan']       ?? '',
                $row['harga']           ?? '',
                $row['mac_address']     ?? '',
                $row['nama_odp']        ?? '',
                $row['tgl_install']     ?? '',
                $row['tgl_jatuh_tempo'] ?? '',
                $koordinat,
            ], ';', '"', '');
        }

        fclose($out);

        while (ob_get_level() > 0) ob_end_clean();

        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($tmpFile));
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');

        readfile($tmpFile);
        unlink($tmpFile);
        exit;
    }

    // =========================================================================
    // PENDAFTARAN PELANGGAN (PUBLIK)
    // =========================================================================

    public function pendaftaran(): void
    {
        if (Auth::check()) {
            $this->redirectTo('/dashboard');
            return;
        }

        $pakets = $this->paket->getAll();

        $this->render('Auth/register', [
            'title'       => 'Daftar Layanan Internet',
            'pakets'      => $pakets,
            'old'         => $this->getOldInput(),
            'errors'      => $this->getFormErrors(),
            'errorFields' => $this->getErrorFields(),
            'success'     => false,
        ]);
    }

    public function storePendaftaran(): void
    {
        if (Auth::check()) {
            $this->redirectTo('/dashboard');
            return;
        }

        $this->verifyCsrf();

        $namaLengkap     = trim($_POST['nama_lengkap'] ?? '');
        $username        = trim(strtolower($_POST['username'] ?? ''));
        $noTelp          = trim($_POST['no_telp'] ?? '');
        $password        = $_POST['password'] ?? '';
        $passwordConfirm = $_POST['password_confirm'] ?? '';
        $alamat          = trim($_POST['alamat'] ?? '');
        $koordinat       = trim($_POST['koordinat'] ?? '');
        $catatan         = trim($_POST['catatan'] ?? '');
        $paketId         = (int)($_POST['paket_id'] ?? 0);
        $setuju          = isset($_POST['setuju']);

        $latitude  = null;
        $longitude = null;
        if (!empty($koordinat) && str_contains($koordinat, ',')) {
            $parts = array_map('trim', explode(',', $koordinat));
            if (count($parts) === 2 && is_numeric($parts[0]) && is_numeric($parts[1])) {
                $latitude  = (float)$parts[0];
                $longitude = (float)$parts[1];
            }
        }

        $old = [
            'nama_lengkap' => $namaLengkap,
            'username'     => $username,
            'no_telp'      => $noTelp,
            'alamat'       => $alamat,
            'koordinat'    => $koordinat,
            'catatan'      => $catatan,
            'paket_id'     => $paketId,
        ];

        $errors      = [];
        $errorFields = [];

        if (strlen($namaLengkap) < 3) {
            $errors[]      = 'Nama lengkap minimal 3 karakter.';
            $errorFields[] = 'nama_lengkap';
        }
        if (strlen($username) < 4) {
            $errors[]      = 'Username minimal 4 karakter.';
            $errorFields[] = 'username';
        } elseif (!preg_match('/^[a-z0-9._]+$/', $username)) {
            $errors[]      = 'Username hanya boleh huruf kecil, angka, titik, dan underscore.';
            $errorFields[] = 'username';
        }
        if (empty($noTelp)) {
            $errors[]      = 'No. WhatsApp wajib diisi.';
            $errorFields[] = 'no_telp';
        }
        if (strlen($password) < 6) {
            $errors[]      = 'Password minimal 6 karakter.';
            $errorFields[] = 'password';
        }
        if ($password !== $passwordConfirm) {
            $errors[] = 'Konfirmasi password tidak cocok.';
        }
        if (empty($alamat)) {
            $errors[]      = 'Alamat wajib diisi.';
            $errorFields[] = 'alamat';
        }
        if ($paketId <= 0) {
            $errors[] = 'Pilih paket internet terlebih dahulu.';
        }
        if (!$setuju) {
            $errors[] = 'Anda harus menyetujui syarat dan ketentuan.';
        }

        $userModel = new UserModel();

        if (empty($errors)) {
            if ($userModel->isUsernameTaken($username)) {
                $errors[]      = 'Username "' . htmlspecialchars($username) . '" sudah digunakan.';
                $errorFields[] = 'username';
            }
        }

        if (empty($errors)) {
            $paket = $this->paket->find($paketId);
            if (!$paket) {
                $errors[] = 'Paket yang dipilih tidak valid.';
            }
        }

        if (!empty($errors)) {
            $this->setOldInput($old);
            $this->setFormErrors($errors);
            $this->setErrorFields($errorFields);
            $this->redirectTo('/daftar');
            return;
        }

        try {
            $this->db->beginTransaction();

            $userId = $userModel->create([
                'username' => $username,
                'password' => Auth::hashPassword($password),
                'role'     => 'pelanggan',
                'status'   => 'active', // ✅ Ini untuk tabel users
            ]);

            if (!$userId) {
                throw new \RuntimeException('Gagal membuat akun user.');
            }

            $pelangganId = $this->model->create([
                'user_id'         => $userId,
                'nama_lengkap'    => $namaLengkap,
                'no_telp'         => $noTelp,
                'alamat'          => $alamat,
                'latitude'        => $latitude,
                'longitude'       => $longitude,
                'paket_id'        => $paketId,
                'tgl_jatuh_tempo' => 5,
                'status_internet' => 'pending', // ✅ Sudah benar
            ]);

            if (!$pelangganId) {
                throw new \RuntimeException('Gagal menyimpan data pelanggan.');
            }

            $this->db->commit();

            try {
                $this->audit->log($userId, "Pendaftaran online pelanggan #{$pelangganId} {$namaLengkap}");
            } catch (\Throwable) {
                // Audit log gagal bukan masalah besar
            }

            $this->clearOldInput();

            $this->render('Auth/register', [
                'title'              => 'Pendaftaran Berhasil',
                'success'            => true,
                'registeredName'     => $namaLengkap,
                'registeredUsername' => $username,
                'registeredTelp'     => $noTelp,
                'pakets'             => [],
                'old'                => [],
                'errors'             => [],
            ]);

        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            $errMsg = $e->getMessage();
            $errFile = basename($e->getFile()) . ':' . $e->getLine();
            error_log("Pendaftaran error: {$errMsg} in {$errFile}");

            $errors[] = "Error: {$errMsg}";
            $this->setOldInput($old);
            $this->setFormErrors($errors);
            $this->redirectTo('/daftar');
        }
    }

    public function cekUsername(): void
    {
        header('Content-Type: application/json');

        $username = trim(strtolower($_GET['u'] ?? ''));

        if (strlen($username) < 4) {
            echo json_encode(['available' => false, 'reason' => 'too_short']);
            return;
        }

        if (!preg_match('/^[a-z0-9._]+$/', $username)) {
            echo json_encode(['available' => false, 'reason' => 'invalid_chars']);
            return;
        }

        $userModel = new UserModel();
        $taken = $userModel->isUsernameTaken($username);
        echo json_encode(['available' => !$taken]);
    }

    // =========================================================================
    // DASHBOARD STATUS PELANGGAN (Admin/Kasir)
    // =========================================================================

    public function status(): void
    {
        Auth::roleGuard(['admin','teknisi' ,'kasir']);

        $filterStatus  = $_GET['status'] ?? 'all';
        $search        = trim($_GET['q'] ?? '');
        
        // ✅ FIX: Sesuaikan dengan ENUM database
        $allowedStatus = ['all', 'pending', 'aktif', 'isolir', 'nonaktif'];

        if (!in_array($filterStatus, $allowedStatus, true)) {
            $filterStatus = 'all';
        }

        $pelangganList = [];
        $totalAll      = 0;
        $countPending  = 0;
        $countAktif    = 0; // ✅ 'aktif' bukan 'active'
        $countIsolir   = 0;
        $countNonaktif = 0;
        $errorMsg      = '';

        try {
            $sql    = "SELECT p.id, p.nama_lengkap, p.no_telp, p.alamat,
                        p.status_internet, p.created_at,
                        u.username,
                        pk.nama_paket, pk.kecepatan, pk.harga
                       FROM pelanggan p
                       LEFT JOIN users u  ON p.user_id  = u.id
                       LEFT JOIN paket pk ON p.paket_id = pk.id";
            $where  = [];
            $params = [];

            if ($filterStatus !== 'all') {
                $where[]  = "p.status_internet = :status";
                $params[':status'] = $filterStatus;
            }

            if ($search !== '') {
                $where[]  = "(p.nama_lengkap LIKE :q OR u.username LIKE :q2 OR p.no_telp LIKE :q3)";
                $params[':q']  = "%{$search}%";
                $params[':q2'] = "%{$search}%";
                $params[':q3'] = "%{$search}%";
            }

            if (!empty($where)) {
                $sql .= " WHERE " . implode(' AND ', $where);
            }

            $sql .= " ORDER BY p.id DESC";

            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            $pelangganList = $stmt->fetchAll(PDO::FETCH_ASSOC);

        } catch (\Throwable $e) {
            $errorMsg = 'Query error: ' . $e->getMessage();
        }

        try {
            $stmt2 = $this->db->query("SELECT status_internet, COUNT(*) as total FROM pelanggan GROUP BY status_internet");
            $rows  = $stmt2->fetchAll(PDO::FETCH_ASSOC);

            foreach ($rows as $row) {
                $s = $row['status_internet'];
                $t = (int)$row['total'];
                switch ($s) {
                    case 'pending':  $countPending  = $t; break;
                    case 'aktif':    $countAktif    = $t; break; // ✅ 'aktif'
                    case 'isolir':   $countIsolir   = $t; break;
                    case 'nonaktif': $countNonaktif = $t; break;
                }
                $totalAll += $t;
            }
        } catch (\Throwable $e) {
            if (!$errorMsg) {
                $errorMsg = 'Count error: ' . $e->getMessage();
            }
        }

        if ($errorMsg) {
            $this->setFlash('danger', $errorMsg);
        }

        $this->render('Pelanggan/status', [
            'title'         => 'Status Pelanggan',
            'activeMenu'    => 'pelanggan/status',
            'pelangganList' => $pelangganList,
            'filterStatus'  => $filterStatus,
            'search'        => $search,
            'totalAll'      => $totalAll,
            'countPending'  => $countPending,
            'countAktif'    => $countAktif, // ✅ 'aktif'
            'countIsolir'   => $countIsolir,
            'countNonaktif' => $countNonaktif,
            'flash'         => $this->getFlash(),
        ]);
    }

    public function updateStatus(string $id): void
    {
        Auth::roleGuard(['admin','teknisi' ,'kasir']);
        $this->verifyCsrf();

        $pelangganId = (int)$id;
        $newStatus   = trim($_POST['status_internet'] ?? '');

        // ✅ FIX: Sesuaikan dengan ENUM database
        $allowed = ['pending', 'aktif', 'isolir', 'nonaktif'];

        if (!in_array($newStatus, $allowed, true)) {
            $this->setFlash('danger', 'Status tidak valid: "' . htmlspecialchars($newStatus) . '"');
            $this->redirectTo('/pelanggan/status');
            return;
        }

        $pelanggan = $this->model->getDetail($pelangganId);
        if (!$pelanggan) {
            $this->setFlash('danger', 'Data pelanggan tidak ditemukan.');
            $this->redirectTo('/pelanggan/status');
            return;
        }

        $oldStatus = $pelanggan['status_internet'];

        $this->model->edit($pelangganId, [
            'status_internet' => $newStatus,
        ]);

        $nama = $pelanggan['nama_lengkap'];
        $this->audit->log(
            Auth::id() ?? 0,
            "Ubah status pelanggan #{$pelangganId} ({$nama}): {$oldStatus} → {$newStatus}"
        );

        $this->setFlash('success', "Status <strong>{$nama}</strong> diubah: <em>{$oldStatus}</em> → <em>{$newStatus}</em>");
        $this->redirectTo('/pelanggan/status');
    }

    // =========================================================================
    // HELPER: Old Input & Error Storage (Session)
    // =========================================================================

    private function getOldInput(): array
    {
        return $_SESSION['_old_input'] ?? [];
    }

    private function setOldInput(array $data): void
    {
        $_SESSION['_old_input'] = $data;
    }

    private function clearOldInput(): void
    {
        unset($_SESSION['_old_input']);
    }

    private function getFormErrors(): array
    {
        $errors = $_SESSION['_form_errors'] ?? [];
        unset($_SESSION['_form_errors']);
        return $errors;
    }

    private function setFormErrors(array $errors): void
    {
        $_SESSION['_form_errors'] = $errors;
    }

    private function getErrorFields(): array
    {
        $fields = $_SESSION['_error_fields'] ?? [];
        unset($_SESSION['_error_fields']);
        return $fields;
    }

    private function setErrorFields(array $fields): void
    {
        $_SESSION['_error_fields'] = $fields;
    }
    
}
