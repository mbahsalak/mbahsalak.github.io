<?php

declare(strict_types=1);

namespace Controller\Layanan;

use Controller\BaseController;
use Core\Auth;
use Config\Database;

/**
 * Portal Pelanggan
 * ─────────────────────────────────────────────
 * Menu Sidebar       │ Route            │ activeMenu
 * ─────────────────────────────────────────────
 * Layanan Saya       │ /layanan-saya    │ layanan_saya
 * Tagihan            │ /tagihan         │ tagihan
 * Pembayaran         │ /pembayaran      │ pembayaran
 * Bantuan (Ticketing)│ /ticketing       │ ticketing
 */
class PelangganPortalController extends BaseController
{
    private ?int $pelangganId = null;
    private array $pelanggan = [];
    private array $paket = [];

    public function __construct()
    {
        Auth::roleGuard(['pelanggan']);
        $this->loadPelanggan();
    }

    // =========================================================================
    // PRIVATE HELPERS
    // =========================================================================

    /**
     * Load data pelanggan + paket berdasarkan user yang sedang login
     */
    private function loadPelanggan(): void
    {
        $user   = Auth::user();
        $userId = (int)($user['id'] ?? 0);

        try {
            $db = Database::getConnection();
            $stmt = $db->prepare("
                SELECT p.*, pk.nama_paket, pk.kecepatan, pk.harga
                FROM pelanggan p
                LEFT JOIN paket pk ON p.paket_id = pk.id
                WHERE p.user_id = ?
                LIMIT 1
            ");
            $stmt->execute([$userId]);
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);

            if ($row) {
                $this->pelangganId = (int)$row['id'];
                $this->pelanggan   = $row;
                $this->paket = [
                    'nama_paket' => $row['nama_paket'] ?? '-',
                    'kecepatan'  => $row['kecepatan']  ?? '10 Mbps',
                    'harga'      => $row['harga']      ?? 0,
                ];
            }
        } catch (\Throwable $e) {
            error_log("[Portal] loadPelanggan error: " . $e->getMessage());
        }
    }

    /**
     * Jalankan query aman, return array kosong jika error
     */
    private function safeQuery(string $sql, array $params = []): array
    {
        try {
            $db   = Database::getConnection();
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            error_log("[Portal] Query error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Parse uptime string dari MikroTik ke detik
     */
    private function parseUptime(string $raw): int
    {
        $uptime = 0;
        if (preg_match('/(\d+)w/', $raw, $m))  $uptime += (int)$m[1] * 604800;
        if (preg_match('/(\d+)d/', $raw, $m))  $uptime += (int)$m[1] * 86400;
        if (preg_match('/(\d+)h/', $raw, $m))  $uptime += (int)$m[1] * 3600;
        if (preg_match('/(\d+)m(?!s)/', $raw, $m)) $uptime += (int)$m[1] * 60;
        if (preg_match('/(\d+)s/', $raw, $m))  $uptime += (int)$m[1];
        if (preg_match('/(\d+):(\d+):(\d+)/', $raw, $m)) {
            $uptime = (int)$m[1] * 3600 + (int)$m[2] * 60 + (int)$m[3];
        }
        return $uptime;
    }

    // =========================================================================
    // 1. LAYANAN SAYA  →  GET /layanan-saya
    // =========================================================================
    public function layanan(): void
    {
        $usageToday = ['rx_bytes' => 0, 'tx_bytes' => 0];
        $usageMonth = ['rx_bytes' => 0, 'tx_bytes' => 0];
        $uptime     = 0;
        $isOnline   = false;
        $lastSeen   = null;
        $ipAddress  = '-';
        $mac        = $this->pelanggan['mac_address'] ?? null;

        // ── Coba ambil dari MikroTik API ──
        if ($this->pelangganId && $mac) {
            try {
                $mikrotik = new \Core\MikrotikClient(
                    $_ENV['MIKROTIK_URL']     ?? 'http://localhost:5000',
                    $_ENV['MIKROTIK_USER']    ?? 'admin',
                    $_ENV['MIKROTIK_PASS']    ?? 'admin123',
                    (int)($_ENV['MIKROTIK_TIMEOUT'] ?? 5)
                );

                // Cek online status
                $clients  = $mikrotik->getConnectedClients();
                $macUpper = strtoupper($mac);

                foreach ($clients as $client) {
                    $clientMac = strtoupper($client['mac-address'] ?? $client['mac_address'] ?? '');
                    if ($clientMac === $macUpper) {
                        $isOnline  = true;
                        $ipAddress = $client['ip-address'] ?? $client['ip_address'] ?? '-';
                        $uptime    = $this->parseUptime($client['uptime'] ?? '0s');
                        break;
                    }
                }

                // Usage today
                $todayData = $mikrotik->getClientUsageToday(strtoupper($mac));
                if (!empty($todayData['rx_bytes']) || !empty($todayData['tx_bytes'])) {
                    $usageToday = [
                        'rx_bytes' => (int)($todayData['rx_bytes'] ?? 0),
                        'tx_bytes' => (int)($todayData['tx_bytes'] ?? 0),
                    ];
                }

                // Usage month
                $monthData = $mikrotik->getClientUsageMonth(strtoupper($mac));
                if (!empty($monthData['rx_bytes']) || !empty($monthData['tx_bytes'])) {
                    $usageMonth = [
                        'rx_bytes' => (int)($monthData['rx_bytes'] ?? 0),
                        'tx_bytes' => (int)($monthData['tx_bytes'] ?? 0),
                    ];
                }
            } catch (\Throwable $e) {
                error_log("[Portal] MikroTik error: " . $e->getMessage());
            }
        }

        // ── Fallback: last seen dari database ──
        if ($this->pelangganId && !$isOnline) {
            $lastSeenRow = $this->safeQuery("
                SELECT snapshot_at, ip_address 
                FROM usage_log 
                WHERE pelanggan_id = ? AND is_online = 1
                ORDER BY snapshot_at DESC 
                LIMIT 1
            ", [$this->pelangganId]);

            if (!empty($lastSeenRow)) {
                $lastSeen  = $lastSeenRow[0]['snapshot_at'] ?? null;
                $ipAddress = $lastSeenRow[0]['ip_address'] ?? '-';
            }
        }

        // ── Fallback: IP dari tabel pelanggan ──
        if ($ipAddress === '-' && !empty($this->pelanggan['ip_address'])) {
            $ipAddress = $this->pelanggan['ip_address'];
        }

        // ── Fallback: usage today dari database ──
        if ($usageToday['rx_bytes'] === 0 && $usageToday['tx_bytes'] === 0 && $this->pelangganId) {
            $todayDb = $this->safeQuery("
                SELECT COALESCE(rx_bytes, 0) AS rx_bytes, COALESCE(tx_bytes, 0) AS tx_bytes
                FROM usage_daily_summary
                WHERE pelanggan_id = ? AND tanggal = CURDATE()
                LIMIT 1
            ", [$this->pelangganId]);

            if (!empty($todayDb)) {
                $usageToday = [
                    'rx_bytes' => (int)($todayDb[0]['rx_bytes'] ?? 0),
                    'tx_bytes' => (int)($todayDb[0]['tx_bytes'] ?? 0),
                ];
            }

            // Fallback kedua: usage_log
            if ($usageToday['rx_bytes'] === 0 && $usageToday['tx_bytes'] === 0) {
                $todayLog = $this->safeQuery("
                    SELECT COALESCE(MAX(rx_bytes), 0) AS rx_bytes, COALESCE(MAX(tx_bytes), 0) AS tx_bytes
                    FROM usage_log
                    WHERE pelanggan_id = ? AND DATE(snapshot_at) = CURDATE()
                ", [$this->pelangganId]);

                if (!empty($todayLog)) {
                    $usageToday = [
                        'rx_bytes' => (int)($todayLog[0]['rx_bytes'] ?? 0),
                        'tx_bytes' => (int)($todayLog[0]['tx_bytes'] ?? 0),
                    ];
                }
            }
        }

        // ── Fallback: usage month dari database ──
        if ($usageMonth['rx_bytes'] === 0 && $usageMonth['tx_bytes'] === 0 && $this->pelangganId) {
            $monthDb = $this->safeQuery("
                SELECT COALESCE(SUM(rx_bytes), 0) AS rx_bytes, COALESCE(SUM(tx_bytes), 0) AS tx_bytes
                FROM usage_daily_summary
                WHERE pelanggan_id = ?
                AND YEAR(tanggal) = YEAR(CURDATE())
                AND MONTH(tanggal) = MONTH(CURDATE())
            ", [$this->pelangganId]);

            if (!empty($monthDb)) {
                $usageMonth = [
                    'rx_bytes' => (int)($monthDb[0]['rx_bytes'] ?? 0),
                    'tx_bytes' => (int)($monthDb[0]['tx_bytes'] ?? 0),
                ];
            }

            // Fallback kedua: usage_log
            if ($usageMonth['rx_bytes'] === 0 && $usageMonth['tx_bytes'] === 0) {
                $monthLog = $this->safeQuery("
                    SELECT COALESCE(SUM(rx_bytes), 0) AS rx_bytes, COALESCE(SUM(tx_bytes), 0) AS tx_bytes
                    FROM usage_log
                    WHERE pelanggan_id = ?
                    AND YEAR(snapshot_at) = YEAR(CURDATE())
                    AND MONTH(snapshot_at) = MONTH(CURDATE())
                ", [$this->pelangganId]);

                if (!empty($monthLog)) {
                    $usageMonth = [
                        'rx_bytes' => (int)($monthLog[0]['rx_bytes'] ?? 0),
                        'tx_bytes' => (int)($monthLog[0]['tx_bytes'] ?? 0),
                    ];
                }
            }
        }

        $this->render('Portal/layanan', [
            'title'      => 'Layanan Saya',
            'activeMenu' => 'layanan_saya',
            'user'       => Auth::user(),
            'flash'      => $this->getFlash(),
            'pelanggan'  => $this->pelanggan,
            'paket'      => $this->paket,
            'isOnline'   => $isOnline,
            'uptime'     => $uptime,
            'lastSeen'   => $lastSeen,
            'ipAddress'  => $ipAddress,
            'usageToday' => $usageToday,
            'usageMonth' => $usageMonth,
        ]);
    }

    // =========================================================================
    // 2. TAGIHAN  →  GET /tagihan
    // =========================================================================
    public function tagihan(): void
    {
        // Tagihan belum dibayar
        $tagihan = $this->safeQuery("
            SELECT t.id, t.periode_bulan AS periode, t.status,
                   t.tipe, t.deskripsi, t.jatuh_tempo, t.total,
                   t.created_at
            FROM tagihan t
            WHERE t.pelanggan_id = ? AND t.status = 'unpaid'
            ORDER BY t.jatuh_tempo ASC
        ", [$this->pelangganId]);

        // 5 pembayaran terbaru (sudah lunas)
        $riwayatBaru = $this->safeQuery("
            SELECT t.id, t.periode_bulan AS periode, t.total,
                   t.tgl_bayar, t.metode_pembayaran AS metode, t.tipe
            FROM tagihan t
            WHERE t.pelanggan_id = ? AND t.status = 'paid'
            ORDER BY t.tgl_bayar DESC
            LIMIT 5
        ", [$this->pelangganId]);

        $totalTunggakan = array_sum(array_column($tagihan, 'total'));

        $this->render('Portal/tagihan', [
            'title'          => 'Tagihan Saya',
            'activeMenu'     => 'tagihan',
            'user'           => Auth::user(),
            'flash'          => $this->getFlash(),
            'pelanggan'      => $this->pelanggan,
            'paket'          => $this->paket,
            'tagihan'        => $tagihan,
            'riwayatBaru'    => $riwayatBaru,
            'totalTunggakan' => $totalTunggakan,
        ]);
    }

    // =========================================================================
    // 3. PEMBAYARAN  →  GET /pembayaran
    // =========================================================================
    public function pembayaran(): void
    {
        $filterBulan  = $_GET['bulan']  ?? '';
        $filterMetode = $_GET['metode'] ?? '';

        $where  = "WHERE t.pelanggan_id = ? AND t.status = 'paid'";
        $params = [$this->pelangganId];

        if ($filterBulan && preg_match('/^\d{4}-\d{2}$/', $filterBulan)) {
            $where   .= " AND DATE_FORMAT(t.tgl_bayar, '%Y-%m') = ?";
            $params[] = $filterBulan;
        }

        if ($filterMetode) {
            $where   .= " AND t.metode_pembayaran = ?";
            $params[] = $filterMetode;
        }

        $riwayat = $this->safeQuery("
            SELECT t.id, t.periode_bulan AS periode, t.total,
                   t.tgl_bayar, t.metode_pembayaran AS metode,
                   t.penerima, t.tipe, t.deskripsi
            FROM tagihan t
            {$where}
            ORDER BY t.tgl_bayar DESC
            LIMIT 100
        ", $params);

        $totalBayar = array_sum(array_column($riwayat, 'total'));

        // List metode pembayaran unik (untuk dropdown filter)
        $metodeList = $this->safeQuery("
            SELECT DISTINCT metode_pembayaran 
            FROM tagihan
            WHERE pelanggan_id = ? AND status = 'paid' AND metode_pembayaran IS NOT NULL
            ORDER BY metode_pembayaran
        ", [$this->pelangganId]);

        $this->render('Portal/pembayaran', [
            'title'        => 'Riwayat Pembayaran',
            'activeMenu'   => 'pembayaran',
            'user'         => Auth::user(),
            'flash'        => $this->getFlash(),
            'pelanggan'    => $this->pelanggan,
            'riwayat'      => $riwayat,
            'totalBayar'   => $totalBayar,
            'filterBulan'  => $filterBulan,
            'filterMetode' => $filterMetode,
            'metodeList'   => $metodeList,
        ]);
    }

    // =========================================================================
    // 4. BANTUAN / TICKETING  →  GET /ticketing
    // =========================================================================
    public function pengaduan(): void
    {
        $filterStatus = $_GET['status'] ?? 'all';

        $where  = "WHERE pg.pelanggan_id = ?";
        $params = [$this->pelangganId];

        if (in_array($filterStatus, ['open', 'proses', 'selesai'], true)) {
            $where   .= " AND pg.status = ?";
            $params[] = $filterStatus;
        }

        $pengaduan = $this->safeQuery("
            SELECT pg.id, pg.judul, pg.deskripsi, pg.status,
                   pg.latitude, pg.longitude,
                   pg.created_at, pg.updated_at
            FROM pengaduan pg
            {$where}
            ORDER BY pg.id DESC
            LIMIT 50
        ", $params);

        // Hitung statistik per status
        $statsAll = $this->safeQuery("
            SELECT status, COUNT(*) AS cnt
            FROM pengaduan
            WHERE pelanggan_id = ?
            GROUP BY status
        ", [$this->pelangganId]);

        $stats = ['all' => 0, 'open' => 0, 'proses' => 0, 'selesai' => 0];
        foreach ($statsAll as $row) {
            $stats[$row['status']] = (int)$row['cnt'];
            $stats['all'] += (int)$row['cnt'];
        }

        $this->render('Portal/pengaduan', [
            'title'        => 'Bantuan & Pengaduan',
            'activeMenu'   => 'ticketing',
            'user'         => Auth::user(),
            'flash'        => $this->getFlash(),
            'pelanggan'    => $this->pelanggan,
            'pengaduan'    => $pengaduan,
            'filterStatus' => $filterStatus,
            'stats'        => $stats,
        ]);
    }

        /**
     * Detail pengaduan  →  GET /ticketing/{id}
     * HANYA bisa diakses oleh pemilik pengaduan
     */
    public function pengaduanDetail(?string $id = null): void
    {
        // ── Ambil ID dari berbagai sumber ──
        $id = $id ?? $_GET['id'] ?? $this->getSegmentFromUri(2) ?? null;

        if (!$id || !ctype_digit((string)$id)) {
            $this->setFlash('danger', 'ID pengaduan tidak valid.');
            $this->redirectTo('/ticketing');
            return;
        }

        $id = (int)$id;
        $pelangganId = (int)($this->pelangganId ?? 0);

        // ── Pastikan pelanggan sudah terdaftar ──
        if ($pelangganId === 0) {
            $this->setFlash('danger', 'Data pelanggan tidak ditemukan.');
            $this->redirectTo('/ticketing');
            return;
        }

        // ── Query HANYA dengan pengecekan ownership ──
        $rows = $this->safeQuery("
            SELECT pg.* 
            FROM pengaduan pg
            WHERE pg.id = ? AND pg.pelanggan_id = ?
            LIMIT 1
        ", [$id, $pelangganId]);

        // ── Jika tidak ditemukan → blokir akses ──
        if (empty($rows)) {
            // Log percobaan akses pengaduan orang lain
            $user = Auth::user();
            error_log("[SECURITY] User {$user['id']} ({$user['username']}) mencoba akses pengaduan #{$id} milik pelanggan lain");
            
            $this->setFlash('danger', 'Pengaduan tidak ditemukan atau Anda tidak memiliki akses.');
            $this->redirectTo('/ticketing');
            return;
        }

        // ── Verifikasi ulang: pastikan pelanggan_id di data cocok ──
        if ((int)$rows[0]['pelanggan_id'] !== $pelangganId) {
            $user = Auth::user();
            error_log("[SECURITY] IDOR attempt: User {$user['id']} mencoba akses pengaduan pelanggan_id={$rows[0]['pelanggan_id']}");
            
            $this->setFlash('danger', 'Akses ditolak.');
            $this->redirectTo('/ticketing');
            return;
        }

        $this->render('Portal/pengaduan_detail', [
            'title'      => 'Detail Pengaduan',
            'activeMenu' => 'ticketing',
            'user'       => Auth::user(),
            'flash'      => $this->getFlash(),
            'pelanggan'  => $this->pelanggan,
            'data'       => $rows[0],
        ]);
    }



        /**
     * Form buat pengaduan  →  GET /ticketing/buat
     * Mendukung pre-fill via ?jenis=upgrade_paket
     */
    public function pengaduanBuat(): void
    {
        $jenis = $_GET['jenis'] ?? '';
        $old = [];

        // Pre-fill berdasarkan jenis permintaan
        if ($jenis === 'upgrade_paket') {
            $old = [
                'judul'     => 'Permintaan Upgrade Paket Internet',
                'deskripsi' => "Dengan hormat,\n\nSaya ingin mengajukan permintaan upgrade paket internet.\n\n"
                             . "Paket saat ini: " . ($this->paket['nama_paket'] ?? '-') . " (" . ($this->paket['kecepatan'] ?? '-') . ")\n"
                             . "Biaya saat ini: Rp " . number_format((float)($this->paket['harga'] ?? 0), 0, ',', '.') . "/bulan\n\n"
                             . "Paket yang diinginkan: \n"
                             . "Alasan upgrade: \n\n"
                             . "Mohon informasinya mengenai ketersediaan dan biaya paket baru.\n\n"
                             . "Terima kasih.",
                'kategori'  => 'upgrade_paket',
            ];
        } elseif ($jenis === 'perbaikan') {
            $old = [
                'judul'     => 'Permintaan Perbaikan Jaringan',
                'deskripsi' => "Dengan hormat,\n\nSaya mengalami masalah pada koneksi internet.\n\n"
                             . "Deskripsi masalah: \n"
                             . "Waktu mulai masalah: \n"
                             . "Dampak yang dirasakan: \n\n"
                             . "Mohon bantuannya untuk dilakukan perbaikan.\n\n"
                             . "Terima kasih.",
                'kategori'  => 'perbaikan',
            ];
        } elseif ($jenis === 'pemasangan') {
            $old = [
                'judul'     => 'Permintaan Pemasangan Baru',
                'deskripsi' => "Dengan hormat,\n\nSaya ingin mengajukan permintaan pemasangan internet baru.\n\n"
                             . "Alamat pemasangan: \n"
                             . "Paket yang diminati: \n"
                             . "No. HP yang bisa dihubungi: " . ($this->pelanggan['no_telp'] ?? '') . "\n\n"
                             . "Mohon informasinya.\n\nTerima kasih.",
                'kategori'  => 'pemasangan',
            ];
        }

        $this->render('Portal/pengaduan_buat', [
            'title'      => 'Buat Pengaduan',
            'activeMenu' => 'ticketing',
            'user'       => Auth::user(),
            'flash'      => $this->getFlash(),
            'pelanggan'  => $this->pelanggan,
            'paket'      => $this->paket,
            'errors'     => [],
            'old'        => $old,
            'jenis'      => $jenis,
        ]);
    }


    /**
     * Simpan pengaduan baru  →  POST /ticketing/store
     */
    public function pengaduanStore(): void
    {
        $this->verifyCsrf();

        $judul     = trim($_POST['judul'] ?? '');
        $deskripsi = trim($_POST['deskripsi'] ?? '');
        $latitude  = $_POST['latitude']  ?? null;
        $longitude = $_POST['longitude'] ?? null;

        // ── Validasi ──
        $errors = [];
        if (strlen($judul) < 5) {
            $errors[] = 'Judul minimal 5 karakter.';
        }
        if (strlen($deskripsi) < 10) {
            $errors[] = 'Deskripsi minimal 10 karakter.';
        }

        if (!empty($errors)) {
            $this->render('Portal/pengaduan_buat', [
                'title'      => 'Buat Pengaduan',
                'activeMenu' => 'ticketing',
                'user'       => Auth::user(),
                'pelanggan'  => $this->pelanggan,
                'errors'     => $errors,
                'old'        => $_POST,
            ]);
            return;
        }

        // ── Simpan ke database ──
        try {
            $db = Database::getConnection();
            $stmt = $db->prepare("
                INSERT INTO pengaduan 
                    (pelanggan_id, judul, deskripsi, status, latitude, longitude, created_at)
                VALUES (?, ?, ?, 'open', ?, ?, NOW())
            ");
            $stmt->execute([
                $this->pelangganId,
                $judul,
                $deskripsi,
                $latitude  ?: null,
                $longitude ?: null,
            ]);

            $this->setFlash('success', 'Pengaduan berhasil dikirim. Tim kami akan segera menindaklanjuti.');
            $this->redirectTo('/ticketing');
        } catch (\Throwable $e) {
            error_log("[Portal] pengaduanStore error: " . $e->getMessage());
            $this->setFlash('danger', 'Gagal mengirim pengaduan. Silakan coba lagi.');
            $this->redirectTo('/ticketing/buat');
        }
    }
}
