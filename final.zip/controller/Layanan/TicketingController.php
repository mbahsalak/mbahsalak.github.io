<?php
/**
 * controller/Layanan/TicketingController.php
 * ✅ Full support: lokasi maps (latitude & longitude)
 * ✅ Validasi koordinat
 * ✅ Support semua role: admin, teknisi, kasir, pelanggan
 * ✅ DELETE tiket (admin only)
 * ✅ Fix: admin access getAll() dengan enrichment data pelanggan
 */

declare(strict_types=1);

namespace Controller\Layanan;

use Controller\BaseController;
use Core\Auth;
use Model\PengaduanModel;
use Model\PelangganModel;
use Model\AuditLogModel;

class TicketingController extends BaseController
{
    private PengaduanModel $model;
    private AuditLogModel  $audit;

    public function __construct()
    {
        $this->model = new PengaduanModel();
        $this->audit = new AuditLogModel();
    }

    // =========================================================================
    // INDEX — Daftar semua tiket
    // =========================================================================

    /**
     * GET /ticketing
     * ✅ Menampilkan semua tiket dengan peta lokasi
     */
    public function index(): void
    {
        Auth::roleGuard(['admin', 'teknisi', 'kasir', 'pelanggan']);

        $user = Auth::user();
        $role = $user['role'] ?? 'pelanggan';

        if ($role === 'pelanggan') {
            // Pelanggan hanya lihat tiket miliknya
            $pelangganId = $user['pelanggan_id']
                ?? $this->findPelangganIdByUserId((int)($user['id'] ?? 0));

            $tickets = $pelangganId ? $this->model->getByPelanggan($pelangganId) : [];

            // Enrich dengan data pelanggan untuk konsistensi view
            $pelangganModel = new PelangganModel();
            $pelangganData  = $pelangganId ? $pelangganModel->getDetail($pelangganId) : null;

            $tickets = array_map(function ($t) use ($pelangganData) {
                $t['nama_lengkap'] = $pelangganData['nama_lengkap'] ?? '-';
                $t['no_telp']      = $pelangganData['no_telp']      ?? '-';
                $t['alamat']       = $pelangganData['alamat']        ?? '-';
                return $t;
            }, $tickets);
        } else {
            // Admin/Teknisi/Kasir lihat semua tiket
            // getAll() harus sudah JOIN ke pelanggan & paket
            $tickets = $this->model->getAll();

            // ✅ FIX: Fallback enrichment jika getAll() tidak JOIN pelanggan
            // Hapus blok ini jika PengaduanModel::getAll() sudah JOIN pelanggan & paket
            $pelangganModel = new PelangganModel();
            $tickets = array_map(function ($t) use ($pelangganModel) {
                if (empty($t['nama_lengkap']) && !empty($t['pelanggan_id'])) {
                    $pelangganData = $pelangganModel->getDetail((int)$t['pelanggan_id']);
                    $t['nama_lengkap'] = $pelangganData['nama_lengkap'] ?? '-';
                    $t['no_telp']      = $pelangganData['no_telp']      ?? '-';
                    $t['alamat']       = $pelangganData['alamat']        ?? '-';
                    $t['nama_paket']   = $t['nama_paket'] ?? ($pelangganData['nama_paket'] ?? null);
                }
                return $t;
            }, $tickets);
        }

        $this->render('Ticketing/index', [
            'title'      => 'Manajemen Tiket Pengaduan',
            'activeMenu' => 'ticketing',
            'user'       => $user,
            'flash'      => $this->getFlash(),
            'tickets'    => $tickets,
        ]);
    }

    // =========================================================================
    // CREATE — Form buat tiket
    // =========================================================================

    /**
     * GET /ticketing/buat
     * ✅ Form dengan maps picker
     */
    public function create(): void
    {
        Auth::roleGuard(['admin', 'teknisi', 'kasir', 'pelanggan']);

        $user = Auth::user();
        $role = $user['role'] ?? 'pelanggan';

        $pelangganModel = new PelangganModel();

        if ($role === 'pelanggan') {
            // Untuk pelanggan, otomatis set pelanggan_id sendiri
            $pelangganId = $user['pelanggan_id']
                ?? $this->findPelangganIdByUserId((int)($user['id'] ?? 0));
            $pelanggan = $pelangganId ? [$pelangganModel->getDetail($pelangganId)] : [];
            $pelanggan = array_filter($pelanggan);
        } else {
            // Admin/Teknisi/Kasir bisa pilih pelanggan
            $pelanggan = $pelangganModel->getAll();
        }

        $this->render('Ticketing/create', [
            'title'       => 'Buat Tiket Pengaduan',
            'activeMenu'  => 'ticketing',
            'user'        => $user,
            'pelanggan'   => $pelanggan,
            'flash'       => $this->getFlash(),
            'isPelanggan' => ($role === 'pelanggan'),
        ]);
    }

    // =========================================================================
    // STORE — Proses simpan tiket
    // =========================================================================

    /**
     * POST /ticketing/buat
     * ✅ Validasi koordinat & simpan lokasi
     */
    public function createTicket(): void
    {
        Auth::roleGuard(['admin', 'teknisi', 'kasir', 'pelanggan']);

        $this->verifyCsrf();
        $input = $this->requestBody();
        $user  = Auth::user();
        $role  = $user['role'] ?? 'pelanggan';

        // ✅ Untuk pelanggan, paksa pelanggan_id miliknya
        if ($role === 'pelanggan') {
            $pelangganId = $user['pelanggan_id']
                ?? $this->findPelangganIdByUserId((int)($user['id'] ?? 0));
            if (!$pelangganId) {
                $this->setFlash('error', 'Data pelanggan tidak ditemukan.');
                $this->redirectTo('/ticketing/buat');
                return;
            }
            $input['pelanggan_id'] = $pelangganId;
        }

        // ✅ Validasi input dasar
        $errors = [];
        if (empty($input['pelanggan_id'])) {
            $errors[] = 'Pelanggan harus dipilih.';
        }
        if (empty($input['judul']) || strlen(trim($input['judul'])) < 3) {
            $errors[] = 'Judul pengaduan minimal 3 karakter.';
        }
        if (empty($input['deskripsi']) || strlen(trim($input['deskripsi'])) < 10) {
            $errors[] = 'Deskripsi minimal 10 karakter.';
        }

        if (!empty($errors)) {
            $this->setFlash('error', implode(' ', $errors));
            $this->redirectTo('/ticketing/buat');
            return;
        }

        // ✅ Sanitasi & validasi koordinat
        $latitude  = $this->sanitizeCoordinate($input['latitude']  ?? null);
        $longitude = $this->sanitizeCoordinate($input['longitude'] ?? null);

        if ($latitude !== null && $longitude !== null) {
            if ($latitude < -90 || $latitude > 90) {
                $this->setFlash('error', 'Koordinat latitude tidak valid (harus -90 s/d 90).');
                $this->redirectTo('/ticketing/buat');
                return;
            }
            if ($longitude < -180 || $longitude > 180) {
                $this->setFlash('error', 'Koordinat longitude tidak valid (harus -180 s/d 180).');
                $this->redirectTo('/ticketing/buat');
                return;
            }
        }

        // ✅ Simpan tiket
        try {
            $id = $this->model->create([
                'pelanggan_id' => (int)$input['pelanggan_id'],
                'judul'        => $input['judul'],
                'deskripsi'    => $input['deskripsi'],
                'latitude'     => $latitude,
                'longitude'    => $longitude,
            ]);

            $this->audit->log(
                (int)($user['id'] ?? 0),
                "Buat tiket pengaduan #{$id}: {$input['judul']}"
            );

            $this->setFlash('success', "Tiket pengaduan #{$id} berhasil dibuat.");
        } catch (\InvalidArgumentException $e) {
            $this->setFlash('error', $e->getMessage());
        } catch (\Throwable $e) {
            error_log("[Ticketing] Create error: " . $e->getMessage());
            $this->setFlash('error', 'Gagal membuat tiket. Silakan coba lagi.');
        }

        $this->redirectTo('/ticketing');
    }

    // =========================================================================
    // SHOW — Detail tiket
    // =========================================================================

    /**
     * GET /ticketing/{id}
     * ✅ Menampilkan lokasi di peta
     */
    public function show(string $id): void
    {
        Auth::roleGuard(['admin', 'teknisi', 'kasir', 'pelanggan']);

        $ticket = $this->model->getDetail((int)$id);

        if (!$ticket) {
            http_response_code(404);
            $this->render('errors/404', [
                'title'   => 'Tiket Tidak Ditemukan',
                'message' => 'Tiket pengaduan yang Anda cari tidak ditemukan.',
            ]);
            return;
        }

        // ✅ Pelanggan hanya bisa lihat tiket miliknya
        $user = Auth::user();
        if (($user['role'] ?? '') === 'pelanggan') {
            $pelangganId = $user['pelanggan_id']
                ?? $this->findPelangganIdByUserId((int)($user['id'] ?? 0));
            if ((int)$ticket['pelanggan_id'] !== (int)$pelangganId) {
                http_response_code(403);
                die('Akses ditolak. Anda hanya bisa melihat tiket milik Anda.');
            }
        }

        $this->render('Ticketing/show', [
            'title'      => "Detail Tiket #{$id}",
            'activeMenu' => 'ticketing',
            'user'       => $user,
            'ticket'     => $ticket,
            'flash'      => $this->getFlash(),
        ]);
    }

    // =========================================================================
    // UPDATE STATUS
    // =========================================================================

    /**
     * POST /ticketing/update/{id}
     * ✅ Update status tiket (admin/teknisi only)
     */
    public function updateStatus(string $id): void
    {
        Auth::roleGuard(['admin', 'teknisi']);

        $this->verifyCsrf();

        $input  = $this->requestBody();
        $status = trim($input['status'] ?? '');

        $allowed = ['open', 'proses', 'selesai'];
        if (!in_array($status, $allowed, true)) {
            $this->setFlash('error', 'Status tidak valid. Pilih: open, proses, atau selesai.');
            $this->redirectTo("/ticketing/{$id}");
            return;
        }

        $ticket = $this->model->getDetail((int)$id);
        if (!$ticket) {
            $this->setFlash('error', 'Tiket tidak ditemukan.');
            $this->redirectTo('/ticketing');
            return;
        }

        $oldStatus = $ticket['status'];

        try {
            $this->model->updateStatus((int)$id, $status);

            $this->audit->log(
                Auth::id() ?? 0,
                "Update status tiket #{$id}: {$oldStatus} → {$status}"
            );

            $this->setFlash('success', "Status tiket #{$id} berhasil diubah: <em>{$oldStatus}</em> → <em>{$status}</em>");
        } catch (\Throwable $e) {
            error_log("[Ticketing] Update error: " . $e->getMessage());
            $this->setFlash('error', 'Gagal mengubah status tiket.');
        }

        $this->redirectTo("/ticketing/{$id}");
    }

    // =========================================================================
    // DELETE — Hapus tiket
    // =========================================================================

    /**
     * POST /ticketing/hapus/{id}
     * ✅ Hanya admin yang bisa hapus tiket
     */
    public function delete(string $id): void
    {
        Auth::roleGuard(['admin']);

        $this->verifyCsrf();

        $ticket = $this->model->getDetail((int)$id);
        if (!$ticket) {
            $this->setFlash('error', 'Tiket tidak ditemukan.');
            $this->redirectTo('/ticketing');
            return;
        }

        try {
            $this->model->delete((int)$id);

            $this->audit->log(
                Auth::id() ?? 0,
                "Hapus tiket #{$id}: {$ticket['judul']}"
            );

            $this->setFlash('success', "Tiket #{$id} \"{$ticket['judul']}\" berhasil dihapus.");
        } catch (\Throwable $e) {
            error_log("[Ticketing] Delete error: " . $e->getMessage());
            $this->setFlash('error', 'Gagal menghapus tiket. Silakan coba lagi.');
        }

        $this->redirectTo('/ticketing');
    }

    // =========================================================================
    // API: Ambil data tiket dengan lokasi (untuk AJAX/JSON)
    // =========================================================================

    /**
     * GET /ticketing/api/locations
     * ✅ Return JSON semua tiket yang punya koordinat
     */
    public function apiLocations(): void
    {
        Auth::roleGuard(['admin', 'teknisi', 'kasir']);

        header('Content-Type: application/json');

        try {
            $tickets = $this->model->getAllWithLocation();
            echo json_encode([
                'success' => true,
                'count'   => count($tickets),
                'data'    => $tickets,
            ]);
        } catch (\Throwable $e) {
            echo json_encode([
                'success' => false,
                'error'   => $e->getMessage(),
            ]);
        }
        exit;
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    /**
     * Cari pelanggan_id berdasarkan user_id
     */
    private function findPelangganIdByUserId(int $userId): ?int
    {
        if ($userId <= 0) return null;

        try {
            $db   = \Config\Database::getConnection();
            $stmt = $db->prepare("SELECT id FROM pelanggan WHERE user_id = :uid LIMIT 1");
            $stmt->execute(['uid' => $userId]);
            $result = $stmt->fetchColumn();
            return $result ? (int)$result : null;
        } catch (\Throwable) {
            return null;
        }
    }

    /**
     * Sanitasi koordinat
     */
    private function sanitizeCoordinate(mixed $value): ?float
    {
        if ($value === null || $value === '' || $value === false) {
            return null;
        }

        if (is_numeric($value)) {
            return (float)$value;
        }

        $clean = preg_replace('/[^0-9.\-]/', '', (string)$value);
        return is_numeric($clean) ? (float)$clean : null;
    }
}
