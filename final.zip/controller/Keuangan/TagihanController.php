<?php
/**
 * controller/Keuangan/TagihanController.php
 */

declare(strict_types=1);

namespace Controller\Keuangan;

use Controller\BaseController;
use Core\Auth;
use Model\TagihanModel;
use Model\PelangganModel;
use Model\SettingModel;
use Model\AuditLogModel;

class TagihanController extends BaseController
{
    private TagihanModel   $model;
    private PelangganModel $pelanggan;
    private AuditLogModel  $audit;
    private SettingModel  $settingModel;

    public function __construct()
    {
        $this->model     = new TagihanModel();
        $this->pelanggan = new PelangganModel();
        $this->audit     = new AuditLogModel();
        $this->settingModel    = new SettingModel();
    }

    // -------------------------------------------------------------------------
    // GET /tagihan
    // -------------------------------------------------------------------------

    public function index(): void
    {
        Auth::roleGuard(['admin', 'kasir']);

        $status = isset($_GET['status']) && $_GET['status'] !== ''
            ? htmlspecialchars($_GET['status'], ENT_QUOTES, 'UTF-8') : null;
        $bulan  = isset($_GET['bulan'])  && $_GET['bulan']  !== ''
            ? htmlspecialchars($_GET['bulan'],  ENT_QUOTES, 'UTF-8') : null;

        $tipe = isset($_GET['tipe']) && $_GET['tipe'] !== ''
            ? htmlspecialchars($_GET['tipe'], ENT_QUOTES, 'UTF-8') : null;

        $tagihan = $this->model->getFiltered($status, $bulan, $tipe);
  
  $kv = $this->settingModel->getAllKV();
        $this->render('Tagihan/index', [
            'title'      => 'Tagihan',
            'activeMenu' => 'tagihan',
            'tagihan'    => $tagihan,
            'filter'     => ['status' => $status ?? '', 'bulan' => $bulan ?? '', 'tipe' => $tipe ?? ''],
            'flash'      => $this->getFlash(),
            'appSettings' => $kv, 
        
]);

    }

    // -------------------------------------------------------------------------
    // GET /tagihan/{id}
    // -------------------------------------------------------------------------

    public function show(string $id): void
    {
        Auth::roleGuard(['admin', 'kasir']);

        $tagihan = $this->model->getDetail((int) $id);
        if (!$tagihan) {
            $this->setFlash('error', 'Tagihan tidak ditemukan.');
            $this->redirectTo('/tagihan');
            return;
        }

        $this->render('Tagihan/show', [
            'title'      => 'Detail Tagihan #' . $id,
            'activeMenu' => 'tagihan',
            'tagihan'    => $tagihan,
            'flash'      => $this->getFlash(),
        ]);
    }

    // -------------------------------------------------------------------------
    // GET /tagihan/buat
    // -------------------------------------------------------------------------

    public function buat(): void
    {
        Auth::roleGuard(['admin', 'kasir']);

        $this->render('Tagihan/buat', [
            'title'      => 'Buat Tagihan',
            'activeMenu' => 'tagihan',
            'pelanggans' => $this->pelanggan->getAllWithPaket(),
            'bulan_ini'  => date('Y-m'),
            'flash'      => $this->getFlash(),
            'old'        => $_SESSION['_old_input'] ?? [],
            'errors'     => $_SESSION['_errors']    ?? [],
        ]);

        unset($_SESSION['_old_input'], $_SESSION['_errors']);
    }

    // -------------------------------------------------------------------------
    // POST /tagihan/simpan
    // -------------------------------------------------------------------------

    public function simpan(): void
    {
        Auth::roleGuard(['admin', 'kasir']);
        \Core\Middleware::validateCsrfToken();

        $pelangganId  = (int)   trim($_POST['pelanggan_id']  ?? '');
        $tipe         =         trim($_POST['tipe']          ?? 'paket');
        $deskripsi    =         trim($_POST['deskripsi']     ?? '');
        $periodeBulan =         trim($_POST['periode_bulan'] ?? '');
        $jatuhTempo   =         trim($_POST['jatuh_tempo']   ?? '');
        $total        = (float) str_replace(['.', ','], ['', '.'], trim($_POST['total'] ?? ''));

        $tipeValid = ['paket', 'pemasangan', 'perbaikan', 'lainnya'];

        // ── Validasi ─────────────────────────────────────────────────────────
        $errors = [];
        if ($pelangganId <= 0)                $errors['pelanggan_id']  = 'Pilih pelanggan.';
        if (!in_array($tipe, $tipeValid))     $errors['tipe']          = 'Tipe tagihan tidak valid.';
        if (!$periodeBulan)                   $errors['periode_bulan'] = 'Periode bulan wajib diisi.';
        if (!$jatuhTempo)                     $errors['jatuh_tempo']   = 'Tanggal jatuh tempo wajib diisi.';
        if ($total <= 0)                      $errors['total']         = 'Total tagihan harus lebih dari 0.';

        // Cek duplikat hanya untuk tipe paket
        if (!$errors && $tipe === 'paket' && $this->model->isDuplicate($pelangganId, $periodeBulan)) {
            $errors['periode_bulan'] = 'Tagihan paket periode ini sudah ada untuk pelanggan tersebut.';
        }

        if ($errors) {
            $_SESSION['_old_input'] = $_POST;
            $_SESSION['_errors']    = $errors;
            $this->setFlash('error', 'Periksa kembali isian form.');
            $this->redirectTo('/tagihan/buat');
            return;
        }

        // ── Simpan ────────────────────────────────────────────────────────────
        $id = $this->model->buat($pelangganId, $tipe, $deskripsi, $periodeBulan, $jatuhTempo, $total);

        if ($id) {
            $pelanggan = $this->pelanggan->getDetail($pelangganId);
            $this->audit->log(
                Auth::id() ?? 0,
                "Buat tagihan #{$id} [{$tipe}] untuk {$pelanggan['nama_lengkap']} " .
                "periode {$periodeBulan} Rp " . number_format($total, 0, ',', '.')
            );
            $this->setFlash('success', 'Tagihan berhasil dibuat.');
            $this->redirectTo('/tagihan/' . $id);
        } else {
            $this->setFlash('error', 'Gagal menyimpan tagihan.');
            $_SESSION['_old_input'] = $_POST;
            $this->redirectTo('/tagihan/buat');
        }
    }

    // -------------------------------------------------------------------------
    // GET /tagihan/generate  — generate tagihan bulanan otomatis semua pelanggan
    // -------------------------------------------------------------------------

    public function generate(): void
    {
        Auth::roleGuard(['admin', 'kasir']);

        $bulan  = $_GET['bulan'] ?? date('Y-m');
        $jumlah = $this->model->generateBulanan($bulan);

        $this->audit->log(Auth::id() ?? 0, "Generate tagihan otomatis periode {$bulan}: {$jumlah} tagihan.");
        $this->setFlash('success', "{$jumlah} tagihan berhasil di-generate untuk periode {$bulan}.");
        $this->redirectTo('/tagihan');
    }


    // -------------------------------------------------------------------------
    // GET /tagihan/edit/{id}
    // -------------------------------------------------------------------------

    public function edit(string $id): void
    {
        Auth::roleGuard(['admin', 'kasir']);

        $tagihan = $this->model->getDetail((int) $id);
        if (!$tagihan) {
            $this->setFlash('error', 'Tagihan tidak ditemukan.');
            $this->redirectTo('/tagihan');
            return;
        }

        $this->render('Tagihan/edit', [
            'title'      => 'Edit Tagihan #' . $id,
            'activeMenu' => 'tagihan',
            'tagihan'    => $tagihan,
            'flash'      => $this->getFlash(),
            'old'        => $_SESSION['_old_input'] ?? [],
            'errors'     => $_SESSION['_errors']    ?? [],
            'csrf_token' => \Core\Middleware::generateCsrfToken(),
        ]);

        unset($_SESSION['_old_input'], $_SESSION['_errors']);
    }

    // -------------------------------------------------------------------------
    // POST /tagihan/update/{id}
    // -------------------------------------------------------------------------

    public function update(string $id): void
    {
        Auth::roleGuard(['admin', 'kasir']);
        \Core\Middleware::validateCsrfToken();

        $tagihanId  = (int) $id;
        $tagihan    = $this->model->getDetail($tagihanId);
        if (!$tagihan) {
            $this->setFlash('error', 'Tagihan tidak ditemukan.');
            $this->redirectTo('/tagihan');
            return;
        }

        $tipe         = trim($_POST['tipe']          ?? 'paket');
        $deskripsi    = trim($_POST['deskripsi']     ?? '');
        $periodeBulan = trim($_POST['periode_bulan'] ?? '');
        $jatuhTempo   = trim($_POST['jatuh_tempo']   ?? '');
        $total        = (float) str_replace(['.', ','], ['', '.'], trim($_POST['total'] ?? ''));
        $status       = trim($_POST['status']        ?? 'unpaid');
        $metode       = trim($_POST['metode_pembayaran'] ?? '');
        $penerima     = trim($_POST['penerima']      ?? '');

        // ── Validasi ─────────────────────────────────────────────────────────
        $errors = [];
        if (!in_array($tipe, ['paket','pemasangan','perbaikan','lainnya'])) $errors['tipe']          = 'Tipe tidak valid.';
        if (!$periodeBulan)                                                  $errors['periode_bulan'] = 'Periode bulan wajib diisi.';
        if (!$jatuhTempo)                                                    $errors['jatuh_tempo']   = 'Jatuh tempo wajib diisi.';
        if ($total <= 0)                                                     $errors['total']         = 'Total harus lebih dari 0.';
        if (!in_array($status, ['paid','unpaid','suspend','cancel']))       $errors['status']        = 'Status tidak valid.';

        if ($errors) {
            $_SESSION['_old_input'] = $_POST;
            $_SESSION['_errors']    = $errors;
            $this->setFlash('error', 'Periksa kembali isian form.');
            $this->redirectTo('/tagihan/edit/' . $tagihanId);
            return;
        }

        $ok = $this->model->ubah($tagihanId, $tipe, $deskripsi, $periodeBulan, $jatuhTempo, $total, $status, $metode, $penerima);

        if ($ok) {
            $this->audit->log(
                Auth::id() ?? 0,
                "Edit tagihan #{$tagihanId} ({$tagihan['nama_lengkap']}) [{$tipe}] " .
                "periode {$periodeBulan} Rp " . number_format($total, 0, ',', '.') .
                " status {$status}" . ($metode ? " via {$metode}" : '') . ($penerima ? " oleh {$penerima}" : '')
            );
            $this->setFlash('success', 'Tagihan berhasil diperbarui.');
            $this->redirectTo('/tagihan/' . $tagihanId);
        } else {
            $this->setFlash('error', 'Gagal memperbarui tagihan.');
            $_SESSION['_old_input'] = $_POST;
            $this->redirectTo('/tagihan/edit/' . $tagihanId);
        }
    }

    // -------------------------------------------------------------------------
    // POST /tagihan/hapus/{id}
    // -------------------------------------------------------------------------

    public function hapus(string $id): void
    {
        Auth::roleGuard(['admin']);
        \Core\Middleware::validateCsrfToken();

        $tagihanId = (int) $id;
        $tagihan   = $this->model->getDetail($tagihanId);
        if (!$tagihan) {
            $this->setFlash('error', 'Tagihan tidak ditemukan.');
            $this->redirectTo('/tagihan');
            return;
        }

        if ($this->model->hapus($tagihanId)) {
            $this->audit->log(
                Auth::id() ?? 0,
                "Hapus tagihan #{$tagihanId} ({$tagihan['nama_lengkap']}) periode {$tagihan['periode_bulan']}"
            );
            $this->setFlash('success', 'Tagihan berhasil dihapus.');
        } else {
            $this->setFlash('error', 'Gagal menghapus tagihan.');
        }

        $this->redirectTo('/tagihan');
    }

    // -------------------------------------------------------------------------
    // GET /tagihan/bayar/{id}
    // -------------------------------------------------------------------------

    public function bayar(string $id): void
    {
        Auth::roleGuard(['admin', 'kasir']);

        $tagihan = $this->model->getDetail((int) $id);
        if (!$tagihan) {
            $this->setFlash('error', 'Tagihan tidak ditemukan.');
            $this->redirectTo('/tagihan');
            return;
        }

        if ($tagihan['status'] === 'paid') {
            $this->setFlash('error', 'Tagihan ini sudah lunas.');
            $this->redirectTo('/tagihan');
            return;
        }

        $this->render('Tagihan/bayar', [
            'title'      => 'Bayar Tagihan',
            'activeMenu' => 'tagihan',
            'tagihan'    => $tagihan,
            'flash'      => $this->getFlash(),
        ]);
    }

    // -------------------------------------------------------------------------
    // POST /tagihan/bayar/{id}
    // -------------------------------------------------------------------------

    public function prosesBayar(string $id): void
    {
        Auth::roleGuard(['admin', 'kasir']);
        \Core\Middleware::validateCsrfToken();

        $tagihanId = (int) $id;
        $tagihan   = $this->model->getDetail($tagihanId);

        if (!$tagihan || $tagihan['status'] === 'paid') {
            $this->setFlash('error', 'Tagihan tidak valid atau sudah lunas.');
            $this->redirectTo('/tagihan');
            return;
        }

        $metode   = trim($_POST['metode_pembayaran'] ?? '');
        $penerima = trim($_POST['penerima'] ?? ($_SESSION['user']['username'] ?? ''));

        if ($metode === '') {
            $this->setFlash('error', 'Pilih metode pembayaran.');
            $this->redirectTo('/tagihan/bayar/' . $tagihanId);
            return;
        }

        if ($this->model->tandaiLunas($tagihanId, $metode, $penerima)) {
            $this->audit->log(
                Auth::id() ?? 0,
                "Bayar tagihan #{$tagihanId} pelanggan: {$tagihan['nama_lengkap']} Rp " .
                number_format($tagihan['total'], 0, ',', '.') .
                " via {$metode} diterima oleh {$penerima}"
            );
            $this->setFlash('success', 'Tagihan berhasil ditandai lunas.');
        } else {
            $this->setFlash('error', 'Gagal memproses pembayaran.');
        }

        $this->redirectTo('/tagihan');
    }

    // -------------------------------------------------------------------------
    // GET /tagihan/cetak/{id}
    // -------------------------------------------------------------------------

    public function cetakInvoice(string $id): void
    {
        Auth::roleGuard(['admin', 'kasir']);

        $tagihan = $this->model->getDetail((int) $id);
        if (!$tagihan) {
            $this->setFlash('error', 'Tagihan tidak ditemukan.');
            $this->redirectTo('/tagihan');
            return;
        }

        $this->render('Tagihan/invoice', [
            'title'   => 'Invoice #' . $id,
            'tagihan' => $tagihan,
        ], 'print');
    }
}
