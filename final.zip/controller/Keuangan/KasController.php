<?php
declare(strict_types=1);

namespace Controller\Keuangan;

use Controller\BaseController;
use Core\Auth;
use Model\KasModel;
use Model\AuditLogModel;

class KasController extends BaseController
{
    private KasModel      $model;
    private AuditLogModel $audit;

    public function __construct()
    {
        $this->model = new KasModel();
        $this->audit = new AuditLogModel();
    }

    // GET /kas
    public function index(): void
    {
        Auth::roleGuard(['admin', 'kasir']);

        $filterBulan  = $_GET['bulan']  ?? date('Y-m');
        $filterTipe   = $_GET['tipe']   ?? '';
        $filterMetode = $_GET['metode'] ?? '';

        $data = $this->model->getFiltered([
            'bulan'  => $filterBulan,
            'tipe'   => $filterTipe,
            'metode' => $filterMetode,
        ]);

        $this->render('Keuangan/kas', [
            'title'      => 'Kas & Arus Kas',
            'activeMenu' => 'kas',
            'list'       => $data['list']    ?? [],
            'summary'    => $data['summary'] ?? ['masuk' => 0, 'keluar' => 0, 'saldo' => 0],
            'total'      => $data['total']   ?? 0,
            'flash'      => $this->getFlash(),
        ]);
    }

    // GET /kas/tambah
    public function create(): void
    {
        Auth::roleGuard(['admin', 'kasir']);
        $this->render('Keuangan/kas_create', [
            'title'      => 'Tambah Transaksi',
            'activeMenu' => 'kas',
            'flash'      => $this->getFlash(),
        ]);
    }

    // POST /kas/simpan
    public function store(): void
    {
        Auth::roleGuard(['admin', 'kasir']);
        $this->verifyCsrf();

        $input  = $this->requestBody();
        $errors = [];
        if (empty($input['tipe']))   $errors[] = 'Tipe transaksi wajib dipilih.';
        if (empty($input['jumlah'])) $errors[] = 'Jumlah wajib diisi.';

        $jumlahRaw = str_replace(['.', ','], ['', '.'], $input['jumlah'] ?? '0');
        $jumlah    = (float)$jumlahRaw;
        if ($jumlah <= 0) $errors[] = 'Jumlah harus lebih dari 0.';

        if ($errors) {
            $this->render('Keuangan/kas_create', [
                'title'  => 'Tambah Transaksi',
                'errors' => $errors,
                'old'    => $input,
            ]);
            return;
        }

        $id = $this->model->create([
            'tipe'               => $input['tipe'],
            'jumlah'             => $jumlah,
            'keterangan'         => trim($input['keterangan'] ?? ''),
            'metode_pembayaran'  => trim($input['metode_pembayaran'] ?? '') ?: null,
        ]);

        $this->audit->log(Auth::id() ?? 0, "Tambah transaksi kas #{$id} ({$input['tipe']} Rp " . number_format($jumlah, 0, ',', '.') . ")");
        $this->setFlash('success', 'Transaksi berhasil ditambahkan.');
        $this->redirectTo('/kas');
    }

    // GET /kas/edit/{id}
    public function edit(string $id): void
    {
        Auth::roleGuard(['admin', 'kasir']);
        $row = $this->model->getById((int)$id);
        if (!$row) {
            $this->setFlash('danger', 'Transaksi tidak ditemukan.');
            $this->redirectTo('/kas');
            return;
        }
        $this->render('Keuangan/kas_edit', [
            'title'      => 'Edit Transaksi',
            'activeMenu' => 'kas',
            'row'        => $row,
            'flash'      => $this->getFlash(),
        ]);
    }

    // POST /kas/update/{id}
    public function update(string $id): void
    {
        Auth::roleGuard(['admin', 'kasir']);
        $this->verifyCsrf();

        $input  = $this->requestBody();
        $errors = [];
        if (empty($input['tipe']))   $errors[] = 'Tipe transaksi wajib dipilih.';
        if (empty($input['jumlah'])) $errors[] = 'Jumlah wajib diisi.';

        $jumlahRaw = str_replace(['.', ','], ['', '.'], $input['jumlah'] ?? '0');
        $jumlah    = (float)$jumlahRaw;
        if ($jumlah <= 0) $errors[] = 'Jumlah harus lebih dari 0.';

        if ($errors) {
            $row = $this->model->getById((int)$id);
            $this->render('Keuangan/kas_edit', [
                'title'  => 'Edit Transaksi',
                'errors' => $errors,
                'row'    => array_merge($row ?? [], $input),
            ]);
            return;
        }

        $this->model->update((int)$id, [
            'tipe'               => $input['tipe'],
            'jumlah'             => $jumlah,
            'keterangan'         => trim($input['keterangan'] ?? ''),
            'metode_pembayaran'  => trim($input['metode_pembayaran'] ?? '') ?: null,
        ]);

        $this->audit->log(Auth::id() ?? 0, "Edit transaksi kas #{$id}");
        $this->setFlash('success', 'Transaksi berhasil diperbarui.');
        $this->redirectTo('/kas');
    }

    // POST /kas/hapus/{id}
    public function destroy(string $id): void
    {
        Auth::roleGuard(['admin', 'kasir']);
        $this->verifyCsrf();

        $row = $this->model->getById((int)$id);
        if ($row) {
            $this->model->delete((int)$id);
            $this->audit->log(Auth::id() ?? 0, "Hapus transaksi kas #{$id}");
            $this->setFlash('success', 'Transaksi berhasil dihapus.');
        } else {
            $this->setFlash('danger', 'Transaksi tidak ditemukan.');
        }
        $this->redirectTo('/kas');
    }

    // GET /kas/export
    public function export(): void
    {
        Auth::roleGuard(['admin', 'kasir']);

        $filterBulan  = $_GET['bulan']  ?? date('Y-m');
        $filterTipe   = $_GET['tipe']   ?? '';
        $filterMetode = $_GET['metode'] ?? '';

        $data    = $this->model->getFiltered([
            'bulan'  => $filterBulan,
            'tipe'   => $filterTipe,
            'metode' => $filterMetode,
        ]);
        $list    = $data['list']    ?? [];
        $summary = $data['summary'] ?? ['masuk' => 0, 'keluar' => 0, 'saldo' => 0];

        $periode  = str_replace('-', '', $filterBulan);
        $filename = "kas_{$periode}_" . date('Ymd_His') . '.xls';
        $tmpFile  = sys_get_temp_dir() . DIRECTORY_SEPARATOR . $filename;

        $out = fopen($tmpFile, 'w');
        fwrite($out, "\xEF\xBB\xBF");

        fwrite($out, "LAPORAN KAS & ARUS KAS\n");
        fwrite($out, "Periode: " . $this->formatPeriode($filterBulan) . "\n");
        if ($filterTipe)   fwrite($out, "Filter Tipe: " . ($filterTipe === 'masuk' ? 'Pemasukan' : 'Pengeluaran') . "\n");
        if ($filterMetode) fwrite($out, "Filter Metode: {$filterMetode}\n");
        fwrite($out, "Dicetak: " . date('d M Y H:i') . "\n\n");

        fwrite($out, "RINGKASAN\n");
        fputcsv($out, ['Pemasukan',   'Rp ' . number_format($summary['masuk']  ?? 0, 0, ',', '.')], "\t");
        fputcsv($out, ['Pengeluaran', 'Rp ' . number_format($summary['keluar'] ?? 0, 0, ',', '.')], "\t");
        fputcsv($out, ['Saldo',       'Rp ' . number_format($summary['saldo']  ?? 0, 0, ',', '.')], "\t");
        fwrite($out, "\n");

        fputcsv($out, ['No', 'Tanggal', 'Tipe', 'Keterangan', 'Metode Pembayaran', 'Jumlah (Rp)'], "\t");

        foreach ($list as $i => $row) {
            $isMasuk = ($row['tipe'] ?? '') === 'masuk';
            $jumlah  = (float)($row['jumlah'] ?? 0);
            fputcsv($out, [
                $i + 1,
                date('d/m/Y', strtotime($row['created_at'] ?? 'now')),
                $isMasuk ? 'Pemasukan' : 'Pengeluaran',
                $row['keterangan'] ?? '',
                $row['metode_pembayaran'] ?? '-',
                $isMasuk ? $jumlah : -$jumlah,
            ], "\t");
        }

        fwrite($out, "\n");
        fputcsv($out, ['', '', '', 'TOTAL PEMASUKAN',   '', $summary['masuk']  ?? 0], "\t");
        fputcsv($out, ['', '', '', 'TOTAL PENGELUARAN', '', $summary['keluar'] ?? 0], "\t");
        fputcsv($out, ['', '', '', 'SALDO',             '', $summary['saldo']  ?? 0], "\t");

        fclose($out);

        while (ob_get_level() > 0) ob_end_clean();

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($tmpFile));
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');

        readfile($tmpFile);
        unlink($tmpFile);
        exit;
    }

    private function formatPeriode(string $ym): string
    {
        $bulan = [
            '01'=>'Januari','02'=>'Februari','03'=>'Maret','04'=>'April',
            '05'=>'Mei','06'=>'Juni','07'=>'Juli','08'=>'Agustus',
            '09'=>'September','10'=>'Oktober','11'=>'November','12'=>'Desember'
        ];
        $parts = explode('-', $ym);
        return count($parts) === 2 ? ($bulan[$parts[1]] ?? $parts[1]) . ' ' . $parts[0] : $ym;
    }
}
