<?php
declare(strict_types=1);

namespace Controller\Keuangan;

use Controller\BaseController;
use Core\Auth;
use Model\KasModel;

class LaporanKasController extends BaseController
{
    private KasModel $model;

    public function __construct()
    {
        $this->model = new KasModel();
    }

    public function index(): void
    {
        Auth::roleGuard(['admin', 'kasir']);

        $tahunList   = $this->model->getTahunTersedia();
        $filterTahun = (int)($_GET['tahun'] ?? date('Y'));

        if (!in_array($filterTahun, $tahunList, true)) {
            $tahunList[] = $filterTahun;
            rsort($tahunList);
        }

        $laporan = $this->model->getLaporanBulanan($filterTahun);

        $this->render('Keuangan/laporan_kas', [
            'title'       => 'Laporan Kas',
            'activeMenu'  => 'laporan/kas',
            'laporan'     => $laporan,
            'tahunList'   => $tahunList,
            'filterTahun' => $filterTahun,
            'flash'       => $this->getFlash(),
        ]);
    }

    public function export(): void
    {
        Auth::roleGuard(['admin', 'kasir']);

        $filterTahun = (int)($_GET['tahun'] ?? date('Y'));
        $laporan     = $this->model->getLaporanBulanan($filterTahun);
        $data        = $laporan['data']  ?? [];
        $total       = $laporan['total'] ?? [
            'masuk' => 0, 'keluar' => 0, 'saldo' => 0, 'total_transaksi' => 0
        ];

        $filename = "laporan_kas_{$filterTahun}_" . date('Ymd_His') . '.csv';
        $tmpFile  = sys_get_temp_dir() . DIRECTORY_SEPARATOR . $filename;

        // ===== Tulis CSV ke file fisik =====
        $this->writeCSV($tmpFile, $filterTahun, $data, $total);

        // ===== Bersihkan SEMUA output buffer =====
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        // ===== Kirim file =====
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($tmpFile));
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');

        readfile($tmpFile);
        unlink($tmpFile);
        exit;
    }

    private function writeCSV(string $tmpFile, int $tahun, array $data, array $total): void
    {
        $fp = fopen($tmpFile, 'w');

        // UTF-8 BOM — WAJIB agar Excel & Google Sheets deteksi encoding
        fwrite($fp, "\xEF\xBB\xBF");

        // Header laporan (baris informasi)
        fputcsv($fp, ['LAPORAN KAS BULANAN - Tahun ' . $tahun], ',', '"');
        fputcsv($fp, ['Dicetak: ' . date('d M Y H:i')], ',', '"');
        fputcsv($fp, [], ',', '"');

        // Header kolom
        fputcsv($fp, [
            'Bulan',
            'Pemasukan',
            'Pengeluaran',
            'Saldo',
            'Jumlah Transaksi'
        ], ',', '"');

        // Data per bulan
        foreach ($data as $d) {
            $nama   = (string)($d['nama_bulan'] ?? '');
            $masuk  = (float)($d['masuk'] ?? 0);
            $keluar = (float)($d['keluar'] ?? 0);
            $saldo  = (float)($d['saldo'] ?? 0);
            $trx    = (int)($d['total_transaksi'] ?? 0);

            fputcsv($fp, [
                $nama,
                $masuk,
                $keluar,
                $saldo,
                $trx
            ], ',', '"');
        }

        // Baris kosong pemisah
        fputcsv($fp, [], ',', '"');

        // Baris total
        fputcsv($fp, [
            'TOTAL',
            (float)$total['masuk'],
            (float)$total['keluar'],
            (float)$total['saldo'],
            (int)$total['total_transaksi']
        ], ',', '"');

        fclose($fp);
    }
}
