<?php
/**
 * controller/Keuangan/LaporanController.php
 */
declare(strict_types=1);

namespace Controller\Keuangan;

use Controller\BaseController;
use Core\Auth;
use Model\TagihanModel;

class LaporanController extends BaseController
{
    private TagihanModel $tagihan;

    public function __construct()
    {
        $this->tagihan = new TagihanModel();
    }

    // GET /laporan/pembayaran
    public function pembayaran(): void
    {
        Auth::roleGuard(['admin', 'kasir']);

        $bulan  = $_GET['bulan']  ?? date('Y-m');
        $status = $_GET['status'] ?? 'paid';
        $tipe   = $_GET['tipe']   ?? '';

        $list = $this->tagihan->getFiltered(
            $status !== '' ? $status : null,
            $bulan  !== '' ? $bulan  : null,
            $tipe   !== '' ? $tipe   : null
        );

        $totalNominal = array_sum(array_column($list, 'total'));
        $totalCount   = count($list);

        $this->render('Laporan/pembayaran', [
            'title'        => 'Laporan Pembayaran',
            'activeMenu'   => 'laporan',
            'list'         => $list,
            'filter'       => ['bulan' => $bulan, 'status' => $status, 'tipe' => $tipe],
            'totalNominal' => $totalNominal,
            'totalCount'   => $totalCount,
        ]);
    }

    // GET /laporan/tagihan
    public function tagihan(): void
    {
        Auth::roleGuard(['admin', 'kasir']);

        $bulan  = $_GET['bulan']  ?? date('Y-m');
        $status = $_GET['status'] ?? '';
        $tipe   = $_GET['tipe']   ?? '';

        $list = $this->tagihan->getFiltered(
            $status !== '' ? $status : null,
            $bulan  !== '' ? $bulan  : null,
            $tipe   !== '' ? $tipe   : null
        );

        $nomPaid   = 0; $cntPaid   = 0;
        $nomUnpaid = 0; $cntUnpaid = 0;
        foreach ($list as $row) {
            if ($row['status'] === 'paid') { $nomPaid   += (float)$row['total']; $cntPaid++;   }
            else                           { $nomUnpaid += (float)$row['total']; $cntUnpaid++; }
        }

        $this->render('Laporan/tagihan', [
            'title'      => 'Laporan Tagihan',
            'activeMenu' => 'laporan',
            'list'       => $list,
            'filter'     => ['bulan' => $bulan, 'status' => $status, 'tipe' => $tipe],
            'nomPaid'    => $nomPaid,   'cntPaid'    => $cntPaid,
            'nomUnpaid'  => $nomUnpaid, 'cntUnpaid'  => $cntUnpaid,
        ]);
    }
}
