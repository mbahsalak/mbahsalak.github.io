<?php
/**
 * controller/Auth/RegisterController.php
 * Mengelola pendaftaran pelanggan baru via form publik.
 *
 * Alur:
 *  GET  /daftar                  → tampil form pendaftaran
 *  POST /daftar                  → proses pendaftaran (status: pending)
 *  GET  /daftar/cek-username     → AJAX cek ketersediaan username
 *
 * Admin approval (role: admin):
 *  POST /pelanggan/aktivasi/{id} → aktifkan akun pending
 *  POST /pelanggan/tolak/{id}    → tolak/nonaktifkan akun
 */

declare(strict_types=1);

namespace Controller\Auth;

use Controller\BaseController;
use Core\Auth;
use Config\Database;
use Model\PelangganModel;
use Model\PaketModel;
use Model\UserModel;
use Model\AuditLogModel;
use PDO;

class RegisterController extends BaseController
{
    private PelangganModel $pelanggan;
    private PaketModel     $paket;
    private AuditLogModel  $audit;
    private PDO            $db;

    public function __construct()
    {
        $this->db        = Database::getConnection();
        $this->pelanggan = new PelangganModel();
        $this->paket     = new PaketModel();
        $this->audit     = new AuditLogModel();
    }

    // =========================================================================
    // FORM PENDAFTARAN (publik)
    // =========================================================================

    public function showForm(): void
    {
        // Kalau sudah login, redirect ke dashboard
        if (Auth::check()) {
            $this->redirectTo('/dashboard');
            return;
        }

        $this->migrateStatusAkun();

        $this->render('Auth/register', [
            'title'  => 'Daftar Layanan',
            'pakets' => $this->paket->getAll(),
        ]);
    }

    public function process(): void
    {
        if (Auth::check()) {
            $this->redirectTo('/dashboard');
            return;
        }

        $this->verifyCsrf();

        $input = $this->requestBody();
        $errors = [];
        $errorFields = [];

        // ── Sanitasi ──
        $nama     = trim($input['nama_lengkap']     ?? '');
        $username = strtolower(trim($input['username'] ?? ''));
        $no_telp  = trim($input['no_telp']          ?? '');
        $password = $input['password']              ?? '';
        $pwdC     = $input['password_confirm']      ?? '';
        $alamat   = trim($input['alamat']           ?? '');
        $koordinat= trim($input['koordinat']        ?? '');
        $catatan  = trim($input['catatan']          ?? '');
        $paketId  = (int)($input['paket_id']        ?? 0);
        $setuju   = !empty($input['setuju']);

        // ── Validasi ──
        if (!$nama) {
            $errors[]      = 'Nama lengkap wajib diisi.';
            $errorFields[] = 'nama_lengkap';
        }

        if (!$username || strlen($username) < 4) {
            $errors[]      = 'Username minimal 4 karakter.';
            $errorFields[] = 'username';
        } elseif (!preg_match('/^[a-z0-9._]+$/', $username)) {
            $errors[]      = 'Username hanya boleh mengandung huruf kecil, angka, titik, dan garis bawah.';
            $errorFields[] = 'username';
        }

        if (!$no_telp) {
            $errors[]      = 'No. WhatsApp wajib diisi.';
            $errorFields[] = 'no_telp';
        } elseif (!preg_match('/^(\+62|62|0)[0-9]{8,13}$/', preg_replace('/[\s\-]/', '', $no_telp))) {
            $errors[]      = 'Format No. WhatsApp tidak valid.';
            $errorFields[] = 'no_telp';
        }

        if (strlen($password) < 6) {
            $errors[]      = 'Password minimal 6 karakter.';
            $errorFields[] = 'password';
        }

        if ($password !== $pwdC) {
            $errors[] = 'Konfirmasi password tidak cocok.';
        }

        if (!$alamat) {
            $errors[]      = 'Alamat wajib diisi.';
            $errorFields[] = 'alamat';
        }

        if (!$setuju) {
            $errors[] = 'Anda harus menyetujui syarat dan ketentuan.';
        }

        // Cek username
        if (empty($errors) || !in_array('username', $errorFields)) {
            $userModel = new UserModel();
            if ($userModel->isUsernameTaken($username)) {
                $errors[]      = 'Username sudah digunakan, silakan pilih username lain.';
                $errorFields[] = 'username';
            }
        }

        if (!empty($errors)) {
            $this->render('Auth/register', [
                'title'       => 'Daftar Layanan',
                'pakets'      => $this->paket->getAll(),
                'errors'      => $errors,
                'errorFields' => $errorFields,
                'old'         => $input,
            ]);
            return;
        }

        // ── Parse koordinat ──
        $lat = null;
        $lng = null;
        if ($koordinat !== '') {
            $parts = explode(',', $koordinat, 2);
            if (count($parts) === 2) {
                $lat = (float)trim($parts[0]);
                $lng = (float)trim($parts[1]);
                // Validasi range
                if ($lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) {
                    $lat = null;
                    $lng = null;
                }
            }
        }

        // ── Simpan ke DB ──
        try {
            $this->db->beginTransaction();

            $userModel = new UserModel();

            // Buat user dengan status 'pending'
            $userId = $userModel->create([
                'username' => $username,
                'password' => Auth::hashPassword($password),
                'role'     => 'pelanggan',
                'status'   => 'pending',
            ]);

            // Catatan instalasi
            $notesArr = [];
            if ($catatan) $notesArr[] = $catatan;
            $notes = implode('; ', $notesArr) ?: null;

            // Buat data pelanggan
            $pelangganId = $this->pelanggan->create([
                'user_id'         => $userId,
                'nama_lengkap'    => $nama,
                'no_telp'         => $no_telp,
                'alamat'          => $alamat,
                'latitude'        => $lat,
                'longitude'       => $lng,
                'paket_id'        => $paketId ?: null,
                'odp_id'          => null,
                'tgl_jatuh_tempo' => 5,
                'status_internet' => 'isolir',   // Belum aktif sampai disetujui
                'catatan'         => $notes,
            ]);

            $this->db->commit();

            // Audit log (tanpa session)
            $this->audit->log(0, "Pendaftaran baru: {$nama} (username: {$username}, ID: {$pelangganId})");

            // TODO: kirim notifikasi ke admin (email/WA)
            $this->notifyAdmin($nama, $username, $no_telp, $pelangganId);

            $this->render('Auth/register', [
                'title'              => 'Pendaftaran Berhasil',
                'pakets'             => [],
                'success'            => true,
                'registeredName'     => $nama,
                'registeredUsername' => $username,
                'registeredTelp'     => $no_telp,
            ]);

        } catch (\Throwable $e) {
            $this->db->rollBack();
            \Core\Logger::error('RegisterController', $e->getMessage());
            $this->render('Auth/register', [
                'title'       => 'Daftar Layanan',
                'pakets'      => $this->paket->getAll(),
                'errors'      => ['Terjadi kesalahan sistem. Silakan coba lagi atau hubungi admin.'],
                'errorFields' => [],
                'old'         => $input,
            ]);
        }
    }

    // =========================================================================
    // AJAX: Cek ketersediaan username
    // =========================================================================

    public function checkUsername(): void
    {
        header('Content-Type: application/json');
        $username  = strtolower(trim($_GET['u'] ?? ''));

        if (strlen($username) < 4 || !preg_match('/^[a-z0-9._]+$/', $username)) {
            echo json_encode(['available' => false, 'reason' => 'invalid']);
            exit;
        }

        $userModel = new UserModel();
        $taken     = $userModel->isUsernameTaken($username);

        echo json_encode(['available' => !$taken]);
        exit;
    }

    // =========================================================================
    // ADMIN: Aktivasi / Tolak akun pending
    // =========================================================================

    /**
     * POST /pelanggan/aktivasi/{id}
     * Mengaktifkan akun pelanggan yang pending → active
     */
    public function aktivasi(string $id): void
    {
        Auth::roleGuard(['admin']);
        $this->verifyCsrf();

        $pelangganId = (int)$id;
        $data = $this->pelanggan->getDetail($pelangganId);

        if (!$data) {
            $this->setFlash('danger', 'Pelanggan tidak ditemukan.');
            $this->redirectTo('/pelanggan');
            return;
        }

        $userModel = new UserModel();
        $userModel->setStatus((int)$data['user_id'], 'active');

        $this->pelanggan->edit($pelangganId, [
            'status_internet' => 'active',
            'tgl_install'     => date('Y-m-d'),
        ]);

        $this->audit->log(
            Auth::id() ?? 0,
            "Aktivasi akun pelanggan #{$pelangganId} — {$data['nama_lengkap']}"
        );

        $this->setFlash('success', "Akun <strong>{$data['nama_lengkap']}</strong> berhasil diaktifkan.");
        $this->redirectTo('/pelanggan');
    }

    /**
     * POST /pelanggan/tolak/{id}
     * Menolak/menonaktifkan akun (pending → inactive)
     */
    public function tolak(string $id): void
    {
        Auth::roleGuard(['admin']);
        $this->verifyCsrf();

        $pelangganId = (int)$id;
        $data = $this->pelanggan->getDetail($pelangganId);

        if (!$data) {
            $this->setFlash('danger', 'Pelanggan tidak ditemukan.');
            $this->redirectTo('/pelanggan');
            return;
        }

        $userModel = new UserModel();
        $userModel->setStatus((int)$data['user_id'], 'inactive');

        $this->pelanggan->edit($pelangganId, [
            'status_internet' => 'isolir',
        ]);

        $this->audit->log(
            Auth::id() ?? 0,
            "Tolak/nonaktifkan akun pelanggan #{$pelangganId} — {$data['nama_lengkap']}"
        );

        $this->setFlash('warning', "Akun <strong>{$data['nama_lengkap']}</strong> ditolak/dinonaktifkan.");
        $this->redirectTo('/pelanggan');
    }

    // =========================================================================
    // HELPER
    // =========================================================================

    /**
     * Pastikan kolom 'status' pada tabel users memiliki nilai 'pending' dan 'inactive'
     */
    private function migrateStatusAkun(): void
    {
        try {
            $this->db->exec("
                ALTER TABLE users
                MODIFY COLUMN status ENUM('active','pending','inactive','banned')
                NOT NULL DEFAULT 'pending'
            ");
        } catch (\Throwable) {}
    }

    /**
     * Kirim notifikasi ke admin (stub — isi dengan logika notif Anda)
     */
    private function notifyAdmin(string $nama, string $username, string $telp, int $pelangganId): void
    {
        // Contoh: simpan notifikasi ke tabel, atau kirim email/WA via queue
        try {
            $stmt = $this->db->prepare("
                INSERT INTO notifikasi (tipe, judul, pesan, created_at)
                VALUES ('pendaftaran', 'Pendaftaran Baru', :pesan, NOW())
            ");
            $stmt->execute([
                ':pesan' => "Pelanggan baru mendaftar: {$nama} (@{$username}, {$telp}) — ID #{$pelangganId}. Perlu aktivasi."
            ]);
        } catch (\Throwable) {
            // Tabel notifikasi mungkin belum ada — abaikan
        }
    }
}
