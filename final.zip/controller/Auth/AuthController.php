<?php
/**
 * controller/Auth/AuthController.php
 * Autentikasi: Login, Register, Logout
 * PHP 8.4 Native Semi-Framework
 *
 * ✅ UPDATED: Session login bertahan 12 jam (43.200 detik)
 */

declare(strict_types=1);

namespace Controller\Auth;

use Controller\BaseController;
use Core\Auth;
use Model\UserModel;
use Model\SettingModel;

class AuthController extends BaseController
{
    private UserModel    $userModel;
    private SettingModel $settingModel;

    public function __construct()
    {
        $this->userModel    = new UserModel();
        $this->settingModel = new SettingModel();
    }

    /**
     * ✅ Helper DRY: Ambil semua setting + normalisasi flash
     */
    private function getAuthViewData(array $extra = []): array
    {
        $kv = $this->settingModel->getAllKV();

        // Normalisasi flash message
        $flash = null;
        $rawFlash = $extra['flash'] ?? $this->getFlash();
        if (!empty($rawFlash)) {
            if (is_array($rawFlash) && isset($rawFlash['type'], $rawFlash['message'])) {
                $flash = $rawFlash;
            } elseif (is_array($rawFlash)) {
                foreach (['success', 'error', 'warning', 'info'] as $type) {
                    if (!empty($rawFlash[$type])) {
                        $flash = ['type' => $type, 'message' => $rawFlash[$type]];
                        break;
                    }
                }
            } elseif (is_string($rawFlash)) {
                $flash = ['type' => 'info', 'message' => $rawFlash];
            }
        }

        return array_merge([
            'title'        => 'Masuk',
            'appSettings'  => $kv,
            'authSettings' => $kv,
            'flash'        => $flash,
        ], $extra);
    }

    // -------------------------------------------------------------------------
    // Login
    // -------------------------------------------------------------------------

    /** GET /login */
    public function showLogin(): void
    {
        $this->render('Login/login', $this->getAuthViewData([
            'error' => $_SESSION['login_error'] ?? null,
            'old'   => $_SESSION['old_input'] ?? [],
        ]), 'auth');

        unset($_SESSION['login_error'], $_SESSION['old_input']);
    }

    /** POST /login */
    public function login(): void
    {
        $input    = $this->requestBody();
        $username = trim($input['username'] ?? '');
        $password = $input['password'] ?? '';

        // Validasi input kosong
        if ($username === '' || $password === '') {
            $this->render('Login/login', $this->getAuthViewData([
                'error' => 'Username dan password wajib diisi.',
                'old'   => ['username' => $username],
            ]), 'auth');
            return;
        }

        $user = $this->userModel->findByUsername($username);

        // Cek user ada dan password cocok
        if (!$user || !Auth::verifyPassword($password, $user['password'])) {
            $this->render('Login/login', $this->getAuthViewData([
                'error' => 'Username atau password salah.',
                'old'   => ['username' => $username],
            ]), 'auth');
            return;
        }

        // Cek status akun aktif
        if (($user['status'] ?? 'inactive') !== 'active') {
            $this->render('Login/login', $this->getAuthViewData([
                'error' => 'Akun Anda telah dinonaktifkan. Hubungi administrator.',
                'old'   => ['username' => $username],
            ]), 'auth');
            return;
        }

        // Simpan ke session + regenerate session ID
        Auth::loginSession($user);

        // ✅ CATAT WAKTU LOGIN — digunakan oleh index.php untuk cek expiry 12 jam
        $_SESSION['_login_time']      = time();
        $_SESSION['_last_activity']   = time();

        $this->redirect(($_ENV['APP_URL'] ?? '') . '/dashboard');
    }

    // -------------------------------------------------------------------------
    // Register
    // -------------------------------------------------------------------------

    /** GET /register */
    public function showRegister(): void
    {
        $this->render('Login/register', $this->getAuthViewData([
            'title' => 'Daftar Akun',
        ]), 'auth');
    }

    /** POST /register */
    public function register(): void
    {
        $input    = $this->requestBody();
        $username = trim($input['username'] ?? '');
        $password = $input['password'] ?? '';
        $confirm  = $input['confirm_password'] ?? '';

        // Validasi field wajib
        if ($username === '' || $password === '') {
            $this->render('Login/register', $this->getAuthViewData([
                'error' => 'Username dan password wajib diisi.',
                'old'   => ['username' => $username],
            ]), 'auth');
            return;
        }

        // Validasi panjang username
        if (strlen($username) < 4 || strlen($username) > 50) {
            $this->render('Login/register', $this->getAuthViewData([
                'error' => 'Username harus antara 4–50 karakter.',
                'old'   => ['username' => $username],
            ]), 'auth');
            return;
        }

        // Validasi password match
        if ($password !== $confirm) {
            $this->render('Login/register', $this->getAuthViewData([
                'error' => 'Konfirmasi password tidak cocok.',
                'old'   => ['username' => $username],
            ]), 'auth');
            return;
        }

        // Validasi minimal panjang password
        if (strlen($password) < 8) {
            $this->render('Login/register', $this->getAuthViewData([
                'error' => 'Password minimal 8 karakter.',
                'old'   => ['username' => $username],
            ]), 'auth');
            return;
        }

        // Cek username sudah terdaftar
        if ($this->userModel->findByUsername($username)) {
            $this->render('Login/register', $this->getAuthViewData([
                'error' => 'Username sudah digunakan. Pilih username lain.',
                'old'   => ['username' => $username],
            ]), 'auth');
            return;
        }

        // Simpan user baru sebagai role 'pelanggan'
        $this->userModel->create([
            'username' => $username,
            'password' => Auth::hashPassword($password),
            'role'     => 'pelanggan',
            'status'   => 'active',
        ]);

        $this->setFlash('success', 'Registrasi berhasil! Silakan login.');
        $this->redirect(($_ENV['APP_URL'] ?? '') . '/login');
    }

    // -------------------------------------------------------------------------
    // Logout
    // -------------------------------------------------------------------------

    /** GET /logout */
    public function logout(): void
    {
        // ✅ HAPUS SEMUA DATA SESSION termasuk _login_time
        $_SESSION = [];

        // Hapus cookie session
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }

        // Destroy session
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }

        // Mulai session baru untuk flash message
        session_start();
        $_SESSION['flash'] = [
            'type'    => 'success',
            'message' => 'Anda telah berhasil keluar.',
        ];

        // Redirect ke login
        header('Location: ' . ($_ENV['APP_URL'] ?? '') . '/login');
        exit;
    }
}
