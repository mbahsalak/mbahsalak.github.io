<?php
/**
 * controller/Auth/ProfileController.php
 * Manajemen profil & ganti password untuk semua role
 */

declare(strict_types=1);

namespace Controller\Auth;

use Controller\BaseController;
use Core\Auth;
use Model\UserModel;
use Model\AuditLogModel;

class ProfileController extends BaseController
{
    private UserModel     $userModel;
    private AuditLogModel $audit;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->audit     = new AuditLogModel();
    }

    /** GET /profile */
    public function index(): void
    {
        $user = Auth::user();
        $this->render('Profile/index', [
            'title'      => 'Profil Saya',
            'activeMenu' => 'profile',
            'user'       => $user,
            'flash'      => $this->getFlash(),
        ]);
    }

    /** POST /profile/update */
    public function update(): void
    {
        $input  = $this->requestBody();
        $userId = Auth::id() ?? 0;

        $data = [
            'nama_lengkap' => $input['nama_lengkap'] ?? '',
            'email'        => $input['email']        ?? '',
            'no_hp'        => $input['no_hp']        ?? '',
        ];

        $ok = $this->userModel->update($userId, $data);

        if ($ok) {
            $this->audit->log($userId, 'Update profil');
            $this->setFlash('success', 'Profil berhasil diperbarui.');
        } else {
            $this->setFlash('error', 'Gagal memperbarui profil.');
        }

        $this->redirectTo('/profile');
    }

    /** GET /profile/ganti-password */
    public function changePassword(): void
    {
        $this->render('Profile/change_password', [
            'title'      => 'Ganti Password',
            'activeMenu' => 'profile',
            'user'       => Auth::user(),
            'flash'      => $this->getFlash(),
        ]);
    }

    /** POST /profile/ganti-password */
    public function doChangePassword(): void
    {
        $input     = $this->requestBody();
        $userId    = Auth::id() ?? 0;
        $user      = $this->userModel->find($userId);

        if (!$user) {
            $this->setFlash('error', 'User tidak ditemukan.');
            $this->redirectTo('/profile/ganti-password');
        }

        // Verifikasi password lama
        if (!password_verify($input['password_lama'] ?? '', $user['password'])) {
            $this->setFlash('error', 'Password lama tidak sesuai.');
            $this->redirectTo('/profile/ganti-password');
        }

        // Validasi password baru
        $passwordBaru = $input['password_baru'] ?? '';
        if (strlen($passwordBaru) < 6) {
            $this->setFlash('error', 'Password baru minimal 6 karakter.');
            $this->redirectTo('/profile/ganti-password');
        }

        if ($passwordBaru !== ($input['konfirmasi_password'] ?? '')) {
            $this->setFlash('error', 'Konfirmasi password tidak cocok.');
            $this->redirectTo('/profile/ganti-password');
        }

        $ok = $this->userModel->update($userId, [
            'password' => password_hash($passwordBaru, PASSWORD_BCRYPT),
        ]);

        if ($ok) {
            $this->audit->log($userId, 'Ganti password');
            $this->setFlash('success', 'Password berhasil diubah.');
        } else {
            $this->setFlash('error', 'Gagal mengubah password.');
        }

        $this->redirectTo('/profile/ganti-password');
    }
}
