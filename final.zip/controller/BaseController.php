<?php
/**
 * controller/BaseController.php
 * Abstract Base Controller — parent semua controller aplikasi
 * PHP 8.4 Native Semi-Framework
 */

declare(strict_types=1);

namespace Controller;

use Core\Middleware;

abstract class BaseController
{
    // -------------------------------------------------------------------------
    // View Rendering
    // -------------------------------------------------------------------------

    /**
     * Render view dengan layout
     *
     * @param string $viewPath   Path relatif dari views/pages/, tanpa .php
     *                           Contoh: 'Login/login', 'Dashboard/index'
     * @param array  $data       Data yang di-extract menjadi variabel di dalam view
     * @param string $layout     Nama layout file di views/layouts/ (tanpa .php)
     */
    protected function render(string $viewPath, array $data = [], string $layout = 'main'): void
    {
        $viewFile   = APP_ROOT . "/views/pages/{$viewPath}.php";
        $layoutFile = APP_ROOT . "/views/layouts/{$layout}.php";

        if (!file_exists($viewFile)) {
            http_response_code(500);
            die("View tidak ditemukan: views/pages/{$viewPath}.php");
        }

        // Selalu inject csrf_token agar tersedia di semua view tanpa perlu
        // memanggil Middleware::generateCsrfToken() secara manual di controller.
        if (!isset($data['csrf_token'])) {
            $data['csrf_token'] = Middleware::generateCsrfToken();
        }

        // Extract data sebagai variabel lokal di scope ini (dan view)
        extract($data, EXTR_SKIP);

        // Buffer output view — hasilnya masuk ke $content
        ob_start();
        require $viewFile;
        $content = ob_get_clean();

        // Render layout; $content tersedia di dalam layout sebagai variabel
        if (file_exists($layoutFile)) {
            require $layoutFile;
        } else {
            // DEBUG: tampilkan path yang dicari agar mudah diagnosa
            echo '<!-- LAYOUT NOT FOUND: ' . htmlspecialchars($layoutFile) . ' -->';
            echo '<!-- APP_ROOT: ' . htmlspecialchars(APP_ROOT) . ' -->';
            echo $content;
        }
    }

    /**
     * Alias render() — kompatibel dengan pemanggilan ->view() di kode lama
     */
    protected function view(string $viewPath, array $data = [], string $layout = 'main'): void
    {
        $this->render($viewPath, $data, $layout);
    }

    // -------------------------------------------------------------------------
    // Response Helpers
    // -------------------------------------------------------------------------

    /**
     * Kirim response JSON
     */
    protected function json(mixed $data, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    /**
     * Redirect ke URL lain
     */
    protected function redirect(string $url): never
    {
        header('Location: ' . $url);
        exit;
    }

    /**
     * Redirect ke URL dengan APP_URL prefix
     */
    protected function redirectTo(string $path): never
    {
        $this->redirect(($_ENV['APP_URL'] ?? '') . $path);
    }

    // -------------------------------------------------------------------------
    // Input & Request
    // -------------------------------------------------------------------------

    /**
     * Ambil semua input POST (sudah di-sanitasi dasar)
     * Untuk validasi lebih dalam, lakukan di controller masing-masing
     */
    protected function requestBody(): array
    {
        $data = [];
        foreach ($_POST as $key => $value) {
            $data[$key] = is_array($value)
                ? array_map(fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'), $value)
                : htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
        }
        return $data;
    }

    /**
     * Ambil satu input dari POST atau GET
     */
    protected function input(string $key, mixed $default = null): mixed
    {
        $value = $_POST[$key] ?? $_GET[$key] ?? null;

        if ($value === null) {
            return $default;
        }

        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }

    /**
     * Ambil satu input integer (aman untuk ID)
     */
    protected function inputInt(string $key, int $default = 0): int
    {
        $value = $_POST[$key] ?? $_GET[$key] ?? null;
        return $value !== null ? (int) $value : $default;
    }

    // -------------------------------------------------------------------------
    // Flash Message
    // -------------------------------------------------------------------------

    /**
     * Set flash message untuk request berikutnya
     * Type: 'success' | 'error' | 'warning' | 'info'
     */
    protected function setFlash(string $type, string $message): void
    {
        $_SESSION['flash'] = ['type' => $type, 'message' => $message];
    }

    /**
     * Ambil dan hapus flash message (one-time read)
     */
    protected function getFlash(): ?array
    {
        $flash = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);
        return $flash;
    }

    // -------------------------------------------------------------------------
    // CSRF
    // -------------------------------------------------------------------------

    /**
     * Verifikasi CSRF token dari POST request.
     *
     * Panggil di awal setiap method yang menerima POST:
     *   $this->verifyCsrf();
     *
     * Jika gagal: set flash error → redirect kembali ke halaman sebelumnya → exit.
     */
    protected function verifyCsrf(?string $fallbackUrl = null): void
    {
        $tokenPost    = trim($_POST['csrf_token'] ?? '');
        $tokenSession = $_SESSION['csrf_token']   ?? '';

        // hash_equals mencegah timing-attack
        $valid = $tokenPost !== ''
              && $tokenSession !== ''
              && hash_equals($tokenSession, $tokenPost);

        if (!$valid) {
            // Rotate token agar tidak bisa di-replay
            unset($_SESSION['csrf_token']);

            $back = $fallbackUrl
                 ?? ($_SERVER['HTTP_REFERER'] ?? ($_ENV['APP_URL'] ?? '') . '/');

            $this->setFlash('error', 'Sesi keamanan kedaluwarsa. Silakan muat ulang halaman dan coba lagi.');
            $this->redirect($back);
            // redirect() sudah exit — baris ini tidak akan tercapai
        }

        // Rotate setelah sukses (Double-Submit / one-time token)
        unset($_SESSION['csrf_token']);
    }

    /**
     * Generate hidden input CSRF untuk dipakai di form view.
     *
     * Cara pakai di view:
     *   <?= $this->csrfField() ?>
     *
     * Atau pakai variabel yang sudah di-inject oleh render():
     *   <input type="hidden" name="csrf_token"
     *          value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8') ?>">
     */
    protected function csrfField(): string
    {
        $token = Middleware::generateCsrfToken();
        return '<input type="hidden" name="csrf_token" value="'
             . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">';
    }
}
