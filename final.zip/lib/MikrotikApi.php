<?php
/**
 * Lightweight MikroTik RouterOS API Wrapper Client
 */

declare(strict_types=1);

namespace Lib;

use RuntimeException;

class MikrotikAPI
{
    private $socket;
    private bool $connected = false;

    /**
     * Membuka koneksi socket ke API MikroTik
     */
    public function connect(string $host, string $user, string $pass, int $port = 8728): bool
    {
        $this->socket = @fsockopen($host, $port, $errno, $errstr, 5);
        if (!$this->socket) {
            throw new RuntimeException("Koneksi API MikroTik Gagal: {$errstr} ({$errno})");
        }

        $this->connected = true;
        
        // Proses Login RouterOS v6 / v7 Compatibility
        $response = $this->comm('/login', false);
        if (isset($response[0]['ret'])) {
            // Skema login enkripsi MD5 (RouterOS lama)
            $md5Data = md5(chr(0) . $pass . pack('H*', $response[0]['ret']));
            $loginResult = $this->comm('/login', [
                '=name=' . $user,
                '=response=' . '00' . $md5Data
            ]);
        } else {
            // Skema login langsung (RouterOS v6.43+ & v7+)
            $loginResult = $this->comm('/login', [
                '=name=' . $user,
                '=password=' . $pass
            ]);
        }

        if (isset($loginResult[0]['!trap'])) {
            $this->disconnect();
            return false;
        }

        return true;
    }

    /**
     * Eksekusi Perintah API MikroTik
     */
    public function comm(string $command, array|bool $paramArray = []): array
    {
        if (!$this->connected) {
            return [];
        }

        $this->writeStr($command);

        if (is_array($paramArray)) {
            foreach ($paramArray as $param) {
                $this->writeStr($param);
            }
        }

        $this->writeStr(''); // Berikan baris kosong sebagai penanda akhir perintah

        return $this->readResponse();
    }

    private function writeStr(string $string): void
    {
        $length = strlen($string);
        if ($length < 0x80) {
            fwrite($this->socket, chr($length));
        } elseif ($length < 0x4000) {
            $length |= 0x8000;
            fwrite($this->socket, chr(($length >> 8) & 0xFF) . chr($length & 0xFF));
        }
        fwrite($this->socket, $string);
    }

    private function readResponse(): array
    {
        $response = [];
        $currentPacket = [];

        while (true) {
            $byte = ord(fread($this->socket, 1));
            $length = 0;

            if (($byte & 0x80) === 0x00) {
                $length = $byte;
            } elseif (($byte & 0xC0) === 0x80) {
                $byte2 = ord(fread($this->socket, 1));
                $length = (($byte & 0x3F) << 8) + $byte2;
            }

            if ($length === 0) {
                break;
            }

            $word = fread($this->socket, $length);
            
            if ($word === '!done') {
                if (!empty($currentPacket)) {
                    $response[] = $currentPacket;
                }
                break;
            }

            if ($word === '!re' || $word === '!trap') {
                if (!empty($currentPacket)) {
                    $response[] = $currentPacket;
                    $currentPacket = [];
                }
                if ($word === '!trap') {
                    $currentPacket['!trap'] = true;
                }
            } elseif (str_starts_with($word, '=')) {
                $parts = explode('=', $word, 3);
                if (count($parts) === 3) {
                    $currentPacket[$parts[1]] = $parts[2];
                }
            }
        }

        return $response;
    }

    public function disconnect(): void
    {
        if ($this->socket) {
            fclose($this->socket);
        }
        $this->connected = false;
    }

    public function __destruct()
    {
        $this->disconnect();
    }
}
