<?php
/**
 * Cronjob: Generate tagihan otomatis setiap bulan
 * Schedule: Tanggal 1 setiap bulan jam 00:05 (5 0 1 * *)
 *
 * Usage:
 *   php cron/generate.php                    Normal mode
 *   php cron/generate.php --verbose          Detail output
 *   php cron/generate.php --dry-run          Simulasi tanpa insert
 *   php cron/generate.php --period 2026-07   Periode spesifik
 */

declare(strict_types=1);

define('APP_ROOT', dirname(__DIR__));

// Autoloader
$autoloaderFile = APP_ROOT . '/config/Autoloader.php';
if (!file_exists($autoloaderFile)) {
    fwrite(STDERR, "ERROR: Autoloader tidak ditemukan\n");
    exit(1);
}
require_once $autoloaderFile;
\Config\Autoloader::register();

// Environment
require_once APP_ROOT . '/config/env.php';

// Timezone
date_default_timezone_set($_ENV['APP_TIMEZONE'] ?? 'Asia/Jakarta');

// ================================================================
//  PARSE ARGUMENTS
// ================================================================

$args = $argv ?? [];
$isVerbose = in_array('--verbose', $args) || in_array('-v', $args);
$isQuiet   = in_array('--quiet', $args)   || in_array('-q', $args);
$isDryRun  = in_array('--dry-run', $args);

// Periode custom (format: YYYY-MM)
$customPeriod = null;
foreach ($args as $i => $arg) {
    if ($i === 0) continue;
    if (preg_match('/^\d{4}-\d{2}$/', $arg)) {
        $customPeriod = $arg;
        break;
    }
    if ($arg === '--period' && isset($args[$i + 1])) {
        if (preg_match('/^\d{4}-\d{2}$/', $args[$i + 1])) {
            $customPeriod = $args[$i + 1];
        }
    }
}

// ================================================================
//  HELPER FUNCTIONS
// ================================================================

function out(string $msg, bool $quiet = false): void
{
    if (!$quiet) echo $msg . "\n";
}

function cronLog(string $level, string $message): void
{
    $logDir = APP_ROOT . '/storage/logs';
    if (!is_dir($logDir)) mkdir($logDir, 0755, true);

    $timestamp  = date('Y-m-d H:i:s');
    $logMessage = "[{$timestamp}] [{$level}] {$message}";

    file_put_contents(
        $logDir . '/generate_tagihan.log',
        $logMessage . "\n",
        FILE_APPEND
    );

    global $isVerbose, $isQuiet;
    if ($isVerbose && !$isQuiet) {
        echo $logMessage . "\n";
    }
}

function getLockFile(string $lockName): string
{
    $lockDir = APP_ROOT . '/storage/locks';
    if (!is_dir($lockDir)) mkdir($lockDir, 0755, true);
    return $lockDir . '/' . $lockName . '.lock';
}

function isRunning(string $lockName): bool
{
    $lockFile = getLockFile($lockName);
    if (!file_exists($lockFile)) return false;

    $pid = (int)trim(file_get_contents($lockFile));
    if ($pid > 0 && is_dir("/proc/{$pid}")) {
        return true;
    }

    @unlink($lockFile);
    return false;
}

function setLock(string $lockName): void
{
    $lockFile = getLockFile($lockName);
    file_put_contents($lockFile, (string)getmypid());
}

function removeLock(string $lockName): void
{
    $lockFile = getLockFile($lockName);
    @unlink($lockFile);
}

function formatRupiah(float $amount): string
{
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

// ================================================================
//  MAIN
// ================================================================

$startTime = microtime(true);
$ts        = date('Y-m-d H:i:s');
$lockName  = 'generate_tagihan';

out("=== generate_tagihan START: {$ts} ===", $isQuiet);

if ($isDryRun) {
    out("⚠️  DRY-RUN MODE: Tidak ada data yang akan di-insert!", false);
    out("", false);
}

// Cek double-run
if (isRunning($lockName)) {
    cronLog('WARNING', "Script {$lockName} sudah berjalan. Skip.");
    out("WARNING: Script sudah berjalan di proses lain. Exit.", $isQuiet);
    exit(0);
}

setLock($lockName);
cronLog('INFO', "Mulai generate tagihan bulanan...");

try {
    $db = \Config\Database::getConnection();
    out("Database connected", $isQuiet);

    // Tentukan periode
    $now   = new DateTimeImmutable();
    $periode   = $customPeriod ?? $now->format('Y-m');
    $jatuhTempo = $now->modify('+7 days')->format('Y-m-d');

    out("Periode     : {$periode}", $isQuiet);
    out("Jatuh Tempo : {$jatuhTempo}", $isQuiet);
    out("", $isQuiet);

    // ================================================================
    //  Ambil pelanggan aktif yang belum punya tagihan bulan ini
    // ================================================================

    $stmt = $db->prepare("
        SELECT p.id, p.user_id, p.nama_lengkap, p.mac_address,
               pk.id AS paket_id, pk.nama_paket, pk.harga
        FROM pelanggan p
        JOIN paket pk ON p.paket_id = pk.id
        WHERE p.id NOT IN (
            SELECT pelanggan_id FROM tagihan 
            WHERE periode_bulan = :periode
        )
    ");
    $stmt->execute([':periode' => $periode]);
    $pelanggans = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Cek pelanggan yang sudah punya tagihan bulan ini
    $stmtExisting = $db->prepare("
        SELECT t.pelanggan_id, p.nama_lengkap, t.total, t.status
        FROM tagihan t
        JOIN pelanggan p ON t.pelanggan_id = p.id
        WHERE t.periode_bulan = :periode
    ");
    $stmtExisting->execute([':periode' => $periode]);
    $existing = $stmtExisting->fetchAll(PDO::FETCH_ASSOC);

    out("Pelanggan aktif tanpa tagihan : " . count($pelanggans), $isQuiet);
    out("Pelanggan sudah punya tagihan  : " . count($existing), $isQuiet);
    out("", $isQuiet);

    if (empty($pelanggans)) {
        cronLog('INFO', "Semua pelanggan sudah punya tagihan periode {$periode}.");
        out("✅ Semua pelanggan sudah punya tagihan bulan ini. Tidak ada yang perlu di-generate.", $isQuiet);
        
        // Tampilkan yang sudah ada
        if ($isVerbose && !empty($existing)) {
            out("\nTagihan yang sudah ada untuk {$periode}:", false);
            out(str_repeat('-', 80), false);
            out(sprintf("  %-5s | %-20s | %-15s | %s", 'ID', 'Nama', 'Total', 'Status'), false);
            out(str_repeat('-', 80), false);
            foreach ($existing as $e) {
                $nama = mb_substr($e['nama_lengkap'], 0, 18);
                out(sprintf(
                    "  %-5s | %-20s | %-15s | %s",
                    $e['pelanggan_id'],
                    $nama,
                    formatRupiah((float)$e['total']),
                    $e['status']
                ), false);
            }
            out(str_repeat('-', 80), false);
        }
        
        removeLock($lockName);
        exit(0);
    }

    // Tampilkan daftar yang akan di-generate
    if ($isVerbose) {
        out("Daftar pelanggan yang akan di-generate tagihan:", false);
        out(str_repeat('-', 80), false);
        out(sprintf("  %-5s | %-20s | %-15s | %s", 'ID', 'Nama', 'Paket', 'Harga'), false);
        out(str_repeat('-', 80), false);

        foreach ($pelanggans as $p) {
            $nama  = mb_substr($p['nama_lengkap'], 0, 18);
            $paket = mb_substr($p['nama_paket'], 0, 13);
            out(sprintf(
                "  %-5s | %-20s | %-15s | %s",
                $p['id'],
                $nama,
                $paket,
                formatRupiah((float)$p['harga'])
            ), false);
        }
        out(str_repeat('-', 80), false);
        out("", false);
    }

    // ================================================================
    //  INSERT TAGIHAN
    // ================================================================

    $successCount = 0;
    $errorCount   = 0;
    $totalAmount  = 0;

    $insert = $db->prepare("
        INSERT INTO tagihan 
        (pelanggan_id, tipe, deskripsi, periode_bulan, total, jumlah, jatuh_tempo, status)
        VALUES (?, 'paket', ?, ?, ?, ?, ?, 'unpaid')
    ");

    foreach ($pelanggans as $p) {
        try {
            $pelangganId = (int)$p['id'];
            $harga       = (float)$p['harga'];
            $namaPaket   = $p['nama_paket'] ?? 'Paket';
            $deskripsi   = "Tagihan {$namaPaket} - {$periode}";

            if (!$isDryRun) {
                $insert->execute([
                    $pelangganId,
                    $deskripsi,
                    $periode,
                    $harga,
                    $harga,         // jumlah = total
                    $jatuhTempo,
                ]);
            }

            $successCount++;
            $totalAmount += $harga;

            $nama = mb_substr($p['nama_lengkap'], 0, 20);
            cronLog('INFO', "✓ Tagihan dibuat: {$nama} | {$namaPaket} | " . formatRupiah($harga));
            
            if ($isVerbose) {
                $prefix = $isDryRun ? '[DRY] ' : '';
                out("  {$prefix}✓ {$nama} — {$namaPaket} — " . formatRupiah($harga), false);
            }

        } catch (Throwable $e) {
            $errorCount++;
            $nama = $p['nama_lengkap'] ?? "ID {$p['id']}";
            cronLog('ERROR', "✗ Pelanggan ID {$p['id']} ({$nama}): " . $e->getMessage());
            out("  ✗ FAILED: {$nama} — {$e->getMessage()}", $isQuiet);
        }
    }

    // ================================================================
    //  HASIL
    // ================================================================

    $elapsed = round(microtime(true) - $startTime, 2);

    out("", $isQuiet);
    out("=== HASIL ===", $isQuiet);
    if ($isDryRun) {
        out("  ⚠️  DRY-RUN: Tidak ada data yang di-insert", $isQuiet);
    }
    out("  Periode          : {$periode}", $isQuiet);
    out("  Berhasil         : {$successCount} tagihan", $isQuiet);
    out("  Gagal            : {$errorCount}", $isQuiet);
    out("  Total tagihan    : " . formatRupiah($totalAmount), $isQuiet);
    out("  Jatuh tempo      : {$jatuhTempo}", $isQuiet);
    out("  Durasi           : {$elapsed} detik", $isQuiet);

    cronLog('INFO', "Selesai. {$successCount} tagihan dibuat, {$errorCount} gagal. Total: " . formatRupiah($totalAmount));

    exit($errorCount > 0 ? 1 : 0);

} catch (Throwable $e) {
    $errorMsg = "Fatal error: " . $e->getMessage();
    cronLog('ERROR', $errorMsg);
    out("\nFATAL ERROR: {$e->getMessage()}", false);

    if ($isVerbose) {
        out("  File: {$e->getFile()}:{$e->getLine()}", false);
        out("  Trace:", false);
        foreach (explode("\n", $e->getTraceAsString()) as $line) {
            out("    {$line}", false);
        }
    }

    exit(1);

} finally {
    removeLock($lockName);
}
