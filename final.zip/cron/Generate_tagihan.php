#!/usr/bin/env php
<?php

declare(strict_types=1);

/**
 * cron/generate_tagihan.php
 *
 * Auto-generate tagihan bulanan semua pelanggan aktif.
 * Dijalankan tanggal 1 tiap bulan jam 07:00.
 *
 * Crontab:
 *   0 7 1 * * /usr/bin/php /var/www/billing-isp/cron/generate_tagihan.php >> /dev/null 2>&1
 *
 * Manual test:
 *   php cron/generate_tagihan.php
 *   php cron/generate_tagihan.php --periode=2026-07   (paksa periode tertentu)
 *   php cron/generate_tagihan.php --dry-run
 */

require_once __DIR__ . '/bootstrap.php';

use Model\UsageLogModel;

$argv    = $argv ?? [];
$dryRun  = in_array('--dry-run', $argv, true);
$periode = null;
foreach ($argv as $arg) {
    if (str_starts_with($arg, '--periode=')) {
        $periode = substr($arg, 10); // format: YYYY-MM
    }
}

// Tentukan periode tagihan
if ($periode) {
    [$yr, $mo] = explode('-', $periode);
} else {
    $yr = date('Y');
    $mo = date('m');
}
$periodeBulan  = sprintf('%04d-%02d', $yr, $mo);    // YYYY-MM
$jatuhTempoTgl = 5; // ambil dari setting jika ada

cronLog("=== generate_tagihan START periode=$periodeBulan" . ($dryRun ? ' [DRY-RUN]' : '') . " ===");

$timer    = startTimer();
$logModel = new UsageLogModel();

try {
    $db = \Config\Database::getConnection();

    // Ambil semua pelanggan aktif beserta harga paketnya
    $stmt = $db->query("
        SELECT p.id AS pelanggan_id, p.tgl_jatuh_tempo,
               pk.harga, pk.nama_paket, p.nama_lengkap
        FROM pelanggan p
        JOIN paket pk ON p.paket_id = pk.id
        JOIN users  u  ON p.user_id  = u.id
        WHERE u.status = 'active'
    ");
    $pelangganList = $stmt->fetchAll(\PDO::FETCH_ASSOC);
    cronLog("Pelanggan aktif: " . count($pelangganList));

    $generated = 0;
    $skipped   = 0;
    $errors    = [];

    foreach ($pelangganList as $p) {
        try {
            // Cek apakah tagihan periode ini sudah ada
            $cek = $db->prepare("
                SELECT id FROM tagihan
                WHERE pelanggan_id = :pid AND periode_bulan = :per
            ");
            $cek->execute([':pid' => $p['pelanggan_id'], ':per' => $periodeBulan]);

            if ($cek->fetch()) {
                $skipped++;
                if (in_array('--verbose', $argv, true)) {
                    cronLog("  SKIP [{$p['pelanggan_id']}] {$p['nama_lengkap']} — sudah ada");
                }
                continue;
            }

            // Hitung tanggal jatuh tempo
            $tgl = (int) ($p['tgl_jatuh_tempo'] ?? $jatuhTempoTgl);
            $jatuhTempo = date('Y-m-d', mktime(0, 0, 0, (int)$mo, $tgl, (int)$yr));

            if (!$dryRun) {
                $ins = $db->prepare("
                    INSERT INTO tagihan
                        (pelanggan_id, periode_bulan, total, jumlah, status, jatuh_tempo)
                    VALUES
                        (:pid, :per, :total, :jumlah, 'unpaid', :jt)
                ");
                $ins->execute([
                    ':pid'    => $p['pelanggan_id'],
                    ':per'    => $periodeBulan,
                    ':total'  => $p['harga'],
                    ':jumlah' => $p['harga'],
                    ':jt'     => $jatuhTempo,
                ]);
            }

            $generated++;
            cronLog("  + [{$p['pelanggan_id']}] {$p['nama_lengkap']} — {$p['nama_paket']} Rp " .
                    number_format((float)$p['harga'], 0, ',', '.') .
                    " | JT: $jatuhTempo");

        } catch (\Throwable $e) {
            $errors[] = "[{$p['pelanggan_id']}] {$e->getMessage()}";
            cronLog("  ERROR [{$p['pelanggan_id']}]: " . $e->getMessage());
        }
    }

    $ms = elapsedMs($timer);
    cronLog(sprintf("Selesai: generated=%d skipped=%d error=%d | durasi=%dms",
        $generated, $skipped, count($errors), $ms));

    if (!$dryRun) {
        $status = count($errors) > 0 && $generated === 0 ? 'error' : 'ok';
        $msg    = "periode=$periodeBulan generated=$generated skipped=$skipped";
        $logModel->logCron('generate_tagihan', $status, $generated, $ms, $msg);
    }

    $exitCode = 0;

} catch (\Throwable $e) {
    $ms = elapsedMs($timer);
    cronLog("FATAL: " . $e->getMessage());
    $logModel->logCron('generate_tagihan', 'error', 0, $ms, $e->getMessage());
    $exitCode = 1;
}

cronLog("=== generate_tagihan END (exit={$exitCode}) ===");
exit($exitCode);
