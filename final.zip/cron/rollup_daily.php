<?php
/**
 * Cronjob: Rollup & Reconcile daily usage data
 * Schedule: Setiap hari jam 00:15 (15 0 * * *)
 *
 * Fungsi:
 *   1. Rekonsiliasi usage_log → usage_daily_summary (backup jika collect_usage terlewat)
 *   2. Pruning log lama (>30 hari)
 *   3. Laporan ringkasan
 *
 * Usage:
 *   php cron/rollup_daily.php              Normal mode
 *   php cron/rollup_daily.php --verbose    Detail output
 *   php cron/rollup_daily.php 2026-06-19   Tanggal spesifik
 */

declare(strict_types=1);

define('APP_ROOT', dirname(__DIR__));

require_once APP_ROOT . '/config/Autoloader.php';
\Config\Autoloader::register();

require_once APP_ROOT . '/config/env.php';
date_default_timezone_set($_ENV['APP_TIMEZONE'] ?? 'Asia/Jakarta');

// ================================================================
//  PARSE ARGUMENTS
// ================================================================

$args = $argv ?? [];
$isVerbose = in_array('--verbose', $args) || in_array('-v', $args);
$isQuiet   = in_array('--quiet', $args)   || in_array('-q', $args);

function out(string $msg, bool $quiet = false): void {
    if (!$quiet) echo $msg . "\n";
}

function formatBytes(int $bytes): string {
    if ($bytes <= 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = min((int)floor(log($bytes, 1024)), count($units) - 1);
    return round($bytes / (1024 ** $i), 2) . ' ' . $units[$i];
}

// ================================================================
//  MAIN
// ================================================================

$startTime = microtime(true);
$ts = date('Y-m-d H:i:s');

out("[{$ts}] === rollup_daily START ===", $isQuiet);

try {
    $db = \Config\Database::getConnection();
    out("Database connected", $isQuiet);

    // Tentukan target tanggal
    $targetDate = date('Y-m-d', strtotime('-1 day')); // default: kemarin
    // Cek argumen tanggal (skip flag)
    foreach ($args as $i => $arg) {
        if ($i === 0) continue; // skip argv[0] = nama file
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $arg)) {
            $targetDate = $arg;
            break;
        }
    }

    out("Target date: {$targetDate}", $isQuiet);
    out("", $isQuiet);

    // ================================================================
    //  1. REKONSILIASI: usage_log → usage_daily_summary
    // ================================================================

    out("--- STEP 1: Rekonsiliasi usage_log → daily_summary ---", $isQuiet);

    // Ambil semua pelanggan yang punya log di tanggal target
    $stmt = $db->prepare("
        SELECT 
            ul.pelanggan_id,
            p.nama_lengkap,
            p.mac_address,
            MAX(ul.rx_bytes) AS rx_bytes,
            MAX(ul.tx_bytes) AS tx_bytes,
            SUM(CASE WHEN ul.is_online = 1 THEN 1 ELSE 0 END) AS online_snapshots,
            MAX(ul.rx_mbps) AS peak_rx_mbps,
            MAX(ul.tx_mbps) AS peak_tx_mbps
        FROM usage_log ul
        JOIN pelanggan p ON ul.pelanggan_id = p.id
        WHERE DATE(ul.snapshot_at) = :tgl
        GROUP BY ul.pelanggan_id
    ");
    $stmt->execute([':tgl' => $targetDate]);
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $reconciled = 0;
    $updated    = 0;

    foreach ($logs as $log) {
        $pelId      = (int)$log['pelanggan_id'];
        $rxBytes    = (int)$log['rx_bytes'];
        $txBytes    = (int)$log['tx_bytes'];
        $peakRxBps  = (int)round(((float)$log['peak_rx_mbps']) * 1_000_000);
        $peakTxBps  = (int)round(((float)$log['peak_tx_mbps']) * 1_000_000);
        $onlineMin  = (int)$log['online_snapshots'] * 5; // asumsi snapshot tiap 5 menit

        if ($rxBytes <= 0 && $txBytes <= 0) continue;

        // Upsert ke usage_daily_summary
        $upsert = $db->prepare("
            INSERT INTO usage_daily_summary 
                (pelanggan_id, tanggal, rx_bytes, tx_bytes, total_bytes, online_minutes, peak_rx_bps, peak_tx_bps)
            VALUES 
                (:pid, :tgl, :rx, :tx, :total, :om, :prx, :ptx)
            ON DUPLICATE KEY UPDATE
                rx_bytes       = GREATEST(rx_bytes, VALUES(rx_bytes)),
                tx_bytes       = GREATEST(tx_bytes, VALUES(tx_bytes)),
                total_bytes    = GREATEST(total_bytes, VALUES(total_bytes)),
                online_minutes = GREATEST(online_minutes, VALUES(online_minutes)),
                peak_rx_bps    = GREATEST(peak_rx_bps, VALUES(peak_rx_bps)),
                peak_tx_bps    = GREATEST(peak_tx_bps, VALUES(peak_tx_bps))
        ");
        
        $upsert->execute([
            ':pid'   => $pelId,
            ':tgl'   => $targetDate,
            ':rx'    => $rxBytes,
            ':tx'    => $txBytes,
            ':total' => $rxBytes + $txBytes,
            ':om'    => $onlineMin,
            ':prx'   => $peakRxBps,
            ':ptx'   => $peakTxBps,
        ]);

        $reconciled++;
        if ($upsert->rowCount() > 0) $updated++;

        if ($isVerbose) {
            $nama = mb_substr($log['nama_lengkap'], 0, 20);
            out(sprintf(
                "  %-5d | %-20s | RX: %-12s | TX: %-12s | Total: %-12s",
                $pelId, $nama,
                formatBytes($rxBytes),
                formatBytes($txBytes),
                formatBytes($rxBytes + $txBytes)
            ), false);
        }
    }

    out("  Reconciled: {$reconciled} pelanggan, {$updated} updated", $isQuiet);
    out("", $isQuiet);

    // ================================================================
    //  2. PRUNING: Hapus usage_log lama (>30 hari)
    // ================================================================

    out("--- STEP 2: Pruning log lama (>30 hari) ---", $isQuiet);

    $pruneBefore = date('Y-m-d', strtotime('-30 days'));

    $pruneStmt = $db->prepare("
        DELETE FROM usage_log 
        WHERE snapshot_at < :before
    ");
    $pruneStmt->execute([':before' => $pruneBefore . ' 00:00:00']);
    $pruned = $pruneStmt->rowCount();

    out("  Pruned: {$pruned} log records (before {$pruneBefore})", $isQuiet);
    out("", $isQuiet);

    // ================================================================
    //  3. LAPORAN RINGKASAN
    // ================================================================

    out("--- STEP 3: Ringkasan {$targetDate} ---", $isQuiet);

    // Ambil ringkasan dari daily_summary
    $summaryStmt = $db->prepare("
        SELECT 
            ds.pelanggan_id,
            p.nama_lengkap,
            ds.rx_bytes,
            ds.tx_bytes,
            ds.total_bytes,
            ds.online_minutes,
            ds.peak_rx_bps,
            ds.peak_tx_bps
        FROM usage_daily_summary ds
        JOIN pelanggan p ON ds.pelanggan_id = p.id
        WHERE ds.tanggal = :tgl
        ORDER BY ds.total_bytes DESC
    ");
    $summaryStmt->execute([':tgl' => $targetDate]);
    $summaries = $summaryStmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($summaries)) {
        out("  Tidak ada data untuk tanggal {$targetDate}", $isQuiet);
    } else {
        $totalRx = 0;
        $totalTx = 0;

        if ($isVerbose) {
            out(str_repeat('-', 90), false);
            out(sprintf(
                "  %-5s | %-20s | %-12s | %-12s | %-12s | %s",
                'ID', 'Nama', 'RX', 'TX', 'Total', 'Online'
            ), false);
            out(str_repeat('-', 90), false);
        }

        foreach ($summaries as $s) {
            $totalRx += (int)$s['rx_bytes'];
            $totalTx += (int)$s['tx_bytes'];

            if ($isVerbose) {
                $nama = mb_substr($s['nama_lengkap'], 0, 18);
                $onlineH = intdiv((int)$s['online_minutes'], 60);
                $onlineM = (int)$s['online_minutes'] % 60;
                out(sprintf(
                    "  %-5s | %-20s | %-12s | %-12s | %-12s | %dh %dm",
                    $s['pelanggan_id'], $nama,
                    formatBytes((int)$s['rx_bytes']),
                    formatBytes((int)$s['tx_bytes']),
                    formatBytes((int)$s['total_bytes']),
                    $onlineH, $onlineM
                ), false);
            }
        }

        if ($isVerbose) {
            out(str_repeat('-', 90), false);
        }

        out(sprintf(
            "  TOTAL: %d pelanggan | RX: %s | TX: %s | Grand Total: %s",
            count($summaries),
            formatBytes($totalRx),
            formatBytes($totalTx),
            formatBytes($totalRx + $totalTx)
        ), $isQuiet);
    }

    // ================================================================
    //  4. STATISTIK DATABASE
    // ================================================================

    if ($isVerbose) {
        out("", false);
        out("--- Statistik Database ---", false);
        
        $countLog = $db->query("SELECT COUNT(*) AS cnt FROM usage_log")->fetch(PDO::FETCH_ASSOC);
        $countDaily = $db->query("SELECT COUNT(*) AS cnt FROM usage_daily_summary")->fetch(PDO::FETCH_ASSOC);
        $countMonthly = $db->query("SELECT COUNT(*) AS cnt FROM usage_monthly_summary")->fetch(PDO::FETCH_ASSOC);
        
        out("  usage_log              : " . ($countLog['cnt'] ?? 0) . " records", false);
        out("  usage_daily_summary    : " . ($countDaily['cnt'] ?? 0) . " records", false);
        out("  usage_monthly_summary  : " . ($countMonthly['cnt'] ?? 0) . " records", false);
    }

    $elapsed = round(microtime(true) - $startTime, 2);
    out("", $isQuiet);
    out("[{$ts}] === rollup_daily END ({$elapsed}s) ===", $isQuiet);

} catch (Throwable $e) {
    out("\nFATAL ERROR: {$e->getMessage()}", false);
    if ($isVerbose) {
        out("  File: {$e->getFile()}:{$e->getLine()}", false);
        out("  Trace:\n" . $e->getTraceAsString(), false);
    }
    exit(1);
}
