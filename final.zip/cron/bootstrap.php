<?php

declare(strict_types=1);

/**
 * cron/bootstrap.php
 *
 * Diinclude oleh semua cron script.
 * Memuat autoloader, env, dan memastikan hanya bisa dijalankan via CLI.
 */

// ── Keamanan: hanya boleh jalan lewat CLI ──────────────────────────────────
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("Forbidden: cron hanya bisa dijalankan via CLI.\n");
}

// ── Root project (satu level di atas folder cron/) ────────────────────────
define('ROOT_PATH', dirname(__DIR__));

// ── Load .env ─────────────────────────────────────────────────────────────
$envFile = ROOT_PATH . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (str_starts_with(trim($line), '#') || !str_contains($line, '=')) continue;
        [$key, $val] = explode('=', $line, 2);
        $_ENV[trim($key)] = trim($val);
        putenv(trim($key) . '=' . trim($val));
    }
}

// ── Autoloader ────────────────────────────────────────────────────────────
require_once ROOT_PATH . '/config/Autoloader.php';

// ── Timezone ──────────────────────────────────────────────────────────────
date_default_timezone_set($_ENV['APP_TIMEZONE'] ?? 'Asia/Jakarta');

// ── Helper: cetak ke stdout + simpan ke file log ──────────────────────────
function cronLog(string $msg): void
{
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $msg;
    echo $line . PHP_EOL;

    $logFile = ROOT_PATH . '/Storage/Logs/cron_' . date('Y-m-d') . '.log';
    file_put_contents($logFile, $line . PHP_EOL, FILE_APPEND);
}

// ── Helper: ukur waktu eksekusi ──────────────────────────────────────────
function startTimer(): float
{
    return microtime(true);
}

function elapsedMs(float $start): int
{
    return (int) round((microtime(true) - $start) * 1000);
}
