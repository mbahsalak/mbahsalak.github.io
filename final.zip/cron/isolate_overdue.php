<?php
/**
 * Cronjob: Isolir pelanggan yang tagihannya overdue
 * Schedule: Setiap hari jam 08:00 (0 8 * * *)
 * 
 * Usage:
 *   php cron/isolate_overdue.php              Normal mode
 *   php cron/isolate_overdue.php --verbose    Dengan output detail
 */

declare(strict_types=1);

define('APP_ROOT', dirname(__DIR__));

// Autoloader
$autoloaderFile = APP_ROOT . '/config/Autoloader.php';
if (!file_exists($autoloaderFile)) {
    fwrite(STDERR, "ERROR: Autoloader tidak ditemukan\n");
    exit(1);
}
require_once $autoloaderFile;
\Config\Autoloader::register();

// Environment
require_once APP_ROOT . '/config/env.php';

// Timezone
date_default_timezone_set($_ENV['APP_TIMEZONE'] ?? 'Asia/Jakarta');

// ================================================================
//  PARSE ARGUMENTS
// ================================================================

$args = $argv ?? [];
$isVerbose = in_array('--verbose', $args) || in_array('-v', $args);
$isQuiet = in_array('--quiet', $args) || in_array('-q', $args);

// ================================================================
//  HELPER FUNCTIONS
// ================================================================

function out(string $msg, bool $quiet = false): void
{
    if (!$quiet) echo $msg . "\n";
}

function cronLog(string $level, string $message): void
{
    $logDir = APP_ROOT . '/storage/logs';
    if (!is_dir($logDir)) mkdir($logDir, 0755, true);
    
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[{$timestamp}] [{$level}] {$message}";
    
    file_put_contents(
        $logDir . '/isolate_overdue.log',
        $logMessage . "\n",
        FILE_APPEND
    );
    
    global $isVerbose, $isQuiet;
    if ($isVerbose && !$isQuiet) {
        echo $logMessage . "\n";
    }
}

function getLockFile(string $lockName): string
{
    $lockDir = APP_ROOT . '/storage/locks';
    if (!is_dir($lockDir)) mkdir($lockDir, 0755, true);
    return $lockDir . '/' . $lockName . '.lock';
}

function isRunning(string $lockName): bool
{
    $lockFile = getLockFile($lockName);
    if (!file_exists($lockFile)) return false;
    
    $pid = (int)trim(file_get_contents($lockFile));
    // Kompatibel Termux: cek /proc/[pid]
    if ($pid > 0 && is_dir("/proc/{$pid}")) {
        return true;
    }
    
    @unlink($lockFile);
    return false;
}

function setLock(string $lockName): void
{
    $lockFile = getLockFile($lockName);
    file_put_contents($lockFile, (string)getmypid());
}

function removeLock(string $lockName): void
{
    $lockFile = getLockFile($lockName);
    @unlink($lockFile);
}

// ================================================================
//  MAIN
// ================================================================

$startTime = microtime(true);
$ts = date('Y-m-d H:i:s');
$lockName = 'isolate_overdue';

out("=== isolate_overdue START: {$ts} ===", $isQuiet);

if (isRunning($lockName)) {
    cronLog('WARNING', "Script {$lockName} sudah berjalan. Skip.");
    out("WARNING: Script sudah berjalan di proses lain. Exit.", $isQuiet);
    exit(0);
}

setLock($lockName);
cronLog('INFO', "Mulai isolir pelanggan overdue...");

try {
    $db = \Config\Database::getConnection();
    out("Database connected", $isQuiet);
    
    // Pastikan Service ada, jika tidak ada kita lewati isolasi mikrotik
    $mikrotikService = null;
    if (class_exists('\Service\MikrotikService')) {
        $mikrotikService = new \Service\MikrotikService();
        out("MikroTik service initialized", $isQuiet);
    } else {
        out("WARNING: \Service\MikrotikService tidak ditemukan, skip isolasi router.", $isQuiet);
    }
    
    // ✅ FIX 1: Gunakan kolom 'total' (bukan total_bayar)
    $stmt = $db->query("
        SELECT t.id, t.pelanggan_id, p.mac_address, p.nama_lengkap, t.jatuh_tempo, t.total
        FROM tagihan t
        JOIN pelanggan p ON t.pelanggan_id = p.id
        WHERE t.status = 'unpaid'
          AND t.jatuh_tempo < DATE_SUB(CURDATE(), INTERVAL 3 DAY)
        ORDER BY t.jatuh_tempo ASC
    ");
    
    $overdue = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($overdue)) {
        cronLog('INFO', "Tidak ada pelanggan overdue.");
        out("Tidak ada pelanggan overdue.", $isQuiet);
        exit(0);
    }
    
    out("Ditemukan " . count($overdue) . " pelanggan overdue", $isQuiet);
    
    if ($isVerbose) {
        out("\nDAFTAR PELANGGAN OVERDUE:", false);
        out(str_repeat('-', 80), false);
        out(sprintf("  %-5s | %-20s | %-12s | %-15s", 'ID', 'Nama', 'Jatuh Tempo', 'Total'), false);
        out(str_repeat('-', 80), false);
        
        foreach ($overdue as $t) {
            $nama = mb_substr($t['nama_lengkap'], 0, 18);
            out(sprintf(
                "  %-5s | %-20s | %-12s | Rp %-12s",
                $t['id'],
                $nama,
                $t['jatuh_tempo'],
                number_format((float)$t['total'], 0, ',', '.')
            ), false);
        }
        out(str_repeat('-', 80), false);
        out("", false);
    }
    
    $isolatedCount = 0;
    $failedCount = 0;
    
    foreach ($overdue as $t) {
        try {
            $pelangganId = (int)$t['pelanggan_id'];
            $nama = $t['nama_lengkap'];
            $mac = strtoupper(trim($t['mac_address'] ?? ''));
            
            // Isolir di MikroTik
            if ($mikrotikService && !empty($mac)) {
                $mikrotikService->isolateCustomer($mac);
                cronLog('INFO', "MikroTik: Isolir MAC {$mac} untuk {$nama}");
            } elseif (empty($mac)) {
                cronLog('WARNING', "MAC kosong untuk pelanggan ID {$pelangganId} ({$nama})");
            }
            
            // Update status user menjadi inactive (jika tabel users ada dan berelasi)
            try {
                $updateStmt = $db->prepare("
                    UPDATE users u
                    JOIN pelanggan p ON u.id = p.user_id
                    SET u.status = 'inactive'
                    WHERE p.id = ?
                ");
                $updateStmt->execute([$pelangganId]);
            } catch (Throwable $e) {
                // Abaikan jika tabel users tidak punya kolom status atau tidak ada relasi
                cronLog('WARNING', "Gagal update status user: " . $e->getMessage());
            }
            
            // ✅ FIX 2: Gunakan status 'suspend' (karena ENUM tidak punya 'isolated')
            $updateTagihan = $db->prepare("
                UPDATE tagihan 
                SET status = 'suspend' 
                WHERE id = ?
            ");
            $updateTagihan->execute([$t['id']]);
            
            $isolatedCount++;
            cronLog('INFO', "✓ Suspend: {$nama} (Tagihan ID: {$t['id']}, Jatuh Tempo: {$t['jatuh_tempo']})");
            out("  ✓ Suspended: {$nama}", $isQuiet);
            
        } catch (Throwable $e) {
            $failedCount++;
            $errorMsg = "Gagal isolir pelanggan ID {$t['pelanggan_id']}: " . $e->getMessage();
            cronLog('ERROR', $errorMsg);
            out("  ✗ FAILED: {$t['nama_lengkap']} - {$e->getMessage()}", $isQuiet);
        }
    }
    
    $elapsed = round(microtime(true) - $startTime, 2);
    
    out("", $isQuiet);
    out("=== HASIL ===", $isQuiet);
    out("  Berhasil disuspend : {$isolatedCount}", $isQuiet);
    out("  Gagal              : {$failedCount}", $isQuiet);
    out("  Durasi             : {$elapsed} detik", $isQuiet);
    
    cronLog('INFO', "Selesai. {$isolatedCount} disuspend, {$failedCount} gagal. Durasi: {$elapsed}s");
    
    exit($failedCount > 0 ? 1 : 0);
    
} catch (Throwable $e) {
    $errorMsg = "Fatal error: " . $e->getMessage();
    cronLog('ERROR', $errorMsg);
    out("\nFATAL ERROR: {$e->getMessage()}", false);
    
    if ($isVerbose) {
        out("  File: {$e->getFile()}:{$e->getLine()}", false);
        out("  Trace:", false);
        foreach (explode("\n", $e->getTraceAsString()) as $line) {
            out("    {$line}", false);
        }
    }
    
    exit(1);
    
} finally {
    removeLock($lockName);
}
