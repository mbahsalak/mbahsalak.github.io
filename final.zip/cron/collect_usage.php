#!/usr/bin/env php
<?php
/**
 * cron/collect_usage.php
 * AUTO-FORCE MODE: Selalu collect ulang, hapus snapshot lama otomatis
 */

declare(strict_types=1);

define('APP_ROOT', dirname(__DIR__));

// Autoloader
$autoloaderFile = APP_ROOT . '/config/Autoloader.php';
if (!file_exists($autoloaderFile)) {
    fwrite(STDERR, "ERROR: Autoloader tidak ditemukan\n");
    exit(1);
}
require_once $autoloaderFile;
\Config\Autoloader::register();

// Environment
require_once APP_ROOT . '/config/env.php';

// Timezone
date_default_timezone_set($_ENV['APP_TIMEZONE'] ?? 'Asia/Jakarta');

// Error reporting
error_reporting(E_ALL & ~E_DEPRECATED & ~E_USER_DEPRECATED);
ini_set('display_errors', '1');

// ================================================================
//  PARSE ARGUMENTS
// ================================================================

$args       = $argv ?? [];
$isVerbose  = in_array('--verbose', $args) || in_array('-v', $args);
$isNoForce  = in_array('--no-force', $args);
$isHelp     = in_array('--help', $args) || in_array('-h', $args);
$isQuiet    = in_array('--quiet', $args) || in_array('-q', $args);

if ($isHelp) {
    echo "collect_usage.php - MikroTik Usage Collector (Auto-Force Mode)\n\n";
    echo "  php collect_usage.php              Auto-force (default)\n";
    echo "  php collect_usage.php --verbose    Detail per pelanggan\n";
    echo "  php collect_usage.php --no-force   Mode normal (skip check)\n";
    echo "  php collect_usage.php --quiet      Hanya output error\n";
    exit(0);
}

// ================================================================
//  HELPERS
// ================================================================

function out(string $msg, bool $quiet = false): void
{
    if (!$quiet) echo $msg . "\n";
}

function logToFile(string $message): void
{
    $logDir = APP_ROOT . '/storage/logs';
    if (!is_dir($logDir)) mkdir($logDir, 0755, true);
    file_put_contents(
        $logDir . '/collect_usage.log',
        '[' . date('Y-m-d H:i:s') . '] ' . $message . "\n",
        FILE_APPEND
    );
}

function formatBytes(int $bytes): string
{
    if ($bytes <= 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = min((int)floor(log($bytes, 1024)), count($units) - 1);
    return round($bytes / (1024 ** $i), 2) . ' ' . $units[$i];
}

// ================================================================
//  MAIN
// ================================================================

$startTime = microtime(true);
$ts        = date('Y-m-d H:i:s');
$mode      = $isNoForce ? 'NORMAL' : 'AUTO-FORCE';

out("=== collect_usage START: {$ts} ===", $isQuiet);
out("  Mode: {$mode}", $isQuiet);

try {
    // Database
    out("Menghubungkan ke database...", $isQuiet);
    $db = \Config\Database::getConnection();
    out("  OK", $isQuiet);

    // Auto-create tabel Monthly
    $db->exec("CREATE TABLE IF NOT EXISTS usage_monthly_summary (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        pelanggan_id INT NOT NULL,
        month_year VARCHAR(7) NOT NULL,
        total_rx_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
        total_tx_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
        total_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
        days_active INT NOT NULL DEFAULT 0,
        last_seen DATETIME DEFAULT NULL,
        last_updated DATETIME DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_pelanggan_month (pelanggan_id, month_year),
        INDEX idx_month_year (month_year),
        INDEX idx_pelanggan (pelanggan_id),
        FOREIGN KEY (pelanggan_id) REFERENCES pelanggan(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // ✅ Auto-create tabel Daily
    $db->exec("CREATE TABLE IF NOT EXISTS usage_daily_summary (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        pelanggan_id INT NOT NULL,
        tanggal DATE NOT NULL,
        rx_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
        tx_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
        total_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
        last_seen DATETIME DEFAULT NULL,
        last_updated DATETIME DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_pelanggan_tanggal (pelanggan_id, tanggal),
        INDEX idx_tanggal (tanggal),
        INDEX idx_pelanggan_daily (pelanggan_id),
        FOREIGN KEY (pelanggan_id) REFERENCES pelanggan(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // AUTO-FORCE: Hapus snapshot lama hari ini
    if (!$isNoForce) {
        out("Membersihkan snapshot lama hari ini...", $isQuiet);
        $deleted = $db->exec("
            DELETE FROM usage_log 
            WHERE DATE(snapshot_at) = CURDATE() 
            AND TIME(snapshot_at) < TIME(NOW() - INTERVAL 55 MINUTE)
        ");
        out("  {$deleted} snapshot lama dihapus", $isQuiet);
    }

    // Service
    out("Menghubungkan ke MikroTik...", $isQuiet);
    $service = new \Service\UsageLogService($db);

    if ($isVerbose) {
        out("  URL  : " . ($_ENV['MIKROTIK_URL'] ?? 'default'), false);
        out("  User : " . ($_ENV['MIKROTIK_USER'] ?? 'default'), false);
    }

    // Collect
    out("Mengumpulkan data...", $isQuiet);

    if (!$isNoForce) {
        $result = $service->collectAllForce();
    } else {
        $result = $service->collectAll();
    }

    // ============================================================
    // ✅ SINKRONISASI DAILY SUMMARY (BULK SQL - SANGAT CEPAT)
    // ============================================================
    out("Menyinkronkan daily summary (hari ini)...", $isQuiet);
    $db->exec("
        INSERT INTO usage_daily_summary (pelanggan_id, tanggal, rx_bytes, tx_bytes, total_bytes, last_seen, last_updated)
        SELECT 
            pelanggan_id, 
            CURDATE(), 
            COALESCE(SUM(rx_bytes), 0), 
            COALESCE(SUM(tx_bytes), 0), 
            COALESCE(SUM(rx_bytes), 0) + COALESCE(SUM(tx_bytes), 0),
            MAX(snapshot_at),
            NOW()
        FROM usage_log
        WHERE DATE(snapshot_at) = CURDATE()
        GROUP BY pelanggan_id
        ON DUPLICATE KEY UPDATE
            rx_bytes = VALUES(rx_bytes),
            tx_bytes = VALUES(tx_bytes),
            total_bytes = VALUES(total_bytes),
            last_seen = VALUES(last_seen),
            last_updated = NOW()
    ");
    out("  OK", $isQuiet);

    $elapsed = round(microtime(true) - $startTime, 2);

    // ============================================================
    //  HASIL
    // ============================================================

    out("", $isQuiet);
    out("=== HASIL ===", $isQuiet);
    out("  Berhasil : {$result['ok']}", $isQuiet);
    out("  Skip     : {$result['skip']}", $isQuiet);
    out("  Error    : {$result['error']}", $isQuiet);
    out("  Durasi   : {$elapsed} detik", $isQuiet);

    // Detail (Hanya jika --verbose)
    if ($isVerbose) {
        out("", false);
        out("DETAIL PER PELANGGAN:", false);
        out(str_repeat('-', 75), false);
        out(sprintf(
            "  %-20s | %-14s | %-14s | %s",
            'Nama', 'Hari Ini', 'Bulan Ini', 'Status'
        ), false);
        out(str_repeat('-', 75), false);

        $stmt = $db->query("
            SELECT p.id, p.nama_lengkap, p.mac_address
            FROM pelanggan p
            WHERE p.mac_address IS NOT NULL AND TRIM(p.mac_address) != ''
            ORDER BY p.id
        ");
        $pelanggans = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($pelanggans as $pel) {
            $pelId = (int)$pel['id'];

            // ✅ Ambil data Hari Ini dari daily_summary yang baru di-sync
            $dStmt = $db->prepare("
                SELECT COALESCE(total_bytes, 0) AS total 
                FROM usage_daily_summary 
                WHERE pelanggan_id = :id AND tanggal = CURDATE()
            ");
            $dStmt->execute([':id' => $pelId]);
            $dRow = $dStmt->fetch(PDO::FETCH_ASSOC);
            $todayTotal = $dRow ? (int)$dRow['total'] : 0;

            // Bulan ini
            $ym = date('Y-m');
            $mStmt = $db->prepare("
                SELECT COALESCE(total_bytes, 0) AS total
                FROM usage_monthly_summary
                WHERE pelanggan_id = :id AND month_year = :ym
            ");
            $mStmt->execute([':id' => $pelId, ':ym' => $ym]);
            $mRow = $mStmt->fetch(PDO::FETCH_ASSOC);
            $monthTotal = $mRow ? (int)$mRow['total'] : 0;

            // Status
            $sStmt = $db->prepare("
                SELECT is_online FROM usage_log
                WHERE pelanggan_id = :id ORDER BY snapshot_at DESC LIMIT 1
            ");
            $sStmt->execute([':id' => $pelId]);
            $sRow = $sStmt->fetch(PDO::FETCH_ASSOC);
            $status = ($sRow && $sRow['is_online']) ? 'ONLINE' : 'OFFLINE';

            $nama = mb_substr($pel['nama_lengkap'], 0, 18);
            out(sprintf(
                "  %-20s | %-14s | %-14s | %s",
                $nama,
                formatBytes($todayTotal),
                formatBytes($monthTotal),
                $status
            ), false);
        }

        out(str_repeat('-', 75), false);
    }

    // Errors
    if (!empty($result['errors'])) {
        out("", $isQuiet);
        out("ERRORS:", $isQuiet);
        foreach ($result['errors'] as $err) {
            out("  - {$err}", $isQuiet);
        }
    }

    // Log
    logToFile(sprintf('[%s] OK:%d SKIP:%d ERR:%d DUR:%.2fs',
        $mode, $result['ok'], $result['skip'], $result['error'], $elapsed
    ));

    out("", $isQuiet);
    out("Selesai! ({$elapsed}s)", $isQuiet);

    exit(($result['error'] > 0 && $result['ok'] === 0) ? 1 : 0);

} catch (\Throwable $e) {
    $ts = date('Y-m-d H:i:s');
    out("", $isQuiet);
    out("FATAL ERROR: {$e->getMessage()}", $isQuiet);

    if ($isVerbose) {
        out("  File: {$e->getFile()}:{$e->getLine()}", false);
        out("  Trace:", false);
        foreach (explode("\n", $e->getTraceAsString()) as $line) {
            out("    {$line}", false);
        }
    }

    logToFile("FATAL: {$e->getMessage()} in {$e->getFile()}:{$e->getLine()}");
    exit(1);
}
