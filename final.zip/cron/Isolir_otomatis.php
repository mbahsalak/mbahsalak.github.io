#!/usr/bin/env php
<?php

declare(strict_types=1);

/**
 * cron/isolir_otomatis.php
 *
 * Auto-isolir pelanggan yang tagihan sudah jatuh tempo & belum bayar.
 * Dijalankan setiap hari jam 08:00.
 *
 * Crontab:
 *   0 8 * * * /usr/bin/php /var/www/billing-isp/cron/isolir_otomatis.php >> /dev/null 2>&1
 *
 * Manual test:
 *   php cron/isolir_otomatis.php
 *   php cron/isolir_otomatis.php --dry-run
 */

require_once __DIR__ . '/bootstrap.php';

use Service\MikrotikService;
use Model\UsageLogModel;

$argv   = $argv ?? [];
$dryRun = in_array('--dry-run', $argv, true);

cronLog("=== isolir_otomatis START" . ($dryRun ? ' [DRY-RUN]' : '') . " ===");

$timer    = startTimer();
$mikrotik = new MikrotikService();
$logModel = new UsageLogModel();

try {
    $db = \Config\Database::getConnection();

    // Pelanggan dengan tagihan jatuh tempo & belum bayar
    $stmt = $db->query("
        SELECT DISTINCT
            p.id                  AS pelanggan_id,
            p.nama_lengkap,
            p.username_mikrotik,
            p.mac_address,
            u.status              AS user_status,
            t.periode_bulan,
            t.jatuh_tempo,
            t.total
        FROM tagihan t
        JOIN pelanggan p ON t.pelanggan_id = p.id
        JOIN users     u ON p.user_id      = u.id
        WHERE t.status       = 'unpaid'
          AND t.jatuh_tempo  < CURDATE()
          AND u.status       = 'active'
        ORDER BY t.jatuh_tempo
    ");
    $jatuhTempo = $stmt->fetchAll(\PDO::FETCH_ASSOC);

    cronLog("Pelanggan jatuh tempo: " . count($jatuhTempo));

    $isolired  = 0;
    $alreadyOff = 0;
    $errors    = [];

    foreach ($jatuhTempo as $row) {
        $uid      = $row['pelanggan_id'];
        $nama     = $row['nama_lengkap'];
        $username = $row['username_mikrotik'] ?? '';

        try {
            if (empty($username)) {
                cronLog("  SKIP [$uid] $nama — tidak punya username_mikrotik");
                continue;
            }

            // Cek apakah PPPoE secret sudah di-disable
            $secrets = $mikrotik->getPppoeSecrets();
            $secret  = collect($secrets ?? [])->firstWhere('name', $username)
                       ?? null;

            // Fungsi bantu cari secret tanpa laravel collection
            $secretFound = null;
            foreach (($secrets ?? []) as $s) {
                if (($s['name'] ?? '') === $username) {
                    $secretFound = $s;
                    break;
                }
            }

            if ($secretFound && ($secretFound['disabled'] ?? 'false') === 'true') {
                $alreadyOff++;
                continue;
            }

            if (!$dryRun && !empty($username)) {
                // Disable PPPoE secret di MikroTik
                $ok = $mikrotik->togglePppoeSecret($username);
                if (!$ok) {
                    throw new \RuntimeException("togglePppoeSecret gagal untuk $username");
                }
                // Kick sesi aktif jika ada
                $mikrotik->kickPppoeSession($username);
            }

            $isolired++;
            cronLog(sprintf(
                "  ISOLIR [%d] %s (username: %s) — tagihan %s Rp %s JT: %s",
                $uid, $nama, $username,
                $row['periode_bulan'],
                number_format((float)$row['total'], 0, ',', '.'),
                $row['jatuh_tempo']
            ));

        } catch (\Throwable $e) {
            $errors[] = "[$uid] $nama: {$e->getMessage()}";
            cronLog("  ERROR [$uid] $nama: " . $e->getMessage());
        }
    }

    $ms = elapsedMs($timer);
    cronLog(sprintf(
        "Selesai: isolir=%d already_off=%d error=%d | durasi=%dms",
        $isolired, $alreadyOff, count($errors), $ms
    ));

    if (!$dryRun) {
        $status = count($errors) > 0 && $isolired === 0 ? 'error' : 'ok';
        $msg    = "isolir=$isolired already_off=$alreadyOff errors=" . count($errors);
        $logModel->logCron('isolir_otomatis', $status, $isolired, $ms, $msg);
    }

    $exitCode = 0;

} catch (\Throwable $e) {
    $ms = elapsedMs($timer);
    cronLog("FATAL: " . $e->getMessage());
    $logModel->logCron('isolir_otomatis', 'error', 0, $ms, $e->getMessage());
    $exitCode = 1;
}

cronLog("=== isolir_otomatis END (exit={$exitCode}) ===");
exit($exitCode);
