<?php

namespace App\Cron;

class CronManager {
    
    private array $jobs;

    public function __construct() {
        // Daftarkan semua script cron di sini
        $this->jobs = [
            'collect_usage'    => ['file' => 'collect_usage.php',    'desc' => 'Snapshot bandwidth tiap jam'],
            'rollup_daily'     => ['file' => 'rollup_daily.php',     'desc' => 'Agregasi usage_log harian'],
            'generate_tagihan' => ['file' => 'Generate_tagihan.php', 'desc' => 'Buat tagihan bulanan'],
            'isolir_otomatis'  => ['file' => 'Isolir_otomatis.php',  'desc' => 'Isolir pelanggan jatuh tempo'],
            'prune_old'        => ['file' => 'Prune_old.php',        'desc' => 'Hapus log data lama']
        ];
    }

    // Menampilkan daftar job (php cron.php --list)
    public function listJobs() {
        $result = [];
        foreach ($this->jobs as $name => $info) {
            $result[] = [
                'status'   => 'success', 
                'job'      => $name, 
                'message'  => $info['desc'] . ' (' . $info['file'] . ')', 
                'duration' => 0.0
            ];
        }
        return $result;
    }

    // Menjalankan job spesifik (php cron.php --job=nama_job)
    public function runJob($jobName, $force = false) {
        if (!isset($this->jobs[$jobName])) {
            throw new \RuntimeException("Job '$jobName' tidak terdaftar.");
        }

        $fileName = $this->jobs[$jobName]['file'];
        $filePath = __DIR__ . '/../../cron/' . $fileName; // Sesuaikan path jika letak file berbeda
        
        // Fallback pencarian file (karena di Termux kadang huruf besar/kecil berpengaruh)
        if (!file_exists($filePath)) {
            $filePath = __DIR__ . '/' . $fileName;
        }

        if (!file_exists($filePath)) {
            return [['status' => 'error', 'job' => $jobName, 'message' => "File $fileName tidak ditemukan", 'duration' => 0.0]];
        }

        $start = microtime(true);
        
        // Mengeksekusi file PHP sebagai command terpisah agar tidak kena limitasi exit()
        $command = "php " . escapeshellarg($filePath);
        if ($force) {
            // Pass argument --force atau sejenisnya ke skrip jika didukung
            $command .= " --dry-run"; // Sebagai contoh, kita lempar dry-run jika dipaksa via terminal
        }

        exec($command, $output, $returnVar);
        $duration = microtime(true) - $start;

        $status = ($returnVar === 0) ? 'success' : 'error';
        $msg = ($returnVar === 0) ? 'Berhasil dieksekusi' : 'Gagal (Exit code: ' . $returnVar . ')';

        return [
            ['status' => $status, 'job' => $jobName, 'message' => $msg, 'duration' => $duration]
        ];
    }

    // Menjalankan penjadwalan jika tidak ada argumen spesifik (php cron.php)
    public function runScheduled($force = false) {
        // Karena sistemmu menggunakan file CRONTAB.txt untuk jadwal spesifik, 
        // eksekusi utama sebaiknya dikembalikan ke pesan info ini.
        return [
            ['status' => 'skipped', 'job' => 'Cron Router', 'message' => 'Gunakan --job=nama_job untuk run manual', 'duration' => 0.01]
        ];
    }
}
