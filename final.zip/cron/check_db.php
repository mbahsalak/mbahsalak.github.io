<?php
declare(strict_types=1);
define('APP_ROOT', dirname(__DIR__));
require_once APP_ROOT . '/config/Autoloader.php';
\Config\Autoloader::register();
require_once APP_ROOT . '/config/env.php';
date_default_timezone_set($_ENV['APP_TIMEZONE'] ?? 'Asia/Jakarta');
error_reporting(E_ALL & ~E_DEPRECATED);

$db = \Config\Database::getConnection();

// Ambil 1 pelanggan sample
$pel = $db->query("SELECT id, nama_lengkap, mac_address FROM pelanggan WHERE mac_address IS NOT NULL AND TRIM(mac_address) != '' LIMIT 1")->fetch(PDO::FETCH_ASSOC);

if (!$pel) {
    echo "❌ Tidak ada pelanggan dengan MAC address\n";
    exit;
}

echo "=== PELANGGAN: {$pel['nama_lengkap']} ({$pel['mac_address']}) ===\n\n";

$client = new \Core\MikrotikClient(
    $_ENV['MIKROTIK_URL']  ?? 'http://localhost:5000',
    $_ENV['MIKROTIK_USER'] ?? 'admin',
    $_ENV['MIKROTIK_PASS'] ?? 'admin123',
    (int)($_ENV['MIKROTIK_TIMEOUT'] ?? 10)
);

$mac = strtoupper($pel['mac_address']);

echo "--- getClientUsageToday({$mac}) ---\n";
try {
    $today = $client->getClientUsageToday($mac);
    echo json_encode($today, JSON_PRETTY_PRINT) . "\n\n";
} catch (\Throwable $e) {
    echo "❌ ERROR: {$e->getMessage()}\n\n";
}

echo "--- getClientUsageMonth({$mac}) ---\n";
try {
    $month = $client->getClientUsageMonth($mac);
    echo json_encode($month, JSON_PRETTY_PRINT) . "\n\n";
} catch (\Throwable $e) {
    echo "❌ ERROR: {$e->getMessage()}\n\n";
}

echo "--- SEMUA METHOD DI MikrotikClient ---\n";
foreach (get_class_methods($client) as $m) {
    echo "  • {$m}()\n";
}
echo "\n";
