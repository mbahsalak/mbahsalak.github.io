<?php declare(strict_types=1);
/**
 * cron/cron.php - Entry Point Cron Job FiberNet
 * Struktur: final/cron/ (semua file cron di sini)
 */

$isCli = (php_sapi_name() === 'cli');

if (!$isCli) {
    $secret = getenv('CRON_SECRET') ?: 'FIBERNET_CRON_SECRET_2024';
    $key    = $_GET['key'] ?? $_SERVER['HTTP_X_CRON_KEY'] ?? '';
    if (!hash_equals($secret, $key)) {
        http_response_code(403);
        die(json_encode(['error' => 'Forbidden']));
    }
    header('Content-Type: application/json; charset=utf-8');
}

@set_time_limit(600);
error_reporting(E_ALL);
ini_set('display_errors', $isCli ? '1' : '0');

// Base path = folder cron/ itu sendiri
define('CRON_PATH', __DIR__);
define('BASE_PATH', dirname(__DIR__)); // parent = final/
define('STORAGE_PATH', BASE_PATH . '/storage');

foreach ([STORAGE_PATH, STORAGE_PATH.'/logs', STORAGE_PATH.'/cron', STORAGE_PATH.'/backups'] as $d) {
    if (!is_dir($d)) @mkdir($d, 0755, true);
}

// Bootstrap config dari parent directory
try {
    $dbConfig = BASE_PATH . '/config/database.php';
    if (file_exists($dbConfig)) require_once $dbConfig;
    
    // Autoload: cari class DI DALAM folder cron/ ini
    spl_autoload_register(function ($class) {
        // Support namespace App\Cron\ maupun tanpa namespace
        $clean = str_replace('App\\Cron\\', '', $class);
        $file = CRON_PATH . '/' . str_replace('\\', '/', $clean) . '.php';
        if (file_exists($file)) {
            require_once $file;
            return true;
        }
        // Fallback: coba langsung nama class tanpa namespace
        $file2 = CRON_PATH . '/' . str_replace('\\', '/', $class) . '.php';
        if (file_exists($file2)) {
            require_once $file2;
            return true;
        }
        return false;
    });
} catch (\Throwable $e) {
    $msg = "BOOTSTRAP ERROR: " . $e->getMessage();
    if ($isCli) { fwrite(STDERR, $msg."\n"); exit(1); }
    http_response_code(500);
    die(json_encode(['error' => $msg]));
}

// Parse arguments
$options = ['job' => null, 'force' => false, 'list' => false];
if ($isCli) {
    foreach ($argv as $arg) {
        if (str_starts_with($arg, '--job=')) $options['job'] = substr($arg, 6);
        if ($arg === '--force') $options['force'] = true;
        if ($arg === '--list')  $options['list']  = true;
    }
} else {
    $options['job']   = $_GET['job']   ?? null;
    $options['force'] = isset($_GET['force']);
    $options['list']  = isset($_GET['list']);
}

// Eksekusi
try {
    // Coba dengan namespace dulu, lalu tanpa namespace
    $managerClass = class_exists('App\\Cron\\CronManager') 
        ? 'App\\Cron\\CronManager' 
        : (class_exists('CronManager') ? 'CronManager' : null);
    
    if (!$managerClass) {
        throw new \RuntimeException(
            "CronManager tidak ditemukan di " . CRON_PATH . "/\n" .
            "Pastikan file CronManager.php ada di dalam folder cron/"
        );
    }
    
    $cron = new $managerClass();
    
    if ($options['list'])       $result = $cron->listJobs();
    elseif ($options['job'])    $result = $cron->runJob($options['job'], $options['force']);
    else                        $result = $cron->runScheduled($options['force']);
    
    if ($isCli) {
        echo "\n" . str_repeat('=', 60) . "\n";
        echo " FIBERNET CRON | " . date('Y-m-d H:i:s') . "\n";
        echo str_repeat('=', 60) . "\n";
        foreach ($result as $r) {
            $icon = match($r['status']) { 'success'=>'✓', 'skipped'=>'○', default=>'✗' };
            printf("  [%s] %-28s %s (%.2fs)\n", $icon, $r['job'], $r['message'], $r['duration']);
        }
        echo str_repeat('=', 60) . "\n\n";
    } else {
        echo json_encode(['success'=>true, 'timestamp'=>date('Y-m-d H:i:s'), 'results'=>$result], JSON_PRETTY_PRINT);
    }
} catch (\Throwable $e) {
    $err = $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine();
    @file_put_contents(STORAGE_PATH.'/logs/cron_error.log', "[".date('Y-m-d H:i:s')."] ".$err."\n", FILE_APPEND|LOCK_EX);
    if ($isCli) { fwrite(STDERR, "FATAL: ".$err."\n"); exit(1); }
    http_response_code(500);
    echo json_encode(['success'=>false, 'error'=>$err]);
}
