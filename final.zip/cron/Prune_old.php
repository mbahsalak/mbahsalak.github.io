#!/usr/bin/env php
<?php

declare(strict_types=1);

/**
 * cron/prune_old.php
 *
 * Hapus snapshot usage_log & cron_log lama supaya DB tidak membengkak.
 * Dijalankan seminggu sekali, misalnya Minggu jam 02:00.
 *
 * Crontab:
 *   0 2 * * 0 /usr/bin/php /var/www/billing-isp/cron/prune_old.php >> /dev/null 2>&1
 *
 * Manual test:
 *   php cron/prune_old.php
 *   php cron/prune_old.php --keep-snapshots=30 --keep-cronlogs=14
 */

require_once __DIR__ . '/bootstrap.php';

use Service\UsageLogService;
use Model\UsageLogModel;

$argv = $argv ?? [];

// Parse argumen opsional
$keepSnapshots = 90;
$keepCronLogs  = 30;
foreach ($argv as $arg) {
    if (str_starts_with($arg, '--keep-snapshots=')) {
        $keepSnapshots = max(7, (int) substr($arg, 17));
    }
    if (str_starts_with($arg, '--keep-cronlogs=')) {
        $keepCronLogs = max(7, (int) substr($arg, 16));
    }
}

cronLog("=== prune_old START (snapshots>{$keepSnapshots}d, cronlogs>{$keepCronLogs}d) ===");

$timer    = startTimer();
$service  = new UsageLogService();
$logModel = new UsageLogModel();

try {
    $deleted  = $service->pruneOld($keepSnapshots, $keepCronLogs);
    $ms       = elapsedMs($timer);

    cronLog("Dihapus: usage_log={$deleted['snapshots']} baris, cron_log={$deleted['cron_logs']} baris");
    cronLog("Selesai: durasi={$ms}ms");

    $msg = "snapshots={$deleted['snapshots']} cron_logs={$deleted['cron_logs']}";
    $logModel->logCron('prune_old', 'ok', $deleted['snapshots'] + $deleted['cron_logs'], $ms, $msg);
    $exitCode = 0;

} catch (\Throwable $e) {
    $ms = elapsedMs($timer);
    cronLog("FATAL: " . $e->getMessage());
    $logModel->logCron('prune_old', 'error', 0, $ms, $e->getMessage());
    $exitCode = 1;
}

cronLog("=== prune_old END (exit={$exitCode}) ===");
exit($exitCode);
