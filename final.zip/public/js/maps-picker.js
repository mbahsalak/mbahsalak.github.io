/**
 * Maps Picker
 * Drop marker untuk memilih lokasi
 */

function initMapPicker(config) {
    const {
        containerId,
        latInput,
        lngInput,
        coordDisplay,
        defaultLat,
        defaultLng,
        defaultZoom,
        coverageCheckUrl,
        coverageResultId,
        getLocationBtnId
    } = config;
    
    // Initialize map
    const map = L.map(containerId).setView([defaultLat, defaultLng], defaultZoom);
    
    L.tileLayer('[{s}.tile.openstreetmap.org](https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png)', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    
    // Marker
    let marker = null;
    
    // Set marker position
    function setMarkerPosition(lat, lng) {
        if (marker) {
            marker.setLatLng([lat, lng]);
        } else {
            marker = L.marker([lat, lng], { draggable: true }).addTo(map);
            
            // Draggable marker
            marker.on('dragend', function(e) {
                const pos = e.target.getLatLng();
                updateCoordinates(pos.lat, pos.lng);
            });
        }
        
        updateCoordinates(lat, lng);
        map.setView([lat, lng], Math.max(map.getZoom(), 15));
    }
    
    // Update coordinate inputs and display
    function updateCoordinates(lat, lng) {
        document.getElementById(latInput).value = lat.toFixed(6);
        document.getElementById(lngInput).value = lng.toFixed(6);
        document.getElementById(coordDisplay).textContent = `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
        
        // Check coverage if URL provided
        if (coverageCheckUrl && coverageResultId) {
            checkCoverage(lat, lng);
        }
    }
    
    // Check coverage area
    async function checkCoverage(lat, lng) {
        const resultDiv = document.getElementById(coverageResultId);
        resultDiv.classList.remove('hidden');
        resultDiv.innerHTML = '<p class="text-gray-600">Memeriksa jangkauan...</p>';
        
        try {
            const response = await fetch(coverageCheckUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: `lat=${lat}&lng=${lng}`
            });
            
            const data = await response.json();
            
            if (data.covered) {
                resultDiv.className = 'p-3 rounded-lg bg-green-100 text-green-700';
                resultDiv.innerHTML = `
                    <p class="font-medium">✓ Lokasi Anda tercover!</p>
                    <p class="text-sm">ODP terdekat: ${data.odp} (${data.distance})</p>
                `;
            } else {
                resultDiv.className = 'p-3 rounded-lg bg-yellow-100 text-yellow-700';
                resultDiv.innerHTML = `
                    <p class="font-medium">⚠ ${data.message}</p>
                    <p class="text-sm">Tim kami akan melakukan survey untuk pengecekan lebih lanjut.</p>
                `;
            }
        } catch (error) {
            resultDiv.className = 'p-3 rounded-lg bg-gray-100 text-gray-600';
            resultDiv.innerHTML = '<p>Tidak dapat memeriksa jangkauan</p>';
        }
    }
    
    // Click on map to place marker
    map.on('click', function(e) {
        setMarkerPosition(e.latlng.lat, e.latlng.lng);
    });
    
    // Get current location button
    if (getLocationBtnId) {
        document.getElementById(getLocationBtnId).addEventListener('click', function() {
            if (!navigator.geolocation) {
                alert('Geolocation tidak didukung oleh browser Anda');
                return;
            }
            
            this.disabled = true;
            this.textContent = 'Mencari lokasi...';
            
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    setMarkerPosition(position.coords.latitude, position.coords.longitude);
                    this.disabled = false;
                    this.textContent = '📍 Gunakan Lokasi Saya Saat Ini';
                },
                (error) => {
                    let message = 'Tidak dapat mendapatkan lokasi Anda';
                    switch (error.code) {
                        case error.PERMISSION_DENIED:
                            message = 'Akses lokasi ditolak. Silakan izinkan akses lokasi di browser Anda.';
                            break;
                        case error.POSITION_UNAVAILABLE:
                            message = 'Informasi lokasi tidak tersedia.';
                            break;
                        case error.TIMEOUT:
                            message = 'Permintaan lokasi timeout.';
                            break;
                    }
                    alert(message);
                    this.disabled = false;
                    this.textContent = '📍 Gunakan Lokasi Saya Saat Ini';
                },
                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 0
                }
            );
        });
    }
    
    // Load existing coordinates if any
    const existingLat = document.getElementById(latInput).value;
    const existingLng = document.getElementById(lngInput).value;
    
    if (existingLat && existingLng) {
        setMarkerPosition(parseFloat(existingLat), parseFloat(existingLng));
    }
    
    return map;
}
