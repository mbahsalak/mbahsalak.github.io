/* =============================================================
   public/js/main.js
   Billing ISP Professional — Native PHP 8.4
   Berisi:
     1. Global Helpers  (escHtml, loadScript, showToast, liveClock)
     2. Dashboard Charts (Pendapatan Bar + Paket Donut)
     3. Dashboard Customizer (toggle widget + drag reorder)
     4. Bandwidth Real-Time Chart (polling /mikrotik/bandwidth)
   ============================================================= */

'use strict';

/* =============================================================
   1. GLOBAL HELPERS
   ============================================================= */

/**
 * Escape HTML — cegah XSS saat render string ke innerHTML.
 */
function escHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

/**
 * Muat script eksternal secara async, panggil callback setelah loaded.
 */
function loadScript(src, callback) {
    const s    = document.createElement('script');
    s.src      = src;
    s.async    = true;
    s.onload   = callback;
    s.onerror  = () => console.error('[loadScript] Gagal memuat:', src);
    document.head.appendChild(s);
}

/**
 * Tampilkan toast notifikasi di pojok kanan bawah.
 * @param {string} message  - Teks pesan
 * @param {'success'|'error'|'info'|'warning'} type
 * @param {number} duration - Durasi tampil dalam ms (default 3000)
 */
function showToast(message, type = 'info', duration = 3000) {
    let container = document.getElementById('toastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastContainer';
        container.style.cssText = [
            'position:fixed', 'bottom:24px', 'right:24px',
            'z-index:9999', 'display:flex', 'flex-direction:column',
            'gap:8px', 'pointer-events:none',
        ].join(';');
        document.body.appendChild(container);
    }

    const colorMap = {
        success: { bg: '#dcfce7', border: '#16a34a', text: '#166534', icon: '✓' },
        error:   { bg: '#fee2e2', border: '#dc2626', text: '#991b1b', icon: '✕' },
        warning: { bg: '#fef3c7', border: '#d97706', text: '#92400e', icon: '!' },
        info:    { bg: '#dbeafe', border: '#2563eb', text: '#1e40af', icon: 'i' },
    };
    const c = colorMap[type] || colorMap.info;

    const toast = document.createElement('div');
    toast.style.cssText = [
        `background:${c.bg}`, `border:1px solid ${c.border}`, `color:${c.text}`,
        'border-radius:8px', 'padding:10px 16px', 'font-size:13px', 'font-weight:500',
        'display:flex', 'align-items:center', 'gap:8px',
        'box-shadow:0 4px 12px rgba(0,0,0,.1)',
        'pointer-events:auto', 'max-width:320px',
        'animation:toastIn .25s ease',
    ].join(';');
    toast.innerHTML = `<span style="font-weight:700;font-size:15px">${c.icon}</span>${escHtml(message)}`;

    // Inject keyframes sekali saja
    if (!document.getElementById('toastKeyframes')) {
        const style = document.createElement('style');
        style.id = 'toastKeyframes';
        style.textContent = `
            @keyframes toastIn  { from { opacity:0; transform:translateY(12px); } to { opacity:1; transform:none; } }
            @keyframes toastOut { from { opacity:1; } to { opacity:0; transform:translateY(8px); } }
        `;
        document.head.appendChild(style);
    }

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'toastOut .25s ease forwards';
        toast.addEventListener('animationend', () => toast.remove(), { once: true });
    }, duration);
}

/**
 * Jam digital live di #liveClock (format HH:MM:SS).
 */
(function initLiveClock() {
    const el = document.getElementById('liveClock');
    if (!el) return;
    const tick = () => {
        el.textContent = new Date().toLocaleTimeString('id-ID', {
            hour: '2-digit', minute: '2-digit', second: '2-digit',
        });
    };
    tick();
    setInterval(tick, 1000);
})();


/* =============================================================
   2. DASHBOARD CHARTS  (Pendapatan & Distribusi Paket)
   Membutuhkan window.DASHBOARD_DATA yang di-inject oleh index.php
   ============================================================= */

(function initCharts() {
    // Cek apakah data tersedia dan Chart.js ada / perlu di-load
    const hasPendapatan = document.getElementById('chartPendapatan');
    const hasPaket      = document.getElementById('chartPaket');
    if (!hasPendapatan && !hasPaket) return;

    function buildCharts() {
        if (!window.Chart) return;

        const dd      = window.DASHBOARD_DATA || {};
        const isDark  = document.documentElement.getAttribute('data-theme') === 'dark';
        const grid    = isDark ? 'rgba(255,255,255,.06)' : 'rgba(0,0,0,.05)';
        const txtClr  = isDark ? '#94a3b8' : '#64748b';

        // ── Bar chart Pendapatan Bulanan ─────────────────────────────────
        if (hasPendapatan && dd.labels) {
            new window.Chart(hasPendapatan, {
                type: 'bar',
                data: {
                    labels:   dd.labels   || [],
                    datasets: [
                        {
                            label:           'Lunas',
                            data:            dd.pendapatan || [],
                            backgroundColor: '#22c55e',
                            borderRadius:    4,
                            borderSkipped:   false,
                        },
                        {
                            label:           'Belum Lunas',
                            data:            dd.unpaid || [],
                            backgroundColor: '#f59e0b',
                            borderRadius:    4,
                            borderSkipped:   false,
                        },
                    ],
                },
                options: {
                    responsive:  true,
                    interaction: { mode: 'index', intersect: false },
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: isDark ? '#1e293b' : '#fff',
                            titleColor:      isDark ? '#f1f5f9' : '#0f172a',
                            bodyColor:       txtClr,
                            borderColor:     isDark ? '#334155' : '#e2e8f0',
                            borderWidth:     1,
                            callbacks: {
                                label: ctx => ` ${ctx.dataset.label}: Rp ${Number(ctx.raw).toLocaleString('id-ID')}`,
                            },
                        },
                    },
                    scales: {
                        x: { grid: { color: grid }, ticks: { color: txtClr } },
                        y: {
                            grid:  { color: grid },
                            ticks: {
                                color: txtClr,
                                callback: v => 'Rp ' + (v >= 1e6
                                    ? (v / 1e6).toFixed(1) + 'jt'
                                    : Number(v).toLocaleString('id-ID')),
                            },
                        },
                    },
                },
            });
        }

        // ── Donut chart Distribusi Paket ─────────────────────────────────
        if (hasPaket && dd.paket && dd.paket.length) {
            const paketLabels = dd.paket.map(p => p.nama_paket  || p.label || '?');
            const paketValues = dd.paket.map(p => p.total       || p.value || 0);
            const paketColors = [
                '#2563eb','#0d9488','#7c3aed','#d97706',
                '#dc2626','#0891b2','#16a34a','#db2777',
            ];

            const donutChart = new window.Chart(hasPaket, {
                type: 'doughnut',
                data: {
                    labels:   paketLabels,
                    datasets: [{
                        data:            paketValues,
                        backgroundColor: paketColors,
                        borderWidth:     2,
                        borderColor:     isDark ? '#1e293b' : '#fff',
                        hoverOffset:     6,
                    }],
                },
                options: {
                    responsive:  true,
                    cutout:      '68%',
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: isDark ? '#1e293b' : '#fff',
                            titleColor:      isDark ? '#f1f5f9' : '#0f172a',
                            bodyColor:       txtClr,
                            borderColor:     isDark ? '#334155' : '#e2e8f0',
                            borderWidth:     1,
                        },
                    },
                },
            });

            // Legend manual
            const legendEl = document.getElementById('donutLegend');
            if (legendEl) {
                legendEl.innerHTML = paketLabels.map((lbl, i) => `
                    <div class="donut-legend__item">
                        <span class="donut-legend__dot" style="background:${paketColors[i % paketColors.length]}"></span>
                        <span class="donut-legend__label">${escHtml(lbl)}</span>
                        <span class="donut-legend__val">${paketValues[i]}</span>
                    </div>`).join('');
            }
        }
    }

    if (!window.Chart) {
        loadScript('https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js', buildCharts);
    } else {
        buildCharts();
    }
})();


/* =============================================================
   3. DASHBOARD CUSTOMIZER
   Fitur: toggle widget tampil/sembunyi + drag reorder
   Preferensi disimpan ke localStorage
   ============================================================= */

const STORAGE_KEY = 'dashboard_layout_v1';

const WIDGET_DEFS = [
    { id: 'stat-pelanggan',  label: 'Total Pelanggan',        section: 'section-stats' },
    { id: 'stat-lunas',      label: 'Tagihan Lunas',          section: 'section-stats' },
    { id: 'stat-unpaid',     label: 'Tagihan Belum Lunas',    section: 'section-stats' },
    { id: 'stat-tiket',      label: 'Tiket Terbuka',          section: 'section-stats' },
    { id: 'stat-kas',        label: 'Kas Masuk',              section: 'section-stats' },
    { id: 'stat-odp',        label: 'ODP Aktif',              section: 'section-stats' },
    { id: 'chart-pendapatan', label: 'Grafik Pendapatan',     section: 'section-charts' },
    { id: 'chart-paket',      label: 'Distribusi Paket',      section: 'section-charts' },
    { id: 'tabel-tagihan',    label: 'Tabel Tagihan Terbaru', section: 'section-tables' },
    { id: 'tabel-tiket',      label: 'Tabel Tiket Terbuka',   section: 'section-tables' },
    { id: 'chart-bandwidth',  label: 'Bandwidth Real-Time',   section: 'section-bandwidth' },
];

function defaultLayout() {
    return { hidden: [], order: WIDGET_DEFS.map(w => w.id) };
}

function loadLayout() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return defaultLayout();
        const parsed = JSON.parse(raw);
        WIDGET_DEFS.map(w => w.id).forEach(id => {
            if (!parsed.order.includes(id)) parsed.order.push(id);
        });
        return parsed;
    } catch {
        return defaultLayout();
    }
}

function saveLayout(layout) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function applyLayout(layout) {
    const sections = {};
    WIDGET_DEFS.forEach(w => {
        if (!sections[w.section]) sections[w.section] = [];
        sections[w.section].push(w.id);
    });

    Object.entries(sections).forEach(([sectionId, widgetIds]) => {
        const container = document.getElementById(sectionId);
        if (!container) return;

        const orderedIds = layout.order.filter(id => widgetIds.includes(id));
        widgetIds.forEach(id => { if (!orderedIds.includes(id)) orderedIds.push(id); });

        orderedIds.forEach(id => {
            const el = container.querySelector(`[data-id="${id}"]`);
            if (!el) return;
            container.appendChild(el);
            el.style.display = layout.hidden.includes(id) ? 'none' : '';
        });

        const allHidden = widgetIds.every(id => layout.hidden.includes(id));
        container.style.display = allHidden ? 'none' : '';
    });
}

(function initCustomizer() {
    const btnCustomize = document.getElementById('btnCustomize');
    const btnClose     = document.getElementById('btnCloseCustomize');
    const btnSave      = document.getElementById('btnSaveLayout');
    const btnReset     = document.getElementById('btnResetLayout');
    const panel        = document.getElementById('customizePanel');
    const togglesWrap  = document.getElementById('customizeToggles');

    if (!btnCustomize || !panel) return;

    let currentLayout = loadLayout();
    applyLayout(currentLayout);

    btnCustomize.addEventListener('click', () => {
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
        if (panel.style.display === 'block') buildToggles();
    });
    btnClose?.addEventListener('click', () => { panel.style.display = 'none'; });

    btnSave?.addEventListener('click', () => {
        saveLayout(currentLayout);
        applyLayout(currentLayout);
        panel.style.display = 'none';
        showToast('Layout dashboard disimpan', 'success');
    });

    btnReset?.addEventListener('click', () => {
        if (!confirm('Reset layout ke tampilan default?')) return;
        currentLayout = defaultLayout();
        saveLayout(currentLayout);
        applyLayout(currentLayout);
        buildToggles();
        showToast('Layout direset ke default', 'info');
    });

    function buildToggles() {
        if (!togglesWrap) return;
        togglesWrap.innerHTML = '';

        const groups = {};
        WIDGET_DEFS.forEach(w => {
            const secEl = document.getElementById(w.section);
            const label = secEl?.dataset.label || w.section;
            if (!groups[label]) groups[label] = [];
            groups[label].push(w);
        });

        Object.entries(groups).forEach(([groupLabel, widgets]) => {
            const group = document.createElement('div');
            group.className = 'ct-group';

            const title = document.createElement('div');
            title.className = 'ct-group__title';
            title.textContent = groupLabel;
            group.appendChild(title);

            const grid = document.createElement('div');
            grid.className = 'ct-grid';

            widgets.forEach(w => {
                const item = document.createElement('label');
                item.className = 'ct-item';

                const cb = document.createElement('input');
                cb.type    = 'checkbox';
                cb.checked = !currentLayout.hidden.includes(w.id);
                cb.addEventListener('change', () => {
                    if (!cb.checked) {
                        if (!currentLayout.hidden.includes(w.id))
                            currentLayout.hidden.push(w.id);
                    } else {
                        currentLayout.hidden = currentLayout.hidden.filter(id => id !== w.id);
                    }
                });

                const span = document.createElement('span');
                span.textContent = w.label;

                item.appendChild(cb);
                item.appendChild(span);
                grid.appendChild(item);
            });

            group.appendChild(grid);
            togglesWrap.appendChild(group);
        });
    }

    initDragReorder('section-stats', currentLayout);
})();

function initDragReorder(sectionId, layout) {
    const container = document.getElementById(sectionId);
    if (!container) return;

    let dragEl      = null;
    let placeholder = null;

    container.addEventListener('dragstart', e => {
        const widget = e.target.closest('.dash-widget');
        if (!widget) return;
        dragEl = widget;
        widget.classList.add('dragging');

        placeholder = document.createElement('div');
        placeholder.className  = 'drag-placeholder';
        placeholder.style.cssText = `
            width:${widget.offsetWidth}px;height:${widget.offsetHeight}px;
            border:2px dashed var(--clr-primary);border-radius:var(--radius-lg);
            background:var(--clr-primary-light);opacity:.5;`;
        setTimeout(() => widget.style.opacity = '0.4', 0);
    });

    container.addEventListener('dragover', e => {
        e.preventDefault();
        const widget = e.target.closest('.dash-widget');
        if (!widget || widget === dragEl) return;
        const rect = widget.getBoundingClientRect();
        const mid  = rect.left + rect.width / 2;
        container.insertBefore(placeholder, e.clientX < mid ? widget : widget.nextSibling);
    });

    container.addEventListener('dragend', e => {
        const widget = e.target.closest('.dash-widget');
        if (!widget) return;
        widget.style.opacity = '';
        widget.classList.remove('dragging');
        if (placeholder?.parentNode) {
            placeholder.parentNode.insertBefore(widget, placeholder);
            placeholder.remove();
        }
        placeholder = null;
        dragEl      = null;

        const newOrder   = [...container.querySelectorAll('.dash-widget')].map(el => el.dataset.id).filter(Boolean);
        const sectionIds = WIDGET_DEFS.filter(w => w.section === sectionId).map(w => w.id);
        layout.order = [...layout.order.filter(id => !sectionIds.includes(id)), ...newOrder];
    });

    container.querySelectorAll('.dash-widget').forEach(w => {
        w.setAttribute('draggable', 'true');
        w.style.cursor = 'grab';
    });
}


/* =============================================================
   4. BANDWIDTH REAL-TIME CHART
   Poll GET /mikrotik/bandwidth setiap 3 detik.
   Response: { ok, data:[{name,type,tx_byte,rx_byte,...}], ts, mode }
     mode:"live" → MikroTik terhubung   → live dot hijau
     mode:"demo" → MikroTik disconnect  → badge kuning "DEMO" berkedip
   ============================================================= */

(function initBandwidthChart() {
    const canvas   = document.getElementById('chartBandwidth');
    const selectEl = document.getElementById('bwIfaceSelect');
    const summaryEl= document.getElementById('bwSummary');
    const errorEl  = document.getElementById('bwError');
    const errorMsg = document.getElementById('bwErrorMsg');
    const pauseBtn = document.getElementById('bwPauseBtn');
    const liveDot  = document.getElementById('bwLiveDot');
    const lastUpd  = document.getElementById('bwLastUpdate');

    if (!canvas) return;  // widget tidak ada di halaman ini

    const MAX_POINTS   = 40;
    const POLL_MS      = 3000;
    const IFACE_COLORS = [
        ['#0d9488', '#5eead4'],  // teal
        ['#2563eb', '#93c5fd'],  // blue
        ['#7c3aed', '#c4b5fd'],  // purple
        ['#d97706', '#fcd34d'],  // amber
        ['#dc2626', '#fca5a5'],  // red
        ['#0891b2', '#67e8f9'],  // cyan
    ];

    let chart        = null;
    let prevSnapshot = {};
    let history      = {};
    let labels       = [];
    let knownIfaces  = [];
    let filterIface  = '';
    let paused       = false;
    let pollTimer    = null;
    let colorMap     = {};

    // ── Helpers ─────────────────────────────────────────────────────────────

    function fmtSpeed(bps) {
        if (bps >= 1e9) return (bps / 1e9).toFixed(2) + ' Gbps';
        if (bps >= 1e6) return (bps / 1e6).toFixed(2) + ' Mbps';
        if (bps >= 1e3) return (bps / 1e3).toFixed(1) + ' Kbps';
        return bps.toFixed(0) + ' bps';
    }

    function timeLabel() {
        return new Date().toLocaleTimeString('id-ID', {
            hour: '2-digit', minute: '2-digit', second: '2-digit',
        });
    }

    // ── Build Chart.js instance ──────────────────────────────────────────────

    function buildChart() {
        if (!window.Chart) return;
        const isDark   = document.documentElement.getAttribute('data-theme') === 'dark';
        const gridClr  = isDark ? 'rgba(255,255,255,.05)' : 'rgba(0,0,0,.05)';
        const txtColor = isDark ? '#94a3b8' : '#64748b';

        chart = new window.Chart(canvas, {
            type: 'line',
            data: { labels: [], datasets: [] },
            options: {
                responsive:  true,
                animation:   false,
                interaction: { mode: 'index', intersect: false },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: isDark ? '#1e293b' : '#fff',
                        titleColor:      isDark ? '#f1f5f9' : '#0f172a',
                        bodyColor:       txtColor,
                        borderColor:     isDark ? '#334155' : '#e2e8f0',
                        borderWidth:     1,
                        padding:         12,
                        callbacks: {
                            label: ctx => ` ${ctx.dataset.label}: ${fmtSpeed(ctx.raw * 8)}`,
                        },
                    },
                },
                scales: {
                    x: {
                        grid:  { color: gridClr },
                        ticks: { maxTicksLimit: 8, maxRotation: 0, color: txtColor },
                    },
                    y: {
                        grid:  { color: gridClr },
                        ticks: { color: txtColor, callback: v => fmtSpeed(v * 8) },
                        min:   0,
                    },
                },
            },
        });
    }

    // ── Rebuild datasets dari history ────────────────────────────────────────

    function rebuildDatasets() {
        if (!chart) return;
        const visible = filterIface ? knownIfaces.filter(n => n === filterIface) : knownIfaces;

        chart.data.labels   = [...labels];
        chart.data.datasets = [];

        visible.forEach((name, idx) => {
            const [txClr, rxClr] = colorMap[name] || IFACE_COLORS[idx % IFACE_COLORS.length];
            const h = history[name] || { txSpeeds: [], rxSpeeds: [] };

            chart.data.datasets.push({
                label:           `${name} TX`,
                data:            [...h.txSpeeds],
                borderColor:     txClr,
                backgroundColor: txClr + '15',
                borderWidth:     2,
                pointRadius:     0,
                fill:            false,
                tension:         0.4,
            });
            chart.data.datasets.push({
                label:           `${name} RX`,
                data:            [...h.rxSpeeds],
                borderColor:     rxClr,
                backgroundColor: rxClr + '15',
                borderWidth:     2,
                pointRadius:     0,
                fill:            false,
                tension:         0.4,
                borderDash:      [5, 4],
            });
        });

        chart.update('none');
    }

    // ── Summary chips ────────────────────────────────────────────────────────

    function updateSummary(latestSpeeds) {
        if (!summaryEl) return;
        summaryEl.innerHTML = '';

        knownIfaces.forEach((name, idx) => {
            const [txClr] = colorMap[name] || IFACE_COLORS[idx % IFACE_COLORS.length];
            const spd = latestSpeeds[name] || { tx: 0, rx: 0 };

            const chip = document.createElement('div');
            chip.className = 'bw-chip' + (filterIface === name ? ' active' : '');
            chip.innerHTML = `
                <span class="bw-chip__dot" style="background:${txClr}"></span>
                <span>${escHtml(name)}</span>
                <span class="bw-chip__speed">
                    ↑${fmtSpeed(spd.tx * 8)} ↓${fmtSpeed(spd.rx * 8)}
                </span>`;

            chip.addEventListener('click', () => {
                filterIface = filterIface === name ? '' : name;
                rebuildDatasets();
                updateSummary(latestSpeeds);
            });
            summaryEl.appendChild(chip);
        });
    }

    // ── Proses respons API ───────────────────────────────────────────────────

    function processData(interfaces, ts, mode) {
        const label        = timeLabel();
        const latestSpeeds = {};

        interfaces.forEach(iface => {
            const name = iface.name;

            if (!knownIfaces.includes(name)) {
                knownIfaces.push(name);
                colorMap[name] = IFACE_COLORS[(knownIfaces.length - 1) % IFACE_COLORS.length];
                history[name]  = {
                    txSpeeds: new Array(labels.length).fill(0),
                    rxSpeeds: new Array(labels.length).fill(0),
                };
                const opt = document.createElement('option');
                opt.value       = name;
                opt.textContent = name;
                selectEl?.appendChild(opt);
            }

            if (!history[name]) history[name] = { txSpeeds: [], rxSpeeds: [] };

            let txSpeed = 0, rxSpeed = 0;
            const prev = prevSnapshot[name];
            if (prev) {
                const dt = ts - prev.ts;
                if (dt > 0) {
                    txSpeed = Math.max(0, (iface.tx_byte - prev.tx_byte) / dt);
                    rxSpeed = Math.max(0, (iface.rx_byte - prev.rx_byte) / dt);
                }
            }

            prevSnapshot[name]   = { tx_byte: iface.tx_byte, rx_byte: iface.rx_byte, ts };
            latestSpeeds[name]   = { tx: txSpeed, rx: rxSpeed };

            history[name].txSpeeds.push(txSpeed);
            history[name].rxSpeeds.push(rxSpeed);
            if (history[name].txSpeeds.length > MAX_POINTS) {
                history[name].txSpeeds.shift();
                history[name].rxSpeeds.shift();
            }
        });

        labels.push(label);
        if (labels.length > MAX_POINTS) labels.shift();

        knownIfaces.forEach(name => {
            const h = history[name];
            while (h.txSpeeds.length > MAX_POINTS) h.txSpeeds.shift();
            while (h.rxSpeeds.length > MAX_POINTS) h.rxSpeeds.shift();
            while (h.txSpeeds.length < labels.length) h.txSpeeds.unshift(0);
            while (h.rxSpeeds.length < labels.length) h.rxSpeeds.unshift(0);
        });

        rebuildDatasets();
        updateSummary(latestSpeeds);

        // ── Badge DEMO ───────────────────────────────────────────────────
        let demoBadge = document.getElementById('bwModeBadge');
        if (mode === 'demo') {
            if (!demoBadge) {
                demoBadge           = document.createElement('span');
                demoBadge.id        = 'bwModeBadge';
                demoBadge.className = 'bw-demo-badge';
                demoBadge.textContent = 'DEMO';
                liveDot?.parentElement?.insertBefore(demoBadge, liveDot);
            }
            if (liveDot) liveDot.style.background = '#f59e0b';
        } else {
            demoBadge?.remove();
            if (liveDot) liveDot.style.background = '';
        }

        if (lastUpd) lastUpd.textContent = 'Updated ' + label;
        if (errorEl) errorEl.style.display = 'none';
        canvas.style.display = '';
    }

    // ── Poll /mikrotik/bandwidth ─────────────────────────────────────────────

    async function poll() {
        if (paused) return;
        try {
            const res  = await fetch('/mikrotik/bandwidth', {
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
            });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);

            const json = await res.json();
            if (!json.ok) throw new Error(json.message || 'Error dari server');

            processData(json.data, json.ts, json.mode || 'live');

        } catch (err) {
            if (errorEl)  errorEl.style.display = '';
            if (errorMsg) errorMsg.textContent  = 'Koneksi MikroTik gagal: ' + err.message;
            if (canvas)   canvas.style.display  = 'none';
            if (liveDot)  liveDot.classList.add('paused');
        }
    }

    // ── Controls ─────────────────────────────────────────────────────────────

    pauseBtn?.addEventListener('click', () => {
        paused = !paused;
        pauseBtn.innerHTML = paused
            ? '<i class="fa-solid fa-play"></i>'
            : '<i class="fa-solid fa-pause"></i>';
        liveDot?.classList.toggle('paused', paused);
        if (!paused) poll();
    });

    selectEl?.addEventListener('change', () => {
        filterIface = selectEl.value;
        rebuildDatasets();
    });

    document.getElementById('themeToggle')?.addEventListener('click', () => {
        if (chart) { chart.destroy(); chart = null; }
        setTimeout(() => { buildChart(); rebuildDatasets(); }, 60);
    });

    // ── Start ────────────────────────────────────────────────────────────────

    function waitAndStart() {
        if (window.Chart) {
            buildChart();
            poll();
            pollTimer = setInterval(poll, POLL_MS);
        } else {
            setTimeout(waitAndStart, 200);
        }
    }

    if (!window.Chart) {
        loadScript(
            'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js',
            waitAndStart
        );
    } else {
        waitAndStart();
    }

})();


/* =============================================================
   5. TOTAL BANDWIDTH DASHBOARD ADMIN
   Poll GET /dashboard/bandwidth-total setiap 3 detik.
   Menampilkan agregat semua pelanggan + top consumers table.
   ============================================================= */

(function initTotalBandwidth() {
    const canvas   = document.getElementById('chartBwTotal');
    if (!canvas) return;

    const txEl     = document.getElementById('bwTotTx');
    const rxEl     = document.getElementById('bwTotRx');
    const onlineEl = document.getElementById('bwTotOnline');
    const totalEl  = document.getElementById('bwTotTotal');
    const pauseBtn = document.getElementById('bwTotalPause');
    const dotEl    = document.getElementById('bwTotalDot');
    const updEl    = document.getElementById('bwTotalUpd');
    const topTable = document.getElementById('bwTopTable');

    const MAX_PTS = 40;
    const POLL_MS = 3000;

    let chart     = null;
    let labels    = [];
    let txHistory = [];
    let rxHistory = [];
    let paused    = false;

    function fmtSpeed(bps) {
        if (bps >= 1e9) return (bps / 1e9).toFixed(2) + ' Gbps';
        if (bps >= 1e6) return (bps / 1e6).toFixed(2) + ' Mbps';
        if (bps >= 1e3) return (bps / 1e3).toFixed(1) + ' Kbps';
        return bps.toFixed(0) + ' bps';
    }

    function buildChart() {
        if (!window.Chart || chart) return;
        const dark      = document.documentElement.getAttribute('data-theme') === 'dark';
        const gridColor = dark ? 'rgba(255,255,255,.05)' : 'rgba(0,0,0,.05)';
        const txtColor  = dark ? '#94a3b8' : '#64748b';

        chart = new window.Chart(canvas, {
            type: 'line',
            data: {
                labels: [],
                datasets: [
                    {
                        label:           'Total Upload',
                        data:            [],
                        borderColor:     '#2563eb',
                        backgroundColor: 'rgba(37,99,235,.08)',
                        borderWidth:     2.5,
                        pointRadius:     0,
                        tension:         .4,
                        fill:            true,
                    },
                    {
                        label:           'Total Download',
                        data:            [],
                        borderColor:     '#0d9488',
                        backgroundColor: 'rgba(13,148,136,.08)',
                        borderWidth:     2.5,
                        pointRadius:     0,
                        tension:         .4,
                        fill:            true,
                    },
                ],
            },
            options: {
                responsive:  true,
                animation:   false,
                interaction: { mode: 'index', intersect: false },
                plugins: {
                    legend: {
                        display:  true,
                        position: 'top',
                        labels:   { boxWidth: 12, font: { size: 11 } },
                    },
                    tooltip: {
                        callbacks: { label: ctx => ` ${ctx.dataset.label}: ${fmtSpeed(ctx.raw * 8)}` },
                    },
                },
                scales: {
                    x: {
                        grid:  { color: gridColor },
                        ticks: { maxTicksLimit: 8, maxRotation: 0, color: txtColor },
                    },
                    y: {
                        grid:  { color: gridColor },
                        min:   0,
                        ticks: { color: txtColor, callback: v => fmtSpeed(v * 8) },
                    },
                },
            },
        });
    }

    function renderTopTable(queues) {
        if (!topTable || !queues?.length) return;

        const sorted = [...queues]
            .sort((a, b) => (b.rx_rate + b.tx_rate) - (a.rx_rate + a.tx_rate))
            .slice(0, 8);

        const maxTotal = (sorted[0]?.tx_rate ?? 0) + (sorted[0]?.rx_rate ?? 0) || 1;

        topTable.innerHTML = `
            <div style="font-size:.72rem;font-weight:700;color:var(--txt-muted);
                        text-transform:uppercase;letter-spacing:.06em;margin-bottom:.6rem">
                Top Pengguna Bandwidth
            </div>
            <div style="overflow-x:auto">
            <table class="table" style="font-size:.8rem">
                <thead><tr>
                    <th>Queue / Pelanggan</th>
                    <th>Target IP</th>
                    <th>Upload</th>
                    <th>Download</th>
                    <th style="width:130px">Beban Relatif</th>
                </tr></thead>
                <tbody>
                ${sorted.map(q => {
                    const total = q.tx_rate + q.rx_rate;
                    const pct   = Math.round(total / maxTotal * 100);
                    const color = pct > 75 ? '#dc2626' : pct > 40 ? '#d97706' : '#16a34a';
                    return `<tr>
                        <td><span class="font-mono" style="font-size:.78rem">${escHtml(q.name)}</span></td>
                        <td><span class="font-mono" style="font-size:.75rem;color:var(--txt-muted)">${escHtml(q.target || '—')}</span></td>
                        <td style="color:var(--clr-primary);font-weight:600">${fmtSpeed(q.tx_rate * 8)}</td>
                        <td style="color:var(--clr-teal);font-weight:600">${fmtSpeed(q.rx_rate * 8)}</td>
                        <td>
                            <div style="display:flex;align-items:center;gap:6px">
                                <div style="flex:1;height:6px;border-radius:3px;
                                            background:var(--border);overflow:hidden">
                                    <div style="height:100%;width:${pct}%;background:${color};
                                                border-radius:3px;transition:width .4s"></div>
                                </div>
                                <span style="font-size:.7rem;color:var(--txt-muted);
                                             width:28px;text-align:right">${pct}%</span>
                            </div>
                        </td>
                    </tr>`;
                }).join('')}
                </tbody>
            </table></div>`;
    }

    async function poll() {
        if (paused) return;
        try {
            const res  = await fetch('/dashboard/bandwidth-total', {
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
            });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const data = await res.json();
            if (!data.ok) throw new Error('error');

            const now   = new Date().toLocaleTimeString('id-ID', {
                hour: '2-digit', minute: '2-digit', second: '2-digit',
            });
            const txBps = data.total_tx_rate * 8;
            const rxBps = data.total_rx_rate * 8;

            labels.push(now);                   if (labels.length > MAX_PTS)    labels.shift();
            txHistory.push(data.total_tx_rate); if (txHistory.length > MAX_PTS) txHistory.shift();
            rxHistory.push(data.total_rx_rate); if (rxHistory.length > MAX_PTS) rxHistory.shift();

            if (chart) {
                chart.data.labels         = [...labels];
                chart.data.datasets[0].data = [...txHistory];
                chart.data.datasets[1].data = [...rxHistory];
                chart.update('none');
            }

            if (txEl)     txEl.textContent     = fmtSpeed(txBps);
            if (rxEl)     rxEl.textContent     = fmtSpeed(rxBps);
            if (onlineEl) onlineEl.textContent = data.online_count + ' aktif';
            if (totalEl)  totalEl.textContent  = fmtSpeed(txBps + rxBps);
            if (updEl)    updEl.textContent    = 'Updated ' + now;

            // Mode badge
            let modeBadge = document.getElementById('bwTotalModeBadge');
            if (!modeBadge && dotEl) {
                modeBadge           = document.createElement('span');
                modeBadge.id        = 'bwTotalModeBadge';
                modeBadge.className = 'bw-demo-badge';
                dotEl.parentElement.insertBefore(modeBadge, dotEl);
            }
            if (modeBadge) {
                modeBadge.textContent = (data.mode || 'live').toUpperCase();
                modeBadge.style.background = data.mode === 'demo' ? '' : 'var(--clr-success-light)';
                modeBadge.style.color      = data.mode === 'demo' ? '' : 'var(--clr-success)';
                modeBadge.style.borderColor= data.mode === 'demo' ? '' : '#86efac';
            }
            if (dotEl) dotEl.style.background = data.mode === 'demo' ? '#f59e0b' : '';

            renderTopTable(data.queues);

        } catch (e) { /* silent — jangan rusak UI */ }
    }

    pauseBtn?.addEventListener('click', function () {
        paused = !paused;
        this.innerHTML = paused
            ? '<i class="fa-solid fa-play"></i>'
            : '<i class="fa-solid fa-pause"></i>';
        dotEl?.classList.toggle('paused', paused);
        if (!paused) poll();
    });

    // Re-build chart saat theme toggle
    document.getElementById('themeToggle')?.addEventListener('click', () => {
        if (chart) { chart.destroy(); chart = null; }
        setTimeout(buildChart, 60);
    });

    function waitAndStart() {
        if (window.Chart) {
            buildChart();
            poll();
            setInterval(poll, POLL_MS);
        } else {
            setTimeout(waitAndStart, 200);
        }
    }
    waitAndStart();

    // Daftarkan ke WIDGET_DEFS jika belum ada
    if (typeof WIDGET_DEFS !== 'undefined' &&
        !WIDGET_DEFS.find(w => w.id === 'chart-bwtotal')) {
        WIDGET_DEFS.push({
            id:      'chart-bwtotal',
            label:   'Total Bandwidth Jaringan',
            section: 'section-bwtotal',
        });
    }
})();


/* =============================================================
   6. BANDWIDTH PER PELANGGAN  (halaman show.php)
   Poll GET /pelanggan/{id}/bandwidth   → speed + usage
   Poll GET /pelanggan/{id}/uptime      → status + uptime
   Elemen dirender di show.php; script hanya berjalan
   jika elemen #chartBwPel ada di DOM.
   ============================================================= */

(function initPelangganBandwidth() {
    const canvas = document.getElementById('chartBwPel');
    if (!canvas) return;   // Hanya aktif di halaman detail pelanggan

    // ── Ambil config yang di-inject show.php ────────────────────────────
    const PID    = window.PELANGGAN_ID   ?? 0;
    const HASMAC = window.PELANGGAN_MAC  ?? false;
    const APPURL = window.APP_URL        ?? '';

    if (!PID) return;

    const MAX_PTS = 30;
    const POLL_MS = 3000;

    let chart      = null;
    let labels     = [];
    let txHistory  = [];
    let rxHistory  = [];
    let paused     = false;

    // ── Helpers ─────────────────────────────────────────────────────────
    function fmtSpeed(bps) {
        if (bps >= 1e9) return (bps / 1e9).toFixed(2) + ' Gbps';
        if (bps >= 1e6) return (bps / 1e6).toFixed(2) + ' Mbps';
        if (bps >= 1e3) return (bps / 1e3).toFixed(1) + ' Kbps';
        return bps.toFixed(0) + ' bps';
    }
    function fmtBytes(b) {
        if (b >= 1e12) return (b / 1e12).toFixed(2) + ' TB';
        if (b >= 1e9)  return (b / 1e9).toFixed(2)  + ' GB';
        if (b >= 1e6)  return (b / 1e6).toFixed(2)  + ' MB';
        if (b >= 1e3)  return (b / 1e3).toFixed(1)  + ' KB';
        return b + ' B';
    }
    function setBadge(id, mode) {
        const el = document.getElementById(id);
        if (!el) return;
        el.textContent = (mode || 'live').toUpperCase();
        const isDemo   = mode === 'demo';
        el.className   = 'bw-badge' + (isDemo ? ' bw-badge--demo' : ' bw-badge--live');
    }

    // ── Chart.js instance ────────────────────────────────────────────────
    function buildChart() {
        if (!window.Chart || chart) return;
        const dark     = document.documentElement.getAttribute('data-theme') === 'dark';
        const gridClr  = dark ? 'rgba(255,255,255,.05)' : 'rgba(0,0,0,.05)';
        const txtColor = dark ? '#94a3b8' : '#64748b';

        chart = new window.Chart(canvas, {
            type: 'line',
            data: {
                labels: [],
                datasets: [
                    {
                        label:           'Upload',
                        data:            [],
                        borderColor:     '#2563eb',
                        backgroundColor: 'rgba(37,99,235,.08)',
                        borderWidth:     2,
                        pointRadius:     0,
                        tension:         .4,
                        fill:            false,
                    },
                    {
                        label:           'Download',
                        data:            [],
                        borderColor:     '#0d9488',
                        backgroundColor: 'rgba(13,148,136,.08)',
                        borderWidth:     2,
                        pointRadius:     0,
                        tension:         .4,
                        fill:            false,
                        borderDash:      [4, 3],
                    },
                ],
            },
            options: {
                responsive:  true,
                animation:   false,
                interaction: { mode: 'index', intersect: false },
                plugins: {
                    legend: {
                        display:  true,
                        position: 'top',
                        labels:   { boxWidth: 12, font: { size: 11 } },
                    },
                    tooltip: {
                        callbacks: { label: ctx => ` ${ctx.dataset.label}: ${fmtSpeed(ctx.raw * 8)}` },
                    },
                },
                scales: {
                    x: {
                        grid:  { color: gridClr },
                        ticks: { maxTicksLimit: 6, maxRotation: 0, color: txtColor },
                    },
                    y: {
                        grid:  { color: gridClr },
                        min:   0,
                        ticks: { color: txtColor, callback: v => fmtSpeed(v * 8) },
                    },
                },
            },
        });
    }

    // ── Poll bandwidth ───────────────────────────────────────────────────
    async function pollBandwidth() {
        if (paused || !HASMAC) return;
        try {
            const res  = await fetch(`${APPURL}/pelanggan/${PID}/bandwidth`, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
            });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const data = await res.json();
            if (!data.ok) throw new Error(data.message || 'error');
            renderBandwidth(data);
        } catch (e) { /* silent */ }
    }

    function renderBandwidth(data) {
        const now   = new Date().toLocaleTimeString('id-ID', {
            hour: '2-digit', minute: '2-digit', second: '2-digit',
        });
        const txBps = data.tx_rate * 8;
        const rxBps = data.rx_rate * 8;

        // Rolling history
        labels.push(now);              if (labels.length > MAX_PTS)    labels.shift();
        txHistory.push(data.tx_rate);  if (txHistory.length > MAX_PTS) txHistory.shift();
        rxHistory.push(data.rx_rate);  if (rxHistory.length > MAX_PTS) rxHistory.shift();

        // Update chart
        if (chart) {
            chart.data.labels           = [...labels];
            chart.data.datasets[0].data = [...txHistory];
            chart.data.datasets[1].data = [...rxHistory];
            chart.update('none');
        }

        // Speed meters
        const txRateEl = document.getElementById('txRate');
        const rxRateEl = document.getElementById('rxRate');
        const txBarEl  = document.getElementById('txBar');
        const rxBarEl  = document.getElementById('rxBar');

        if (txRateEl) txRateEl.textContent = fmtSpeed(txBps);
        if (rxRateEl) rxRateEl.textContent = fmtSpeed(rxBps);

        // Bar = % dari kecepatan paket (ambil dari data, default 100 Mbps)
        const paketBps = (data.paket_speed_mbps ?? 100) * 1e6;
        if (txBarEl) txBarEl.style.width = Math.min(100, txBps / paketBps * 100) + '%';
        if (rxBarEl) rxBarEl.style.width = Math.min(100, rxBps / paketBps * 100) + '%';

        // Usage totals
        const totEl = document.getElementById('usageTotals');
        if (totEl) {
            totEl.innerHTML = `
                <div class="usage-total-item">
                    <div class="usage-total-item__label">
                        <i class="fa-solid fa-arrow-up" style="color:var(--clr-primary);margin-right:.3rem"></i>Total Upload
                    </div>
                    <div class="usage-total-item__val">${fmtBytes(data.tx_byte)}</div>
                </div>
                <div class="usage-total-item">
                    <div class="usage-total-item__label">
                        <i class="fa-solid fa-arrow-down" style="color:var(--clr-teal);margin-right:.3rem"></i>Total Download
                    </div>
                    <div class="usage-total-item__val">${fmtBytes(data.rx_byte)}</div>
                </div>
                ${data.ip ? `
                <div class="usage-total-item">
                    <div class="usage-total-item__label">
                        <i class="fa-solid fa-network-wired" style="color:var(--clr-primary);margin-right:.3rem"></i>IP Address
                    </div>
                    <div class="usage-total-item__val font-mono" style="font-size:.85rem">${escHtml(data.ip)}</div>
                </div>` : ''}
                ${data.queue_name ? `
                <div class="usage-total-item">
                    <div class="usage-total-item__label">
                        <i class="fa-solid fa-list" style="margin-right:.3rem"></i>Queue
                    </div>
                    <div class="usage-total-item__val font-mono" style="font-size:.85rem">${escHtml(data.queue_name)}</div>
                </div>` : ''}`;
        }

        // IP di info grid
        const ipEl = document.getElementById('pelIp');
        if (ipEl && data.ip) ipEl.textContent = data.ip;

        setBadge('bwModePel', data.mode);

        // Live dot
        const dot = document.getElementById('bwDotPel');
        if (dot) dot.style.background = data.mode === 'demo' ? '#f59e0b' : '';
    }

    // ── Poll uptime ──────────────────────────────────────────────────────
    async function loadUptime() {
        try {
            const res  = await fetch(`${APPURL}/pelanggan/${PID}/uptime`, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
            });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const data = await res.json();
            renderUptime(data);
        } catch (e) {
            const el = document.getElementById('uptimeDisplay');
            if (el) el.innerHTML = '<span style="color:var(--clr-danger);font-size:1rem">Gagal memuat</span>';
        }
    }

    function renderUptime(data) {
        // Status dot + text di card header
        const statusDot  = document.getElementById('statusDot');
        const statusText = document.getElementById('statusText');
        const statusBadge= document.getElementById('statusBadge');
        const online     = data.status === 'online';

        if (statusDot)  statusDot.className  = 'status-dot status-dot--' + (online ? 'online' : 'offline');
        if (statusText) statusText.textContent = online ? 'Online' : 'Offline';
        if (statusBadge) {
            statusBadge.style.borderColor = online ? 'var(--clr-success)' : 'var(--clr-danger)';
        }

        // IP (sync dengan bandwidth)
        if (data.ip) {
            const ipEl = document.getElementById('pelIp');
            if (ipEl && ipEl.textContent === '—') ipEl.textContent = data.ip;
        }

        // Uptime display
        const upEl = document.getElementById('uptimeDisplay');
        if (upEl) {
            upEl.innerHTML = data.uptime_human && data.uptime_human !== '—'
                ? `${escHtml(data.uptime_human)}<small>${data.mode === 'demo' ? 'Data simulasi' : 'Waktu koneksi aktif'}</small>`
                : `<span style="color:var(--txt-muted);font-size:1rem">Uptime tidak tersedia</span>`;
        }

        // Meta rows
        const metaEl = document.getElementById('uptimeMeta');
        if (metaEl) {
            metaEl.innerHTML = `
                <div class="uptime-meta-row">
                    <span>Status</span>
                    <span>${online ? '🟢 Online' : '🔴 Offline'}</span>
                </div>
                ${data.ip ? `<div class="uptime-meta-row">
                    <span>IP Address</span>
                    <span class="font-mono">${escHtml(data.ip)}</span>
                </div>` : ''}
                ${data.mode ? `<div class="uptime-meta-row">
                    <span>Sumber Data</span>
                    <span>${escHtml(data.mode)}</span>
                </div>` : ''}`;
        }

        setBadge('uptimeMode', data.mode);
    }

    // ── Pause button ─────────────────────────────────────────────────────
    document.getElementById('bwPausePel')?.addEventListener('click', function () {
        paused = !paused;
        this.innerHTML = paused
            ? '<i class="fa-solid fa-play"></i>'
            : '<i class="fa-solid fa-pause"></i>';
        document.getElementById('bwDotPel')?.classList.toggle('paused', paused);
        if (!paused) pollBandwidth();
    });

    // Re-build chart saat theme toggle
    document.getElementById('themeToggle')?.addEventListener('click', () => {
        if (chart) { chart.destroy(); chart = null; }
        setTimeout(buildChart, 60);
    });

    // ── Start ────────────────────────────────────────────────────────────
    loadUptime();   // Uptime: satu kali load (tidak perlu polling cepat)
    setInterval(loadUptime, 30_000);  // refresh uptime tiap 30 detik

    if (HASMAC) {
        function waitAndStart() {
            if (window.Chart) {
                buildChart();
                pollBandwidth();
                setInterval(pollBandwidth, POLL_MS);
            } else {
                setTimeout(waitAndStart, 200);
            }
        }
        waitAndStart();
    }

})();


/* =============================================================
   7. SIDEBAR DROPDOWN NAVIGATION
   ============================================================= */

function toggleNavDropdown(btn) {
    const dropdown = btn.nextElementSibling;
    if (!dropdown || !dropdown.classList.contains('nav-dropdown')) return;

    const isOpen = dropdown.classList.contains('open');

    // Tutup semua dropdown lain dulu
    document.querySelectorAll('.nav-dropdown.open').forEach(d => {
        if (d !== dropdown) {
            d.classList.remove('open');
            const b = d.previousElementSibling;
            if (b) {
                b.classList.remove('open', 'active');
                b.setAttribute('aria-expanded', 'false');
            }
        }
    });

    // Toggle yang diklik
    dropdown.classList.toggle('open', !isOpen);
    btn.classList.toggle('open', !isOpen);
    btn.setAttribute('aria-expanded', String(!isOpen));

    // Pertahankan class 'active' jika ada sub-item yang aktif
    const hasActive = dropdown.querySelector('.nav-item.active');
    if (hasActive) btn.classList.add('active');
}

// Init: pastikan dropdown dengan sub-item aktif selalu terbuka saat load
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.nav-dropdown').forEach(d => {
        const hasActive = d.querySelector('.nav-item.active');
        if (hasActive) {
            d.classList.add('open');
            const btn = d.previousElementSibling;
            if (btn) {
                btn.classList.add('open', 'active');
                btn.setAttribute('aria-expanded', 'true');
            }
        }
    });
});
