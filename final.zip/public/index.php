<?php
/**
 * public/index.php — Front Controller
 * PHP 8.4 Native Semi-Framework — Billing ISP
 *
 * ✅ FIXED: Session pakai default path PHP (hindari permission error di Android)
 */

declare(strict_types=1);

// --- 0. Output Buffering ---
ob_start();

// --- 1. Error Reporting ---
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('log_errors', '1');

// --- 2. APP_ROOT ---
define('APP_ROOT', dirname(__DIR__));

// --- 3. Session dengan Lifetime 12 Jam ---
$sessionLifetime = 43200; // 12 jam

// ✅ PAKAI DEFAULT SESSION PATH PHP (lebih reliable di Android)
// Tidak perlu custom path yang sering bermasalah dengan permission
ini_set('session.gc_maxlifetime',  (string)$sessionLifetime);
ini_set('session.cookie_lifetime', (string)$sessionLifetime);
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Lax');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies','1');
ini_set('session.gc_probability',  '1');
ini_set('session.gc_divisor',      '100');

if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_httponly' => true,
        'cookie_secure'   => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
        'cookie_samesite' => 'Lax',
        'use_strict_mode' => true,
        'cookie_lifetime' => $sessionLifetime,
    ]);
}

// --- 3b. Cek Session Expiry (Double Check) ---
if (isset($_SESSION['user_id'])) {
    $loginTime = $_SESSION['_login_time'] ?? 0;

    if ($loginTime > 0 && (time() - $loginTime) > $sessionLifetime) {
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(), '', time() - 42000,
                $params['path'], $params['domain'],
                $params['secure'], $params['httponly']
            );
        }

        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }

        session_start();
        $_SESSION['flash'] = [
            'type'    => 'warning',
            'message' => 'Sesi Anda telah berakhir (12 jam). Silakan login kembali.',
        ];

        header('Location: /login');
        exit;
    }

    $_SESSION['_last_activity'] = time();
}

// --- 4. Load Autoloader ---
$autoloaderFile = APP_ROOT . '/config/Autoloader.php';
if (!file_exists($autoloaderFile)) {
    http_response_code(500);
    die('<h1>500</h1><p>File <code>config/Autoloader.php</code> tidak ditemukan.<br>APP_ROOT: ' . APP_ROOT . '</p>');
}
require_once $autoloaderFile;
\Config\Autoloader::register();

// --- 5. Load env.php ---
$envFile = APP_ROOT . '/config/env.php';
if (!file_exists($envFile)) {
    http_response_code(500);
    die('<h1>500</h1><p>File <code>config/env.php</code> tidak ditemukan.</p>');
}
require_once $envFile;

if (($_ENV['APP_ENV'] ?? 'development') === 'production') {
    ini_set('display_errors', '0');
    error_reporting(0);
}

// --- 6. Routes ---
try {
    $routeFile = APP_ROOT . '/routes/web.php';

    if (!file_exists($routeFile)) {
        throw new \RuntimeException('File routes/web.php tidak ditemukan.', 500);
    }

    require_once $routeFile;

} catch (\Throwable $e) {
    $logDir = APP_ROOT . '/storage/Logs';
    if (is_dir($logDir) && is_writable($logDir)) {
        file_put_contents(
            $logDir . '/error.log',
            sprintf("[%s] %s in %s on line %d\n",
                date('Y-m-d H:i:s'), $e->getMessage(), $e->getFile(), $e->getLine()
            ),
            FILE_APPEND
        );
    }

    $code = match (true) {
        $e->getCode() === 404 => 404,
        $e->getCode() === 403 => 403,
        default               => 500,
    };

    http_response_code($code);

    $errorPage = APP_ROOT . "/views/pages/errors/{$code}.php";
    if (file_exists($errorPage)) {
        include $errorPage;
    } else {
        echo "<h1>Error {$code}</h1>";
        echo '<p>' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</p>';
    }
}
