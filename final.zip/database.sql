-- 1. Inisialisasi Database
CREATE DATABASE IF NOT EXISTS billing_isp_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE billing_isp_db;

-- 2. Master Tabel User & RBAC
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'kasir', 'teknisi', 'pelanggan') NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. Master Data ODP & Paket Internet
CREATE TABLE odp (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nama_odp VARCHAR(50) NOT NULL UNIQUE,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    kapasitas INT DEFAULT 16,
    terpasang INT DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE paket (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nama_paket VARCHAR(100) NOT NULL,
    kecepatan VARCHAR(20) NOT NULL,
    harga DECIMAL(15,2) NOT NULL,
    deskripsi TEXT NULL
) ENGINE=InnoDB;

-- 4. Data Pelanggan (Relasi ke User, Paket, dan ODP)
CREATE TABLE pelanggan (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    nama_lengkap VARCHAR(100) NOT NULL,
    no_telp VARCHAR(20) NOT NULL,
    alamat TEXT NOT NULL,
    latitude DECIMAL(10, 8) NULL,
    longitude DECIMAL(11, 8) NULL,
    odp_id INT NULL,
    paket_id INT NOT NULL,
    tgl_jatuh_tempo INT DEFAULT 5, -- Tanggal jatuh tempo bulanan (misal setiap tgl 5)
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (odp_id) REFERENCES odp(id) ON DELETE SET NULL,
    FOREIGN KEY (paket_id) REFERENCES paket(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- 5. Transaksi & Keuangan
CREATE TABLE tagihan (
    id INT PRIMARY KEY AUTO_INCREMENT,
    pelanggan_id INT NOT NULL,
    periode_bulan VARCHAR(7) NOT NULL, -- Format: YYYY-MM
    total DECIMAL(15,2) NOT NULL,
    status ENUM('unpaid', 'paid') DEFAULT 'unpaid',
    jatuh_tempo DATE NOT NULL,
    tgl_bayar TIMESTAMP NULL DEFAULT NULL,
    FOREIGN KEY (pelanggan_id) REFERENCES pelanggan(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE kas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    tipe ENUM('masuk', 'keluar') NOT NULL,
    jumlah DECIMAL(15,2) NOT NULL,
    keterangan TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 6. Ticketing & Pelayanan Gangguan
CREATE TABLE pengaduan (
    id INT PRIMARY KEY AUTO_INCREMENT,
    pelanggan_id INT NOT NULL,
    judul VARCHAR(100) NOT NULL,
    deskripsi TEXT NOT NULL,
    status ENUM('open', 'proses', 'selesai') DEFAULT 'open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (pelanggan_id) REFERENCES pelanggan(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 7. Log & Audit Keamanan
CREATE TABLE audit_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NULL,
    aktivitas TEXT NOT NULL,
    ip_address VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;


-- 8. Data Dummy Inisialisasi awal
-- Password default default: 'password' (hasil enkripsi password_hash BCRYPT)
INSERT INTO users (id, username, password, role, status) VALUES 
(1, 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active'),
(2, 'kasir_utama', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'kasir', 'active'),
(3, 'teknisi_lapangan', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'teknisi', 'active'),
(4, 'budi_cust', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'pelanggan', 'active');

INSERT INTO paket (id, nama_paket, kecepatan, harga, deskripsi) VALUES 
(1, 'Bronze Plan', '20 Mbps', 150000.00, 'Paket internet hemat kuota unlimited'),
(2, 'Gold Plan', '50 Mbps', 300000.00, 'Paket internet cepat keluarga');

INSERT INTO odp (id, nama_odp, latitude, longitude, kapasitas, terpasang) VALUES 
(1, 'ODP-PBL-01', -6.20000000, 106.81000000, 16, 1),
(2, 'ODP-PBL-02', -6.20150000, 106.81220000, 16, 0);

INSERT INTO pelanggan (id, user_id, nama_lengkap, no_telp, alamat, latitude, longitude, odp_id, paket_id, tgl_jatuh_tempo) VALUES 
(1, 4, 'Budi Santoso', '081234567890', 'Jl. Merdeka No 123, Jakarta Central', -6.20050000, 106.81050000, 1, 2, 5);

INSERT INTO tagihan (id, pelanggan_id, periode_bulan, total, status, jatuh_tempo) VALUES 
(1, 1, '2026-06', 300000.00, 'unpaid', '2026-06-05');
