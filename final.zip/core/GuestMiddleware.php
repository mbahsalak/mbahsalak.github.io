<?php
/**
 * core/GuestMiddleware.php
 * Hanya untuk tamu (belum login)
 * Redirect ke /dashboard jika user sudah login — cegah akses ke /login & /register
 */

declare(strict_types=1);

namespace Core;

class GuestMiddleware extends Middleware
{
    public function handle(): void
    {
        if (Auth::check()) {
            self::redirectTo(($_ENV['APP_URL'] ?? '') . '/dashboard');
        }
    }
}
