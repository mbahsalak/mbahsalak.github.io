<?php

declare(strict_types=1);

namespace Core;

/**
 * MikroTik REST API Client
 * Terhubung ke dummy server (Flask) atau RouterOS v7 REST API
 */
class MikrotikClient
{
    public private(set) string $baseUrl;
    public private(set) string $username;
    public private(set) string $password;
    public private(set) int $timeout;

    public function __construct(
        ?string $baseUrl  = null,
        ?string $username = null,
        ?string $password = null,
        int $timeout      = 10,
    ) {
        $this->baseUrl  = $baseUrl  ?? $_ENV['MIKROTIK_API_URL']   ?? 'http://localhost:5000';
        $this->username = $username ?? $_ENV['MIKROTIK_REST_USER'] ?? 'admin';
        $this->password = $password ?? $_ENV['MIKROTIK_REST_PASS'] ?? 'admin123';
        $this->timeout  = $timeout;
    }

    /**
     * Property Hook PHP 8.4: cek koneksi otomatis
     */
    public bool $isConnected {
        get => $this->ping();
    }

    /**
     * Normalisasi MAC Address ke format uppercase dengan colon
     */
    public static function normalizeMac(string $mac): string
    {
        // Hapus semua separator yang mungkin (titik, dash, spasi, colon)
        $clean = strtoupper(preg_replace('/[^a-fA-F0-9]/', '', $mac));

        // Jika panjang bukan 12 karakter hex, kembalikan apa adanya
        if (strlen($clean) !== 12) {
            return strtoupper(trim($mac));
        }

        // Format ke AA:BB:CC:DD:EE:FF
        return implode(':', str_split($clean, 2));
    }

    /**
     * GET request dengan Basic Auth
     */
    public function get(string $endpoint): array
    {
        $url = rtrim($this->baseUrl, '/') . '/' . ltrim($endpoint, '/');

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_HTTPHEADER     => [
                'Accept: application/json',
                'Content-Type: application/json',
                'Authorization: Basic ' . base64_encode("{$this->username}:{$this->password}"),
            ],
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_FOLLOWLOCATION => true,
        ]);

        Logger::info('MikrotikClient', "GET {$url}");

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error    = curl_error($ch);
        $errno    = curl_errno($ch);
        // curl_close($ch);

        Logger::info('MikrotikClient', "GET {$url} → HTTP {$httpCode}");

        // ── Penanganan error yang lebih detail ──────────────────────
        if ($response === false || $errno > 0) {
            $msg = match ($errno) {
                6       => "DNS resolution gagal untuk host: {$this->baseUrl}",
                7       => "Tidak bisa terhubung ke {$this->baseUrl} — pastikan Flask server berjalan (python 1.py)",
                28      => "Timeout: server tidak merespons dalam {$this->timeout} detik",
                default => "cURL error ({$errno}): {$error}",
            };
            throw new \RuntimeException("Koneksi gagal: {$msg}");
        }

        if ($httpCode === 401) {
            throw new \RuntimeException('Autentikasi gagal: Username/Password salah');
        }
        if ($httpCode === 404) {
            throw new \RuntimeException("Endpoint tidak ditemukan: {$endpoint}");
        }
        if ($httpCode >= 400) {
            throw new \RuntimeException("Server error: HTTP {$httpCode}");
        }

        $data = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            Logger::error('MikrotikClient', "Invalid JSON response: " . substr($response, 0, 200));
            throw new \RuntimeException('Response bukan JSON valid');
        }

        return $data;
    }

    /**
     * Ambil statistik router berdasarkan MAC Address
     */
    public function getRouterByMac(string $macAddress): array
    {
        $mac = self::normalizeMac($macAddress);
        return $this->get("/api/mikrotik/{$mac}");
    }

    /**
     * Ping server — sekarang menggunakan Auth agar tidak ditolak 401
     */
    private function ping(): bool
    {
        $url = rtrim($this->baseUrl, '/') . '/health';

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 3,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_NOBODY         => false,
            CURLOPT_HTTPHEADER     => [
                'Accept: application/json',
                'Authorization: Basic ' . base64_encode("{$this->username}:{$this->password}"),
            ],
            CURLOPT_SSL_VERIFYPEER => false,
        ]);
        $response = curl_exec($ch);
        $code     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // /health endpoint tidak butuh auth di Flask dummy, tapi tetap kirim
        return $code >= 200 && $code < 400;
    }

    /**
     * POST request
     */
    public function post(string $endpoint, array $body = []): array
    {
        $url = rtrim($this->baseUrl, '/') . '/' . ltrim($endpoint, '/');
        $ch  = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($body),
            CURLOPT_HTTPHEADER     => [
                'Accept: application/json',
                'Content-Type: application/json',
                'Authorization: Basic ' . base64_encode("{$this->username}:{$this->password}"),
            ],
            CURLOPT_SSL_VERIFYPEER => false,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error    = curl_error($ch);
        curl_close($ch);
        Logger::info('MikrotikClient', "POST {$url} → HTTP {$httpCode}");
        if ($response === false) throw new \RuntimeException("Koneksi gagal: {$error}");
        if ($httpCode === 401) throw new \RuntimeException('Autentikasi gagal');
        if ($httpCode >= 400) throw new \RuntimeException("Server error: HTTP {$httpCode}");
        $data = json_decode($response, true);
        return is_array($data) ? $data : ['ok' => true];
    }

    /**
     * DELETE request
     */
    public function delete(string $endpoint): bool
    {
        $url = rtrim($this->baseUrl, '/') . '/' . ltrim($endpoint, '/');
        $ch  = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_CUSTOMREQUEST  => 'DELETE',
            CURLOPT_HTTPHEADER     => [
                'Accept: application/json',
                'Authorization: Basic ' . base64_encode("{$this->username}:{$this->password}"),
            ],
            CURLOPT_SSL_VERIFYPEER => false,
        ]);
        curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $httpCode >= 200 && $httpCode < 300;
    }

    // =========================================================================
    // PPPoE SECRETS
    // =========================================================================

    public function getPppoeSecrets(): array
    {
        return $this->get('/api/pppoe/secrets');
    }

    public function addPppoeSecret(
        string $username,
        string $password,
        string $profile = 'default',
        string $service = 'pppoe',
        string $comment = ''
    ): bool {
        $res = $this->post('/api/pppoe/secrets', compact('username','password','profile','service','comment'));
        return ($res['ok'] ?? $res['success'] ?? false) !== false;
    }

    public function updatePppoePassword(string $username, string $newPassword): bool
    {
        $res = $this->post("/api/pppoe/secrets/{$username}/password", ['password' => $newPassword]);
        return ($res['ok'] ?? $res['success'] ?? false) !== false;
    }

    public function togglePppoeSecret(string $username): bool
    {
        $res = $this->post("/api/pppoe/secrets/{$username}/toggle", []);
        return ($res['ok'] ?? $res['success'] ?? false) !== false;
    }

    public function deletePppoeSecret(string $username): bool
    {
        return $this->delete("/api/pppoe/secrets/{$username}");
    }

    // =========================================================================
    // ACTIVE CONNECTIONS
    // =========================================================================

    public function getPppoeActive(): array
    {
        return $this->get('/api/pppoe/active');
    }

    public function kickPppoeSession(string $username): bool
    {
        $res = $this->post("/api/pppoe/active/{$username}/kick", []);
        return ($res['ok'] ?? $res['success'] ?? false) !== false;
    }

    // =========================================================================
    // SIMPLE QUEUE
    // =========================================================================

    public function getSimpleQueues(): array
    {
        return $this->get('/api/queues');
    }

    public function addSimpleQueue(
        string $name,
        string $target,
        string $maxLimit = '10M/10M',
        string $comment  = ''
    ): bool {
        $res = $this->post('/api/queues', compact('name','target','maxLimit','comment'));
        return ($res['ok'] ?? $res['success'] ?? false) !== false;
    }

    public function updateSimpleQueue(string $name, string $maxLimit): bool
    {
        $res = $this->post("/api/queues/{$name}", ['maxLimit' => $maxLimit]);
        return ($res['ok'] ?? $res['success'] ?? false) !== false;
    }

    public function deleteSimpleQueue(string $name): bool
    {
        return $this->delete("/api/queues/{$name}");
    }
    // =========================================================================
    // CONNECTED CLIENTS (MAC-based, BUKAN PPPoE)
    // =========================================================================

    /**
     * Ambil daftar klien aktif berdasarkan MAC address
     * (dari DHCP lease + ARP table + wireless registration)
     */
    public function getConnectedClients(): array
    {
        return $this->get('/api/clients/active');
    }

    /**
     * Putus koneksi klien berdasarkan MAC address
     */
    public function kickClientByMac(string $macAddress): bool
    {
        $mac = self::normalizeMac($macAddress);
        $res = $this->post("/api/clients/active/{$mac}/kick", []);
        return ($res['ok'] ?? $res['success'] ?? false) !== false;
    }
    // =========================================================================
    // PER-CLIENT DATA (by MAC Address)
    // =========================================================================

    /**
     * Ambil status uptime klien berdasarkan MAC
     */
    public function getClientUptime(string $macAddress): array
    {
        $mac = self::normalizeMac($macAddress);
        return $this->get("/api/clients/{$mac}/uptime");
    }

    /**
     * Ambil bandwidth real-time klien berdasarkan MAC
     */
    public function getClientBandwidth(string $macAddress): array
    {
        $mac = self::normalizeMac($macAddress);
        return $this->get("/api/clients/{$mac}/bandwidth");
    }

    /**
     * Ambil penggunaan bandwidth hari ini (per jam)
     */
    public function getClientUsageToday(string $macAddress): array
    {
        $mac = self::normalizeMac($macAddress);
        return $this->get("/api/clients/{$mac}/usage/today");
    }

    /**
     * Ambil penggunaan bandwidth bulan ini (per hari)
     */
    public function getClientUsageMonth(string $macAddress): array
    {
        $mac = self::normalizeMac($macAddress);
        return $this->get("/api/clients/{$mac}/usage/month");
    }
        /**
     * GET /api/system/info
     */
    public function getSystemInfo(): array
    {
        return $this->get('/api/system/info');
    }

    /**
     * GET /api/system/identity
     */
    public function getSystemIdentity(): array
    {
        return $this->get('/api/system/identity');
    }

    /**
     * GET /api/interfaces
     */
    public function getInterfaces(): array
    {
        return $this->get('/api/interfaces');
    }
/**
 * Ambil ringkasan bandwidth 12 bulan semua client
 */
public function getMonthlyUsageAll(int $months = 12): array
{
    $response = $this->request('GET', "/api/usage/monthly-all?months={$months}");
    return $response;
}

/**
 * Ambil bandwidth 12 bulan per client
 */
public function getMonthlyUsageClient(string $mac, int $months = 12): array
{
    $mac = strtoupper($mac);
    $response = $this->request('GET', "/api/usage/monthly/{$mac}?months={$months}");
    return $response;
}

/**
 * Ambil bandwidth realtime total
 */
public function getRealtimeUsage(): array
{
    $response = $this->request('GET', '/api/usage/realtime');
    return $response;
}


}
