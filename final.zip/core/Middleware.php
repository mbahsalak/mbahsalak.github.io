<?php
/**
 * core/Middleware.php
 * Base Middleware Abstract Class + CSRF Helper
 * PHP 8.4 Native Semi-Framework
 *
 * CATATAN PSR-4: File ini HANYA berisi abstract class Middleware.
 * Setiap middleware konkret ada di file sendiri:
 *   core/AuthMiddleware.php   -> Core\AuthMiddleware
 *   core/GuestMiddleware.php  -> Core\GuestMiddleware
 *   core/RoleMiddleware.php   -> Core\RoleMiddleware
 */

declare(strict_types=1);

namespace Core;

abstract class Middleware
{
    /**
     * Entry point middleware — wajib di-override subclass
     */
    abstract public function handle(): void;

    /**
     * Generate CSRF token ke session, kembalikan sebagai string
     */
    public static function generateCsrfToken(): string
    {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    /**
     * Validasi CSRF token dari POST request
     * Support: field 'csrf_token' di form ATAU header 'X-CSRF-TOKEN' untuk AJAX
     */
    public static function validateCsrfToken(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }

        $submitted = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        $stored    = $_SESSION['csrf_token'] ?? '';

        if (empty($submitted) || !hash_equals($stored, $submitted)) {
            http_response_code(403);
            die('Akses ditolak: Validasi CSRF Token gagal. Silakan muat ulang halaman.');
        }
    }

    /**
     * Helper redirect — tersedia untuk semua subclass
     */
    protected static function redirectTo(string $url): never
    {
        header('Location: ' . $url);
        exit;
    }
}
