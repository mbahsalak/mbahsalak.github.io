<?php
/**
 * core/AuthMiddleware.php
 * Wajib login — redirect ke /login jika session tidak aktif
 * Otomatis validasi CSRF pada setiap POST request
 */

declare(strict_types=1);

namespace Core;

class AuthMiddleware extends Middleware
{
    public function handle(): void
    {
        if (!Auth::check()) {
            self::redirectTo(($_ENV['APP_URL'] ?? '') . '/login');
        }

        // Validasi CSRF untuk semua POST yang sudah login
        self::validateCsrfToken();
    }
}
