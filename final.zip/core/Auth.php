<?php
/**
 * core/Auth.php
 * Authentication & Role-Based Access Control (RBAC) System
 * PHP 8.4 Native Semi-Framework
 */

declare(strict_types=1);

namespace Core;

class Auth
{
    /**
     * Ambil data session user yang sedang aktif login
     */
    public static function user(): ?array
    {
        return $_SESSION['user'] ?? null;
    }

    /**
     * Cek apakah user sudah login (berdasarkan session key 'user.id')
     */
    public static function check(): bool
    {
        return isset($_SESSION['user']['id']);
    }

    /**
     * Cek hak akses role user (RBAC Guard)
     * Menerima satu role (string) atau beberapa role (array)
     */
    public static function hasRole(array|string $roles): bool
    {
        if (!self::check()) {
            return false;
        }

        $userRole = $_SESSION['user']['role'] ?? '';

        return is_array($roles)
            ? in_array($userRole, $roles, strict: true)
            : $userRole === $roles;
    }

    /**
     * Guard ketat berbasis role — langsung abort 403 jika tidak punya akses
     * Panggil di awal method controller yang perlu dibatasi
     */
    public static function roleGuard(array|string $allowedRoles): void
    {
        if (!self::hasRole($allowedRoles)) {
            http_response_code(403);
            $errorPage = APP_ROOT . '/views/pages/errors/403.php';
            file_exists($errorPage)
                ? include $errorPage
                : die('<h1>403 Forbidden</h1><p>Anda tidak memiliki izin untuk mengakses halaman ini.</p>');
            exit;
        }
    }

    /**
     * Dapatkan role user yang sedang login
     */
    public static function role(): ?string
    {
        return $_SESSION['user']['role'] ?? null;
    }

    /**
     * Dapatkan ID user yang sedang login
     */
    public static function id(): ?int
    {
        return isset($_SESSION['user']['id'])
            ? (int) $_SESSION['user']['id']
            : null;
    }

    /**
     * Hash password menggunakan BCRYPT (cost 12 untuk PHP 8.4)
     */
    public static function hashPassword(string $password): string
    {
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }

    /**
     * Verifikasi password plaintext terhadap hash di database
     */
    public static function verifyPassword(string $password, string $hash): bool
    {
        return password_verify($password, $hash);
    }

    /**
     * Hapus session sepenuhnya dan invalidasi cookie (Logout aman)
     */
    public static function logout(): void
    {
        // Kosongkan array session
        $_SESSION = [];

        // Hapus cookie session dari browser
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }

        session_destroy();
    }

    /**
     * Login manual: simpan data user ke session
     * Dipanggil dari AuthController setelah verifikasi berhasil
     */
        /**
     * Login manual: simpan data user ke session
     * Dipanggil dari AuthController setelah verifikasi berhasil
     */
    public static function loginSession(array $user): void
    {
        // --- Tambahkan Blok Ini ---
        // Pastikan session belum dimulai
        if (session_status() === PHP_SESSION_NONE) {
            // Atur konfigurasi session untuk bertahan 2 jam
            session_set_cookie_params([
                'lifetime' => 7200, // 2 jam dalam detik
                'path' => '/',      // Sesuaikan jika aplikasi Anda tidak di root
                'domain' => '',     // Biarkan kosong untuk domain saat ini
                'secure' => false,  // Ubah ke true jika pakai HTTPS
                'httponly' => true, // Lebih aman
                'samesite' => 'Lax' // Proteksi CSRF
            ]);
            session_start();
        }
        // --- Akhir Blok Tambahan ---

        // Regenerasi session ID untuk mencegah session fixation attack
        session_regenerate_id(delete_old_session: true);

// Contoh di AuthController saat login berhasil
$_SESSION['user'] = [
    'id' => $user['id'],
    'username' => $user['username'],
    'role' => $user['role'],        // ← HARUS ADA!
    'nama_lengkap' => $user['nama_lengkap'] ?? $user['username']
];
    }

}
