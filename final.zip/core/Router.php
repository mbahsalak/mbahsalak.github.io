<?php
/**
 * core/Router.php
 * HTTP Router — Routing, Middleware Pipeline, Named Parameters
 * PHP 8.4 Native Semi-Framework
 */

declare(strict_types=1);

namespace Core;

class Router
{
    /** @var array<int, array{method:string, pattern:string, paramNames:list<string>, handler:array{0:class-string,1:string}, middleware:list<string>}> */
    private array $routes = [];

    /** Prefix aktif saat menggunakan group() */
    private string $groupPrefix = '';

    /** Middleware aktif saat menggunakan group() */
    private array $groupMiddleware = [];

    // -------------------------------------------------------------------------
    // Pendaftaran Rute
    // -------------------------------------------------------------------------

    public function get(string $path, array $handler, array $middlewares = []): void
    {
        $this->addRoute('GET', $path, $handler, $middlewares);
    }

    public function post(string $path, array $handler, array $middlewares = []): void
    {
        $this->addRoute('POST', $path, $handler, $middlewares);
    }

    public function put(string $path, array $handler, array $middlewares = []): void
    {
        $this->addRoute('PUT', $path, $handler, $middlewares);
    }

    public function delete(string $path, array $handler, array $middlewares = []): void
    {
        $this->addRoute('DELETE', $path, $handler, $middlewares);
    }

    /**
     * Grup rute dengan prefix URL dan/atau middleware bersama
     * 
     * Contoh:
     *   $router->group('/pelanggan', [AuthMiddleware::class], function($r) {
     *       $r->get('/', [...]);
     *       $r->get('/{id}', [...]);
     *   });
     */
    public function group(string $prefix, array $middlewares, callable $callback): void
    {
        $prevPrefix     = $this->groupPrefix;
        $prevMiddleware = $this->groupMiddleware;

        $this->groupPrefix     = $prevPrefix . $prefix;
        $this->groupMiddleware = array_merge($prevMiddleware, $middlewares);

        $callback($this);

        // Kembalikan state group ke sebelumnya (mendukung nested group)
        $this->groupPrefix     = $prevPrefix;
        $this->groupMiddleware = $prevMiddleware;
    }

    // -------------------------------------------------------------------------
    // Internal: Simpan Rute
    // -------------------------------------------------------------------------

    private function addRoute(string $method, string $path, array $handler, array $middlewares): void
    {
        $fullPath   = $this->groupPrefix . $path;
        $allMiddleware = array_merge($this->groupMiddleware, $middlewares);

        // Ekstrak nama parameter dari path: /pelanggan/{id} => ['id']
        preg_match_all('/\{([a-zA-Z0-9_]+)\}/', $fullPath, $paramMatches);
        $paramNames = $paramMatches[1];

        // Konversi path ke regex: {id} => ([^/]+)
        $pattern = '#^' . preg_replace('/\{[a-zA-Z0-9_]+\}/', '([^/]+)', $fullPath) . '$#';

        $this->routes[] = [
            'method'     => strtoupper($method),
            'pattern'    => $pattern,
            'paramNames' => $paramNames,
            'handler'    => $handler,
            'middleware' => $allMiddleware,
        ];
    }

    // -------------------------------------------------------------------------
    // Eksekusi: Cocokkan URL dan Jalankan
    // -------------------------------------------------------------------------

    public function resolve(): void
    {
        $uri    = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $uri    = '/' . trim($uri ?? '/', '/');
        // Normalisasi: root path tetap '/'
        if ($uri !== '/') {
            $uri = rtrim($uri, '/');
        }

        $method = strtoupper($_SERVER['REQUEST_METHOD']);

        // Dukung method spoofing via hidden field _method (PUT, DELETE dari form HTML)
        if ($method === 'POST' && isset($_POST['_method'])) {
            $method = strtoupper($_POST['_method']);
        }

        foreach ($this->routes as $route) {
            if ($route['method'] !== $method) {
                continue;
            }

            if (!preg_match($route['pattern'], $uri, $matches)) {
                continue;
            }

            // Hapus full-match pertama, ambil hanya capture groups
            array_shift($matches);

            // Buat array asosiatif parameter: ['id' => '42']
            $params = array_combine($route['paramNames'], $matches) ?: [];

            // --- 1. Jalankan Middleware Pipeline ---
            $this->runMiddleware($route['middleware']);

            // --- 2. Dispatch ke Controller ---
            [$controllerClass, $methodName] = $route['handler'];
            $this->dispatch($controllerClass, $methodName, $params);
            return;
        }

        // Tidak ada rute yang cocok — kirim 404
        $this->handleNotFound();
    }

    // -------------------------------------------------------------------------
    // Helpers Private
    // -------------------------------------------------------------------------

    /**
     * Jalankan middleware satu per satu secara berurutan
     * Mendukung class string atau 'ClassName:arg1,arg2' untuk middleware berparameter
     */
    private function runMiddleware(array $middlewareList): void
    {
        foreach ($middlewareList as $middlewareEntry) {
            // Dukungan format 'RoleMiddleware:admin,kasir'
            if (str_contains($middlewareEntry, ':')) {
                [$class, $args] = explode(':', $middlewareEntry, 2);
                $roles = explode(',', $args);
            } else {
                $class = $middlewareEntry;
                $roles = [];
            }

            if (!class_exists($class)) {
                throw new \RuntimeException("Middleware [{$class}] tidak ditemukan.");
            }

            $instance = empty($roles) ? new $class() : new $class($roles);

            if (!($instance instanceof Middleware)) {
                throw new \RuntimeException("Middleware [{$class}] harus extends Core\\Middleware.");
            }

            $instance->handle();
        }
    }

    /**
     * Dispatch ke controller method dengan named parameters
     */
    private function dispatch(string $controllerClass, string $methodName, array $params): void
    {
        if (!class_exists($controllerClass)) {
            throw new \RuntimeException("Controller [{$controllerClass}] tidak ditemukan.");
        }

        $controller = new $controllerClass();

        if (!method_exists($controller, $methodName)) {
            throw new \RuntimeException("Method [{$methodName}] tidak ditemukan di [{$controllerClass}].");
        }

        // Inject parameter secara posisional menggunakan values dari named params
        $controller->$methodName(...array_values($params));
    }

    /**
     * Handle 404 Not Found
     */
    private function handleNotFound(): void
    {
        http_response_code(404);
        $errorPage = defined('APP_ROOT') ? APP_ROOT . '/views/pages/errors/404.php' : null;

        if ($errorPage && file_exists($errorPage)) {
            include $errorPage;
        } else {
            echo '<h1>404 - Halaman Tidak Ditemukan</h1>';
            echo '<p>URL yang Anda akses tidak tersedia.</p>';
        }
    }
}
