<?php

declare(strict_types=1);

namespace Core;

use PDO;
use PDOException;
use PDOStatement;

/**
 * Database Singleton Class
 * ============================================================
 * Menyediakan satu koneksi PDO yang digunakan di seluruh aplikasi.
 * 
 * Penggunaan:
 *   $db   = Database::getConnection();     // Mengembalikan PDO
 *   $stmt = $db->query("SELECT * FROM pelanggan");
 *   $rows = $stmt->fetchAll();
 *
 *   // Atau pakai helper:
 *   $row  = Database::fetchOne("SELECT * FROM pelanggan WHERE id = ?", [1]);
 *   $rows = Database::fetchAll("SELECT * FROM pelanggan");
 *   $id   = Database::insert("INSERT INTO kas (tipe, jumlah) VALUES (?, ?)", ['masuk', 50000]);
 * ============================================================
 */
class Database
{
    private static ?PDO $connection = null;
    private static ?self $instance = null;

    // -------------------------------------------------------------------------
    // Konfigurasi default
    // -------------------------------------------------------------------------
    private string $host;
    private string $port;
    private string $database;
    private string $username;
    private string $password;
    private string $charset;

    /**
     * Constructor private — tidak bisa di-new dari luar
     */
    private function __construct()
    {
        $this->host     = $_ENV['DB_HOST']     ?? '127.0.0.1';
        $this->port     = $_ENV['DB_PORT']     ?? '3306';
        $this->database = $_ENV['DB_DATABASE'] ?? 'billing_isp_db';
        $this->username = $_ENV['DB_USERNAME'] ?? 'root';
        $this->password = $_ENV['DB_PASSWORD'] ?? '';
        $this->charset  = $_ENV['DB_CHARSET']  ?? 'utf8mb4';
    }

    // =========================================================================
    // SINGLETON
    // =========================================================================

    /**
     * Dapatkan instance Database (internal)
     */
    private static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Dapatkan koneksi PDO (Singleton)
     * 
     * @return PDO
     * @throws \RuntimeException jika koneksi gagal
     */
    public static function getConnection(): PDO
    {
        if (self::$connection === null) {
            self::$connection = self::getInstance()->createConnection();
        }
        return self::$connection;
    }

    // =========================================================================
    // KONEKSI
    // =========================================================================

    /**
     * Buat koneksi PDO baru
     */
    private function createConnection(): PDO
    {
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=%s',
            $this->host,
            $this->port,
            $this->database,
            $this->charset
        );

        try {
            $pdo = new PDO($dsn, $this->username, $this->password, [
                // Error mode: lempar exception
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,

                // Fetch mode default: array asosiatif
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,

                // Gunakan native prepared statements (bukan emulasi)
                PDO::ATTR_EMULATE_PREPARES   => false,

                // Return integer sebagai int, bukan string
                PDO::ATTR_STRINGIFY_FETCHES  => false,

                // Set charset saat koneksi dibuat
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES {$this->charset} COLLATE {$this->charset}_unicode_ci",
            ]);

            // Log koneksi berhasil
            Logger::info('Database', "Connected to {$this->database}@{$this->host}:{$this->port}");

            return $pdo;

        } catch (PDOException $e) {
            Logger::error('Database', "Connection failed: {$e->getMessage()}");
            throw new \RuntimeException(
                "Gagal koneksi ke database: {$e->getMessage()}"
            );
        }
    }

    // =========================================================================
    // QUERY HELPERS — Shortcut agar tidak perlu prepare+execute manual
    // =========================================================================

    /**
     * Jalankan query SELECT dan kembalikan semua baris
     *
     * @param string $sql    Query SQL dengan placeholder (?)
     * @param array  $params Parameter untuk binding
     * @return array         Array of associative arrays
     *
     * Contoh:
     *   $rows = Database::fetchAll("SELECT * FROM pelanggan WHERE status = ?", ['active']);
     */
    public static function fetchAll(string $sql, array $params = []): array
    {
        $stmt = self::getConnection()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Jalankan query SELECT dan kembalikan SATU baris saja
     *
     * @param string $sql    Query SQL dengan placeholder (?)
     * @param array  $params Parameter untuk binding
     * @return array|null    Array asosiatif atau null jika tidak ditemukan
     *
     * Contoh:
     *   $user = Database::fetchOne("SELECT * FROM users WHERE id = ?", [1]);
     */
    public static function fetchOne(string $sql, array $params = []): ?array
    {
        $stmt = self::getConnection()->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result !== false ? $result : null;
    }

    /**
     * Jalankan query SELECT dan kembalikan satu kolom saja (scalar)
     *
     * @param string $sql    Query SQL
     * @param array  $params Parameter
     * @return mixed         Nilai kolom pertama, atau null
     *
     * Contoh:
     *   $count = Database::fetchColumn("SELECT COUNT(*) FROM pelanggan");
     */
    public static function fetchColumn(string $sql, array $params = []): mixed
    {
        $stmt = self::getConnection()->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetchColumn();
        return $result !== false ? $result : null;
    }

    /**
     * Jalankan INSERT dan kembalikan last insert ID
     *
     * @param string $sql    Query INSERT dengan placeholder (?)
     * @param array  $params Parameter untuk binding
     * @return string        Last insert ID
     *
     * Contoh:
     *   $id = Database::insert("INSERT INTO pelanggan (nama, alamat) VALUES (?, ?)", ['Budi', 'Jl. Merdeka']);
     */
    public static function insert(string $sql, array $params = []): string
    {
        $pdo  = self::getConnection();
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $pdo->lastInsertId();
    }

    /**
     * Jalankan UPDATE atau DELETE dan kembalikan jumlah baris yang terpengaruh
     *
     * @param string $sql    Query UPDATE/DELETE dengan placeholder (?)
     * @param array  $params Parameter untuk binding
     * @return int           Jumlah baris yang terpengaruh
     *
     * Contoh:
     *   $affected = Database::execute("UPDATE pelanggan SET status = ? WHERE id = ?", ['inactive', 5]);
     */
    public static function execute(string $sql, array $params = []): int
    {
        $stmt = self::getConnection()->prepare($sql);
        $stmt->execute($params);
        return $stmt->rowCount();
    }

    // =========================================================================
    // TRANSAKSI
    // =========================================================================

    /**
     * Mulai transaksi
     */
    public static function beginTransaction(): bool
    {
        return self::getConnection()->beginTransaction();
    }

    /**
     * Commit transaksi
     */
    public static function commit(): bool
    {
        return self::getConnection()->commit();
    }

    /**
     * Rollback transaksi
     */
    public static function rollBack(): bool
    {
        return self::getConnection()->rollBack();
    }

    /**
     * Jalankan callback di dalam transaksi
     * Otomatis commit jika sukses, rollback jika exception
     *
     * @param callable $callback Fungsi yang menerima PDO sebagai parameter
     * @return mixed Hasil dari callback
     *
     * Contoh:
     *   Database::transaction(function($pdo) {
     *       $pdo->prepare("INSERT INTO kas ...")->execute([...]);
     *       $pdo->prepare("UPDATE tagihan ...")->execute([...]);
     *   });
     */
    public static function transaction(callable $callback): mixed
    {
        $pdo = self::getConnection();

        try {
            $pdo->beginTransaction();
            $result = $callback($pdo);
            $pdo->commit();
            return $result;
        } catch (\Throwable $e) {
            $pdo->rollBack();
            Logger::error('Database', "Transaction failed: {$e->getMessage()}");
            throw $e;
        }
    }

    // =========================================================================
    // UTILITAS
    // =========================================================================

    /**
     * Cek apakah tabel ada di database
     */
    public static function tableExists(string $tableName): bool
    {
        $stmt = self::getConnection()->prepare(
            "SELECT COUNT(*) FROM information_schema.tables 
             WHERE table_schema = DATABASE() AND table_name = ?"
        );
        $stmt->execute([$tableName]);
        return (int) $stmt->fetchColumn() > 0;
    }

    /**
     * Dapatkan daftar kolom dari sebuah tabel
     *
     * @return array Daftar nama kolom
     */
    public static function getColumns(string $tableName): array
    {
        $stmt = self::getConnection()->prepare(
            "SELECT COLUMN_NAME FROM information_schema.columns 
             WHERE table_schema = DATABASE() AND table_name = ? 
             ORDER BY ORDINAL_POSITION"
        );
        $stmt->execute([$tableName]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    /**
     * Hitung jumlah baris di tabel
     */
    public static function count(string $tableName, string $where = '1=1', array $params = []): int
    {
        $sql  = "SELECT COUNT(*) FROM `{$tableName}` WHERE {$where}";
        $stmt = self::getConnection()->prepare($sql);
        $stmt->execute($params);
        return (int) $stmt->fetchColumn();
    }

    /**
     * Reset koneksi (misalnya setelah fork atau long-running process)
     */
    public static function resetConnection(): void
    {
        self::$connection = null;
        self::$instance   = null;
    }

    // =========================================================================
    // PENCEGAHAN DUPLIKASI
    // =========================================================================

    /**
     * Cegah cloning
     */
    private function __clone()
    {
        throw new \RuntimeException('Database singleton cannot be cloned');
    }

    /**
     * Cegah unserialization
     */
    public function __wakeup()
    {
        throw new \RuntimeException('Database singleton cannot be unserialized');
    }

    /**
     * Cegah serialization
     */
    public function __sleep(): array
    {
        throw new \RuntimeException('Database singleton cannot be serialized');
    }
}
