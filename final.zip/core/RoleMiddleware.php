<?php
/**
 * core/RoleMiddleware.php
 * Guard berbasis role RBAC
 *
 * Cara pakai di web.php (format string dengan parameter):
 *   'Core\RoleMiddleware:admin,kasir'
 *
 * Atau pakai Auth::roleGuard() langsung di dalam method controller.
 */

declare(strict_types=1);

namespace Core;

class RoleMiddleware extends Middleware
{
    public function __construct(private readonly array $allowedRoles) {}

    public function handle(): void
    {
        // Pastikan sudah login dulu
        if (!Auth::check()) {
            self::redirectTo(($_ENV['APP_URL'] ?? '') . '/login');
        }

        if (!Auth::hasRole($this->allowedRoles)) {
            http_response_code(403);
            $errorPage = defined('APP_ROOT') ? APP_ROOT . '/views/pages/errors/403.php' : null;

            if ($errorPage && file_exists($errorPage)) {
                include $errorPage;
            } else {
                echo '<h1>403 Forbidden</h1><p>Anda tidak memiliki akses ke halaman ini.</p>';
            }
            exit;
        }
    }
}
