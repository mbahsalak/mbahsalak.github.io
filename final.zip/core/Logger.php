<?php

declare(strict_types=1);

namespace Core;

class Logger
{
    private static ?string $logDir = null;

    private static function getLogDir(): string
    {
        if (self::$logDir === null) {
            self::$logDir = (defined('APP_ROOT') ? APP_ROOT : dirname(__DIR__)) . '/storage/logs';

            if (!is_dir(self::$logDir)) {
                mkdir(self::$logDir, 0755, true);
            }
        }

        return self::$logDir;
    }

    private static function write(string $level, string $channel, string $message): void
    {
        try {
            $logDir    = self::getLogDir();
            $logFile   = $logDir . '/' . date('Y-m-d') . '.log';
            $timestamp = date('Y-m-d H:i:s');
            $line      = "[{$timestamp}] [{$level}] [{$channel}] {$message}" . PHP_EOL;

            file_put_contents($logFile, $line, FILE_APPEND);
        } catch (\Throwable) {
            // Diam saja — logger tidak boleh menyebabkan error
        }
    }

    public static function info(string $channel, string $message): void
    {
        self::write('INFO', $channel, $message);
    }

    public static function warning(string $channel, string $message): void
    {
        self::write('WARNING', $channel, $message);
    }

    public static function error(string $channel, string $message): void
    {
        self::write('ERROR', $channel, $message);
    }

    public static function debug(string $channel, string $message): void
    {
        self::write('DEBUG', $channel, $message);
    }
}
