
### 6. `SETUP.md`
[span_25](start_span)[span_26](start_span)Dokumentasi langkah demi langkah cara mengonfigurasi dan menjalankan aplikasi dari nol pada server lokal atau VPS[span_25](end_span)[span_26](end_span).

```markdown
# Panduan Instalasi dan Setup Billing ISP

Ikuti instruksi di bawah ini untuk memasang aplikasi di lingkungan lokal atau server produksi Anda.

## Prasyarat Sistem
- **PHP**: Versi 8.4 ke atas.
- **Ekstensi PHP**: `pdo`, `pdo_mysql`, `openssl`, `session`, `json`.
- **Database**: MySQL versi 5.7+ atau MariaDB versi 10.3+.
- **Web Server**: Apache (dengan `mod_rewrite` aktif) atau Nginx.

---

## Langkah-Langkah Instalasi

### 1. Ekstrak Proyek
Letakkan folder proyek di direktori web server Anda (contoh: `htdocs/billing-isp` atau `/var/www/html/`).

### 2. Konfigurasi Database
1. Buka aplikasi manajemen database Anda (phpMyAdmin / Navicat / DBeaver).
2. Buat database baru dengan nama `billing_isp`.
3. Import file `database.sql` yang berada di root direktori proyek ini ke dalam database baru tersebut.

### 3. Setup Environment File
1. Salin atau ubah nama file `.env` di root folder.
2. Sesuaikan konfigurasi database dengan server Anda:
   ```ini
   DB_HOST=127.0.0.1
   DB_NAME=billing_isp
   DB_USER=root
   DB_PASS=isi_password_jika_ada