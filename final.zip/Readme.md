# Billing ISP - PHP 8.4 Native Semi Framework (MVC)

Aplikasi manajemen operasional dan sistem penagihan (*billing*) ISP (Internet Service Provider) yang dirancang menggunakan arsitektur MVC berbasis kode PHP 8.4 Native murni tanpa framework pihak ketiga berat.

## 🚀 Fitur Utama
- **Multi-Role RBAC Authentication**: Admin, Kasir, Teknisi, dan Pelanggan.
- **Billing Otomatis & Invoice**: Penghitungan billing bulanan terintegrasi cetak invoice (PDF Ready).
- **MikroTik RouterOS API Integrasi**: Otomatisasi blokir/isolir pelanggan menunggak langsung ke router.
- **Ticketing & Pelayanan**: Sistem manajemen komplain/gangguan jaringan terpusat bagi pelanggan.
- **Maps Integrasi**: Pemetaan titik koordinat lokasi pelanggan dan ODP (*Optical Distribution Pack*).
- **Kas & Akuntansi**: Pencatatan arus keuangan masuk dan keluar secara riil.
- **Audit Logging**: Rekam jejak seluruh aktivitas user demi keamanan sistem.

## 📂 Struktur Folder Utama
```text
Billing-isp/
├── config/       # Kredensial Database, Autoloader PSR-4, & Env Loader
├── core/         # Router Core Engine, Middleware Protection, & Auth System
├── controller/   # Logika Pengendali Data (Sub-folder sesuai modul kerja)
├── model/        # Query Builder & Interaksi Basis Data (Entity Model)
├── views/        # Layout Template & Tampilan Interface UI HTML/PHP
├── routes/       # Mapping URL Routing Aplikasi
├── storage/      # Penyimpanan Log Internal, Backup DB, & Berkas PDF Invoice
└── public/       # Folder Akses Publik (CSS, JS, & Media Assets)
